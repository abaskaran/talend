
package upi_process.ingestrecord_allrules_t_0_1;

import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.DataQuality;
import routines.Relational;
import routines.Mathematical;
import routines.DataQualityDependencies;
import routines.SQLike;
import routines.Numeric;
import routines.WordVertex;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringUtils;
import routines.StringHandling;
import routines.DQTechnical;
import routines.TalendDate;
import routines.DataMasking;
import routines.DqStringHandling;
import routines.Tree;
import routines.Member;
import routines.MemberUpis;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;
 




	//the import part of tJavaFlex_3
	//import java.util.List;


//import java.util.ArrayList;
import java.util.Map;


import routines.StringUtils;
import routines.Member;
import routines.MemberUpis;
import routines.Tree;
import routines.WordVertex;




@SuppressWarnings("unused")

/**
 * Job: IngestRecord_Allrules_T Purpose: <br>
 * Description:  <br>
 * @author 
 * @version 7.3.1.20200219_1130
 * @status 
 */
public class IngestRecord_Allrules_T implements TalendJob {

protected static void logIgnoredError(String message, Throwable cause) {
       System.err.println(message);
       if (cause != null) {
               cause.printStackTrace();
       }

}


	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}
	
	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	
	private final static String utf8Charset = "UTF-8";
	//contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String,String> propertyTypes = new java.util.HashMap<>();
		
		public PropertiesWithType(java.util.Properties properties){
			super(properties);
		}
		public PropertiesWithType(){
			super();
		}
		
		public void setContextType(String key, String type) {
			propertyTypes.put(key,type);
		}
	
		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}
	
	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();
	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties){
			super(properties);
		}
		public ContextProperties(){
			super();
		}

		public void synchronizeContext(){
			
			if(location != null){
				
					this.setProperty("location", location.toString());
				
			}
			
			if(stg_location != null){
				
					this.setProperty("stg_location", stg_location.toString());
				
			}
			
			if(fuzzymatch != null){
				
					this.setProperty("fuzzymatch", fuzzymatch.toString());
				
			}
			
		}

		public String location;
		public String getLocation(){
			return this.location;
		}
		
		public String stg_location;
		public String getStg_location(){
			return this.stg_location;
		}
		
public String fuzzymatch;
public String getFuzzymatch(){
	return this.fuzzymatch;
}
	}
	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.
	public ContextProperties getContext() {
		return this.context;
	}
	private final String jobVersion = "0.1";
	private final String jobName = "IngestRecord_Allrules_T";
	private final String projectName = "UPI_PROCESS";
	public Integer errorCode = null;
	private String currentComponent = "";
	
		private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
        private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();
	
		private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
		public  final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();
	

private RunStat runStat = new RunStat();

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";
	
	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(), new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	JobStructureCatcherUtils talendJobLog = new JobStructureCatcherUtils(jobName, "_npi9wOFoEeq29tKmgkFe1g", "0.1");
	org.talend.job.audit.JobAuditLogger auditLogger_talendJobLog = null;

private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

public String getExceptionStackTrace() {
	if ("failure".equals(this.getStatus())) {
		errorMessagePS.flush();
		return baos.toString();
	}
	return null;
}

private Exception exception;

public Exception getException() {
	if ("failure".equals(this.getStatus())) {
		return this.exception;
	}
	return null;
}

private class TalendException extends Exception {

	private static final long serialVersionUID = 1L;

	private java.util.Map<String, Object> globalMap = null;
	private Exception e = null;
	private String currentComponent = null;
	private String virtualComponentName = null;
	
	public void setVirtualComponentName (String virtualComponentName){
		this.virtualComponentName = virtualComponentName;
	}

	private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
		this.currentComponent= errorComponent;
		this.globalMap = globalMap;
		this.e = e;
	}

	public Exception getException() {
		return this.e;
	}

	public String getCurrentComponent() {
		return this.currentComponent;
	}

	
    public String getExceptionCauseMessage(Exception e){
        Throwable cause = e;
        String message = null;
        int i = 10;
        while (null != cause && 0 < i--) {
            message = cause.getMessage();
            if (null == message) {
                cause = cause.getCause();
            } else {
                break;          
            }
        }
        if (null == message) {
            message = e.getClass().getName();
        }   
        return message;
    }

	@Override
	public void printStackTrace() {
		if (!(e instanceof TalendException || e instanceof TDieException)) {
			if(virtualComponentName!=null && currentComponent.indexOf(virtualComponentName+"_")==0){
				globalMap.put(virtualComponentName+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			}
			globalMap.put(currentComponent+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
		}
		if (!(e instanceof TDieException)) {
			if(e instanceof TalendException){
				e.printStackTrace();
			} else {
				e.printStackTrace();
				e.printStackTrace(errorMessagePS);
				IngestRecord_Allrules_T.this.exception = e;
			}
		}
		if (!(e instanceof TalendException)) {
		try {
			for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
				if (m.getName().compareTo(currentComponent + "_error") == 0) {
					m.invoke(IngestRecord_Allrules_T.this, new Object[] { e , currentComponent, globalMap});
					break;
				}
			}

			if(!(e instanceof TDieException)){
			}
		} catch (Exception e) {
			this.e.printStackTrace();
		}
		}
	}
}

			public void tFileInputDelimited_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tLogRow_7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileOutputDelimited_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileOutputDelimited_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputDelimited_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFlowToIterate_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputDelimited_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFilterRow_9_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJavaFlex_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tLogRow_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileOutputDelimited_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMatchGroup_1_GroupOut_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
							tMatchGroup_1_GroupIn_error(exception, errorComponent, globalMap);
						
						}
					
			public void tMatchGroup_1_GroupIn_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAggregateRow_2_AGGOUT_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
							tAggregateRow_2_AGGIN_error(exception, errorComponent, globalMap);
						
						}
					
			public void tAggregateRow_2_AGGIN_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSortRow_2_SortOut_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
							tSortRow_2_SortIn_error(exception, errorComponent, globalMap);
						
						}
					
			public void tSortRow_2_SortIn_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void talendJobLog_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					talendJobLog_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputDelimited_4_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileInputDelimited_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void talendJobLog_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}





	

	

public static class copyOfoutStruct implements routines.system.IPersistableRow<copyOfoutStruct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecord_Allrules_T = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T = new byte[0];

	
			    public String GID;

				public String getGID () {
					return this.GID;
				}
				
			    public Integer count;

				public Integer getCount () {
					return this.count;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecord_Allrules_T) {

        	try {

        		int length = 0;
		
					this.GID = readString(dis);
					
						this.count = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.GID,dos);
					
					// Integer
				
						writeInteger(this.count,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("GID="+GID);
		sb.append(",count="+String.valueOf(count));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(copyOfoutStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row22Struct implements routines.system.IPersistableRow<row22Struct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecord_Allrules_T = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T = new byte[0];

	
			    public String GID;

				public String getGID () {
					return this.GID;
				}
				
			    public Integer count;

				public Integer getCount () {
					return this.count;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecord_Allrules_T) {

        	try {

        		int length = 0;
		
					this.GID = readString(dis);
					
						this.count = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.GID,dos);
					
					// Integer
				
						writeInteger(this.count,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("GID="+GID);
		sb.append(",count="+String.valueOf(count));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row22Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class OnRowsEndStructtAggregateRow_2 implements routines.system.IPersistableRow<OnRowsEndStructtAggregateRow_2> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecord_Allrules_T = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T = new byte[0];

	
			    public String GID;

				public String getGID () {
					return this.GID;
				}
				
			    public Integer count;

				public Integer getCount () {
					return this.count;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecord_Allrules_T) {

        	try {

        		int length = 0;
		
					this.GID = readString(dis);
					
						this.count = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.GID,dos);
					
					// Integer
				
						writeInteger(this.count,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("GID="+GID);
		sb.append(",count="+String.valueOf(count));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(OnRowsEndStructtAggregateRow_2 other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row21Struct implements routines.system.IPersistableRow<row21Struct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecord_Allrules_T = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T = new byte[0];

	
			    public Character Gender;

				public Character getGender () {
					return this.Gender;
				}
				
			    public java.util.Date Date;

				public java.util.Date getDate () {
					return this.Date;
				}
				
			    public String First_Name;

				public String getFirst_Name () {
					return this.First_Name;
				}
				
			    public String Last_Name;

				public String getLast_Name () {
					return this.Last_Name;
				}
				
			    public String State;

				public String getState () {
					return this.State;
				}
				
			    public String City;

				public String getCity () {
					return this.City;
				}
				
			    public String Zip_Code;

				public String getZip_Code () {
					return this.Zip_Code;
				}
				
			    public String Address_Line_1;

				public String getAddress_Line_1 () {
					return this.Address_Line_1;
				}
				
			    public String Address_Line_2;

				public String getAddress_Line_2 () {
					return this.Address_Line_2;
				}
				
			    public String Phone_Number;

				public String getPhone_Number () {
					return this.Phone_Number;
				}
				
			    public String Social_Security_Number;

				public String getSocial_Security_Number () {
					return this.Social_Security_Number;
				}
				
			    public String UPI_ID;

				public String getUPI_ID () {
					return this.UPI_ID;
				}
				
			    public String MBI;

				public String getMBI () {
					return this.MBI;
				}
				
			    public String Client_ID;

				public String getClient_ID () {
					return this.Client_ID;
				}
				
			    public String Carrier_ID;

				public String getCarrier_ID () {
					return this.Carrier_ID;
				}
				
			    public String Account_ID;

				public String getAccount_ID () {
					return this.Account_ID;
				}
				
			    public String Group_ID;

				public String getGroup_ID () {
					return this.Group_ID;
				}
				
			    public String Contract_Family_ID;

				public String getContract_Family_ID () {
					return this.Contract_Family_ID;
				}
				
			    public String Multi_Birth_Code;

				public String getMulti_Birth_Code () {
					return this.Multi_Birth_Code;
				}
				
			    public String Member_Key;

				public String getMember_Key () {
					return this.Member_Key;
				}
				
			    public String Source;

				public String getSource () {
					return this.Source;
				}
				
			    public java.util.Date year;

				public java.util.Date getYear () {
					return this.year;
				}
				
			    public String GID;

				public String getGID () {
					return this.GID;
				}
				
			    public Integer GRP_SIZE;

				public Integer getGRP_SIZE () {
					return this.GRP_SIZE;
				}
				
			    public Boolean MASTER;

				public Boolean getMASTER () {
					return this.MASTER;
				}
				
			    public Double SCORE;

				public Double getSCORE () {
					return this.SCORE;
				}
				
			    public Double GRP_QUALITY;

				public Double getGRP_QUALITY () {
					return this.GRP_QUALITY;
				}
				
			    public String MATCHING_DISTANCES;

				public String getMATCHING_DISTANCES () {
					return this.MATCHING_DISTANCES;
				}
				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecord_Allrules_T) {

        	try {

        		int length = 0;
		
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.Gender = null;
           				} else {
           			    	this.Gender = dis.readChar();
           				}
					
					this.Date = readDate(dis);
					
					this.First_Name = readString(dis);
					
					this.Last_Name = readString(dis);
					
					this.State = readString(dis);
					
					this.City = readString(dis);
					
					this.Zip_Code = readString(dis);
					
					this.Address_Line_1 = readString(dis);
					
					this.Address_Line_2 = readString(dis);
					
					this.Phone_Number = readString(dis);
					
					this.Social_Security_Number = readString(dis);
					
					this.UPI_ID = readString(dis);
					
					this.MBI = readString(dis);
					
					this.Client_ID = readString(dis);
					
					this.Carrier_ID = readString(dis);
					
					this.Account_ID = readString(dis);
					
					this.Group_ID = readString(dis);
					
					this.Contract_Family_ID = readString(dis);
					
					this.Multi_Birth_Code = readString(dis);
					
					this.Member_Key = readString(dis);
					
					this.Source = readString(dis);
					
					this.year = readDate(dis);
					
					this.GID = readString(dis);
					
						this.GRP_SIZE = readInteger(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.MASTER = null;
           				} else {
           			    	this.MASTER = dis.readBoolean();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.SCORE = null;
           				} else {
           			    	this.SCORE = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.GRP_QUALITY = null;
           				} else {
           			    	this.GRP_QUALITY = dis.readDouble();
           				}
					
					this.MATCHING_DISTANCES = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Character
				
						if(this.Gender == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeChar(this.Gender);
		            	}
					
					// java.util.Date
				
						writeDate(this.Date,dos);
					
					// String
				
						writeString(this.First_Name,dos);
					
					// String
				
						writeString(this.Last_Name,dos);
					
					// String
				
						writeString(this.State,dos);
					
					// String
				
						writeString(this.City,dos);
					
					// String
				
						writeString(this.Zip_Code,dos);
					
					// String
				
						writeString(this.Address_Line_1,dos);
					
					// String
				
						writeString(this.Address_Line_2,dos);
					
					// String
				
						writeString(this.Phone_Number,dos);
					
					// String
				
						writeString(this.Social_Security_Number,dos);
					
					// String
				
						writeString(this.UPI_ID,dos);
					
					// String
				
						writeString(this.MBI,dos);
					
					// String
				
						writeString(this.Client_ID,dos);
					
					// String
				
						writeString(this.Carrier_ID,dos);
					
					// String
				
						writeString(this.Account_ID,dos);
					
					// String
				
						writeString(this.Group_ID,dos);
					
					// String
				
						writeString(this.Contract_Family_ID,dos);
					
					// String
				
						writeString(this.Multi_Birth_Code,dos);
					
					// String
				
						writeString(this.Member_Key,dos);
					
					// String
				
						writeString(this.Source,dos);
					
					// java.util.Date
				
						writeDate(this.year,dos);
					
					// String
				
						writeString(this.GID,dos);
					
					// Integer
				
						writeInteger(this.GRP_SIZE,dos);
					
					// Boolean
				
						if(this.MASTER == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeBoolean(this.MASTER);
		            	}
					
					// Double
				
						if(this.SCORE == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.SCORE);
		            	}
					
					// Double
				
						if(this.GRP_QUALITY == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.GRP_QUALITY);
		            	}
					
					// String
				
						writeString(this.MATCHING_DISTANCES,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Gender="+String.valueOf(Gender));
		sb.append(",Date="+String.valueOf(Date));
		sb.append(",First_Name="+First_Name);
		sb.append(",Last_Name="+Last_Name);
		sb.append(",State="+State);
		sb.append(",City="+City);
		sb.append(",Zip_Code="+Zip_Code);
		sb.append(",Address_Line_1="+Address_Line_1);
		sb.append(",Address_Line_2="+Address_Line_2);
		sb.append(",Phone_Number="+Phone_Number);
		sb.append(",Social_Security_Number="+Social_Security_Number);
		sb.append(",UPI_ID="+UPI_ID);
		sb.append(",MBI="+MBI);
		sb.append(",Client_ID="+Client_ID);
		sb.append(",Carrier_ID="+Carrier_ID);
		sb.append(",Account_ID="+Account_ID);
		sb.append(",Group_ID="+Group_ID);
		sb.append(",Contract_Family_ID="+Contract_Family_ID);
		sb.append(",Multi_Birth_Code="+Multi_Birth_Code);
		sb.append(",Member_Key="+Member_Key);
		sb.append(",Source="+Source);
		sb.append(",year="+String.valueOf(year));
		sb.append(",GID="+GID);
		sb.append(",GRP_SIZE="+String.valueOf(GRP_SIZE));
		sb.append(",MASTER="+String.valueOf(MASTER));
		sb.append(",SCORE="+String.valueOf(SCORE));
		sb.append(",GRP_QUALITY="+String.valueOf(GRP_QUALITY));
		sb.append(",MATCHING_DISTANCES="+MATCHING_DISTANCES);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row21Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row20Struct implements routines.system.IPersistableRow<row20Struct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecord_Allrules_T = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T = new byte[0];

	
			    public Character Gender;

				public Character getGender () {
					return this.Gender;
				}
				
			    public java.util.Date Date;

				public java.util.Date getDate () {
					return this.Date;
				}
				
			    public String First_Name;

				public String getFirst_Name () {
					return this.First_Name;
				}
				
			    public String Last_Name;

				public String getLast_Name () {
					return this.Last_Name;
				}
				
			    public String State;

				public String getState () {
					return this.State;
				}
				
			    public String City;

				public String getCity () {
					return this.City;
				}
				
			    public String Zip_Code;

				public String getZip_Code () {
					return this.Zip_Code;
				}
				
			    public String Address_Line_1;

				public String getAddress_Line_1 () {
					return this.Address_Line_1;
				}
				
			    public String Address_Line_2;

				public String getAddress_Line_2 () {
					return this.Address_Line_2;
				}
				
			    public String Phone_Number;

				public String getPhone_Number () {
					return this.Phone_Number;
				}
				
			    public String Social_Security_Number;

				public String getSocial_Security_Number () {
					return this.Social_Security_Number;
				}
				
			    public String UPI_ID;

				public String getUPI_ID () {
					return this.UPI_ID;
				}
				
			    public String MBI;

				public String getMBI () {
					return this.MBI;
				}
				
			    public String Client_ID;

				public String getClient_ID () {
					return this.Client_ID;
				}
				
			    public String Carrier_ID;

				public String getCarrier_ID () {
					return this.Carrier_ID;
				}
				
			    public String Account_ID;

				public String getAccount_ID () {
					return this.Account_ID;
				}
				
			    public String Group_ID;

				public String getGroup_ID () {
					return this.Group_ID;
				}
				
			    public String Contract_Family_ID;

				public String getContract_Family_ID () {
					return this.Contract_Family_ID;
				}
				
			    public String Multi_Birth_Code;

				public String getMulti_Birth_Code () {
					return this.Multi_Birth_Code;
				}
				
			    public String Member_Key;

				public String getMember_Key () {
					return this.Member_Key;
				}
				
			    public String Source;

				public String getSource () {
					return this.Source;
				}
				
			    public java.util.Date year;

				public java.util.Date getYear () {
					return this.year;
				}
				
			    public String GID;

				public String getGID () {
					return this.GID;
				}
				
			    public Integer GRP_SIZE;

				public Integer getGRP_SIZE () {
					return this.GRP_SIZE;
				}
				
			    public Boolean MASTER;

				public Boolean getMASTER () {
					return this.MASTER;
				}
				
			    public Double SCORE;

				public Double getSCORE () {
					return this.SCORE;
				}
				
			    public Double GRP_QUALITY;

				public Double getGRP_QUALITY () {
					return this.GRP_QUALITY;
				}
				
			    public String MATCHING_DISTANCES;

				public String getMATCHING_DISTANCES () {
					return this.MATCHING_DISTANCES;
				}
				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecord_Allrules_T) {

        	try {

        		int length = 0;
		
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.Gender = null;
           				} else {
           			    	this.Gender = dis.readChar();
           				}
					
					this.Date = readDate(dis);
					
					this.First_Name = readString(dis);
					
					this.Last_Name = readString(dis);
					
					this.State = readString(dis);
					
					this.City = readString(dis);
					
					this.Zip_Code = readString(dis);
					
					this.Address_Line_1 = readString(dis);
					
					this.Address_Line_2 = readString(dis);
					
					this.Phone_Number = readString(dis);
					
					this.Social_Security_Number = readString(dis);
					
					this.UPI_ID = readString(dis);
					
					this.MBI = readString(dis);
					
					this.Client_ID = readString(dis);
					
					this.Carrier_ID = readString(dis);
					
					this.Account_ID = readString(dis);
					
					this.Group_ID = readString(dis);
					
					this.Contract_Family_ID = readString(dis);
					
					this.Multi_Birth_Code = readString(dis);
					
					this.Member_Key = readString(dis);
					
					this.Source = readString(dis);
					
					this.year = readDate(dis);
					
					this.GID = readString(dis);
					
						this.GRP_SIZE = readInteger(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.MASTER = null;
           				} else {
           			    	this.MASTER = dis.readBoolean();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.SCORE = null;
           				} else {
           			    	this.SCORE = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.GRP_QUALITY = null;
           				} else {
           			    	this.GRP_QUALITY = dis.readDouble();
           				}
					
					this.MATCHING_DISTANCES = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Character
				
						if(this.Gender == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeChar(this.Gender);
		            	}
					
					// java.util.Date
				
						writeDate(this.Date,dos);
					
					// String
				
						writeString(this.First_Name,dos);
					
					// String
				
						writeString(this.Last_Name,dos);
					
					// String
				
						writeString(this.State,dos);
					
					// String
				
						writeString(this.City,dos);
					
					// String
				
						writeString(this.Zip_Code,dos);
					
					// String
				
						writeString(this.Address_Line_1,dos);
					
					// String
				
						writeString(this.Address_Line_2,dos);
					
					// String
				
						writeString(this.Phone_Number,dos);
					
					// String
				
						writeString(this.Social_Security_Number,dos);
					
					// String
				
						writeString(this.UPI_ID,dos);
					
					// String
				
						writeString(this.MBI,dos);
					
					// String
				
						writeString(this.Client_ID,dos);
					
					// String
				
						writeString(this.Carrier_ID,dos);
					
					// String
				
						writeString(this.Account_ID,dos);
					
					// String
				
						writeString(this.Group_ID,dos);
					
					// String
				
						writeString(this.Contract_Family_ID,dos);
					
					// String
				
						writeString(this.Multi_Birth_Code,dos);
					
					// String
				
						writeString(this.Member_Key,dos);
					
					// String
				
						writeString(this.Source,dos);
					
					// java.util.Date
				
						writeDate(this.year,dos);
					
					// String
				
						writeString(this.GID,dos);
					
					// Integer
				
						writeInteger(this.GRP_SIZE,dos);
					
					// Boolean
				
						if(this.MASTER == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeBoolean(this.MASTER);
		            	}
					
					// Double
				
						if(this.SCORE == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.SCORE);
		            	}
					
					// Double
				
						if(this.GRP_QUALITY == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.GRP_QUALITY);
		            	}
					
					// String
				
						writeString(this.MATCHING_DISTANCES,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Gender="+String.valueOf(Gender));
		sb.append(",Date="+String.valueOf(Date));
		sb.append(",First_Name="+First_Name);
		sb.append(",Last_Name="+Last_Name);
		sb.append(",State="+State);
		sb.append(",City="+City);
		sb.append(",Zip_Code="+Zip_Code);
		sb.append(",Address_Line_1="+Address_Line_1);
		sb.append(",Address_Line_2="+Address_Line_2);
		sb.append(",Phone_Number="+Phone_Number);
		sb.append(",Social_Security_Number="+Social_Security_Number);
		sb.append(",UPI_ID="+UPI_ID);
		sb.append(",MBI="+MBI);
		sb.append(",Client_ID="+Client_ID);
		sb.append(",Carrier_ID="+Carrier_ID);
		sb.append(",Account_ID="+Account_ID);
		sb.append(",Group_ID="+Group_ID);
		sb.append(",Contract_Family_ID="+Contract_Family_ID);
		sb.append(",Multi_Birth_Code="+Multi_Birth_Code);
		sb.append(",Member_Key="+Member_Key);
		sb.append(",Source="+Source);
		sb.append(",year="+String.valueOf(year));
		sb.append(",GID="+GID);
		sb.append(",GRP_SIZE="+String.valueOf(GRP_SIZE));
		sb.append(",MASTER="+String.valueOf(MASTER));
		sb.append(",SCORE="+String.valueOf(SCORE));
		sb.append(",GRP_QUALITY="+String.valueOf(GRP_QUALITY));
		sb.append(",MATCHING_DISTANCES="+MATCHING_DISTANCES);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row20Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row19Struct implements routines.system.IPersistableRow<row19Struct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecord_Allrules_T = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T = new byte[0];

	
			    public Character Gender;

				public Character getGender () {
					return this.Gender;
				}
				
			    public java.util.Date Date;

				public java.util.Date getDate () {
					return this.Date;
				}
				
			    public String First_Name;

				public String getFirst_Name () {
					return this.First_Name;
				}
				
			    public String Last_Name;

				public String getLast_Name () {
					return this.Last_Name;
				}
				
			    public String State;

				public String getState () {
					return this.State;
				}
				
			    public String City;

				public String getCity () {
					return this.City;
				}
				
			    public String Zip_Code;

				public String getZip_Code () {
					return this.Zip_Code;
				}
				
			    public String Address_Line_1;

				public String getAddress_Line_1 () {
					return this.Address_Line_1;
				}
				
			    public String Address_Line_2;

				public String getAddress_Line_2 () {
					return this.Address_Line_2;
				}
				
			    public String Phone_Number;

				public String getPhone_Number () {
					return this.Phone_Number;
				}
				
			    public String Social_Security_Number;

				public String getSocial_Security_Number () {
					return this.Social_Security_Number;
				}
				
			    public String UPI_ID;

				public String getUPI_ID () {
					return this.UPI_ID;
				}
				
			    public String MBI;

				public String getMBI () {
					return this.MBI;
				}
				
			    public String Client_ID;

				public String getClient_ID () {
					return this.Client_ID;
				}
				
			    public String Carrier_ID;

				public String getCarrier_ID () {
					return this.Carrier_ID;
				}
				
			    public String Account_ID;

				public String getAccount_ID () {
					return this.Account_ID;
				}
				
			    public String Group_ID;

				public String getGroup_ID () {
					return this.Group_ID;
				}
				
			    public String Contract_Family_ID;

				public String getContract_Family_ID () {
					return this.Contract_Family_ID;
				}
				
			    public String Multi_Birth_Code;

				public String getMulti_Birth_Code () {
					return this.Multi_Birth_Code;
				}
				
			    public String Member_Key;

				public String getMember_Key () {
					return this.Member_Key;
				}
				
			    public String Source;

				public String getSource () {
					return this.Source;
				}
				
			    public java.util.Date year;

				public java.util.Date getYear () {
					return this.year;
				}
				
			    public String GID;

				public String getGID () {
					return this.GID;
				}
				
			    public Integer GRP_SIZE;

				public Integer getGRP_SIZE () {
					return this.GRP_SIZE;
				}
				
			    public Boolean MASTER;

				public Boolean getMASTER () {
					return this.MASTER;
				}
				
			    public Double SCORE;

				public Double getSCORE () {
					return this.SCORE;
				}
				
			    public Double GRP_QUALITY;

				public Double getGRP_QUALITY () {
					return this.GRP_QUALITY;
				}
				
			    public String MATCHING_DISTANCES;

				public String getMATCHING_DISTANCES () {
					return this.MATCHING_DISTANCES;
				}
				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecord_Allrules_T) {

        	try {

        		int length = 0;
		
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.Gender = null;
           				} else {
           			    	this.Gender = dis.readChar();
           				}
					
					this.Date = readDate(dis);
					
					this.First_Name = readString(dis);
					
					this.Last_Name = readString(dis);
					
					this.State = readString(dis);
					
					this.City = readString(dis);
					
					this.Zip_Code = readString(dis);
					
					this.Address_Line_1 = readString(dis);
					
					this.Address_Line_2 = readString(dis);
					
					this.Phone_Number = readString(dis);
					
					this.Social_Security_Number = readString(dis);
					
					this.UPI_ID = readString(dis);
					
					this.MBI = readString(dis);
					
					this.Client_ID = readString(dis);
					
					this.Carrier_ID = readString(dis);
					
					this.Account_ID = readString(dis);
					
					this.Group_ID = readString(dis);
					
					this.Contract_Family_ID = readString(dis);
					
					this.Multi_Birth_Code = readString(dis);
					
					this.Member_Key = readString(dis);
					
					this.Source = readString(dis);
					
					this.year = readDate(dis);
					
					this.GID = readString(dis);
					
						this.GRP_SIZE = readInteger(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.MASTER = null;
           				} else {
           			    	this.MASTER = dis.readBoolean();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.SCORE = null;
           				} else {
           			    	this.SCORE = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.GRP_QUALITY = null;
           				} else {
           			    	this.GRP_QUALITY = dis.readDouble();
           				}
					
					this.MATCHING_DISTANCES = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Character
				
						if(this.Gender == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeChar(this.Gender);
		            	}
					
					// java.util.Date
				
						writeDate(this.Date,dos);
					
					// String
				
						writeString(this.First_Name,dos);
					
					// String
				
						writeString(this.Last_Name,dos);
					
					// String
				
						writeString(this.State,dos);
					
					// String
				
						writeString(this.City,dos);
					
					// String
				
						writeString(this.Zip_Code,dos);
					
					// String
				
						writeString(this.Address_Line_1,dos);
					
					// String
				
						writeString(this.Address_Line_2,dos);
					
					// String
				
						writeString(this.Phone_Number,dos);
					
					// String
				
						writeString(this.Social_Security_Number,dos);
					
					// String
				
						writeString(this.UPI_ID,dos);
					
					// String
				
						writeString(this.MBI,dos);
					
					// String
				
						writeString(this.Client_ID,dos);
					
					// String
				
						writeString(this.Carrier_ID,dos);
					
					// String
				
						writeString(this.Account_ID,dos);
					
					// String
				
						writeString(this.Group_ID,dos);
					
					// String
				
						writeString(this.Contract_Family_ID,dos);
					
					// String
				
						writeString(this.Multi_Birth_Code,dos);
					
					// String
				
						writeString(this.Member_Key,dos);
					
					// String
				
						writeString(this.Source,dos);
					
					// java.util.Date
				
						writeDate(this.year,dos);
					
					// String
				
						writeString(this.GID,dos);
					
					// Integer
				
						writeInteger(this.GRP_SIZE,dos);
					
					// Boolean
				
						if(this.MASTER == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeBoolean(this.MASTER);
		            	}
					
					// Double
				
						if(this.SCORE == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.SCORE);
		            	}
					
					// Double
				
						if(this.GRP_QUALITY == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.GRP_QUALITY);
		            	}
					
					// String
				
						writeString(this.MATCHING_DISTANCES,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Gender="+String.valueOf(Gender));
		sb.append(",Date="+String.valueOf(Date));
		sb.append(",First_Name="+First_Name);
		sb.append(",Last_Name="+Last_Name);
		sb.append(",State="+State);
		sb.append(",City="+City);
		sb.append(",Zip_Code="+Zip_Code);
		sb.append(",Address_Line_1="+Address_Line_1);
		sb.append(",Address_Line_2="+Address_Line_2);
		sb.append(",Phone_Number="+Phone_Number);
		sb.append(",Social_Security_Number="+Social_Security_Number);
		sb.append(",UPI_ID="+UPI_ID);
		sb.append(",MBI="+MBI);
		sb.append(",Client_ID="+Client_ID);
		sb.append(",Carrier_ID="+Carrier_ID);
		sb.append(",Account_ID="+Account_ID);
		sb.append(",Group_ID="+Group_ID);
		sb.append(",Contract_Family_ID="+Contract_Family_ID);
		sb.append(",Multi_Birth_Code="+Multi_Birth_Code);
		sb.append(",Member_Key="+Member_Key);
		sb.append(",Source="+Source);
		sb.append(",year="+String.valueOf(year));
		sb.append(",GID="+GID);
		sb.append(",GRP_SIZE="+String.valueOf(GRP_SIZE));
		sb.append(",MASTER="+String.valueOf(MASTER));
		sb.append(",SCORE="+String.valueOf(SCORE));
		sb.append(",GRP_QUALITY="+String.valueOf(GRP_QUALITY));
		sb.append(",MATCHING_DISTANCES="+MATCHING_DISTANCES);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row19Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class copyOfdobStruct implements routines.system.IPersistableRow<copyOfdobStruct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecord_Allrules_T = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T = new byte[0];

	
			    public Character Gender;

				public Character getGender () {
					return this.Gender;
				}
				
			    public java.util.Date Date;

				public java.util.Date getDate () {
					return this.Date;
				}
				
			    public String First_Name;

				public String getFirst_Name () {
					return this.First_Name;
				}
				
			    public String Last_Name;

				public String getLast_Name () {
					return this.Last_Name;
				}
				
			    public String State;

				public String getState () {
					return this.State;
				}
				
			    public String City;

				public String getCity () {
					return this.City;
				}
				
			    public String Zip_Code;

				public String getZip_Code () {
					return this.Zip_Code;
				}
				
			    public String Address_Line_1;

				public String getAddress_Line_1 () {
					return this.Address_Line_1;
				}
				
			    public String Address_Line_2;

				public String getAddress_Line_2 () {
					return this.Address_Line_2;
				}
				
			    public String Phone_Number;

				public String getPhone_Number () {
					return this.Phone_Number;
				}
				
			    public String Social_Security_Number;

				public String getSocial_Security_Number () {
					return this.Social_Security_Number;
				}
				
			    public String UPI_ID;

				public String getUPI_ID () {
					return this.UPI_ID;
				}
				
			    public String MBI;

				public String getMBI () {
					return this.MBI;
				}
				
			    public String Client_ID;

				public String getClient_ID () {
					return this.Client_ID;
				}
				
			    public String Carrier_ID;

				public String getCarrier_ID () {
					return this.Carrier_ID;
				}
				
			    public String Account_ID;

				public String getAccount_ID () {
					return this.Account_ID;
				}
				
			    public String Group_ID;

				public String getGroup_ID () {
					return this.Group_ID;
				}
				
			    public String Contract_Family_ID;

				public String getContract_Family_ID () {
					return this.Contract_Family_ID;
				}
				
			    public String Multi_Birth_Code;

				public String getMulti_Birth_Code () {
					return this.Multi_Birth_Code;
				}
				
			    public String Member_Key;

				public String getMember_Key () {
					return this.Member_Key;
				}
				
			    public String Source;

				public String getSource () {
					return this.Source;
				}
				
			    public java.util.Date year;

				public java.util.Date getYear () {
					return this.year;
				}
				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecord_Allrules_T) {

        	try {

        		int length = 0;
		
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.Gender = null;
           				} else {
           			    	this.Gender = dis.readChar();
           				}
					
					this.Date = readDate(dis);
					
					this.First_Name = readString(dis);
					
					this.Last_Name = readString(dis);
					
					this.State = readString(dis);
					
					this.City = readString(dis);
					
					this.Zip_Code = readString(dis);
					
					this.Address_Line_1 = readString(dis);
					
					this.Address_Line_2 = readString(dis);
					
					this.Phone_Number = readString(dis);
					
					this.Social_Security_Number = readString(dis);
					
					this.UPI_ID = readString(dis);
					
					this.MBI = readString(dis);
					
					this.Client_ID = readString(dis);
					
					this.Carrier_ID = readString(dis);
					
					this.Account_ID = readString(dis);
					
					this.Group_ID = readString(dis);
					
					this.Contract_Family_ID = readString(dis);
					
					this.Multi_Birth_Code = readString(dis);
					
					this.Member_Key = readString(dis);
					
					this.Source = readString(dis);
					
					this.year = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Character
				
						if(this.Gender == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeChar(this.Gender);
		            	}
					
					// java.util.Date
				
						writeDate(this.Date,dos);
					
					// String
				
						writeString(this.First_Name,dos);
					
					// String
				
						writeString(this.Last_Name,dos);
					
					// String
				
						writeString(this.State,dos);
					
					// String
				
						writeString(this.City,dos);
					
					// String
				
						writeString(this.Zip_Code,dos);
					
					// String
				
						writeString(this.Address_Line_1,dos);
					
					// String
				
						writeString(this.Address_Line_2,dos);
					
					// String
				
						writeString(this.Phone_Number,dos);
					
					// String
				
						writeString(this.Social_Security_Number,dos);
					
					// String
				
						writeString(this.UPI_ID,dos);
					
					// String
				
						writeString(this.MBI,dos);
					
					// String
				
						writeString(this.Client_ID,dos);
					
					// String
				
						writeString(this.Carrier_ID,dos);
					
					// String
				
						writeString(this.Account_ID,dos);
					
					// String
				
						writeString(this.Group_ID,dos);
					
					// String
				
						writeString(this.Contract_Family_ID,dos);
					
					// String
				
						writeString(this.Multi_Birth_Code,dos);
					
					// String
				
						writeString(this.Member_Key,dos);
					
					// String
				
						writeString(this.Source,dos);
					
					// java.util.Date
				
						writeDate(this.year,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Gender="+String.valueOf(Gender));
		sb.append(",Date="+String.valueOf(Date));
		sb.append(",First_Name="+First_Name);
		sb.append(",Last_Name="+Last_Name);
		sb.append(",State="+State);
		sb.append(",City="+City);
		sb.append(",Zip_Code="+Zip_Code);
		sb.append(",Address_Line_1="+Address_Line_1);
		sb.append(",Address_Line_2="+Address_Line_2);
		sb.append(",Phone_Number="+Phone_Number);
		sb.append(",Social_Security_Number="+Social_Security_Number);
		sb.append(",UPI_ID="+UPI_ID);
		sb.append(",MBI="+MBI);
		sb.append(",Client_ID="+Client_ID);
		sb.append(",Carrier_ID="+Carrier_ID);
		sb.append(",Account_ID="+Account_ID);
		sb.append(",Group_ID="+Group_ID);
		sb.append(",Contract_Family_ID="+Contract_Family_ID);
		sb.append(",Multi_Birth_Code="+Multi_Birth_Code);
		sb.append(",Member_Key="+Member_Key);
		sb.append(",Source="+Source);
		sb.append(",year="+String.valueOf(year));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(copyOfdobStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row18Struct implements routines.system.IPersistableRow<row18Struct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecord_Allrules_T = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T = new byte[0];

	
			    public Character Gender;

				public Character getGender () {
					return this.Gender;
				}
				
			    public String Date_of_Birth;

				public String getDate_of_Birth () {
					return this.Date_of_Birth;
				}
				
			    public String First_Name;

				public String getFirst_Name () {
					return this.First_Name;
				}
				
			    public String Last_Name;

				public String getLast_Name () {
					return this.Last_Name;
				}
				
			    public String State;

				public String getState () {
					return this.State;
				}
				
			    public String City;

				public String getCity () {
					return this.City;
				}
				
			    public String Zip_Code;

				public String getZip_Code () {
					return this.Zip_Code;
				}
				
			    public String Address_Line_1;

				public String getAddress_Line_1 () {
					return this.Address_Line_1;
				}
				
			    public String Address_Line_2;

				public String getAddress_Line_2 () {
					return this.Address_Line_2;
				}
				
			    public String Phone_Number;

				public String getPhone_Number () {
					return this.Phone_Number;
				}
				
			    public String Social_Security_Number;

				public String getSocial_Security_Number () {
					return this.Social_Security_Number;
				}
				
			    public String UPI_ID;

				public String getUPI_ID () {
					return this.UPI_ID;
				}
				
			    public String MBI;

				public String getMBI () {
					return this.MBI;
				}
				
			    public String Client_ID;

				public String getClient_ID () {
					return this.Client_ID;
				}
				
			    public String Carrier_ID;

				public String getCarrier_ID () {
					return this.Carrier_ID;
				}
				
			    public String Account_ID;

				public String getAccount_ID () {
					return this.Account_ID;
				}
				
			    public String Group_ID;

				public String getGroup_ID () {
					return this.Group_ID;
				}
				
			    public String Contract_Family_ID;

				public String getContract_Family_ID () {
					return this.Contract_Family_ID;
				}
				
			    public String Multi_Birth_Code;

				public String getMulti_Birth_Code () {
					return this.Multi_Birth_Code;
				}
				
			    public String Member_Key;

				public String getMember_Key () {
					return this.Member_Key;
				}
				
			    public String Source;

				public String getSource () {
					return this.Source;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecord_Allrules_T) {

        	try {

        		int length = 0;
		
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.Gender = null;
           				} else {
           			    	this.Gender = dis.readChar();
           				}
					
					this.Date_of_Birth = readString(dis);
					
					this.First_Name = readString(dis);
					
					this.Last_Name = readString(dis);
					
					this.State = readString(dis);
					
					this.City = readString(dis);
					
					this.Zip_Code = readString(dis);
					
					this.Address_Line_1 = readString(dis);
					
					this.Address_Line_2 = readString(dis);
					
					this.Phone_Number = readString(dis);
					
					this.Social_Security_Number = readString(dis);
					
					this.UPI_ID = readString(dis);
					
					this.MBI = readString(dis);
					
					this.Client_ID = readString(dis);
					
					this.Carrier_ID = readString(dis);
					
					this.Account_ID = readString(dis);
					
					this.Group_ID = readString(dis);
					
					this.Contract_Family_ID = readString(dis);
					
					this.Multi_Birth_Code = readString(dis);
					
					this.Member_Key = readString(dis);
					
					this.Source = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Character
				
						if(this.Gender == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeChar(this.Gender);
		            	}
					
					// String
				
						writeString(this.Date_of_Birth,dos);
					
					// String
				
						writeString(this.First_Name,dos);
					
					// String
				
						writeString(this.Last_Name,dos);
					
					// String
				
						writeString(this.State,dos);
					
					// String
				
						writeString(this.City,dos);
					
					// String
				
						writeString(this.Zip_Code,dos);
					
					// String
				
						writeString(this.Address_Line_1,dos);
					
					// String
				
						writeString(this.Address_Line_2,dos);
					
					// String
				
						writeString(this.Phone_Number,dos);
					
					// String
				
						writeString(this.Social_Security_Number,dos);
					
					// String
				
						writeString(this.UPI_ID,dos);
					
					// String
				
						writeString(this.MBI,dos);
					
					// String
				
						writeString(this.Client_ID,dos);
					
					// String
				
						writeString(this.Carrier_ID,dos);
					
					// String
				
						writeString(this.Account_ID,dos);
					
					// String
				
						writeString(this.Group_ID,dos);
					
					// String
				
						writeString(this.Contract_Family_ID,dos);
					
					// String
				
						writeString(this.Multi_Birth_Code,dos);
					
					// String
				
						writeString(this.Member_Key,dos);
					
					// String
				
						writeString(this.Source,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Gender="+String.valueOf(Gender));
		sb.append(",Date_of_Birth="+Date_of_Birth);
		sb.append(",First_Name="+First_Name);
		sb.append(",Last_Name="+Last_Name);
		sb.append(",State="+State);
		sb.append(",City="+City);
		sb.append(",Zip_Code="+Zip_Code);
		sb.append(",Address_Line_1="+Address_Line_1);
		sb.append(",Address_Line_2="+Address_Line_2);
		sb.append(",Phone_Number="+Phone_Number);
		sb.append(",Social_Security_Number="+Social_Security_Number);
		sb.append(",UPI_ID="+UPI_ID);
		sb.append(",MBI="+MBI);
		sb.append(",Client_ID="+Client_ID);
		sb.append(",Carrier_ID="+Carrier_ID);
		sb.append(",Account_ID="+Account_ID);
		sb.append(",Group_ID="+Group_ID);
		sb.append(",Contract_Family_ID="+Contract_Family_ID);
		sb.append(",Multi_Birth_Code="+Multi_Birth_Code);
		sb.append(",Member_Key="+Member_Key);
		sb.append(",Source="+Source);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row18Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFileInputDelimited_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileInputDelimited_4_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
		String currentVirtualComponent = null;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row18Struct row18 = new row18Struct();
copyOfdobStruct copyOfdob = new copyOfdobStruct();
row19Struct row19 = new row19Struct();
row19Struct row20 = row19;
row19Struct row21 = row19;
row22Struct row22 = new row22Struct();
copyOfoutStruct copyOfout = new copyOfoutStruct();





	
	/**
	 * [tMatchGroup_1_GroupOut begin ] start
	 */

	

	
		
		ok_Hash.put("tMatchGroup_1_GroupOut", false);
		start_Hash.put("tMatchGroup_1_GroupOut", System.currentTimeMillis());
		
	
		currentVirtualComponent = "tMatchGroup_1";
	
	currentComponent="tMatchGroup_1_GroupOut";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"copyOfdob");
			
		int tos_count_tMatchGroup_1_GroupOut = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tMatchGroup_1_GroupOut", "tMatchGroupOut");
				talendJobLogProcess(globalMap);
			}
			
class tMatchGroup_1Struct implements routines.system.IPersistableRow<tMatchGroup_1Struct> {
  final byte[] commonByteArrayLock_UPI_PROCESS_IngestRecord_Allrules_T = new byte[0];
  byte[] commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T = new byte[0];
    public Character Gender;

    public Character getGender () {
      return this.Gender;
    }
    public java.util.Date Date;

    public java.util.Date getDate () {
      return this.Date;
    }
    public String First_Name;

    public String getFirst_Name () {
      return this.First_Name;
    }
    public String Last_Name;

    public String getLast_Name () {
      return this.Last_Name;
    }
    public String State;

    public String getState () {
      return this.State;
    }
    public String City;

    public String getCity () {
      return this.City;
    }
    public String Zip_Code;

    public String getZip_Code () {
      return this.Zip_Code;
    }
    public String Address_Line_1;

    public String getAddress_Line_1 () {
      return this.Address_Line_1;
    }
    public String Address_Line_2;

    public String getAddress_Line_2 () {
      return this.Address_Line_2;
    }
    public String Phone_Number;

    public String getPhone_Number () {
      return this.Phone_Number;
    }
    public String Social_Security_Number;

    public String getSocial_Security_Number () {
      return this.Social_Security_Number;
    }
    public String UPI_ID;

    public String getUPI_ID () {
      return this.UPI_ID;
    }
    public String MBI;

    public String getMBI () {
      return this.MBI;
    }
    public String Client_ID;

    public String getClient_ID () {
      return this.Client_ID;
    }
    public String Carrier_ID;

    public String getCarrier_ID () {
      return this.Carrier_ID;
    }
    public String Account_ID;

    public String getAccount_ID () {
      return this.Account_ID;
    }
    public String Group_ID;

    public String getGroup_ID () {
      return this.Group_ID;
    }
    public String Contract_Family_ID;

    public String getContract_Family_ID () {
      return this.Contract_Family_ID;
    }
    public String Multi_Birth_Code;

    public String getMulti_Birth_Code () {
      return this.Multi_Birth_Code;
    }
    public String Member_Key;

    public String getMember_Key () {
      return this.Member_Key;
    }
    public String Source;

    public String getSource () {
      return this.Source;
    }
    public java.util.Date year;

    public java.util.Date getYear () {
      return this.year;
    }
  public void copyDateToOut(row19Struct other){
      other.Gender = this.Gender;
      other.Date = this.Date;
      other.First_Name = this.First_Name;
      other.Last_Name = this.Last_Name;
      other.State = this.State;
      other.City = this.City;
      other.Zip_Code = this.Zip_Code;
      other.Address_Line_1 = this.Address_Line_1;
      other.Address_Line_2 = this.Address_Line_2;
      other.Phone_Number = this.Phone_Number;
      other.Social_Security_Number = this.Social_Security_Number;
      other.UPI_ID = this.UPI_ID;
      other.MBI = this.MBI;
      other.Client_ID = this.Client_ID;
      other.Carrier_ID = this.Carrier_ID;
      other.Account_ID = this.Account_ID;
      other.Group_ID = this.Group_ID;
      other.Contract_Family_ID = this.Contract_Family_ID;
      other.Multi_Birth_Code = this.Multi_Birth_Code;
      other.Member_Key = this.Member_Key;
      other.Source = this.Source;
      other.year = this.year;
  }
    
        private java.util.Date readDate(ObjectInputStream dis) throws IOException{
          java.util.Date dateReturn = null;
          int length = 0;
          length = dis.readByte();
          
          if (length == -1) {
            dateReturn = null;
          } else {
            dateReturn = new Date(dis.readLong());
          }
          return dateReturn;
        }
              
        private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
          if (date1 == null) {
            dos.writeByte(-1);
          } else {
            dos.writeByte(0);
            dos.writeLong(date1.getTime());
          }
        }
        private String readString(ObjectInputStream dis) throws IOException{
          String strReturn = null;
          int length = 0;
          length = dis.readInt();
          
          if (length == -1) {
            strReturn = null;
          } else {
            if (length > commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T.length) {
              if (length < 1024 && commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T.length == 0) {
                commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T = new byte[1024];
              } else {
                commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T = new byte[2 * length];
              }
            }
            dis.readFully(commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T, 0, length);
            strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T, 0, length, utf8Charset);
          }
          return strReturn;
        }
  
        private void writeString(String str, ObjectOutputStream dos) throws IOException{
          if (str == null) {
            dos.writeInt(-1);
          } else {
            byte[] byteArray = str.getBytes(utf8Charset);
            dos.writeInt(byteArray.length);
            dos.write(byteArray);
          }
        }
          
     
  public void readData(ObjectInputStream dis) {
    synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecord_Allrules_T) {
      try {
        int length = 0;
                length = dis.readByte();
                if (length == -1) {
                  this.Gender = null;
                } else {
                  this.Gender = dis.readChar();
                }
              this.Date = readDate(dis);
              this.First_Name = readString(dis);
              this.Last_Name = readString(dis);
              this.State = readString(dis);
              this.City = readString(dis);
              this.Zip_Code = readString(dis);
              this.Address_Line_1 = readString(dis);
              this.Address_Line_2 = readString(dis);
              this.Phone_Number = readString(dis);
              this.Social_Security_Number = readString(dis);
              this.UPI_ID = readString(dis);
              this.MBI = readString(dis);
              this.Client_ID = readString(dis);
              this.Carrier_ID = readString(dis);
              this.Account_ID = readString(dis);
              this.Group_ID = readString(dis);
              this.Contract_Family_ID = readString(dis);
              this.Multi_Birth_Code = readString(dis);
              this.Member_Key = readString(dis);
              this.Source = readString(dis);
              this.year = readDate(dis);
          } catch (IOException e) {
            throw new RuntimeException(e);
      }
    }
  }

  public void writeData(ObjectOutputStream dos) {
    try {
           // Character
              if (this.Gender == null) {
                dos.writeByte(-1);
              } else {
                dos.writeByte(0);
                dos.writeChar(this.Gender);
              }
           // java.util.Date
            writeDate(this.Date,dos);
           // String
            writeString(this.First_Name,dos);
           // String
            writeString(this.Last_Name,dos);
           // String
            writeString(this.State,dos);
           // String
            writeString(this.City,dos);
           // String
            writeString(this.Zip_Code,dos);
           // String
            writeString(this.Address_Line_1,dos);
           // String
            writeString(this.Address_Line_2,dos);
           // String
            writeString(this.Phone_Number,dos);
           // String
            writeString(this.Social_Security_Number,dos);
           // String
            writeString(this.UPI_ID,dos);
           // String
            writeString(this.MBI,dos);
           // String
            writeString(this.Client_ID,dos);
           // String
            writeString(this.Carrier_ID,dos);
           // String
            writeString(this.Account_ID,dos);
           // String
            writeString(this.Group_ID,dos);
           // String
            writeString(this.Contract_Family_ID,dos);
           // String
            writeString(this.Multi_Birth_Code,dos);
           // String
            writeString(this.Member_Key,dos);
           // String
            writeString(this.Source,dos);
           // java.util.Date
            writeDate(this.year,dos);
        } catch (IOException e) {
          throw new RuntimeException(e);
    }
  }


  public String toString() {
    
    StringBuilder sb = new StringBuilder();
    sb.append(super.toString());
    sb.append("[");
        sb.append(","+ "Gender="+String.valueOf(Gender));
        sb.append(","+ "Date="+String.valueOf(Date));
        sb.append(","+ "First_Name="+First_Name);
        sb.append(","+ "Last_Name="+Last_Name);
        sb.append(","+ "State="+State);
        sb.append(","+ "City="+City);
        sb.append(","+ "Zip_Code="+Zip_Code);
        sb.append(","+ "Address_Line_1="+Address_Line_1);
        sb.append(","+ "Address_Line_2="+Address_Line_2);
        sb.append(","+ "Phone_Number="+Phone_Number);
        sb.append(","+ "Social_Security_Number="+Social_Security_Number);
        sb.append(","+ "UPI_ID="+UPI_ID);
        sb.append(","+ "MBI="+MBI);
        sb.append(","+ "Client_ID="+Client_ID);
        sb.append(","+ "Carrier_ID="+Carrier_ID);
        sb.append(","+ "Account_ID="+Account_ID);
        sb.append(","+ "Group_ID="+Group_ID);
        sb.append(","+ "Contract_Family_ID="+Contract_Family_ID);
        sb.append(","+ "Multi_Birth_Code="+Multi_Birth_Code);
        sb.append(","+ "Member_Key="+Member_Key);
        sb.append(","+ "Source="+Source);
        sb.append(","+ "year="+String.valueOf(year));
    sb.append("]");
    return sb.toString();
  }
    
  /** 
   * Compare keys
   */
  public int compareTo(tMatchGroup_1Struct other) {
    int returnValue = -1;
  return returnValue;
  }
    
  private int checkNullsAndCompare(Object object1, Object object2) {
    int returnValue = 0;
    if (object1 instanceof Comparable && object2 instanceof Comparable) {
      returnValue = ((Comparable) object1).compareTo(object2);
    } else if (object1 != null && object2 != null) {
      returnValue = compareStrings(object1.toString(), object2.toString());
    } else if (object1 == null && object2 != null) {
      returnValue = 1;
    } else if (object1 != null && object2 == null) {
      returnValue = -1;
    } else {
      returnValue = 0;
    }
    return returnValue;
  }

  private int compareStrings(String string1, String string2) {
    return string1.compareTo(string2);
  }
}
 

class tMatchGroup_1_2Struct implements routines.system.IPersistableComparableLookupRow<tMatchGroup_1_2Struct>,org.talend.dataquality.indicators.mapdb.helper.IObjectConvertArray {
  final byte[] commonByteArrayLock_UPI_PROCESS_IngestRecord_Allrules_T = new byte[0];
  byte[] commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T = new byte[0];
    private  final int DEFAULT_HASHCODE = 1;
    private  final int PRIME = 31;
    private int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;
  public void copyDateToOut(tMatchGroup_1_2Struct other){
  }
    
    @Override
    public int hashCode() {
      if (this.hashCodeDirty) {
        final int prime = PRIME;
        int result = DEFAULT_HASHCODE;
        
        this.hashCode = result;
        this.hashCodeDirty = false;
      }
      return this.hashCode;
    }
    
    @Override
    public boolean equals(Object obj) {
      if (this == obj)
        return true;
      if (obj == null)
        return false;
      if (getClass() != obj.getClass())
        return false;
      final tMatchGroup_1_2Struct other = (tMatchGroup_1_2Struct) obj;
      
      return true;
    }
    public void copyDataTo(tMatchGroup_1_2Struct other) {
      }
      
      public void copyKeysDataTo(tMatchGroup_1_2Struct other) {
      }
    
      public void readKeysData(ObjectInputStream dis) {
          synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecord_Allrules_T) {
            try {
              int length = 0;
                }
              finally {}
          }
        }
      public void writeKeysData(ObjectOutputStream dos) {
          try {
          }
            finally {}
        }
      /** 
       * Fill Values data by reading ObjectInputStream.
       */
      public void readValuesData(DataInputStream dis, ObjectInputStream ois) {
   
      }

      /** 
       * Return a byte array which represents Values data.
       */
      public void writeValuesData(DataOutputStream dos, ObjectOutputStream oos) {

      }

    public String toString() {
      
      StringBuilder sb = new StringBuilder();
      sb.append(super.toString());
      sb.append("[");
      sb.append("]");
      return sb.toString();
    }
      
    /** 
     * Compare keys
     */
    public int compareTo(tMatchGroup_1_2Struct other) {
      int returnValue = -1;
    return returnValue;
    }
      
    private int checkNullsAndCompare(Object object1, Object object2) {
      int returnValue = 0;
      if (object1 instanceof Comparable && object2 instanceof Comparable) {
        returnValue = ((Comparable) object1).compareTo(object2);
      } else if (object1 != null && object2 != null) {
        returnValue = compareStrings(object1.toString(), object2.toString());
      } else if (object1 == null && object2 != null) {
        returnValue = 1;
      } else if (object1 != null && object2 == null) {
        returnValue = -1;
      } else {
        returnValue = 0;
      }
      return returnValue;
    }

    private int compareStrings(String string1, String string2) {
      return string1.compareTo(string2);
    }
    
    @Override
    public Object[] getArrays() {
        Object[] array=new Object[0];
        return array;
    }
    @Override
    public void restoreObjectByArrays(Object[] elements) {
    }
}//end of _2struct



org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE 
  matchingModeEnum_tMatchGroup_1 = org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.ALL_ROWS;
  org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<tMatchGroup_1Struct> 
    tHash_Lookup_copyOfdob = org.talend.designer.components.lookup.memory.AdvancedMemoryLookup.<tMatchGroup_1Struct>getLookup(matchingModeEnum_tMatchGroup_1);
globalMap.put("tHash_Lookup_copyOfdob", tHash_Lookup_copyOfdob);

/*store all block rows*/  
  java.util.Map<tMatchGroup_1_2Struct, String> blockRows_copyOfdob = new java.util.HashMap<tMatchGroup_1_2Struct, String>();
 



/**
 * [tMatchGroup_1_GroupOut begin ] stop
 */



	
	/**
	 * [tMap_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_3", false);
		start_Hash.put("tMap_3", System.currentTimeMillis());
		
	
	currentComponent="tMap_3";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row18");
			
		int tos_count_tMap_3 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tMap_3", "tMap");
				talendJobLogProcess(globalMap);
			}
			




// ###############################
// # Lookup's keys initialization
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_3__Struct  {
}
Var__tMap_3__Struct Var__tMap_3 = new Var__tMap_3__Struct();
// ###############################

// ###############################
// # Outputs initialization
copyOfdobStruct copyOfdob_tmp = new copyOfdobStruct();
// ###############################

        
        



        









 



/**
 * [tMap_3 begin ] stop
 */



	
	/**
	 * [tFileInputDelimited_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputDelimited_4", false);
		start_Hash.put("tFileInputDelimited_4", System.currentTimeMillis());
		
	
	currentComponent="tFileInputDelimited_4";

	
		int tos_count_tFileInputDelimited_4 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tFileInputDelimited_4", "tFileInputDelimited");
				talendJobLogProcess(globalMap);
			}
			
	
	
	
 
	
	
	final routines.system.RowState rowstate_tFileInputDelimited_4 = new routines.system.RowState();
	
	
				int nb_line_tFileInputDelimited_4 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_4 = null;
				int limit_tFileInputDelimited_4 = -1;
				try{
					
						Object filename_tFileInputDelimited_4 = "C:/Talend/Source/UPI_SyntheticTestData_V3_CompleteSet.txt";
						if(filename_tFileInputDelimited_4 instanceof java.io.InputStream){
							
			int footer_value_tFileInputDelimited_4 = 0, random_value_tFileInputDelimited_4 = -1;
			if(footer_value_tFileInputDelimited_4 >0 || random_value_tFileInputDelimited_4 > 0){
				throw new java.lang.Exception("When the input source is a stream,footer and random shouldn't be bigger than 0.");				
			}
		
						}
						try {
							fid_tFileInputDelimited_4 = new org.talend.fileprocess.FileInputDelimited("C:/Talend/Source/UPI_SyntheticTestData_V3_CompleteSet.txt", "ISO-8859-15","|","\n",false,1,0,
									limit_tFileInputDelimited_4
								,-1, false);
						} catch(java.lang.Exception e) {
							
								
								System.err.println(e.getMessage());
							
						}
					
				    
					while (fid_tFileInputDelimited_4!=null && fid_tFileInputDelimited_4.nextRecord()) {
						rowstate_tFileInputDelimited_4.reset();
						
			    						row18 = null;			
												
									boolean whetherReject_tFileInputDelimited_4 = false;
									row18 = new row18Struct();
									try {
										
				int columnIndexWithD_tFileInputDelimited_4 = 0;
				
					String temp = ""; 
				
					columnIndexWithD_tFileInputDelimited_4 = 0;
					
						temp = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4).trim();
						if(temp.length() > 0) {
							
								try {
								
    								row18.Gender = ParserUtils.parseTo_Character(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_4) {
									rowstate_tFileInputDelimited_4.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"Gender", "row18", temp, ex_tFileInputDelimited_4), ex_tFileInputDelimited_4));
								}
    							
						} else {						
							
								
									row18.Gender = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_4 = 1;
					
							row18.Date_of_Birth = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4).trim();
						
				
					columnIndexWithD_tFileInputDelimited_4 = 2;
					
							row18.First_Name = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4).trim();
						
				
					columnIndexWithD_tFileInputDelimited_4 = 3;
					
							row18.Last_Name = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4).trim();
						
				
					columnIndexWithD_tFileInputDelimited_4 = 4;
					
							row18.State = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4).trim();
						
				
					columnIndexWithD_tFileInputDelimited_4 = 5;
					
							row18.City = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4).trim();
						
				
					columnIndexWithD_tFileInputDelimited_4 = 6;
					
							row18.Zip_Code = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4).trim();
						
				
					columnIndexWithD_tFileInputDelimited_4 = 7;
					
							row18.Address_Line_1 = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4).trim();
						
				
					columnIndexWithD_tFileInputDelimited_4 = 8;
					
							row18.Address_Line_2 = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4).trim();
						
				
					columnIndexWithD_tFileInputDelimited_4 = 9;
					
							row18.Phone_Number = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4).trim();
						
				
					columnIndexWithD_tFileInputDelimited_4 = 10;
					
							row18.Social_Security_Number = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4).trim();
						
				
					columnIndexWithD_tFileInputDelimited_4 = 11;
					
							row18.UPI_ID = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4).trim();
						
				
					columnIndexWithD_tFileInputDelimited_4 = 12;
					
							row18.MBI = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4).trim();
						
				
					columnIndexWithD_tFileInputDelimited_4 = 13;
					
							row18.Client_ID = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4).trim();
						
				
					columnIndexWithD_tFileInputDelimited_4 = 14;
					
							row18.Carrier_ID = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4).trim();
						
				
					columnIndexWithD_tFileInputDelimited_4 = 15;
					
							row18.Account_ID = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4).trim();
						
				
					columnIndexWithD_tFileInputDelimited_4 = 16;
					
							row18.Group_ID = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4).trim();
						
				
					columnIndexWithD_tFileInputDelimited_4 = 17;
					
							row18.Contract_Family_ID = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4).trim();
						
				
					columnIndexWithD_tFileInputDelimited_4 = 18;
					
							row18.Multi_Birth_Code = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4).trim();
						
				
					columnIndexWithD_tFileInputDelimited_4 = 19;
					
							row18.Member_Key = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4).trim();
						
				
					columnIndexWithD_tFileInputDelimited_4 = 20;
					
							row18.Source = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4).trim();
						
				
				
										
										if(rowstate_tFileInputDelimited_4.getException()!=null) {
											throw rowstate_tFileInputDelimited_4.getException();
										}
										
										
							
			    					} catch (java.lang.Exception e) {
			        					whetherReject_tFileInputDelimited_4 = true;
			        					
			                					System.err.println(e.getMessage());
			                					row18 = null;
			                				
			    					}
								

 



/**
 * [tFileInputDelimited_4 begin ] stop
 */
	
	/**
	 * [tFileInputDelimited_4 main ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_4";

	

 


	tos_count_tFileInputDelimited_4++;

/**
 * [tFileInputDelimited_4 main ] stop
 */
	
	/**
	 * [tFileInputDelimited_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_4";

	

 



/**
 * [tFileInputDelimited_4 process_data_begin ] stop
 */
// Start of branch "row18"
if(row18 != null) { 



	
	/**
	 * [tMap_3 main ] start
	 */

	

	
	
	currentComponent="tMap_3";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"row18");
			

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_3 = false;
		
        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_3 = false;
		  boolean mainRowRejected_tMap_3 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_3__Struct Var = Var__tMap_3;// ###############################
        // ###############################
        // # Output tables

copyOfdob = null;


// # Output table : 'copyOfdob'
copyOfdob_tmp.Gender = row18.Gender;
copyOfdob_tmp.Date = TalendDate.parseDate("yyyy-MM-dd",TalendDate.formatDate("yyyy-MM-dd",TalendDate.parseDate("yyyyMMdd",row18.Date_of_Birth))) ;
copyOfdob_tmp.First_Name = row18.First_Name;
copyOfdob_tmp.Last_Name = row18.Last_Name;
copyOfdob_tmp.State = row18.State;
copyOfdob_tmp.City = row18.City;
copyOfdob_tmp.Zip_Code = row18.Zip_Code;
copyOfdob_tmp.Address_Line_1 = row18.Address_Line_1;
copyOfdob_tmp.Address_Line_2 = row18.Address_Line_2;
copyOfdob_tmp.Phone_Number = row18.Phone_Number;
copyOfdob_tmp.Social_Security_Number = row18.Social_Security_Number;
copyOfdob_tmp.UPI_ID = row18.UPI_ID;
copyOfdob_tmp.MBI = row18.MBI ;
copyOfdob_tmp.Client_ID = row18.Client_ID;
copyOfdob_tmp.Carrier_ID = row18.Carrier_ID;
copyOfdob_tmp.Account_ID = row18.Account_ID;
copyOfdob_tmp.Group_ID = row18.Group_ID;
copyOfdob_tmp.Contract_Family_ID = row18.Contract_Family_ID;
copyOfdob_tmp.Multi_Birth_Code = row18.Multi_Birth_Code;
copyOfdob_tmp.Member_Key = row18.Member_Key;
copyOfdob_tmp.Source = row18.Source;
copyOfdob_tmp.year = TalendDate.parseDate("yyyy",TalendDate.formatDate("yyyy",TalendDate.parseDate("yyyyddMM",row18.Date_of_Birth))) ;
copyOfdob = copyOfdob_tmp;
// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_3 = false;










 


	tos_count_tMap_3++;

/**
 * [tMap_3 main ] stop
 */
	
	/**
	 * [tMap_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_3";

	

 



/**
 * [tMap_3 process_data_begin ] stop
 */
// Start of branch "copyOfdob"
if(copyOfdob != null) { 



	
	/**
	 * [tMatchGroup_1_GroupOut main ] start
	 */

	

	
	
		currentVirtualComponent = "tMatchGroup_1";
	
	currentComponent="tMatchGroup_1_GroupOut";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"copyOfdob");
			
  tMatchGroup_1Struct copyOfdob_HashRow = new tMatchGroup_1Struct();
        
      copyOfdob_HashRow.Gender =  copyOfdob.Gender;
        
      copyOfdob_HashRow.Date =  copyOfdob.Date;
        
      copyOfdob_HashRow.First_Name =  copyOfdob.First_Name;
        
      copyOfdob_HashRow.Last_Name =  copyOfdob.Last_Name;
        
      copyOfdob_HashRow.State =  copyOfdob.State;
        
      copyOfdob_HashRow.City =  copyOfdob.City;
        
      copyOfdob_HashRow.Zip_Code =  copyOfdob.Zip_Code;
        
      copyOfdob_HashRow.Address_Line_1 =  copyOfdob.Address_Line_1;
        
      copyOfdob_HashRow.Address_Line_2 =  copyOfdob.Address_Line_2;
        
      copyOfdob_HashRow.Phone_Number =  copyOfdob.Phone_Number;
        
      copyOfdob_HashRow.Social_Security_Number =  copyOfdob.Social_Security_Number;
        
      copyOfdob_HashRow.UPI_ID =  copyOfdob.UPI_ID;
        
      copyOfdob_HashRow.MBI =  copyOfdob.MBI;
        
      copyOfdob_HashRow.Client_ID =  copyOfdob.Client_ID;
        
      copyOfdob_HashRow.Carrier_ID =  copyOfdob.Carrier_ID;
        
      copyOfdob_HashRow.Account_ID =  copyOfdob.Account_ID;
        
      copyOfdob_HashRow.Group_ID =  copyOfdob.Group_ID;
        
      copyOfdob_HashRow.Contract_Family_ID =  copyOfdob.Contract_Family_ID;
        
      copyOfdob_HashRow.Multi_Birth_Code =  copyOfdob.Multi_Birth_Code;
        
      copyOfdob_HashRow.Member_Key =  copyOfdob.Member_Key;
        
      copyOfdob_HashRow.Source =  copyOfdob.Source;
        
      copyOfdob_HashRow.year =  copyOfdob.year;
tHash_Lookup_copyOfdob.put(copyOfdob_HashRow);
 


	tos_count_tMatchGroup_1_GroupOut++;

/**
 * [tMatchGroup_1_GroupOut main ] stop
 */
	
	/**
	 * [tMatchGroup_1_GroupOut process_data_begin ] start
	 */

	

	
	
		currentVirtualComponent = "tMatchGroup_1";
	
	currentComponent="tMatchGroup_1_GroupOut";

	

 



/**
 * [tMatchGroup_1_GroupOut process_data_begin ] stop
 */
	
	/**
	 * [tMatchGroup_1_GroupOut process_data_end ] start
	 */

	

	
	
		currentVirtualComponent = "tMatchGroup_1";
	
	currentComponent="tMatchGroup_1_GroupOut";

	

 



/**
 * [tMatchGroup_1_GroupOut process_data_end ] stop
 */

} // End of branch "copyOfdob"




	
	/**
	 * [tMap_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_3";

	

 



/**
 * [tMap_3 process_data_end ] stop
 */

} // End of branch "row18"




	
	/**
	 * [tFileInputDelimited_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_4";

	

 



/**
 * [tFileInputDelimited_4 process_data_end ] stop
 */
	
	/**
	 * [tFileInputDelimited_4 end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_4";

	



            }
            }finally{
                if(!((Object)("C:/Talend/Source/UPI_SyntheticTestData_V3_CompleteSet.txt") instanceof java.io.InputStream)){
                	if(fid_tFileInputDelimited_4!=null){
                		fid_tFileInputDelimited_4.close();
                	}
                }
                if(fid_tFileInputDelimited_4!=null){
                	globalMap.put("tFileInputDelimited_4_NB_LINE", fid_tFileInputDelimited_4.getRowNumber());
					
                }
			}
			  

 

ok_Hash.put("tFileInputDelimited_4", true);
end_Hash.put("tFileInputDelimited_4", System.currentTimeMillis());




/**
 * [tFileInputDelimited_4 end ] stop
 */

	
	/**
	 * [tMap_3 end ] start
	 */

	

	
	
	currentComponent="tMap_3";

	


// ###############################
// # Lookup hashes releasing
// ###############################      





			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row18",2,0,
			 			talendJobLog,"tFileInputDelimited_4","tFileInputDelimited","tMap_3","tMap","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tMap_3", true);
end_Hash.put("tMap_3", System.currentTimeMillis());




/**
 * [tMap_3 end ] stop
 */

	
	/**
	 * [tMatchGroup_1_GroupOut end ] start
	 */

	

	
	
		currentVirtualComponent = "tMatchGroup_1";
	
	currentComponent="tMatchGroup_1_GroupOut";

	
tHash_Lookup_copyOfdob.endPut();
			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"copyOfdob",2,0,
			 			talendJobLog,"tMap_3","tMap","tMatchGroup_1_GroupOut","tMatchGroupOut","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tMatchGroup_1_GroupOut", true);
end_Hash.put("tMatchGroup_1_GroupOut", System.currentTimeMillis());




/**
 * [tMatchGroup_1_GroupOut end ] stop
 */




	
	/**
	 * [tAggregateRow_2_AGGOUT begin ] start
	 */

	

	
		
		ok_Hash.put("tAggregateRow_2_AGGOUT", false);
		start_Hash.put("tAggregateRow_2_AGGOUT", System.currentTimeMillis());
		
	
		currentVirtualComponent = "tAggregateRow_2";
	
	currentComponent="tAggregateRow_2_AGGOUT";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row21");
			
		int tos_count_tAggregateRow_2_AGGOUT = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAggregateRow_2_AGGOUT", "tAggregateOut");
				talendJobLogProcess(globalMap);
			}
			

// ------------ Seems it is not used

java.util.Map hashAggreg_tAggregateRow_2 = new java.util.HashMap(); 

// ------------

	class UtilClass_tAggregateRow_2 { // G_OutBegin_AggR_144

		public double sd(Double[] data) {
	        final int n = data.length;
        	if (n < 2) {
	            return Double.NaN;
        	}
        	double d1 = 0d;
        	double d2 =0d;
	        
	        for (int i = 0; i < data.length; i++) {
            	d1 += (data[i]*data[i]);
            	d2 += data[i];
        	}
        
	        return Math.sqrt((n*d1 - d2*d2)/n/(n-1));
	    }
	    
		public void checkedIADD(byte a, byte b, boolean checkTypeOverFlow, boolean checkUlp) {
		    byte r = (byte) (a + b);
		    if (checkTypeOverFlow && ((a ^ r) & (b ^ r)) < 0) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'short/Short'", "'byte/Byte'"));
		    }
		}
		
		public void checkedIADD(short a, short b, boolean checkTypeOverFlow, boolean checkUlp) {
		    short r = (short) (a + b);
		    if (checkTypeOverFlow && ((a ^ r) & (b ^ r)) < 0) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'int/Integer'", "'short/Short'"));
		    }
		}
		
		public void checkedIADD(int a, int b, boolean checkTypeOverFlow, boolean checkUlp) {
		    int r = a + b;
		    if (checkTypeOverFlow && ((a ^ r) & (b ^ r)) < 0) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'long/Long'", "'int/Integer'"));
		    }
		}
		
		public void checkedIADD(long a, long b, boolean checkTypeOverFlow, boolean checkUlp) {
		    long r = a + b;
		    if (checkTypeOverFlow && ((a ^ r) & (b ^ r)) < 0) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'BigDecimal'", "'long/Long'"));
		    }
		}
		
		public void checkedIADD(float a, float b, boolean checkTypeOverFlow, boolean checkUlp) {
		
			if(checkUlp) {
			    float minAddedValue = Math.ulp(a);
			    if (minAddedValue > Math.abs(b)) {
			        throw new RuntimeException(buildPrecisionMessage(String.valueOf(a), String.valueOf(b), "'double' or 'BigDecimal'", "'float/Float'"));
			    }
			}
			
		    if (checkTypeOverFlow && ((double) a + (double) b > (double) Float.MAX_VALUE) || ((double) a + (double) b < (double) -Float.MAX_VALUE)) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'double' or 'BigDecimal'", "'float/Float'"));
		    }
		}
		
		public void checkedIADD(double a, double b, boolean checkTypeOverFlow, boolean checkUlp) {
		
			if(checkUlp) {
			    double minAddedValue = Math.ulp(a);
			    if (minAddedValue > Math.abs(b)) {
			        throw new RuntimeException(buildPrecisionMessage(String.valueOf(a), String.valueOf(a), "'BigDecimal'", "'double/Double'"));
			    }
			}
		
		    if (checkTypeOverFlow && (a + b > (double) Double.MAX_VALUE) || (a + b < -Double.MAX_VALUE )) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'BigDecimal'", "'double/Double'"));
		    }
		}
		
		public void checkedIADD(double a, byte b, boolean checkTypeOverFlow, boolean checkUlp) {
		
		    if (checkTypeOverFlow && (a + b > (double) Double.MAX_VALUE) || (a + b < -Double.MAX_VALUE )) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'BigDecimal'", "'double/Double'"));
		    }
		}
		
		public void checkedIADD(double a, short b, boolean checkTypeOverFlow, boolean checkUlp) {
		
		    if (checkTypeOverFlow && (a + b > (double) Double.MAX_VALUE) || (a + b < -Double.MAX_VALUE )) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'BigDecimal'", "'double/Double'"));
		    }
		}
		
		public void checkedIADD(double a, int b, boolean checkTypeOverFlow, boolean checkUlp) {
		
		    if (checkTypeOverFlow && (a + b > (double) Double.MAX_VALUE) || (a + b < -Double.MAX_VALUE )) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'BigDecimal'", "'double/Double'"));
		    }
		}
		
		public void checkedIADD(double a, float b, boolean checkTypeOverFlow, boolean checkUlp) {
		
			if(checkUlp) {
			    double minAddedValue = Math.ulp(a);
			    if (minAddedValue > Math.abs(b)) {
			        throw new RuntimeException(buildPrecisionMessage(String.valueOf(a), String.valueOf(a), "'BigDecimal'", "'double/Double'"));
			    }
			}
		
		    if (checkTypeOverFlow && (a + b > (double) Double.MAX_VALUE) || (a + b < -Double.MAX_VALUE )) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'BigDecimal'", "'double/Double'"));
		    }
		}
		
		private String buildOverflowMessage(String a, String b, String advicedTypes, String originalType) {
		    return "Type overflow when adding " + b + " to " + a
		    + ", to resolve this problem, increase the precision by using "+ advicedTypes +" type in place of "+ originalType +".";
		}
		
		private String buildPrecisionMessage(String a, String b, String advicedTypes, String originalType) {
		    return "The double precision is unsufficient to add the value " + b + " to " + a
		    + ", to resolve this problem, increase the precision by using "+ advicedTypes +" type in place of "+ originalType +".";
		}

	} // G_OutBegin_AggR_144

	UtilClass_tAggregateRow_2 utilClass_tAggregateRow_2 = new UtilClass_tAggregateRow_2();

	

	class AggOperationStruct_tAggregateRow_2 { // G_OutBegin_AggR_100

		private static final int DEFAULT_HASHCODE = 1;
	    private static final int PRIME = 31;
	    private int hashCode = DEFAULT_HASHCODE;
	    public boolean hashCodeDirty = true;

    				String GID;int count = 0;
       			int count_clmCount = 0;
           			
        
	    @Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;
		
							result = prime * result + ((this.GID == null) ? 0 : this.GID.hashCode());
							
	    		this.hashCode = result;
	    		this.hashCodeDirty = false;		
			}
			return this.hashCode;
		}
		
		@Override
		public boolean equals(Object obj) {
			if (this == obj) return true;
			if (obj == null) return false;
			if (getClass() != obj.getClass()) return false;
			final AggOperationStruct_tAggregateRow_2 other = (AggOperationStruct_tAggregateRow_2) obj;
			
							if (this.GID == null) {
								if (other.GID != null) 
									return false;
							} else if (!this.GID.equals(other.GID)) 
								return false;
						
			
			return true;
		}
  
        
	} // G_OutBegin_AggR_100

	AggOperationStruct_tAggregateRow_2 operation_result_tAggregateRow_2 = null;
	AggOperationStruct_tAggregateRow_2 operation_finder_tAggregateRow_2 = new AggOperationStruct_tAggregateRow_2();
	java.util.Map<AggOperationStruct_tAggregateRow_2,AggOperationStruct_tAggregateRow_2> hash_tAggregateRow_2 = new java.util.HashMap<AggOperationStruct_tAggregateRow_2,AggOperationStruct_tAggregateRow_2>();
	

 



/**
 * [tAggregateRow_2_AGGOUT begin ] stop
 */



	
	/**
	 * [tFileOutputDelimited_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileOutputDelimited_5", false);
		start_Hash.put("tFileOutputDelimited_5", System.currentTimeMillis());
		
	
	currentComponent="tFileOutputDelimited_5";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row20");
			
		int tos_count_tFileOutputDelimited_5 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tFileOutputDelimited_5", "tFileOutputDelimited");
				talendJobLogProcess(globalMap);
			}
			

String fileName_tFileOutputDelimited_5 = "";
    fileName_tFileOutputDelimited_5 = (new java.io.File(context.location+"temp.csv")).getAbsolutePath().replace("\\","/");
    String fullName_tFileOutputDelimited_5 = null;
    String extension_tFileOutputDelimited_5 = null;
    String directory_tFileOutputDelimited_5 = null;
    if((fileName_tFileOutputDelimited_5.indexOf("/") != -1)) {
        if(fileName_tFileOutputDelimited_5.lastIndexOf(".") < fileName_tFileOutputDelimited_5.lastIndexOf("/")) {
            fullName_tFileOutputDelimited_5 = fileName_tFileOutputDelimited_5;
            extension_tFileOutputDelimited_5 = "";
        } else {
            fullName_tFileOutputDelimited_5 = fileName_tFileOutputDelimited_5.substring(0, fileName_tFileOutputDelimited_5.lastIndexOf("."));
            extension_tFileOutputDelimited_5 = fileName_tFileOutputDelimited_5.substring(fileName_tFileOutputDelimited_5.lastIndexOf("."));
        }
        directory_tFileOutputDelimited_5 = fileName_tFileOutputDelimited_5.substring(0, fileName_tFileOutputDelimited_5.lastIndexOf("/"));
    } else {
        if(fileName_tFileOutputDelimited_5.lastIndexOf(".") != -1) {
            fullName_tFileOutputDelimited_5 = fileName_tFileOutputDelimited_5.substring(0, fileName_tFileOutputDelimited_5.lastIndexOf("."));
            extension_tFileOutputDelimited_5 = fileName_tFileOutputDelimited_5.substring(fileName_tFileOutputDelimited_5.lastIndexOf("."));
        } else {
            fullName_tFileOutputDelimited_5 = fileName_tFileOutputDelimited_5;
            extension_tFileOutputDelimited_5 = "";
        }
        directory_tFileOutputDelimited_5 = "";
    }
    boolean isFileGenerated_tFileOutputDelimited_5 = true;
    java.io.File filetFileOutputDelimited_5 = new java.io.File(fileName_tFileOutputDelimited_5);
    globalMap.put("tFileOutputDelimited_5_FILE_NAME",fileName_tFileOutputDelimited_5);
            int nb_line_tFileOutputDelimited_5 = 0;
            int splitedFileNo_tFileOutputDelimited_5 = 0;
            int currentRow_tFileOutputDelimited_5 = 0;

            final String OUT_DELIM_tFileOutputDelimited_5 = /** Start field tFileOutputDelimited_5:FIELDSEPARATOR */";"/** End field tFileOutputDelimited_5:FIELDSEPARATOR */;

            final String OUT_DELIM_ROWSEP_tFileOutputDelimited_5 = /** Start field tFileOutputDelimited_5:ROWSEPARATOR */"\n"/** End field tFileOutputDelimited_5:ROWSEPARATOR */;

                    //create directory only if not exists
                    if(directory_tFileOutputDelimited_5 != null && directory_tFileOutputDelimited_5.trim().length() != 0) {
                        java.io.File dir_tFileOutputDelimited_5 = new java.io.File(directory_tFileOutputDelimited_5);
                        if(!dir_tFileOutputDelimited_5.exists()) {
                            dir_tFileOutputDelimited_5.mkdirs();
                        }
                    }

                        //routines.system.Row
                        java.io.Writer outtFileOutputDelimited_5 = null;

                        java.io.File fileToDelete_tFileOutputDelimited_5 = new java.io.File(fileName_tFileOutputDelimited_5);
                        if(fileToDelete_tFileOutputDelimited_5.exists()) {
                            fileToDelete_tFileOutputDelimited_5.delete();
                        }
                        outtFileOutputDelimited_5 = new java.io.BufferedWriter(new java.io.OutputStreamWriter(
                        new java.io.FileOutputStream(fileName_tFileOutputDelimited_5, false),"ISO-8859-15"));


        resourceMap.put("out_tFileOutputDelimited_5", outtFileOutputDelimited_5);
resourceMap.put("nb_line_tFileOutputDelimited_5", nb_line_tFileOutputDelimited_5);

 



/**
 * [tFileOutputDelimited_5 begin ] stop
 */



	
	/**
	 * [tLogRow_7 begin ] start
	 */

	

	
		
		ok_Hash.put("tLogRow_7", false);
		start_Hash.put("tLogRow_7", System.currentTimeMillis());
		
	
	currentComponent="tLogRow_7";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row19");
			
		int tos_count_tLogRow_7 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tLogRow_7", "tLogRow");
				talendJobLogProcess(globalMap);
			}
			

	///////////////////////
	
         class Util_tLogRow_7 {

        String[] des_top = { ".", ".", "-", "+" };

        String[] des_head = { "|=", "=|", "-", "+" };

        String[] des_bottom = { "'", "'", "-", "+" };

        String name="";

        java.util.List<String[]> list = new java.util.ArrayList<String[]>();

        int[] colLengths = new int[28];

        public void addRow(String[] row) {

            for (int i = 0; i < 28; i++) {
                if (row[i]!=null) {
                  colLengths[i] = Math.max(colLengths[i], row[i].length());
                }
            }
            list.add(row);
        }

        public void setTableName(String name) {

            this.name = name;
        }

            public StringBuilder format() {
            
                StringBuilder sb = new StringBuilder();
  
            
                    sb.append(print(des_top));
    
                    int totals = 0;
                    for (int i = 0; i < colLengths.length; i++) {
                        totals = totals + colLengths[i];
                    }
    
                    // name
                    sb.append("|");
                    int k = 0;
                    for (k = 0; k < (totals + 27 - name.length()) / 2; k++) {
                        sb.append(' ');
                    }
                    sb.append(name);
                    for (int i = 0; i < totals + 27 - name.length() - k; i++) {
                        sb.append(' ');
                    }
                    sb.append("|\n");

                    // head and rows
                    sb.append(print(des_head));
                    for (int i = 0; i < list.size(); i++) {
    
                        String[] row = list.get(i);
    
                        java.util.Formatter formatter = new java.util.Formatter(new StringBuilder());
                        
                        StringBuilder sbformat = new StringBuilder();                                             
        			        sbformat.append("|%1$-");
        			        sbformat.append(colLengths[0]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%2$-");
        			        sbformat.append(colLengths[1]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%3$-");
        			        sbformat.append(colLengths[2]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%4$-");
        			        sbformat.append(colLengths[3]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%5$-");
        			        sbformat.append(colLengths[4]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%6$-");
        			        sbformat.append(colLengths[5]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%7$-");
        			        sbformat.append(colLengths[6]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%8$-");
        			        sbformat.append(colLengths[7]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%9$-");
        			        sbformat.append(colLengths[8]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%10$-");
        			        sbformat.append(colLengths[9]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%11$-");
        			        sbformat.append(colLengths[10]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%12$-");
        			        sbformat.append(colLengths[11]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%13$-");
        			        sbformat.append(colLengths[12]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%14$-");
        			        sbformat.append(colLengths[13]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%15$-");
        			        sbformat.append(colLengths[14]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%16$-");
        			        sbformat.append(colLengths[15]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%17$-");
        			        sbformat.append(colLengths[16]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%18$-");
        			        sbformat.append(colLengths[17]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%19$-");
        			        sbformat.append(colLengths[18]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%20$-");
        			        sbformat.append(colLengths[19]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%21$-");
        			        sbformat.append(colLengths[20]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%22$-");
        			        sbformat.append(colLengths[21]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%23$-");
        			        sbformat.append(colLengths[22]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%24$-");
        			        sbformat.append(colLengths[23]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%25$-");
        			        sbformat.append(colLengths[24]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%26$-");
        			        sbformat.append(colLengths[25]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%27$-");
        			        sbformat.append(colLengths[26]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%28$-");
        			        sbformat.append(colLengths[27]);
        			        sbformat.append("s");
        			                      
                        sbformat.append("|\n");                    
       
                        formatter.format(sbformat.toString(), (Object[])row);	
                                
                        sb.append(formatter.toString());
                        if (i == 0)
                            sb.append(print(des_head)); // print the head
                    }
    
                    // end
                    sb.append(print(des_bottom));
                    return sb;
                }
            

            private StringBuilder print(String[] fillChars) {
                StringBuilder sb = new StringBuilder();
                //first column
                sb.append(fillChars[0]);                
                    for (int i = 0; i < colLengths[0] - fillChars[0].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);	                

                    for (int i = 0; i < colLengths[1] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[2] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[3] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[4] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[5] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[6] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[7] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[8] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[9] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[10] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[11] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[12] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[13] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[14] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[15] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[16] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[17] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[18] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[19] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[20] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[21] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[22] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[23] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[24] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[25] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[26] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                
                    //last column
                    for (int i = 0; i < colLengths[27] - fillChars[1].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }         
                sb.append(fillChars[1]);
                sb.append("\n");               
                return sb;
            }
            
            public boolean isTableEmpty(){
            	if (list.size() > 1)
            		return false;
            	return true;
            }
        }
        Util_tLogRow_7 util_tLogRow_7 = new Util_tLogRow_7();
        util_tLogRow_7.setTableName("tLogRow_7");
        util_tLogRow_7.addRow(new String[]{"Gender","Date","First_Name","Last_Name","State","City","Zip_Code","Address_Line_1","Address_Line_2","Phone_Number","Social_Security_Number","UPI_ID","MBI","Client_ID","Carrier_ID","Account_ID","Group_ID","Contract_Family_ID","Multi_Birth_Code","Member_Key","Source","year","GID","GRP_SIZE","MASTER","SCORE","GRP_QUALITY","MATCHING_DISTANCES",});        
 		StringBuilder strBuffer_tLogRow_7 = null;
		int nb_line_tLogRow_7 = 0;
///////////////////////    			



 



/**
 * [tLogRow_7 begin ] stop
 */



	
	/**
	 * [tMatchGroup_1_GroupIn begin ] start
	 */

	

	
		
		ok_Hash.put("tMatchGroup_1_GroupIn", false);
		start_Hash.put("tMatchGroup_1_GroupIn", System.currentTimeMillis());
		
	
		currentVirtualComponent = "tMatchGroup_1";
	
	currentComponent="tMatchGroup_1_GroupIn";

	
		int tos_count_tMatchGroup_1_GroupIn = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tMatchGroup_1_GroupIn", "tMatchGroupIn");
				talendJobLogProcess(globalMap);
			}
			


 



/**
 * [tMatchGroup_1_GroupIn begin ] stop
 */
	
	/**
	 * [tMatchGroup_1_GroupIn main ] start
	 */

	

	
	
		currentVirtualComponent = "tMatchGroup_1";
	
	currentComponent="tMatchGroup_1_GroupIn";

	
java.util.List<java.util.List<java.util.Map<String, String>>> matchingRulesAll_tMatchGroup_1 = new java.util.ArrayList<java.util.List<java.util.Map<String, String>>>();
java.util.List<java.util.Map<String, String>> matcherList_tMatchGroup_1 = null;
java.util.Map<String,String> tmpMap_tMatchGroup_1 =null;
java.util.Map<String,String> paramMapTmp_tMatchGroup_1 =null;
java.util.List<java.util.Map<String, String>> defaultSurvivorshipRules_tMatchGroup_1 = new java.util.ArrayList<java.util.Map<String, String>>();
java.util.List<java.util.Map<String, String>> particularSurvivorshipRules_tMatchGroup_1 = new java.util.ArrayList<java.util.Map<String, String>>();
        matcherList_tMatchGroup_1 = new java.util.ArrayList<java.util.Map<String, String>>();
                tmpMap_tMatchGroup_1=new java.util.HashMap<String,String>();
                       tmpMap_tMatchGroup_1.put("MATCHING_TYPE","Exact - ignore case");
                       tmpMap_tMatchGroup_1.put("RECORD_MATCH_THRESHOLD",0.90+"");
                       tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME","Address_Line_1");
                       tmpMap_tMatchGroup_1.put("SURVIVORSHIP_FUNCTION","Concatenate");
                       tmpMap_tMatchGroup_1.put("HANDLE_NULL","nullMatchNull");
                       tmpMap_tMatchGroup_1.put("ATTRIBUTE_THRESHOLD",1.0+"");
                       tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT",1+"");
                       tmpMap_tMatchGroup_1.put("COLUMN_IDX","7");
                       tmpMap_tMatchGroup_1.put("MATCHING_ALGORITHM","Simple VSR Matcher");
                       tmpMap_tMatchGroup_1.put("TOKENIZATION_TYPE","No");
                matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
                tmpMap_tMatchGroup_1=new java.util.HashMap<String,String>();
                       tmpMap_tMatchGroup_1.put("MATCHING_TYPE","Exact - ignore case");
                       tmpMap_tMatchGroup_1.put("RECORD_MATCH_THRESHOLD",0.90+"");
                       tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME","Address_Line_2");
                       tmpMap_tMatchGroup_1.put("SURVIVORSHIP_FUNCTION","Concatenate");
                       tmpMap_tMatchGroup_1.put("HANDLE_NULL","nullMatchNull");
                       tmpMap_tMatchGroup_1.put("ATTRIBUTE_THRESHOLD",1.0+"");
                       tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT",1+"");
                       tmpMap_tMatchGroup_1.put("COLUMN_IDX","8");
                       tmpMap_tMatchGroup_1.put("MATCHING_ALGORITHM","Simple VSR Matcher");
                       tmpMap_tMatchGroup_1.put("TOKENIZATION_TYPE","No");
                matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
                tmpMap_tMatchGroup_1=new java.util.HashMap<String,String>();
                       tmpMap_tMatchGroup_1.put("MATCHING_TYPE","Exact - ignore case");
                       tmpMap_tMatchGroup_1.put("RECORD_MATCH_THRESHOLD",0.90+"");
                       tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME","City");
                       tmpMap_tMatchGroup_1.put("SURVIVORSHIP_FUNCTION","Concatenate");
                       tmpMap_tMatchGroup_1.put("HANDLE_NULL","nullMatchNull");
                       tmpMap_tMatchGroup_1.put("ATTRIBUTE_THRESHOLD",1.0+"");
                       tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT",1+"");
                       tmpMap_tMatchGroup_1.put("COLUMN_IDX","5");
                       tmpMap_tMatchGroup_1.put("MATCHING_ALGORITHM","Simple VSR Matcher");
                       tmpMap_tMatchGroup_1.put("TOKENIZATION_TYPE","No");
                matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
                tmpMap_tMatchGroup_1=new java.util.HashMap<String,String>();
                       tmpMap_tMatchGroup_1.put("MATCHING_TYPE","Exact - ignore case");
                       tmpMap_tMatchGroup_1.put("RECORD_MATCH_THRESHOLD",0.90+"");
                       tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME","Date");
                       tmpMap_tMatchGroup_1.put("SURVIVORSHIP_FUNCTION","Concatenate");
                       tmpMap_tMatchGroup_1.put("HANDLE_NULL","nullMatchNull");
                       tmpMap_tMatchGroup_1.put("ATTRIBUTE_THRESHOLD",1.0+"");
                       tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT",1+"");
                       tmpMap_tMatchGroup_1.put("COLUMN_IDX","1");
                       tmpMap_tMatchGroup_1.put("MATCHING_ALGORITHM","Simple VSR Matcher");
                       tmpMap_tMatchGroup_1.put("TOKENIZATION_TYPE","No");
                matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
                tmpMap_tMatchGroup_1=new java.util.HashMap<String,String>();
                       tmpMap_tMatchGroup_1.put("MATCHING_TYPE","Exact - ignore case");
                       tmpMap_tMatchGroup_1.put("RECORD_MATCH_THRESHOLD",0.90+"");
                       tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME","First_Name");
                       tmpMap_tMatchGroup_1.put("SURVIVORSHIP_FUNCTION","Concatenate");
                       tmpMap_tMatchGroup_1.put("HANDLE_NULL","nullMatchNull");
                       tmpMap_tMatchGroup_1.put("ATTRIBUTE_THRESHOLD",1.0+"");
                       tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT",1+"");
                       tmpMap_tMatchGroup_1.put("COLUMN_IDX","2");
                       tmpMap_tMatchGroup_1.put("MATCHING_ALGORITHM","Simple VSR Matcher");
                       tmpMap_tMatchGroup_1.put("TOKENIZATION_TYPE","No");
                matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
                tmpMap_tMatchGroup_1=new java.util.HashMap<String,String>();
                       tmpMap_tMatchGroup_1.put("MATCHING_TYPE","Exact - ignore case");
                       tmpMap_tMatchGroup_1.put("RECORD_MATCH_THRESHOLD",0.90+"");
                       tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME","Gender");
                       tmpMap_tMatchGroup_1.put("SURVIVORSHIP_FUNCTION","Concatenate");
                       tmpMap_tMatchGroup_1.put("HANDLE_NULL","nullMatchNull");
                       tmpMap_tMatchGroup_1.put("ATTRIBUTE_THRESHOLD",1.0+"");
                       tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT",1+"");
                       tmpMap_tMatchGroup_1.put("COLUMN_IDX","0");
                       tmpMap_tMatchGroup_1.put("MATCHING_ALGORITHM","Simple VSR Matcher");
                       tmpMap_tMatchGroup_1.put("TOKENIZATION_TYPE","No");
                matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
                tmpMap_tMatchGroup_1=new java.util.HashMap<String,String>();
                       tmpMap_tMatchGroup_1.put("MATCHING_TYPE","Exact - ignore case");
                       tmpMap_tMatchGroup_1.put("RECORD_MATCH_THRESHOLD",0.90+"");
                       tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME","Last_Name");
                       tmpMap_tMatchGroup_1.put("SURVIVORSHIP_FUNCTION","Concatenate");
                       tmpMap_tMatchGroup_1.put("HANDLE_NULL","nullMatchNull");
                       tmpMap_tMatchGroup_1.put("ATTRIBUTE_THRESHOLD",1.0+"");
                       tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT",1+"");
                       tmpMap_tMatchGroup_1.put("COLUMN_IDX","3");
                       tmpMap_tMatchGroup_1.put("MATCHING_ALGORITHM","Simple VSR Matcher");
                       tmpMap_tMatchGroup_1.put("TOKENIZATION_TYPE","No");
                matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
                tmpMap_tMatchGroup_1=new java.util.HashMap<String,String>();
                       tmpMap_tMatchGroup_1.put("MATCHING_TYPE","Exact - ignore case");
                       tmpMap_tMatchGroup_1.put("RECORD_MATCH_THRESHOLD",0.90+"");
                       tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME","MBI");
                       tmpMap_tMatchGroup_1.put("SURVIVORSHIP_FUNCTION","Concatenate");
                       tmpMap_tMatchGroup_1.put("HANDLE_NULL","nullMatchAll");
                       tmpMap_tMatchGroup_1.put("ATTRIBUTE_THRESHOLD",1.0+"");
                       tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT",5+"");
                       tmpMap_tMatchGroup_1.put("COLUMN_IDX","12");
                       tmpMap_tMatchGroup_1.put("MATCHING_ALGORITHM","Simple VSR Matcher");
                       tmpMap_tMatchGroup_1.put("TOKENIZATION_TYPE","No");
                matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
                tmpMap_tMatchGroup_1=new java.util.HashMap<String,String>();
                       tmpMap_tMatchGroup_1.put("MATCHING_TYPE","Exact - ignore case");
                       tmpMap_tMatchGroup_1.put("RECORD_MATCH_THRESHOLD",0.90+"");
                       tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME","Social_Security_Number");
                       tmpMap_tMatchGroup_1.put("SURVIVORSHIP_FUNCTION","Concatenate");
                       tmpMap_tMatchGroup_1.put("HANDLE_NULL","nullMatchAll");
                       tmpMap_tMatchGroup_1.put("ATTRIBUTE_THRESHOLD",1.0+"");
                       tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT",5+"");
                       tmpMap_tMatchGroup_1.put("COLUMN_IDX","10");
                       tmpMap_tMatchGroup_1.put("MATCHING_ALGORITHM","Simple VSR Matcher");
                       tmpMap_tMatchGroup_1.put("TOKENIZATION_TYPE","No");
                matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
                tmpMap_tMatchGroup_1=new java.util.HashMap<String,String>();
                       tmpMap_tMatchGroup_1.put("MATCHING_TYPE","Exact - ignore case");
                       tmpMap_tMatchGroup_1.put("RECORD_MATCH_THRESHOLD",0.90+"");
                       tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME","State");
                       tmpMap_tMatchGroup_1.put("SURVIVORSHIP_FUNCTION","Concatenate");
                       tmpMap_tMatchGroup_1.put("HANDLE_NULL","nullMatchNull");
                       tmpMap_tMatchGroup_1.put("ATTRIBUTE_THRESHOLD",1.0+"");
                       tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT",1+"");
                       tmpMap_tMatchGroup_1.put("COLUMN_IDX","4");
                       tmpMap_tMatchGroup_1.put("MATCHING_ALGORITHM","Simple VSR Matcher");
                       tmpMap_tMatchGroup_1.put("TOKENIZATION_TYPE","No");
                matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
                tmpMap_tMatchGroup_1=new java.util.HashMap<String,String>();
                       tmpMap_tMatchGroup_1.put("MATCHING_TYPE","Exact - ignore case");
                       tmpMap_tMatchGroup_1.put("RECORD_MATCH_THRESHOLD",0.90+"");
                       tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME","Zip_Code");
                       tmpMap_tMatchGroup_1.put("SURVIVORSHIP_FUNCTION","Concatenate");
                       tmpMap_tMatchGroup_1.put("HANDLE_NULL","nullMatchNull");
                       tmpMap_tMatchGroup_1.put("ATTRIBUTE_THRESHOLD",1.0+"");
                       tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT",1+"");
                       tmpMap_tMatchGroup_1.put("COLUMN_IDX","6");
                       tmpMap_tMatchGroup_1.put("MATCHING_ALGORITHM","Simple VSR Matcher");
                       tmpMap_tMatchGroup_1.put("TOKENIZATION_TYPE","No");
                matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
                tmpMap_tMatchGroup_1=new java.util.HashMap<String,String>();
                       tmpMap_tMatchGroup_1.put("MATCHING_TYPE","Exact - ignore case");
                       tmpMap_tMatchGroup_1.put("RECORD_MATCH_THRESHOLD",0.90+"");
                       tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME","year");
                       tmpMap_tMatchGroup_1.put("SURVIVORSHIP_FUNCTION","Concatenate");
                       tmpMap_tMatchGroup_1.put("HANDLE_NULL","nullMatchNull");
                       tmpMap_tMatchGroup_1.put("ATTRIBUTE_THRESHOLD",1.0+"");
                       tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT",10+"");
                       tmpMap_tMatchGroup_1.put("COLUMN_IDX","21");
                       tmpMap_tMatchGroup_1.put("MATCHING_ALGORITHM","Simple VSR Matcher");
                       tmpMap_tMatchGroup_1.put("TOKENIZATION_TYPE","No");
                matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
                tmpMap_tMatchGroup_1=new java.util.HashMap<String,String>();
                       tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN_IDX","9");
                       tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN","Phone_Number");
                       tmpMap_tMatchGroup_1.put("MATCHING_TYPE","dummy");
                       tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME","Phone_Number");
                       tmpMap_tMatchGroup_1.put("COLUMN_IDX","9");
                       tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT",0+"");
                matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
                tmpMap_tMatchGroup_1=new java.util.HashMap<String,String>();
                       tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN_IDX","11");
                       tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN","UPI_ID");
                       tmpMap_tMatchGroup_1.put("MATCHING_TYPE","dummy");
                       tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME","UPI_ID");
                       tmpMap_tMatchGroup_1.put("COLUMN_IDX","11");
                       tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT",0+"");
                matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
                tmpMap_tMatchGroup_1=new java.util.HashMap<String,String>();
                       tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN_IDX","13");
                       tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN","Client_ID");
                       tmpMap_tMatchGroup_1.put("MATCHING_TYPE","dummy");
                       tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME","Client_ID");
                       tmpMap_tMatchGroup_1.put("COLUMN_IDX","13");
                       tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT",0+"");
                matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
                tmpMap_tMatchGroup_1=new java.util.HashMap<String,String>();
                       tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN_IDX","14");
                       tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN","Carrier_ID");
                       tmpMap_tMatchGroup_1.put("MATCHING_TYPE","dummy");
                       tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME","Carrier_ID");
                       tmpMap_tMatchGroup_1.put("COLUMN_IDX","14");
                       tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT",0+"");
                matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
                tmpMap_tMatchGroup_1=new java.util.HashMap<String,String>();
                       tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN_IDX","15");
                       tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN","Account_ID");
                       tmpMap_tMatchGroup_1.put("MATCHING_TYPE","dummy");
                       tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME","Account_ID");
                       tmpMap_tMatchGroup_1.put("COLUMN_IDX","15");
                       tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT",0+"");
                matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
                tmpMap_tMatchGroup_1=new java.util.HashMap<String,String>();
                       tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN_IDX","16");
                       tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN","Group_ID");
                       tmpMap_tMatchGroup_1.put("MATCHING_TYPE","dummy");
                       tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME","Group_ID");
                       tmpMap_tMatchGroup_1.put("COLUMN_IDX","16");
                       tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT",0+"");
                matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
                tmpMap_tMatchGroup_1=new java.util.HashMap<String,String>();
                       tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN_IDX","17");
                       tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN","Contract_Family_ID");
                       tmpMap_tMatchGroup_1.put("MATCHING_TYPE","dummy");
                       tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME","Contract_Family_ID");
                       tmpMap_tMatchGroup_1.put("COLUMN_IDX","17");
                       tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT",0+"");
                matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
                tmpMap_tMatchGroup_1=new java.util.HashMap<String,String>();
                       tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN_IDX","18");
                       tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN","Multi_Birth_Code");
                       tmpMap_tMatchGroup_1.put("MATCHING_TYPE","dummy");
                       tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME","Multi_Birth_Code");
                       tmpMap_tMatchGroup_1.put("COLUMN_IDX","18");
                       tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT",0+"");
                matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
                tmpMap_tMatchGroup_1=new java.util.HashMap<String,String>();
                       tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN_IDX","19");
                       tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN","Member_Key");
                       tmpMap_tMatchGroup_1.put("MATCHING_TYPE","dummy");
                       tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME","Member_Key");
                       tmpMap_tMatchGroup_1.put("COLUMN_IDX","19");
                       tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT",0+"");
                matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
                tmpMap_tMatchGroup_1=new java.util.HashMap<String,String>();
                       tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN_IDX","20");
                       tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN","Source");
                       tmpMap_tMatchGroup_1.put("MATCHING_TYPE","dummy");
                       tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME","Source");
                       tmpMap_tMatchGroup_1.put("COLUMN_IDX","20");
                       tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT",0+"");
                matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
        java.util.Collections.sort(matcherList_tMatchGroup_1,new Comparator<java.util.Map<String, String>>() {

            @Override
            public int compare(java.util.Map<String, String> map1, java.util.Map<String, String> map2) {

                return Integer.valueOf(map1.get("COLUMN_IDX")).compareTo(Integer.valueOf(map2.get("COLUMN_IDX")));
            }

        });
            matchingRulesAll_tMatchGroup_1.add(matcherList_tMatchGroup_1);
    java.util.Map<String,String> realSurShipMap_tMatchGroup_1=null;
    realSurShipMap_tMatchGroup_1=null;
if(matchingRulesAll_tMatchGroup_1.size()==0){
   //If no matching rules in external data, try to get to rule from JOIN_KEY table (which will be compatible to old version less than 5.3)    
}


row19Struct masterRow_tMatchGroup_1 = null; // a master-row in a group
row19Struct subRow_tMatchGroup_1 = null; // a sub-row in a group.
// key row
tMatchGroup_1Struct hashKey_copyOfdob = new tMatchGroup_1Struct();  
// rows respond to key row 
tMatchGroup_1Struct hashValue_copyOfdob = new tMatchGroup_1Struct();
java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap_tMatchGroup_1 = (java.util.concurrent.ConcurrentHashMap) globalMap.get("concurrentHashMap");
concurrentHashMap_tMatchGroup_1.putIfAbsent("gid_tMatchGroup_1", new java.util.concurrent.atomic.AtomicLong(0L));
java.util.concurrent.atomic.AtomicLong gid_tMatchGroup_1 = (java.util.concurrent.atomic.AtomicLong) concurrentHashMap_tMatchGroup_1.get("gid_tMatchGroup_1");
// master rows in a group
final java.util.List<row19Struct> masterRows_tMatchGroup_1 = new java.util.ArrayList<row19Struct>();
// all rows in a group 
final java.util.List<row19Struct> groupRows_tMatchGroup_1 = new java.util.ArrayList<row19Struct>();
// this Map key is MASTER GID,value is this MASTER index of all MASTERS.it will be used to get DUPLICATE GRP_QUALITY from MASTER and only in case of separate output.
final java.util.Map<String,Double> gID2GQMap_tMatchGroup_1 = new java.util.HashMap<String,Double>();
final double CONFIDENCE_THRESHOLD_tMatchGroup_1 = Double.valueOf(0.95);



//Long gid_tMatchGroup_1 = 0L;
boolean forceLoop_tMatchGroup_1 = (blockRows_copyOfdob.isEmpty());
        java.util.Iterator<tMatchGroup_1_2Struct> iter_tMatchGroup_1 = blockRows_copyOfdob.keySet().iterator();

//TDQ-9172 reuse JAVA API at here.


org.talend.dataquality.record.linkage.grouping.AbstractRecordGrouping<Object> recordGroupImp_tMatchGroup_1;
 recordGroupImp_tMatchGroup_1=new org.talend.dataquality.record.linkage.grouping.AbstractRecordGrouping<Object>(){
    @Override
    protected void outputRow(Object[] row) {
        row19Struct outStuct_tMatchGroup_1 = new row19Struct ();
        boolean isMaster=false; 
           
              if(0 <row.length){
                  outStuct_tMatchGroup_1.Gender=row[0]==null?null:(Character)row[0];
              }
              
           
              if(1 <row.length){
                  outStuct_tMatchGroup_1.Date=row[1]==null?null:(Date)row[1];
              }
              
           
              if(2 <row.length){
                  outStuct_tMatchGroup_1.First_Name=row[2]==null?null:(String)row[2];
              }
              
           
              if(3 <row.length){
                  outStuct_tMatchGroup_1.Last_Name=row[3]==null?null:(String)row[3];
              }
              
           
              if(4 <row.length){
                  outStuct_tMatchGroup_1.State=row[4]==null?null:(String)row[4];
              }
              
           
              if(5 <row.length){
                  outStuct_tMatchGroup_1.City=row[5]==null?null:(String)row[5];
              }
              
           
              if(6 <row.length){
                  outStuct_tMatchGroup_1.Zip_Code=row[6]==null?null:(String)row[6];
              }
              
           
              if(7 <row.length){
                  outStuct_tMatchGroup_1.Address_Line_1=row[7]==null?null:(String)row[7];
              }
              
           
              if(8 <row.length){
                  outStuct_tMatchGroup_1.Address_Line_2=row[8]==null?null:(String)row[8];
              }
              
           
              if(9 <row.length){
                  outStuct_tMatchGroup_1.Phone_Number=row[9]==null?null:(String)row[9];
              }
              
           
              if(10 <row.length){
                  outStuct_tMatchGroup_1.Social_Security_Number=row[10]==null?null:(String)row[10];
              }
              
           
              if(11 <row.length){
                  outStuct_tMatchGroup_1.UPI_ID=row[11]==null?null:(String)row[11];
              }
              
           
              if(12 <row.length){
                  outStuct_tMatchGroup_1.MBI=row[12]==null?null:(String)row[12];
              }
              
           
              if(13 <row.length){
                  outStuct_tMatchGroup_1.Client_ID=row[13]==null?null:(String)row[13];
              }
              
           
              if(14 <row.length){
                  outStuct_tMatchGroup_1.Carrier_ID=row[14]==null?null:(String)row[14];
              }
              
           
              if(15 <row.length){
                  outStuct_tMatchGroup_1.Account_ID=row[15]==null?null:(String)row[15];
              }
              
           
              if(16 <row.length){
                  outStuct_tMatchGroup_1.Group_ID=row[16]==null?null:(String)row[16];
              }
              
           
              if(17 <row.length){
                  outStuct_tMatchGroup_1.Contract_Family_ID=row[17]==null?null:(String)row[17];
              }
              
           
              if(18 <row.length){
                  outStuct_tMatchGroup_1.Multi_Birth_Code=row[18]==null?null:(String)row[18];
              }
              
           
              if(19 <row.length){
                  outStuct_tMatchGroup_1.Member_Key=row[19]==null?null:(String)row[19];
              }
              
           
              if(20 <row.length){
                  outStuct_tMatchGroup_1.Source=row[20]==null?null:(String)row[20];
              }
              
           
              if(21 <row.length){
                  outStuct_tMatchGroup_1.year=row[21]==null?null:(Date)row[21];
              }
              
           
              if(22 <row.length){
                  outStuct_tMatchGroup_1.GID=row[22]==null?null:(String)row[22];
              }
              
           
              if(23 <row.length){
                  outStuct_tMatchGroup_1.GRP_SIZE=row[23]==null?null:(Integer)row[23];
              }
              
           
              if(24 <row.length){
                  outStuct_tMatchGroup_1.MASTER=row[24]==null?null:(Boolean)row[24];
              }
              
           
              if(25 <row.length){
                  outStuct_tMatchGroup_1.SCORE=row[25]==null?null:(Double)row[25];
              }
              
           
              if(26 <row.length){
                  outStuct_tMatchGroup_1.GRP_QUALITY=row[26]==null?null:(Double)row[26];
              }
              
           
              if(27 <row.length){
                  outStuct_tMatchGroup_1.MATCHING_DISTANCES=row[27]==null?null:(String)row[27];
              }
              
          if(outStuct_tMatchGroup_1.MASTER==true){
             masterRows_tMatchGroup_1.add(outStuct_tMatchGroup_1);
         }else{
             groupRows_tMatchGroup_1.add(outStuct_tMatchGroup_1);
         }
    }
    @Override
    protected boolean isMaster(Object col) {
        return String.valueOf(col).equals("true");
    }
    @Override
    protected Object incrementGroupSize(Object oldGroupSize) {
        return Integer.parseInt(String.valueOf(oldGroupSize)) + 1;
    }
    @Override
    protected Object[] createTYPEArray(int size) {
        return  new Object[size];
    }
    @Override
    protected Object castAsType(Object objectValue) {
        return objectValue;
    }
   @Override
   protected void outputRow(org.talend.dataquality.record.linkage.grouping.swoosh.RichRecord row) {
       // No implementation temporarily.

   }      
};
recordGroupImp_tMatchGroup_1.setOrginalInputColumnSize(22);

recordGroupImp_tMatchGroup_1.setColumnDelimiter(";");
recordGroupImp_tMatchGroup_1.setIsOutputDistDetails(true);

recordGroupImp_tMatchGroup_1.setAcceptableThreshold(Float.valueOf(0.85+""));
recordGroupImp_tMatchGroup_1.setIsLinkToPrevious(false&&true);
recordGroupImp_tMatchGroup_1.setIsDisplayAttLabels(false);
recordGroupImp_tMatchGroup_1.setIsGIDStringType("true".equals("true")?true :false);
recordGroupImp_tMatchGroup_1.setIsPassOriginalValue(false&&false);
recordGroupImp_tMatchGroup_1.setIsStoreOndisk(false);
gID2GQMap_tMatchGroup_1.clear();

while (iter_tMatchGroup_1.hasNext() || forceLoop_tMatchGroup_1){ // C_01

  if (forceLoop_tMatchGroup_1){
    forceLoop_tMatchGroup_1 = false;
  } else {
    // block existing

  }
  tHash_Lookup_copyOfdob.lookup(hashKey_copyOfdob);
  masterRows_tMatchGroup_1.clear();
  groupRows_tMatchGroup_1.clear();
  
  
  //add mutch rules
  for(java.util.List<java.util.Map<String, String>> matcherList:matchingRulesAll_tMatchGroup_1){
     recordGroupImp_tMatchGroup_1.addMatchRule(matcherList);
  }
  recordGroupImp_tMatchGroup_1.initialize();
 
  while (tHash_Lookup_copyOfdob.hasNext()){  // loop on each data in one block
    hashValue_copyOfdob = tHash_Lookup_copyOfdob.next();
    // set the a loop data into inputTexts one column by one column. 
    java.util.List<Object> inputTexts=new java.util.ArrayList<Object>();
          inputTexts.add(hashValue_copyOfdob.Gender);
          
          inputTexts.add(hashValue_copyOfdob.Date);
          
          inputTexts.add(hashValue_copyOfdob.First_Name);
          
          inputTexts.add(hashValue_copyOfdob.Last_Name);
          
          inputTexts.add(hashValue_copyOfdob.State);
          
          inputTexts.add(hashValue_copyOfdob.City);
          
          inputTexts.add(hashValue_copyOfdob.Zip_Code);
          
          inputTexts.add(hashValue_copyOfdob.Address_Line_1);
          
          inputTexts.add(hashValue_copyOfdob.Address_Line_2);
          
          inputTexts.add(hashValue_copyOfdob.Phone_Number);
          
          inputTexts.add(hashValue_copyOfdob.Social_Security_Number);
          
          inputTexts.add(hashValue_copyOfdob.UPI_ID);
          
          inputTexts.add(hashValue_copyOfdob.MBI);
          
          inputTexts.add(hashValue_copyOfdob.Client_ID);
          
          inputTexts.add(hashValue_copyOfdob.Carrier_ID);
          
          inputTexts.add(hashValue_copyOfdob.Account_ID);
          
          inputTexts.add(hashValue_copyOfdob.Group_ID);
          
          inputTexts.add(hashValue_copyOfdob.Contract_Family_ID);
          
          inputTexts.add(hashValue_copyOfdob.Multi_Birth_Code);
          
          inputTexts.add(hashValue_copyOfdob.Member_Key);
          
          inputTexts.add(hashValue_copyOfdob.Source);
          
          inputTexts.add(hashValue_copyOfdob.year);
          
    
    recordGroupImp_tMatchGroup_1.doGroup((Object[]) inputTexts.toArray(new Object[inputTexts.size()]));
    
  } // while

  recordGroupImp_tMatchGroup_1.end();
  groupRows_tMatchGroup_1.addAll(masterRows_tMatchGroup_1);
    
    java.util.Collections.sort(groupRows_tMatchGroup_1, 
      new Comparator<row19Struct>(){
        public int compare(row19Struct row1, row19Struct row2){
          if (!(row1.GID).equals(row2.GID)){
            return (row1.GID).compareTo(row2.GID);
          } else {
            // false < true
            return (row2.MASTER).compareTo(row1.MASTER); 
          }
        }
      }
    );

  // output data
  for (row19Struct out_tMatchGroup_1 : groupRows_tMatchGroup_1){ // C_02
  
    if (out_tMatchGroup_1 != null){ // C_03


      // all output
      row19 = new row19Struct(); 
          row19.Gender = out_tMatchGroup_1.Gender; 
          row19.Date = out_tMatchGroup_1.Date; 
          row19.First_Name = out_tMatchGroup_1.First_Name; 
          row19.Last_Name = out_tMatchGroup_1.Last_Name; 
          row19.State = out_tMatchGroup_1.State; 
          row19.City = out_tMatchGroup_1.City; 
          row19.Zip_Code = out_tMatchGroup_1.Zip_Code; 
          row19.Address_Line_1 = out_tMatchGroup_1.Address_Line_1; 
          row19.Address_Line_2 = out_tMatchGroup_1.Address_Line_2; 
          row19.Phone_Number = out_tMatchGroup_1.Phone_Number; 
          row19.Social_Security_Number = out_tMatchGroup_1.Social_Security_Number; 
          row19.UPI_ID = out_tMatchGroup_1.UPI_ID; 
          row19.MBI = out_tMatchGroup_1.MBI; 
          row19.Client_ID = out_tMatchGroup_1.Client_ID; 
          row19.Carrier_ID = out_tMatchGroup_1.Carrier_ID; 
          row19.Account_ID = out_tMatchGroup_1.Account_ID; 
          row19.Group_ID = out_tMatchGroup_1.Group_ID; 
          row19.Contract_Family_ID = out_tMatchGroup_1.Contract_Family_ID; 
          row19.Multi_Birth_Code = out_tMatchGroup_1.Multi_Birth_Code; 
          row19.Member_Key = out_tMatchGroup_1.Member_Key; 
          row19.Source = out_tMatchGroup_1.Source; 
          row19.year = out_tMatchGroup_1.year; 
          row19.GID = out_tMatchGroup_1.GID; 
          row19.GRP_SIZE = out_tMatchGroup_1.GRP_SIZE; 
          row19.MASTER = out_tMatchGroup_1.MASTER; 
          row19.SCORE = out_tMatchGroup_1.SCORE; 
          row19.GRP_QUALITY = out_tMatchGroup_1.GRP_QUALITY; 
          row19.MATCHING_DISTANCES = out_tMatchGroup_1.MATCHING_DISTANCES;
 


	tos_count_tMatchGroup_1_GroupIn++;

/**
 * [tMatchGroup_1_GroupIn main ] stop
 */
	
	/**
	 * [tMatchGroup_1_GroupIn process_data_begin ] start
	 */

	

	
	
		currentVirtualComponent = "tMatchGroup_1";
	
	currentComponent="tMatchGroup_1_GroupIn";

	

 



/**
 * [tMatchGroup_1_GroupIn process_data_begin ] stop
 */
// Start of branch "row19"
if(row19 != null) { 



	
	/**
	 * [tLogRow_7 main ] start
	 */

	

	
	
	currentComponent="tLogRow_7";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"row19");
			
///////////////////////		
						

				
				String[] row_tLogRow_7 = new String[28];
   				
	    		if(row19.Gender != null) { //              
                 row_tLogRow_7[0]=    						    
				                String.valueOf(row19.Gender)			
					          ;	
							
	    		} //			
    			   				
	    		if(row19.Date != null) { //              
                 row_tLogRow_7[1]=    						
								FormatterUtils.format_Date(row19.Date, "yyyy-dd-MM")
					          ;	
							
	    		} //			
    			   				
	    		if(row19.First_Name != null) { //              
                 row_tLogRow_7[2]=    						    
				                String.valueOf(row19.First_Name)			
					          ;	
							
	    		} //			
    			   				
	    		if(row19.Last_Name != null) { //              
                 row_tLogRow_7[3]=    						    
				                String.valueOf(row19.Last_Name)			
					          ;	
							
	    		} //			
    			   				
	    		if(row19.State != null) { //              
                 row_tLogRow_7[4]=    						    
				                String.valueOf(row19.State)			
					          ;	
							
	    		} //			
    			   				
	    		if(row19.City != null) { //              
                 row_tLogRow_7[5]=    						    
				                String.valueOf(row19.City)			
					          ;	
							
	    		} //			
    			   				
	    		if(row19.Zip_Code != null) { //              
                 row_tLogRow_7[6]=    						    
				                String.valueOf(row19.Zip_Code)			
					          ;	
							
	    		} //			
    			   				
	    		if(row19.Address_Line_1 != null) { //              
                 row_tLogRow_7[7]=    						    
				                String.valueOf(row19.Address_Line_1)			
					          ;	
							
	    		} //			
    			   				
	    		if(row19.Address_Line_2 != null) { //              
                 row_tLogRow_7[8]=    						    
				                String.valueOf(row19.Address_Line_2)			
					          ;	
							
	    		} //			
    			   				
	    		if(row19.Phone_Number != null) { //              
                 row_tLogRow_7[9]=    						    
				                String.valueOf(row19.Phone_Number)			
					          ;	
							
	    		} //			
    			   				
	    		if(row19.Social_Security_Number != null) { //              
                 row_tLogRow_7[10]=    						    
				                String.valueOf(row19.Social_Security_Number)			
					          ;	
							
	    		} //			
    			   				
	    		if(row19.UPI_ID != null) { //              
                 row_tLogRow_7[11]=    						    
				                String.valueOf(row19.UPI_ID)			
					          ;	
							
	    		} //			
    			   				
	    		if(row19.MBI != null) { //              
                 row_tLogRow_7[12]=    						    
				                String.valueOf(row19.MBI)			
					          ;	
							
	    		} //			
    			   				
	    		if(row19.Client_ID != null) { //              
                 row_tLogRow_7[13]=    						    
				                String.valueOf(row19.Client_ID)			
					          ;	
							
	    		} //			
    			   				
	    		if(row19.Carrier_ID != null) { //              
                 row_tLogRow_7[14]=    						    
				                String.valueOf(row19.Carrier_ID)			
					          ;	
							
	    		} //			
    			   				
	    		if(row19.Account_ID != null) { //              
                 row_tLogRow_7[15]=    						    
				                String.valueOf(row19.Account_ID)			
					          ;	
							
	    		} //			
    			   				
	    		if(row19.Group_ID != null) { //              
                 row_tLogRow_7[16]=    						    
				                String.valueOf(row19.Group_ID)			
					          ;	
							
	    		} //			
    			   				
	    		if(row19.Contract_Family_ID != null) { //              
                 row_tLogRow_7[17]=    						    
				                String.valueOf(row19.Contract_Family_ID)			
					          ;	
							
	    		} //			
    			   				
	    		if(row19.Multi_Birth_Code != null) { //              
                 row_tLogRow_7[18]=    						    
				                String.valueOf(row19.Multi_Birth_Code)			
					          ;	
							
	    		} //			
    			   				
	    		if(row19.Member_Key != null) { //              
                 row_tLogRow_7[19]=    						    
				                String.valueOf(row19.Member_Key)			
					          ;	
							
	    		} //			
    			   				
	    		if(row19.Source != null) { //              
                 row_tLogRow_7[20]=    						    
				                String.valueOf(row19.Source)			
					          ;	
							
	    		} //			
    			   				
	    		if(row19.year != null) { //              
                 row_tLogRow_7[21]=    						
								FormatterUtils.format_Date(row19.year, "dd-MM-yyyy")
					          ;	
							
	    		} //			
    			   				
	    		if(row19.GID != null) { //              
                 row_tLogRow_7[22]=    						    
				                String.valueOf(row19.GID)			
					          ;	
							
	    		} //			
    			   				
	    		if(row19.GRP_SIZE != null) { //              
                 row_tLogRow_7[23]=    						    
				                String.valueOf(row19.GRP_SIZE)			
					          ;	
							
	    		} //			
    			   				
	    		if(row19.MASTER != null) { //              
                 row_tLogRow_7[24]=    						    
				                String.valueOf(row19.MASTER)			
					          ;	
							
	    		} //			
    			   				
	    		if(row19.SCORE != null) { //              
                 row_tLogRow_7[25]=    						
								FormatterUtils.formatUnwithE(row19.SCORE)
					          ;	
							
	    		} //			
    			   				
	    		if(row19.GRP_QUALITY != null) { //              
                 row_tLogRow_7[26]=    						
								FormatterUtils.formatUnwithE(row19.GRP_QUALITY)
					          ;	
							
	    		} //			
    			   				
	    		if(row19.MATCHING_DISTANCES != null) { //              
                 row_tLogRow_7[27]=    						    
				                String.valueOf(row19.MATCHING_DISTANCES)			
					          ;	
							
	    		} //			
    			 

				util_tLogRow_7.addRow(row_tLogRow_7);	
				nb_line_tLogRow_7++;
//////

//////                    
                    
///////////////////////    			

 
     row20 = row19;


	tos_count_tLogRow_7++;

/**
 * [tLogRow_7 main ] stop
 */
	
	/**
	 * [tLogRow_7 process_data_begin ] start
	 */

	

	
	
	currentComponent="tLogRow_7";

	

 



/**
 * [tLogRow_7 process_data_begin ] stop
 */

	
	/**
	 * [tFileOutputDelimited_5 main ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_5";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"row20");
			


                    StringBuilder sb_tFileOutputDelimited_5 = new StringBuilder();
                            if(row20.Gender != null) {
                        sb_tFileOutputDelimited_5.append(
                            row20.Gender
                        );
                            }
                            sb_tFileOutputDelimited_5.append(OUT_DELIM_tFileOutputDelimited_5);
                            if(row20.Date != null) {
                        sb_tFileOutputDelimited_5.append(
                            FormatterUtils.format_Date(row20.Date, "yyyy-dd-MM")
                        );
                            }
                            sb_tFileOutputDelimited_5.append(OUT_DELIM_tFileOutputDelimited_5);
                            if(row20.First_Name != null) {
                        sb_tFileOutputDelimited_5.append(
                            row20.First_Name
                        );
                            }
                            sb_tFileOutputDelimited_5.append(OUT_DELIM_tFileOutputDelimited_5);
                            if(row20.Last_Name != null) {
                        sb_tFileOutputDelimited_5.append(
                            row20.Last_Name
                        );
                            }
                            sb_tFileOutputDelimited_5.append(OUT_DELIM_tFileOutputDelimited_5);
                            if(row20.State != null) {
                        sb_tFileOutputDelimited_5.append(
                            row20.State
                        );
                            }
                            sb_tFileOutputDelimited_5.append(OUT_DELIM_tFileOutputDelimited_5);
                            if(row20.City != null) {
                        sb_tFileOutputDelimited_5.append(
                            row20.City
                        );
                            }
                            sb_tFileOutputDelimited_5.append(OUT_DELIM_tFileOutputDelimited_5);
                            if(row20.Zip_Code != null) {
                        sb_tFileOutputDelimited_5.append(
                            row20.Zip_Code
                        );
                            }
                            sb_tFileOutputDelimited_5.append(OUT_DELIM_tFileOutputDelimited_5);
                            if(row20.Address_Line_1 != null) {
                        sb_tFileOutputDelimited_5.append(
                            row20.Address_Line_1
                        );
                            }
                            sb_tFileOutputDelimited_5.append(OUT_DELIM_tFileOutputDelimited_5);
                            if(row20.Address_Line_2 != null) {
                        sb_tFileOutputDelimited_5.append(
                            row20.Address_Line_2
                        );
                            }
                            sb_tFileOutputDelimited_5.append(OUT_DELIM_tFileOutputDelimited_5);
                            if(row20.Phone_Number != null) {
                        sb_tFileOutputDelimited_5.append(
                            row20.Phone_Number
                        );
                            }
                            sb_tFileOutputDelimited_5.append(OUT_DELIM_tFileOutputDelimited_5);
                            if(row20.Social_Security_Number != null) {
                        sb_tFileOutputDelimited_5.append(
                            row20.Social_Security_Number
                        );
                            }
                            sb_tFileOutputDelimited_5.append(OUT_DELIM_tFileOutputDelimited_5);
                            if(row20.UPI_ID != null) {
                        sb_tFileOutputDelimited_5.append(
                            row20.UPI_ID
                        );
                            }
                            sb_tFileOutputDelimited_5.append(OUT_DELIM_tFileOutputDelimited_5);
                            if(row20.MBI != null) {
                        sb_tFileOutputDelimited_5.append(
                            row20.MBI
                        );
                            }
                            sb_tFileOutputDelimited_5.append(OUT_DELIM_tFileOutputDelimited_5);
                            if(row20.Client_ID != null) {
                        sb_tFileOutputDelimited_5.append(
                            row20.Client_ID
                        );
                            }
                            sb_tFileOutputDelimited_5.append(OUT_DELIM_tFileOutputDelimited_5);
                            if(row20.Carrier_ID != null) {
                        sb_tFileOutputDelimited_5.append(
                            row20.Carrier_ID
                        );
                            }
                            sb_tFileOutputDelimited_5.append(OUT_DELIM_tFileOutputDelimited_5);
                            if(row20.Account_ID != null) {
                        sb_tFileOutputDelimited_5.append(
                            row20.Account_ID
                        );
                            }
                            sb_tFileOutputDelimited_5.append(OUT_DELIM_tFileOutputDelimited_5);
                            if(row20.Group_ID != null) {
                        sb_tFileOutputDelimited_5.append(
                            row20.Group_ID
                        );
                            }
                            sb_tFileOutputDelimited_5.append(OUT_DELIM_tFileOutputDelimited_5);
                            if(row20.Contract_Family_ID != null) {
                        sb_tFileOutputDelimited_5.append(
                            row20.Contract_Family_ID
                        );
                            }
                            sb_tFileOutputDelimited_5.append(OUT_DELIM_tFileOutputDelimited_5);
                            if(row20.Multi_Birth_Code != null) {
                        sb_tFileOutputDelimited_5.append(
                            row20.Multi_Birth_Code
                        );
                            }
                            sb_tFileOutputDelimited_5.append(OUT_DELIM_tFileOutputDelimited_5);
                            if(row20.Member_Key != null) {
                        sb_tFileOutputDelimited_5.append(
                            row20.Member_Key
                        );
                            }
                            sb_tFileOutputDelimited_5.append(OUT_DELIM_tFileOutputDelimited_5);
                            if(row20.Source != null) {
                        sb_tFileOutputDelimited_5.append(
                            row20.Source
                        );
                            }
                            sb_tFileOutputDelimited_5.append(OUT_DELIM_tFileOutputDelimited_5);
                            if(row20.year != null) {
                        sb_tFileOutputDelimited_5.append(
                            FormatterUtils.format_Date(row20.year, "dd-MM-yyyy")
                        );
                            }
                            sb_tFileOutputDelimited_5.append(OUT_DELIM_tFileOutputDelimited_5);
                            if(row20.GID != null) {
                        sb_tFileOutputDelimited_5.append(
                            row20.GID
                        );
                            }
                            sb_tFileOutputDelimited_5.append(OUT_DELIM_tFileOutputDelimited_5);
                            if(row20.GRP_SIZE != null) {
                        sb_tFileOutputDelimited_5.append(
                            row20.GRP_SIZE
                        );
                            }
                            sb_tFileOutputDelimited_5.append(OUT_DELIM_tFileOutputDelimited_5);
                            if(row20.MASTER != null) {
                        sb_tFileOutputDelimited_5.append(
                            row20.MASTER
                        );
                            }
                            sb_tFileOutputDelimited_5.append(OUT_DELIM_tFileOutputDelimited_5);
                            if(row20.SCORE != null) {
                        sb_tFileOutputDelimited_5.append(
                            row20.SCORE
                        );
                            }
                            sb_tFileOutputDelimited_5.append(OUT_DELIM_tFileOutputDelimited_5);
                            if(row20.GRP_QUALITY != null) {
                        sb_tFileOutputDelimited_5.append(
                            row20.GRP_QUALITY
                        );
                            }
                            sb_tFileOutputDelimited_5.append(OUT_DELIM_tFileOutputDelimited_5);
                            if(row20.MATCHING_DISTANCES != null) {
                        sb_tFileOutputDelimited_5.append(
                            row20.MATCHING_DISTANCES
                        );
                            }
                    sb_tFileOutputDelimited_5.append(OUT_DELIM_ROWSEP_tFileOutputDelimited_5);


                    nb_line_tFileOutputDelimited_5++;
                    resourceMap.put("nb_line_tFileOutputDelimited_5", nb_line_tFileOutputDelimited_5);

                        outtFileOutputDelimited_5.write(sb_tFileOutputDelimited_5.toString());




 
     row21 = row20;


	tos_count_tFileOutputDelimited_5++;

/**
 * [tFileOutputDelimited_5 main ] stop
 */
	
	/**
	 * [tFileOutputDelimited_5 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_5";

	

 



/**
 * [tFileOutputDelimited_5 process_data_begin ] stop
 */

	
	/**
	 * [tAggregateRow_2_AGGOUT main ] start
	 */

	

	
	
		currentVirtualComponent = "tAggregateRow_2";
	
	currentComponent="tAggregateRow_2_AGGOUT";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"row21");
			
	
operation_finder_tAggregateRow_2.GID = row21.GID;
			

	operation_finder_tAggregateRow_2.hashCodeDirty = true;
	
	operation_result_tAggregateRow_2 = hash_tAggregateRow_2.get(operation_finder_tAggregateRow_2);

	

	if(operation_result_tAggregateRow_2 == null) { // G_OutMain_AggR_001

		operation_result_tAggregateRow_2 = new AggOperationStruct_tAggregateRow_2();

		operation_result_tAggregateRow_2.GID = operation_finder_tAggregateRow_2.GID;
				
		
		

		hash_tAggregateRow_2.put(operation_result_tAggregateRow_2, operation_result_tAggregateRow_2);
	
	} // G_OutMain_AggR_001


	
				operation_result_tAggregateRow_2.count_clmCount++;
				operation_result_tAggregateRow_2.count++;
				


 


	tos_count_tAggregateRow_2_AGGOUT++;

/**
 * [tAggregateRow_2_AGGOUT main ] stop
 */
	
	/**
	 * [tAggregateRow_2_AGGOUT process_data_begin ] start
	 */

	

	
	
		currentVirtualComponent = "tAggregateRow_2";
	
	currentComponent="tAggregateRow_2_AGGOUT";

	

 



/**
 * [tAggregateRow_2_AGGOUT process_data_begin ] stop
 */
	
	/**
	 * [tAggregateRow_2_AGGOUT process_data_end ] start
	 */

	

	
	
		currentVirtualComponent = "tAggregateRow_2";
	
	currentComponent="tAggregateRow_2_AGGOUT";

	

 



/**
 * [tAggregateRow_2_AGGOUT process_data_end ] stop
 */



	
	/**
	 * [tFileOutputDelimited_5 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_5";

	

 



/**
 * [tFileOutputDelimited_5 process_data_end ] stop
 */



	
	/**
	 * [tLogRow_7 process_data_end ] start
	 */

	

	
	
	currentComponent="tLogRow_7";

	

 



/**
 * [tLogRow_7 process_data_end ] stop
 */

} // End of branch "row19"



	
		} // C_03
		
		} // C_02
		
		} // C_01
	
	
	/**
	 * [tMatchGroup_1_GroupIn process_data_end ] start
	 */

	

	
	
		currentVirtualComponent = "tMatchGroup_1";
	
	currentComponent="tMatchGroup_1_GroupIn";

	

 



/**
 * [tMatchGroup_1_GroupIn process_data_end ] stop
 */
	
	/**
	 * [tMatchGroup_1_GroupIn end ] start
	 */

	

	
	
		currentVirtualComponent = "tMatchGroup_1";
	
	currentComponent="tMatchGroup_1_GroupIn";

	
blockRows_copyOfdob.clear();
blockRows_copyOfdob = null;
masterRows_tMatchGroup_1.clear();
groupRows_tMatchGroup_1.clear();

if (tHash_Lookup_copyOfdob != null) {
  tHash_Lookup_copyOfdob.endGet();
}
globalMap.remove("tHash_Lookup_copyOfdob");
 

ok_Hash.put("tMatchGroup_1_GroupIn", true);
end_Hash.put("tMatchGroup_1_GroupIn", System.currentTimeMillis());




/**
 * [tMatchGroup_1_GroupIn end ] stop
 */

	
	/**
	 * [tLogRow_7 end ] start
	 */

	

	
	
	currentComponent="tLogRow_7";

	


//////

                    
                    java.io.PrintStream consoleOut_tLogRow_7 = null;
                    if (globalMap.get("tLogRow_CONSOLE")!=null)
                    {
                    	consoleOut_tLogRow_7 = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
                    }
                    else
                    {
                    	consoleOut_tLogRow_7 = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
                    	globalMap.put("tLogRow_CONSOLE",consoleOut_tLogRow_7);
                    }
                    
                    consoleOut_tLogRow_7.println(util_tLogRow_7.format().toString());
                    consoleOut_tLogRow_7.flush();
//////
globalMap.put("tLogRow_7_NB_LINE",nb_line_tLogRow_7);

///////////////////////    			

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row19",2,0,
			 			talendJobLog,"tMatchGroup_1_GroupIn","tMatchGroupIn","tLogRow_7","tLogRow","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tLogRow_7", true);
end_Hash.put("tLogRow_7", System.currentTimeMillis());




/**
 * [tLogRow_7 end ] stop
 */

	
	/**
	 * [tFileOutputDelimited_5 end ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_5";

	



		
			
					if(outtFileOutputDelimited_5!=null) {
						outtFileOutputDelimited_5.flush();
						outtFileOutputDelimited_5.close();
					}
				
				globalMap.put("tFileOutputDelimited_5_NB_LINE",nb_line_tFileOutputDelimited_5);
				globalMap.put("tFileOutputDelimited_5_FILE_NAME",fileName_tFileOutputDelimited_5);
			
		
		
		resourceMap.put("finish_tFileOutputDelimited_5", true);
	

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row20",2,0,
			 			talendJobLog,"tLogRow_7","tLogRow","tFileOutputDelimited_5","tFileOutputDelimited","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tFileOutputDelimited_5", true);
end_Hash.put("tFileOutputDelimited_5", System.currentTimeMillis());




/**
 * [tFileOutputDelimited_5 end ] stop
 */

	
	/**
	 * [tAggregateRow_2_AGGOUT end ] start
	 */

	

	
	
		currentVirtualComponent = "tAggregateRow_2";
	
	currentComponent="tAggregateRow_2_AGGOUT";

	

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row21",2,0,
			 			talendJobLog,"tFileOutputDelimited_5","tFileOutputDelimited","tAggregateRow_2_AGGOUT","tAggregateOut","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tAggregateRow_2_AGGOUT", true);
end_Hash.put("tAggregateRow_2_AGGOUT", System.currentTimeMillis());




/**
 * [tAggregateRow_2_AGGOUT end ] stop
 */



	
	/**
	 * [tFileOutputDelimited_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileOutputDelimited_6", false);
		start_Hash.put("tFileOutputDelimited_6", System.currentTimeMillis());
		
	
	currentComponent="tFileOutputDelimited_6";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"copyOfout");
			
		int tos_count_tFileOutputDelimited_6 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tFileOutputDelimited_6", "tFileOutputDelimited");
				talendJobLogProcess(globalMap);
			}
			

String fileName_tFileOutputDelimited_6 = "";
    fileName_tFileOutputDelimited_6 = (new java.io.File(context.location+"temp_stg.csv")).getAbsolutePath().replace("\\","/");
    String fullName_tFileOutputDelimited_6 = null;
    String extension_tFileOutputDelimited_6 = null;
    String directory_tFileOutputDelimited_6 = null;
    if((fileName_tFileOutputDelimited_6.indexOf("/") != -1)) {
        if(fileName_tFileOutputDelimited_6.lastIndexOf(".") < fileName_tFileOutputDelimited_6.lastIndexOf("/")) {
            fullName_tFileOutputDelimited_6 = fileName_tFileOutputDelimited_6;
            extension_tFileOutputDelimited_6 = "";
        } else {
            fullName_tFileOutputDelimited_6 = fileName_tFileOutputDelimited_6.substring(0, fileName_tFileOutputDelimited_6.lastIndexOf("."));
            extension_tFileOutputDelimited_6 = fileName_tFileOutputDelimited_6.substring(fileName_tFileOutputDelimited_6.lastIndexOf("."));
        }
        directory_tFileOutputDelimited_6 = fileName_tFileOutputDelimited_6.substring(0, fileName_tFileOutputDelimited_6.lastIndexOf("/"));
    } else {
        if(fileName_tFileOutputDelimited_6.lastIndexOf(".") != -1) {
            fullName_tFileOutputDelimited_6 = fileName_tFileOutputDelimited_6.substring(0, fileName_tFileOutputDelimited_6.lastIndexOf("."));
            extension_tFileOutputDelimited_6 = fileName_tFileOutputDelimited_6.substring(fileName_tFileOutputDelimited_6.lastIndexOf("."));
        } else {
            fullName_tFileOutputDelimited_6 = fileName_tFileOutputDelimited_6;
            extension_tFileOutputDelimited_6 = "";
        }
        directory_tFileOutputDelimited_6 = "";
    }
    boolean isFileGenerated_tFileOutputDelimited_6 = true;
    java.io.File filetFileOutputDelimited_6 = new java.io.File(fileName_tFileOutputDelimited_6);
    globalMap.put("tFileOutputDelimited_6_FILE_NAME",fileName_tFileOutputDelimited_6);
            int nb_line_tFileOutputDelimited_6 = 0;
            int splitedFileNo_tFileOutputDelimited_6 = 0;
            int currentRow_tFileOutputDelimited_6 = 0;

            final String OUT_DELIM_tFileOutputDelimited_6 = /** Start field tFileOutputDelimited_6:FIELDSEPARATOR */";"/** End field tFileOutputDelimited_6:FIELDSEPARATOR */;

            final String OUT_DELIM_ROWSEP_tFileOutputDelimited_6 = /** Start field tFileOutputDelimited_6:ROWSEPARATOR */"\n"/** End field tFileOutputDelimited_6:ROWSEPARATOR */;

                    //create directory only if not exists
                    if(directory_tFileOutputDelimited_6 != null && directory_tFileOutputDelimited_6.trim().length() != 0) {
                        java.io.File dir_tFileOutputDelimited_6 = new java.io.File(directory_tFileOutputDelimited_6);
                        if(!dir_tFileOutputDelimited_6.exists()) {
                            dir_tFileOutputDelimited_6.mkdirs();
                        }
                    }

                        //routines.system.Row
                        java.io.Writer outtFileOutputDelimited_6 = null;

                        java.io.File fileToDelete_tFileOutputDelimited_6 = new java.io.File(fileName_tFileOutputDelimited_6);
                        if(fileToDelete_tFileOutputDelimited_6.exists()) {
                            fileToDelete_tFileOutputDelimited_6.delete();
                        }
                        outtFileOutputDelimited_6 = new java.io.BufferedWriter(new java.io.OutputStreamWriter(
                        new java.io.FileOutputStream(fileName_tFileOutputDelimited_6, false),"ISO-8859-15"));
                                    if(filetFileOutputDelimited_6.length()==0){
                                        outtFileOutputDelimited_6.write("GID");
                                            outtFileOutputDelimited_6.write(OUT_DELIM_tFileOutputDelimited_6);
                                        outtFileOutputDelimited_6.write("count");
                                        outtFileOutputDelimited_6.write(OUT_DELIM_ROWSEP_tFileOutputDelimited_6);
                                        outtFileOutputDelimited_6.flush();
                                    }


        resourceMap.put("out_tFileOutputDelimited_6", outtFileOutputDelimited_6);
resourceMap.put("nb_line_tFileOutputDelimited_6", nb_line_tFileOutputDelimited_6);

 



/**
 * [tFileOutputDelimited_6 begin ] stop
 */



	
	/**
	 * [tMap_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_4", false);
		start_Hash.put("tMap_4", System.currentTimeMillis());
		
	
	currentComponent="tMap_4";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row22");
			
		int tos_count_tMap_4 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tMap_4", "tMap");
				talendJobLogProcess(globalMap);
			}
			




// ###############################
// # Lookup's keys initialization
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_4__Struct  {
}
Var__tMap_4__Struct Var__tMap_4 = new Var__tMap_4__Struct();
// ###############################

// ###############################
// # Outputs initialization
copyOfoutStruct copyOfout_tmp = new copyOfoutStruct();
// ###############################

        
        



        









 



/**
 * [tMap_4 begin ] stop
 */



	
	/**
	 * [tAggregateRow_2_AGGIN begin ] start
	 */

	

	
		
		ok_Hash.put("tAggregateRow_2_AGGIN", false);
		start_Hash.put("tAggregateRow_2_AGGIN", System.currentTimeMillis());
		
	
		currentVirtualComponent = "tAggregateRow_2";
	
	currentComponent="tAggregateRow_2_AGGIN";

	
		int tos_count_tAggregateRow_2_AGGIN = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAggregateRow_2_AGGIN", "tAggregateIn");
				talendJobLogProcess(globalMap);
			}
			

java.util.Collection<AggOperationStruct_tAggregateRow_2> values_tAggregateRow_2 = hash_tAggregateRow_2.values();

globalMap.put("tAggregateRow_2_NB_LINE", values_tAggregateRow_2.size());

for(AggOperationStruct_tAggregateRow_2 aggregated_row_tAggregateRow_2 : values_tAggregateRow_2) { // G_AggR_600



 



/**
 * [tAggregateRow_2_AGGIN begin ] stop
 */
	
	/**
	 * [tAggregateRow_2_AGGIN main ] start
	 */

	

	
	
		currentVirtualComponent = "tAggregateRow_2";
	
	currentComponent="tAggregateRow_2_AGGIN";

	

            				    row22.GID = aggregated_row_tAggregateRow_2.GID;
            				    row22.count = (int) aggregated_row_tAggregateRow_2.count;
	                                	row22.count = (int) aggregated_row_tAggregateRow_2.count_clmCount;
	                                	

 


	tos_count_tAggregateRow_2_AGGIN++;

/**
 * [tAggregateRow_2_AGGIN main ] stop
 */
	
	/**
	 * [tAggregateRow_2_AGGIN process_data_begin ] start
	 */

	

	
	
		currentVirtualComponent = "tAggregateRow_2";
	
	currentComponent="tAggregateRow_2_AGGIN";

	

 



/**
 * [tAggregateRow_2_AGGIN process_data_begin ] stop
 */

	
	/**
	 * [tMap_4 main ] start
	 */

	

	
	
	currentComponent="tMap_4";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"row22");
			

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_4 = false;
		
        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_4 = false;
		  boolean mainRowRejected_tMap_4 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_4__Struct Var = Var__tMap_4;// ###############################
        // ###############################
        // # Output tables

copyOfout = null;


// # Output table : 'copyOfout'
copyOfout_tmp.GID = row22.GID;
copyOfout_tmp.count = row22.count;
copyOfout = copyOfout_tmp;
// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_4 = false;










 


	tos_count_tMap_4++;

/**
 * [tMap_4 main ] stop
 */
	
	/**
	 * [tMap_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_4";

	

 



/**
 * [tMap_4 process_data_begin ] stop
 */
// Start of branch "copyOfout"
if(copyOfout != null) { 



	
	/**
	 * [tFileOutputDelimited_6 main ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_6";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"copyOfout");
			


                    StringBuilder sb_tFileOutputDelimited_6 = new StringBuilder();
                            if(copyOfout.GID != null) {
                        sb_tFileOutputDelimited_6.append(
                            copyOfout.GID
                        );
                            }
                            sb_tFileOutputDelimited_6.append(OUT_DELIM_tFileOutputDelimited_6);
                            if(copyOfout.count != null) {
                        sb_tFileOutputDelimited_6.append(
                            copyOfout.count
                        );
                            }
                    sb_tFileOutputDelimited_6.append(OUT_DELIM_ROWSEP_tFileOutputDelimited_6);


                    nb_line_tFileOutputDelimited_6++;
                    resourceMap.put("nb_line_tFileOutputDelimited_6", nb_line_tFileOutputDelimited_6);

                        outtFileOutputDelimited_6.write(sb_tFileOutputDelimited_6.toString());




 


	tos_count_tFileOutputDelimited_6++;

/**
 * [tFileOutputDelimited_6 main ] stop
 */
	
	/**
	 * [tFileOutputDelimited_6 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_6";

	

 



/**
 * [tFileOutputDelimited_6 process_data_begin ] stop
 */
	
	/**
	 * [tFileOutputDelimited_6 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_6";

	

 



/**
 * [tFileOutputDelimited_6 process_data_end ] stop
 */

} // End of branch "copyOfout"




	
	/**
	 * [tMap_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_4";

	

 



/**
 * [tMap_4 process_data_end ] stop
 */



	
	/**
	 * [tAggregateRow_2_AGGIN process_data_end ] start
	 */

	

	
	
		currentVirtualComponent = "tAggregateRow_2";
	
	currentComponent="tAggregateRow_2_AGGIN";

	

 



/**
 * [tAggregateRow_2_AGGIN process_data_end ] stop
 */
	
	/**
	 * [tAggregateRow_2_AGGIN end ] start
	 */

	

	
	
		currentVirtualComponent = "tAggregateRow_2";
	
	currentComponent="tAggregateRow_2_AGGIN";

	

} // G_AggR_600

 

ok_Hash.put("tAggregateRow_2_AGGIN", true);
end_Hash.put("tAggregateRow_2_AGGIN", System.currentTimeMillis());




/**
 * [tAggregateRow_2_AGGIN end ] stop
 */

	
	/**
	 * [tMap_4 end ] start
	 */

	

	
	
	currentComponent="tMap_4";

	


// ###############################
// # Lookup hashes releasing
// ###############################      





			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row22",2,0,
			 			talendJobLog,"tAggregateRow_2_AGGIN","tAggregateIn","tMap_4","tMap","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tMap_4", true);
end_Hash.put("tMap_4", System.currentTimeMillis());




/**
 * [tMap_4 end ] stop
 */

	
	/**
	 * [tFileOutputDelimited_6 end ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_6";

	



		
			
					if(outtFileOutputDelimited_6!=null) {
						outtFileOutputDelimited_6.flush();
						outtFileOutputDelimited_6.close();
					}
				
				globalMap.put("tFileOutputDelimited_6_NB_LINE",nb_line_tFileOutputDelimited_6);
				globalMap.put("tFileOutputDelimited_6_FILE_NAME",fileName_tFileOutputDelimited_6);
			
		
		
		resourceMap.put("finish_tFileOutputDelimited_6", true);
	

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"copyOfout",2,0,
			 			talendJobLog,"tMap_4","tMap","tFileOutputDelimited_6","tFileOutputDelimited","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tFileOutputDelimited_6", true);
end_Hash.put("tFileOutputDelimited_6", System.currentTimeMillis());




/**
 * [tFileOutputDelimited_6 end ] stop
 */



























				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFileInputDelimited_4:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk1", 0, "ok");
								} 
							
							tFileInputDelimited_2Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
					te.setVirtualComponentName(currentVirtualComponent);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
							//free memory for "tAggregateRow_2_AGGIN"
							globalMap.remove("tAggregateRow_2");
						
				try{
					
	
	/**
	 * [tFileInputDelimited_4 finally ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_4";

	

 



/**
 * [tFileInputDelimited_4 finally ] stop
 */

	
	/**
	 * [tMap_3 finally ] start
	 */

	

	
	
	currentComponent="tMap_3";

	

 



/**
 * [tMap_3 finally ] stop
 */

	
	/**
	 * [tMatchGroup_1_GroupOut finally ] start
	 */

	

	
	
		currentVirtualComponent = "tMatchGroup_1";
	
	currentComponent="tMatchGroup_1_GroupOut";

	

 



/**
 * [tMatchGroup_1_GroupOut finally ] stop
 */

	
	/**
	 * [tMatchGroup_1_GroupIn finally ] start
	 */

	

	
	
		currentVirtualComponent = "tMatchGroup_1";
	
	currentComponent="tMatchGroup_1_GroupIn";

	

 



/**
 * [tMatchGroup_1_GroupIn finally ] stop
 */

	
	/**
	 * [tLogRow_7 finally ] start
	 */

	

	
	
	currentComponent="tLogRow_7";

	

 



/**
 * [tLogRow_7 finally ] stop
 */

	
	/**
	 * [tFileOutputDelimited_5 finally ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_5";

	


		if(resourceMap.get("finish_tFileOutputDelimited_5") == null){ 
			
				
						java.io.Writer outtFileOutputDelimited_5 = (java.io.Writer)resourceMap.get("out_tFileOutputDelimited_5");
						if(outtFileOutputDelimited_5!=null) {
							outtFileOutputDelimited_5.flush();
							outtFileOutputDelimited_5.close();
						}
					
				
			
		}
	

 



/**
 * [tFileOutputDelimited_5 finally ] stop
 */

	
	/**
	 * [tAggregateRow_2_AGGOUT finally ] start
	 */

	

	
	
		currentVirtualComponent = "tAggregateRow_2";
	
	currentComponent="tAggregateRow_2_AGGOUT";

	

 



/**
 * [tAggregateRow_2_AGGOUT finally ] stop
 */

	
	/**
	 * [tAggregateRow_2_AGGIN finally ] start
	 */

	

	
	
		currentVirtualComponent = "tAggregateRow_2";
	
	currentComponent="tAggregateRow_2_AGGIN";

	

 



/**
 * [tAggregateRow_2_AGGIN finally ] stop
 */

	
	/**
	 * [tMap_4 finally ] start
	 */

	

	
	
	currentComponent="tMap_4";

	

 



/**
 * [tMap_4 finally ] stop
 */

	
	/**
	 * [tFileOutputDelimited_6 finally ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_6";

	


		if(resourceMap.get("finish_tFileOutputDelimited_6") == null){ 
			
				
						java.io.Writer outtFileOutputDelimited_6 = (java.io.Writer)resourceMap.get("out_tFileOutputDelimited_6");
						if(outtFileOutputDelimited_6!=null) {
							outtFileOutputDelimited_6.flush();
							outtFileOutputDelimited_6.close();
						}
					
				
			
		}
	

 



/**
 * [tFileOutputDelimited_6 finally ] stop
 */



























				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileInputDelimited_4_SUBPROCESS_STATE", 1);
	}
	


public static class row17Struct implements routines.system.IPersistableRow<row17Struct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecord_Allrules_T = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T = new byte[0];

	
			    public String Gender;

				public String getGender () {
					return this.Gender;
				}
				
			    public String Date;

				public String getDate () {
					return this.Date;
				}
				
			    public String First_Name;

				public String getFirst_Name () {
					return this.First_Name;
				}
				
			    public String Last_Name;

				public String getLast_Name () {
					return this.Last_Name;
				}
				
			    public String State;

				public String getState () {
					return this.State;
				}
				
			    public String City;

				public String getCity () {
					return this.City;
				}
				
			    public String Zip_Code;

				public String getZip_Code () {
					return this.Zip_Code;
				}
				
			    public String Address_Line_1;

				public String getAddress_Line_1 () {
					return this.Address_Line_1;
				}
				
			    public String Address_Line_2;

				public String getAddress_Line_2 () {
					return this.Address_Line_2;
				}
				
			    public String Phone_Number;

				public String getPhone_Number () {
					return this.Phone_Number;
				}
				
			    public String Social_Security_Number;

				public String getSocial_Security_Number () {
					return this.Social_Security_Number;
				}
				
			    public String UPI_ID;

				public String getUPI_ID () {
					return this.UPI_ID;
				}
				
			    public String MBI;

				public String getMBI () {
					return this.MBI;
				}
				
			    public String Client_ID;

				public String getClient_ID () {
					return this.Client_ID;
				}
				
			    public String Carrier_ID;

				public String getCarrier_ID () {
					return this.Carrier_ID;
				}
				
			    public String Account_ID;

				public String getAccount_ID () {
					return this.Account_ID;
				}
				
			    public String Group_ID;

				public String getGroup_ID () {
					return this.Group_ID;
				}
				
			    public String Contract_Family_ID;

				public String getContract_Family_ID () {
					return this.Contract_Family_ID;
				}
				
			    public String Multi_Birth_Code;

				public String getMulti_Birth_Code () {
					return this.Multi_Birth_Code;
				}
				
			    public String Member_Key;

				public String getMember_Key () {
					return this.Member_Key;
				}
				
			    public String Source;

				public String getSource () {
					return this.Source;
				}
				
			    public String GID;

				public String getGID () {
					return this.GID;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecord_Allrules_T) {

        	try {

        		int length = 0;
		
					this.Gender = readString(dis);
					
					this.Date = readString(dis);
					
					this.First_Name = readString(dis);
					
					this.Last_Name = readString(dis);
					
					this.State = readString(dis);
					
					this.City = readString(dis);
					
					this.Zip_Code = readString(dis);
					
					this.Address_Line_1 = readString(dis);
					
					this.Address_Line_2 = readString(dis);
					
					this.Phone_Number = readString(dis);
					
					this.Social_Security_Number = readString(dis);
					
					this.UPI_ID = readString(dis);
					
					this.MBI = readString(dis);
					
					this.Client_ID = readString(dis);
					
					this.Carrier_ID = readString(dis);
					
					this.Account_ID = readString(dis);
					
					this.Group_ID = readString(dis);
					
					this.Contract_Family_ID = readString(dis);
					
					this.Multi_Birth_Code = readString(dis);
					
					this.Member_Key = readString(dis);
					
					this.Source = readString(dis);
					
					this.GID = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Gender,dos);
					
					// String
				
						writeString(this.Date,dos);
					
					// String
				
						writeString(this.First_Name,dos);
					
					// String
				
						writeString(this.Last_Name,dos);
					
					// String
				
						writeString(this.State,dos);
					
					// String
				
						writeString(this.City,dos);
					
					// String
				
						writeString(this.Zip_Code,dos);
					
					// String
				
						writeString(this.Address_Line_1,dos);
					
					// String
				
						writeString(this.Address_Line_2,dos);
					
					// String
				
						writeString(this.Phone_Number,dos);
					
					// String
				
						writeString(this.Social_Security_Number,dos);
					
					// String
				
						writeString(this.UPI_ID,dos);
					
					// String
				
						writeString(this.MBI,dos);
					
					// String
				
						writeString(this.Client_ID,dos);
					
					// String
				
						writeString(this.Carrier_ID,dos);
					
					// String
				
						writeString(this.Account_ID,dos);
					
					// String
				
						writeString(this.Group_ID,dos);
					
					// String
				
						writeString(this.Contract_Family_ID,dos);
					
					// String
				
						writeString(this.Multi_Birth_Code,dos);
					
					// String
				
						writeString(this.Member_Key,dos);
					
					// String
				
						writeString(this.Source,dos);
					
					// String
				
						writeString(this.GID,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Gender="+Gender);
		sb.append(",Date="+Date);
		sb.append(",First_Name="+First_Name);
		sb.append(",Last_Name="+Last_Name);
		sb.append(",State="+State);
		sb.append(",City="+City);
		sb.append(",Zip_Code="+Zip_Code);
		sb.append(",Address_Line_1="+Address_Line_1);
		sb.append(",Address_Line_2="+Address_Line_2);
		sb.append(",Phone_Number="+Phone_Number);
		sb.append(",Social_Security_Number="+Social_Security_Number);
		sb.append(",UPI_ID="+UPI_ID);
		sb.append(",MBI="+MBI);
		sb.append(",Client_ID="+Client_ID);
		sb.append(",Carrier_ID="+Carrier_ID);
		sb.append(",Account_ID="+Account_ID);
		sb.append(",Group_ID="+Group_ID);
		sb.append(",Contract_Family_ID="+Contract_Family_ID);
		sb.append(",Multi_Birth_Code="+Multi_Birth_Code);
		sb.append(",Member_Key="+Member_Key);
		sb.append(",Source="+Source);
		sb.append(",GID="+GID);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row17Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row14Struct implements routines.system.IPersistableRow<row14Struct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecord_Allrules_T = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T = new byte[0];

	
			    public String Gender;

				public String getGender () {
					return this.Gender;
				}
				
			    public String Date;

				public String getDate () {
					return this.Date;
				}
				
			    public String First_Name;

				public String getFirst_Name () {
					return this.First_Name;
				}
				
			    public String Last_Name;

				public String getLast_Name () {
					return this.Last_Name;
				}
				
			    public String State;

				public String getState () {
					return this.State;
				}
				
			    public String City;

				public String getCity () {
					return this.City;
				}
				
			    public String Zip_Code;

				public String getZip_Code () {
					return this.Zip_Code;
				}
				
			    public String Address_Line_1;

				public String getAddress_Line_1 () {
					return this.Address_Line_1;
				}
				
			    public String Address_Line_2;

				public String getAddress_Line_2 () {
					return this.Address_Line_2;
				}
				
			    public String Phone_Number;

				public String getPhone_Number () {
					return this.Phone_Number;
				}
				
			    public String Social_Security_Number;

				public String getSocial_Security_Number () {
					return this.Social_Security_Number;
				}
				
			    public String UPI_ID;

				public String getUPI_ID () {
					return this.UPI_ID;
				}
				
			    public String MBI;

				public String getMBI () {
					return this.MBI;
				}
				
			    public String Client_ID;

				public String getClient_ID () {
					return this.Client_ID;
				}
				
			    public String Carrier_ID;

				public String getCarrier_ID () {
					return this.Carrier_ID;
				}
				
			    public String Account_ID;

				public String getAccount_ID () {
					return this.Account_ID;
				}
				
			    public String Group_ID;

				public String getGroup_ID () {
					return this.Group_ID;
				}
				
			    public String Contract_Family_ID;

				public String getContract_Family_ID () {
					return this.Contract_Family_ID;
				}
				
			    public String Multi_Birth_Code;

				public String getMulti_Birth_Code () {
					return this.Multi_Birth_Code;
				}
				
			    public String Member_Key;

				public String getMember_Key () {
					return this.Member_Key;
				}
				
			    public String Source;

				public String getSource () {
					return this.Source;
				}
				
			    public String GID;

				public String getGID () {
					return this.GID;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecord_Allrules_T) {

        	try {

        		int length = 0;
		
					this.Gender = readString(dis);
					
					this.Date = readString(dis);
					
					this.First_Name = readString(dis);
					
					this.Last_Name = readString(dis);
					
					this.State = readString(dis);
					
					this.City = readString(dis);
					
					this.Zip_Code = readString(dis);
					
					this.Address_Line_1 = readString(dis);
					
					this.Address_Line_2 = readString(dis);
					
					this.Phone_Number = readString(dis);
					
					this.Social_Security_Number = readString(dis);
					
					this.UPI_ID = readString(dis);
					
					this.MBI = readString(dis);
					
					this.Client_ID = readString(dis);
					
					this.Carrier_ID = readString(dis);
					
					this.Account_ID = readString(dis);
					
					this.Group_ID = readString(dis);
					
					this.Contract_Family_ID = readString(dis);
					
					this.Multi_Birth_Code = readString(dis);
					
					this.Member_Key = readString(dis);
					
					this.Source = readString(dis);
					
					this.GID = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Gender,dos);
					
					// String
				
						writeString(this.Date,dos);
					
					// String
				
						writeString(this.First_Name,dos);
					
					// String
				
						writeString(this.Last_Name,dos);
					
					// String
				
						writeString(this.State,dos);
					
					// String
				
						writeString(this.City,dos);
					
					// String
				
						writeString(this.Zip_Code,dos);
					
					// String
				
						writeString(this.Address_Line_1,dos);
					
					// String
				
						writeString(this.Address_Line_2,dos);
					
					// String
				
						writeString(this.Phone_Number,dos);
					
					// String
				
						writeString(this.Social_Security_Number,dos);
					
					// String
				
						writeString(this.UPI_ID,dos);
					
					// String
				
						writeString(this.MBI,dos);
					
					// String
				
						writeString(this.Client_ID,dos);
					
					// String
				
						writeString(this.Carrier_ID,dos);
					
					// String
				
						writeString(this.Account_ID,dos);
					
					// String
				
						writeString(this.Group_ID,dos);
					
					// String
				
						writeString(this.Contract_Family_ID,dos);
					
					// String
				
						writeString(this.Multi_Birth_Code,dos);
					
					// String
				
						writeString(this.Member_Key,dos);
					
					// String
				
						writeString(this.Source,dos);
					
					// String
				
						writeString(this.GID,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Gender="+Gender);
		sb.append(",Date="+Date);
		sb.append(",First_Name="+First_Name);
		sb.append(",Last_Name="+Last_Name);
		sb.append(",State="+State);
		sb.append(",City="+City);
		sb.append(",Zip_Code="+Zip_Code);
		sb.append(",Address_Line_1="+Address_Line_1);
		sb.append(",Address_Line_2="+Address_Line_2);
		sb.append(",Phone_Number="+Phone_Number);
		sb.append(",Social_Security_Number="+Social_Security_Number);
		sb.append(",UPI_ID="+UPI_ID);
		sb.append(",MBI="+MBI);
		sb.append(",Client_ID="+Client_ID);
		sb.append(",Carrier_ID="+Carrier_ID);
		sb.append(",Account_ID="+Account_ID);
		sb.append(",Group_ID="+Group_ID);
		sb.append(",Contract_Family_ID="+Contract_Family_ID);
		sb.append(",Multi_Birth_Code="+Multi_Birth_Code);
		sb.append(",Member_Key="+Member_Key);
		sb.append(",Source="+Source);
		sb.append(",GID="+GID);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row14Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row16Struct implements routines.system.IPersistableRow<row16Struct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecord_Allrules_T = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T = new byte[0];

	
			    public String Gender;

				public String getGender () {
					return this.Gender;
				}
				
			    public String Date;

				public String getDate () {
					return this.Date;
				}
				
			    public String First_Name;

				public String getFirst_Name () {
					return this.First_Name;
				}
				
			    public String Last_Name;

				public String getLast_Name () {
					return this.Last_Name;
				}
				
			    public String State;

				public String getState () {
					return this.State;
				}
				
			    public String City;

				public String getCity () {
					return this.City;
				}
				
			    public String Zip_Code;

				public String getZip_Code () {
					return this.Zip_Code;
				}
				
			    public String Address_Line_1;

				public String getAddress_Line_1 () {
					return this.Address_Line_1;
				}
				
			    public String Address_Line_2;

				public String getAddress_Line_2 () {
					return this.Address_Line_2;
				}
				
			    public String Phone_Number;

				public String getPhone_Number () {
					return this.Phone_Number;
				}
				
			    public String Social_Security_Number;

				public String getSocial_Security_Number () {
					return this.Social_Security_Number;
				}
				
			    public String UPI_ID;

				public String getUPI_ID () {
					return this.UPI_ID;
				}
				
			    public String MBI;

				public String getMBI () {
					return this.MBI;
				}
				
			    public String Client_ID;

				public String getClient_ID () {
					return this.Client_ID;
				}
				
			    public String Carrier_ID;

				public String getCarrier_ID () {
					return this.Carrier_ID;
				}
				
			    public String Account_ID;

				public String getAccount_ID () {
					return this.Account_ID;
				}
				
			    public String Group_ID;

				public String getGroup_ID () {
					return this.Group_ID;
				}
				
			    public String Contract_Family_ID;

				public String getContract_Family_ID () {
					return this.Contract_Family_ID;
				}
				
			    public String Multi_Birth_Code;

				public String getMulti_Birth_Code () {
					return this.Multi_Birth_Code;
				}
				
			    public String Member_Key;

				public String getMember_Key () {
					return this.Member_Key;
				}
				
			    public String Source;

				public String getSource () {
					return this.Source;
				}
				
			    public String year;

				public String getYear () {
					return this.year;
				}
				
			    public String GID;

				public String getGID () {
					return this.GID;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecord_Allrules_T) {

        	try {

        		int length = 0;
		
					this.Gender = readString(dis);
					
					this.Date = readString(dis);
					
					this.First_Name = readString(dis);
					
					this.Last_Name = readString(dis);
					
					this.State = readString(dis);
					
					this.City = readString(dis);
					
					this.Zip_Code = readString(dis);
					
					this.Address_Line_1 = readString(dis);
					
					this.Address_Line_2 = readString(dis);
					
					this.Phone_Number = readString(dis);
					
					this.Social_Security_Number = readString(dis);
					
					this.UPI_ID = readString(dis);
					
					this.MBI = readString(dis);
					
					this.Client_ID = readString(dis);
					
					this.Carrier_ID = readString(dis);
					
					this.Account_ID = readString(dis);
					
					this.Group_ID = readString(dis);
					
					this.Contract_Family_ID = readString(dis);
					
					this.Multi_Birth_Code = readString(dis);
					
					this.Member_Key = readString(dis);
					
					this.Source = readString(dis);
					
					this.year = readString(dis);
					
					this.GID = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Gender,dos);
					
					// String
				
						writeString(this.Date,dos);
					
					// String
				
						writeString(this.First_Name,dos);
					
					// String
				
						writeString(this.Last_Name,dos);
					
					// String
				
						writeString(this.State,dos);
					
					// String
				
						writeString(this.City,dos);
					
					// String
				
						writeString(this.Zip_Code,dos);
					
					// String
				
						writeString(this.Address_Line_1,dos);
					
					// String
				
						writeString(this.Address_Line_2,dos);
					
					// String
				
						writeString(this.Phone_Number,dos);
					
					// String
				
						writeString(this.Social_Security_Number,dos);
					
					// String
				
						writeString(this.UPI_ID,dos);
					
					// String
				
						writeString(this.MBI,dos);
					
					// String
				
						writeString(this.Client_ID,dos);
					
					// String
				
						writeString(this.Carrier_ID,dos);
					
					// String
				
						writeString(this.Account_ID,dos);
					
					// String
				
						writeString(this.Group_ID,dos);
					
					// String
				
						writeString(this.Contract_Family_ID,dos);
					
					// String
				
						writeString(this.Multi_Birth_Code,dos);
					
					// String
				
						writeString(this.Member_Key,dos);
					
					// String
				
						writeString(this.Source,dos);
					
					// String
				
						writeString(this.year,dos);
					
					// String
				
						writeString(this.GID,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Gender="+Gender);
		sb.append(",Date="+Date);
		sb.append(",First_Name="+First_Name);
		sb.append(",Last_Name="+Last_Name);
		sb.append(",State="+State);
		sb.append(",City="+City);
		sb.append(",Zip_Code="+Zip_Code);
		sb.append(",Address_Line_1="+Address_Line_1);
		sb.append(",Address_Line_2="+Address_Line_2);
		sb.append(",Phone_Number="+Phone_Number);
		sb.append(",Social_Security_Number="+Social_Security_Number);
		sb.append(",UPI_ID="+UPI_ID);
		sb.append(",MBI="+MBI);
		sb.append(",Client_ID="+Client_ID);
		sb.append(",Carrier_ID="+Carrier_ID);
		sb.append(",Account_ID="+Account_ID);
		sb.append(",Group_ID="+Group_ID);
		sb.append(",Contract_Family_ID="+Contract_Family_ID);
		sb.append(",Multi_Birth_Code="+Multi_Birth_Code);
		sb.append(",Member_Key="+Member_Key);
		sb.append(",Source="+Source);
		sb.append(",year="+year);
		sb.append(",GID="+GID);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row16Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class OnRowsEndStructtSortRow_2 implements routines.system.IPersistableRow<OnRowsEndStructtSortRow_2> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecord_Allrules_T = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T = new byte[0];

	
			    public String Gender;

				public String getGender () {
					return this.Gender;
				}
				
			    public String Date;

				public String getDate () {
					return this.Date;
				}
				
			    public String First_Name;

				public String getFirst_Name () {
					return this.First_Name;
				}
				
			    public String Last_Name;

				public String getLast_Name () {
					return this.Last_Name;
				}
				
			    public String State;

				public String getState () {
					return this.State;
				}
				
			    public String City;

				public String getCity () {
					return this.City;
				}
				
			    public String Zip_Code;

				public String getZip_Code () {
					return this.Zip_Code;
				}
				
			    public String Address_Line_1;

				public String getAddress_Line_1 () {
					return this.Address_Line_1;
				}
				
			    public String Address_Line_2;

				public String getAddress_Line_2 () {
					return this.Address_Line_2;
				}
				
			    public String Phone_Number;

				public String getPhone_Number () {
					return this.Phone_Number;
				}
				
			    public String Social_Security_Number;

				public String getSocial_Security_Number () {
					return this.Social_Security_Number;
				}
				
			    public String UPI_ID;

				public String getUPI_ID () {
					return this.UPI_ID;
				}
				
			    public String MBI;

				public String getMBI () {
					return this.MBI;
				}
				
			    public String Client_ID;

				public String getClient_ID () {
					return this.Client_ID;
				}
				
			    public String Carrier_ID;

				public String getCarrier_ID () {
					return this.Carrier_ID;
				}
				
			    public String Account_ID;

				public String getAccount_ID () {
					return this.Account_ID;
				}
				
			    public String Group_ID;

				public String getGroup_ID () {
					return this.Group_ID;
				}
				
			    public String Contract_Family_ID;

				public String getContract_Family_ID () {
					return this.Contract_Family_ID;
				}
				
			    public String Multi_Birth_Code;

				public String getMulti_Birth_Code () {
					return this.Multi_Birth_Code;
				}
				
			    public String Member_Key;

				public String getMember_Key () {
					return this.Member_Key;
				}
				
			    public String Source;

				public String getSource () {
					return this.Source;
				}
				
			    public String year;

				public String getYear () {
					return this.year;
				}
				
			    public String GID;

				public String getGID () {
					return this.GID;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecord_Allrules_T) {

        	try {

        		int length = 0;
		
					this.Gender = readString(dis);
					
					this.Date = readString(dis);
					
					this.First_Name = readString(dis);
					
					this.Last_Name = readString(dis);
					
					this.State = readString(dis);
					
					this.City = readString(dis);
					
					this.Zip_Code = readString(dis);
					
					this.Address_Line_1 = readString(dis);
					
					this.Address_Line_2 = readString(dis);
					
					this.Phone_Number = readString(dis);
					
					this.Social_Security_Number = readString(dis);
					
					this.UPI_ID = readString(dis);
					
					this.MBI = readString(dis);
					
					this.Client_ID = readString(dis);
					
					this.Carrier_ID = readString(dis);
					
					this.Account_ID = readString(dis);
					
					this.Group_ID = readString(dis);
					
					this.Contract_Family_ID = readString(dis);
					
					this.Multi_Birth_Code = readString(dis);
					
					this.Member_Key = readString(dis);
					
					this.Source = readString(dis);
					
					this.year = readString(dis);
					
					this.GID = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Gender,dos);
					
					// String
				
						writeString(this.Date,dos);
					
					// String
				
						writeString(this.First_Name,dos);
					
					// String
				
						writeString(this.Last_Name,dos);
					
					// String
				
						writeString(this.State,dos);
					
					// String
				
						writeString(this.City,dos);
					
					// String
				
						writeString(this.Zip_Code,dos);
					
					// String
				
						writeString(this.Address_Line_1,dos);
					
					// String
				
						writeString(this.Address_Line_2,dos);
					
					// String
				
						writeString(this.Phone_Number,dos);
					
					// String
				
						writeString(this.Social_Security_Number,dos);
					
					// String
				
						writeString(this.UPI_ID,dos);
					
					// String
				
						writeString(this.MBI,dos);
					
					// String
				
						writeString(this.Client_ID,dos);
					
					// String
				
						writeString(this.Carrier_ID,dos);
					
					// String
				
						writeString(this.Account_ID,dos);
					
					// String
				
						writeString(this.Group_ID,dos);
					
					// String
				
						writeString(this.Contract_Family_ID,dos);
					
					// String
				
						writeString(this.Multi_Birth_Code,dos);
					
					// String
				
						writeString(this.Member_Key,dos);
					
					// String
				
						writeString(this.Source,dos);
					
					// String
				
						writeString(this.year,dos);
					
					// String
				
						writeString(this.GID,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Gender="+Gender);
		sb.append(",Date="+Date);
		sb.append(",First_Name="+First_Name);
		sb.append(",Last_Name="+Last_Name);
		sb.append(",State="+State);
		sb.append(",City="+City);
		sb.append(",Zip_Code="+Zip_Code);
		sb.append(",Address_Line_1="+Address_Line_1);
		sb.append(",Address_Line_2="+Address_Line_2);
		sb.append(",Phone_Number="+Phone_Number);
		sb.append(",Social_Security_Number="+Social_Security_Number);
		sb.append(",UPI_ID="+UPI_ID);
		sb.append(",MBI="+MBI);
		sb.append(",Client_ID="+Client_ID);
		sb.append(",Carrier_ID="+Carrier_ID);
		sb.append(",Account_ID="+Account_ID);
		sb.append(",Group_ID="+Group_ID);
		sb.append(",Contract_Family_ID="+Contract_Family_ID);
		sb.append(",Multi_Birth_Code="+Multi_Birth_Code);
		sb.append(",Member_Key="+Member_Key);
		sb.append(",Source="+Source);
		sb.append(",year="+year);
		sb.append(",GID="+GID);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(OnRowsEndStructtSortRow_2 other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row7Struct implements routines.system.IPersistableRow<row7Struct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecord_Allrules_T = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T = new byte[0];

	
			    public String Gender;

				public String getGender () {
					return this.Gender;
				}
				
			    public String Date;

				public String getDate () {
					return this.Date;
				}
				
			    public String First_Name;

				public String getFirst_Name () {
					return this.First_Name;
				}
				
			    public String Last_Name;

				public String getLast_Name () {
					return this.Last_Name;
				}
				
			    public String State;

				public String getState () {
					return this.State;
				}
				
			    public String City;

				public String getCity () {
					return this.City;
				}
				
			    public String Zip_Code;

				public String getZip_Code () {
					return this.Zip_Code;
				}
				
			    public String Address_Line_1;

				public String getAddress_Line_1 () {
					return this.Address_Line_1;
				}
				
			    public String Address_Line_2;

				public String getAddress_Line_2 () {
					return this.Address_Line_2;
				}
				
			    public String Phone_Number;

				public String getPhone_Number () {
					return this.Phone_Number;
				}
				
			    public String Social_Security_Number;

				public String getSocial_Security_Number () {
					return this.Social_Security_Number;
				}
				
			    public String UPI_ID;

				public String getUPI_ID () {
					return this.UPI_ID;
				}
				
			    public String MBI;

				public String getMBI () {
					return this.MBI;
				}
				
			    public String Client_ID;

				public String getClient_ID () {
					return this.Client_ID;
				}
				
			    public String Carrier_ID;

				public String getCarrier_ID () {
					return this.Carrier_ID;
				}
				
			    public String Account_ID;

				public String getAccount_ID () {
					return this.Account_ID;
				}
				
			    public String Group_ID;

				public String getGroup_ID () {
					return this.Group_ID;
				}
				
			    public String Contract_Family_ID;

				public String getContract_Family_ID () {
					return this.Contract_Family_ID;
				}
				
			    public String Multi_Birth_Code;

				public String getMulti_Birth_Code () {
					return this.Multi_Birth_Code;
				}
				
			    public String Member_Key;

				public String getMember_Key () {
					return this.Member_Key;
				}
				
			    public String Source;

				public String getSource () {
					return this.Source;
				}
				
			    public String year;

				public String getYear () {
					return this.year;
				}
				
			    public String GID;

				public String getGID () {
					return this.GID;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecord_Allrules_T) {

        	try {

        		int length = 0;
		
					this.Gender = readString(dis);
					
					this.Date = readString(dis);
					
					this.First_Name = readString(dis);
					
					this.Last_Name = readString(dis);
					
					this.State = readString(dis);
					
					this.City = readString(dis);
					
					this.Zip_Code = readString(dis);
					
					this.Address_Line_1 = readString(dis);
					
					this.Address_Line_2 = readString(dis);
					
					this.Phone_Number = readString(dis);
					
					this.Social_Security_Number = readString(dis);
					
					this.UPI_ID = readString(dis);
					
					this.MBI = readString(dis);
					
					this.Client_ID = readString(dis);
					
					this.Carrier_ID = readString(dis);
					
					this.Account_ID = readString(dis);
					
					this.Group_ID = readString(dis);
					
					this.Contract_Family_ID = readString(dis);
					
					this.Multi_Birth_Code = readString(dis);
					
					this.Member_Key = readString(dis);
					
					this.Source = readString(dis);
					
					this.year = readString(dis);
					
					this.GID = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Gender,dos);
					
					// String
				
						writeString(this.Date,dos);
					
					// String
				
						writeString(this.First_Name,dos);
					
					// String
				
						writeString(this.Last_Name,dos);
					
					// String
				
						writeString(this.State,dos);
					
					// String
				
						writeString(this.City,dos);
					
					// String
				
						writeString(this.Zip_Code,dos);
					
					// String
				
						writeString(this.Address_Line_1,dos);
					
					// String
				
						writeString(this.Address_Line_2,dos);
					
					// String
				
						writeString(this.Phone_Number,dos);
					
					// String
				
						writeString(this.Social_Security_Number,dos);
					
					// String
				
						writeString(this.UPI_ID,dos);
					
					// String
				
						writeString(this.MBI,dos);
					
					// String
				
						writeString(this.Client_ID,dos);
					
					// String
				
						writeString(this.Carrier_ID,dos);
					
					// String
				
						writeString(this.Account_ID,dos);
					
					// String
				
						writeString(this.Group_ID,dos);
					
					// String
				
						writeString(this.Contract_Family_ID,dos);
					
					// String
				
						writeString(this.Multi_Birth_Code,dos);
					
					// String
				
						writeString(this.Member_Key,dos);
					
					// String
				
						writeString(this.Source,dos);
					
					// String
				
						writeString(this.year,dos);
					
					// String
				
						writeString(this.GID,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Gender="+Gender);
		sb.append(",Date="+Date);
		sb.append(",First_Name="+First_Name);
		sb.append(",Last_Name="+Last_Name);
		sb.append(",State="+State);
		sb.append(",City="+City);
		sb.append(",Zip_Code="+Zip_Code);
		sb.append(",Address_Line_1="+Address_Line_1);
		sb.append(",Address_Line_2="+Address_Line_2);
		sb.append(",Phone_Number="+Phone_Number);
		sb.append(",Social_Security_Number="+Social_Security_Number);
		sb.append(",UPI_ID="+UPI_ID);
		sb.append(",MBI="+MBI);
		sb.append(",Client_ID="+Client_ID);
		sb.append(",Carrier_ID="+Carrier_ID);
		sb.append(",Account_ID="+Account_ID);
		sb.append(",Group_ID="+Group_ID);
		sb.append(",Contract_Family_ID="+Contract_Family_ID);
		sb.append(",Multi_Birth_Code="+Multi_Birth_Code);
		sb.append(",Member_Key="+Member_Key);
		sb.append(",Source="+Source);
		sb.append(",year="+year);
		sb.append(",GID="+GID);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row7Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row8Struct implements routines.system.IPersistableRow<row8Struct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecord_Allrules_T = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T = new byte[0];

	
			    public String Gender;

				public String getGender () {
					return this.Gender;
				}
				
			    public String Date;

				public String getDate () {
					return this.Date;
				}
				
			    public String First_Name;

				public String getFirst_Name () {
					return this.First_Name;
				}
				
			    public String Last_Name;

				public String getLast_Name () {
					return this.Last_Name;
				}
				
			    public String State;

				public String getState () {
					return this.State;
				}
				
			    public String City;

				public String getCity () {
					return this.City;
				}
				
			    public String Zip_Code;

				public String getZip_Code () {
					return this.Zip_Code;
				}
				
			    public String Address_Line_1;

				public String getAddress_Line_1 () {
					return this.Address_Line_1;
				}
				
			    public String Address_Line_2;

				public String getAddress_Line_2 () {
					return this.Address_Line_2;
				}
				
			    public String Phone_Number;

				public String getPhone_Number () {
					return this.Phone_Number;
				}
				
			    public String Social_Security_Number;

				public String getSocial_Security_Number () {
					return this.Social_Security_Number;
				}
				
			    public String UPI_ID;

				public String getUPI_ID () {
					return this.UPI_ID;
				}
				
			    public String MBI;

				public String getMBI () {
					return this.MBI;
				}
				
			    public String Client_ID;

				public String getClient_ID () {
					return this.Client_ID;
				}
				
			    public String Carrier_ID;

				public String getCarrier_ID () {
					return this.Carrier_ID;
				}
				
			    public String Account_ID;

				public String getAccount_ID () {
					return this.Account_ID;
				}
				
			    public String Group_ID;

				public String getGroup_ID () {
					return this.Group_ID;
				}
				
			    public String Contract_Family_ID;

				public String getContract_Family_ID () {
					return this.Contract_Family_ID;
				}
				
			    public String Multi_Birth_Code;

				public String getMulti_Birth_Code () {
					return this.Multi_Birth_Code;
				}
				
			    public String Member_Key;

				public String getMember_Key () {
					return this.Member_Key;
				}
				
			    public String Source;

				public String getSource () {
					return this.Source;
				}
				
			    public String year;

				public String getYear () {
					return this.year;
				}
				
			    public String GID;

				public String getGID () {
					return this.GID;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecord_Allrules_T) {

        	try {

        		int length = 0;
		
					this.Gender = readString(dis);
					
					this.Date = readString(dis);
					
					this.First_Name = readString(dis);
					
					this.Last_Name = readString(dis);
					
					this.State = readString(dis);
					
					this.City = readString(dis);
					
					this.Zip_Code = readString(dis);
					
					this.Address_Line_1 = readString(dis);
					
					this.Address_Line_2 = readString(dis);
					
					this.Phone_Number = readString(dis);
					
					this.Social_Security_Number = readString(dis);
					
					this.UPI_ID = readString(dis);
					
					this.MBI = readString(dis);
					
					this.Client_ID = readString(dis);
					
					this.Carrier_ID = readString(dis);
					
					this.Account_ID = readString(dis);
					
					this.Group_ID = readString(dis);
					
					this.Contract_Family_ID = readString(dis);
					
					this.Multi_Birth_Code = readString(dis);
					
					this.Member_Key = readString(dis);
					
					this.Source = readString(dis);
					
					this.year = readString(dis);
					
					this.GID = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Gender,dos);
					
					// String
				
						writeString(this.Date,dos);
					
					// String
				
						writeString(this.First_Name,dos);
					
					// String
				
						writeString(this.Last_Name,dos);
					
					// String
				
						writeString(this.State,dos);
					
					// String
				
						writeString(this.City,dos);
					
					// String
				
						writeString(this.Zip_Code,dos);
					
					// String
				
						writeString(this.Address_Line_1,dos);
					
					// String
				
						writeString(this.Address_Line_2,dos);
					
					// String
				
						writeString(this.Phone_Number,dos);
					
					// String
				
						writeString(this.Social_Security_Number,dos);
					
					// String
				
						writeString(this.UPI_ID,dos);
					
					// String
				
						writeString(this.MBI,dos);
					
					// String
				
						writeString(this.Client_ID,dos);
					
					// String
				
						writeString(this.Carrier_ID,dos);
					
					// String
				
						writeString(this.Account_ID,dos);
					
					// String
				
						writeString(this.Group_ID,dos);
					
					// String
				
						writeString(this.Contract_Family_ID,dos);
					
					// String
				
						writeString(this.Multi_Birth_Code,dos);
					
					// String
				
						writeString(this.Member_Key,dos);
					
					// String
				
						writeString(this.Source,dos);
					
					// String
				
						writeString(this.year,dos);
					
					// String
				
						writeString(this.GID,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Gender="+Gender);
		sb.append(",Date="+Date);
		sb.append(",First_Name="+First_Name);
		sb.append(",Last_Name="+Last_Name);
		sb.append(",State="+State);
		sb.append(",City="+City);
		sb.append(",Zip_Code="+Zip_Code);
		sb.append(",Address_Line_1="+Address_Line_1);
		sb.append(",Address_Line_2="+Address_Line_2);
		sb.append(",Phone_Number="+Phone_Number);
		sb.append(",Social_Security_Number="+Social_Security_Number);
		sb.append(",UPI_ID="+UPI_ID);
		sb.append(",MBI="+MBI);
		sb.append(",Client_ID="+Client_ID);
		sb.append(",Carrier_ID="+Carrier_ID);
		sb.append(",Account_ID="+Account_ID);
		sb.append(",Group_ID="+Group_ID);
		sb.append(",Contract_Family_ID="+Contract_Family_ID);
		sb.append(",Multi_Birth_Code="+Multi_Birth_Code);
		sb.append(",Member_Key="+Member_Key);
		sb.append(",Source="+Source);
		sb.append(",year="+year);
		sb.append(",GID="+GID);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row8Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row5Struct implements routines.system.IPersistableRow<row5Struct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecord_Allrules_T = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T = new byte[0];

	
			    public String GID;

				public String getGID () {
					return this.GID;
				}
				
			    public Integer count;

				public Integer getCount () {
					return this.count;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecord_Allrules_T, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecord_Allrules_T) {

        	try {

        		int length = 0;
		
					this.GID = readString(dis);
					
						this.count = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.GID,dos);
					
					// Integer
				
						writeInteger(this.count,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("GID="+GID);
		sb.append(",count="+String.valueOf(count));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row5Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFileInputDelimited_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileInputDelimited_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
		String currentVirtualComponent = null;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row5Struct row5 = new row5Struct();
row8Struct row8 = new row8Struct();
row7Struct row7 = new row7Struct();
row16Struct row16 = new row16Struct();
row14Struct row14 = new row14Struct();
row14Struct row17 = row14;




	
	/**
	 * [tFlowToIterate_1 begin ] start
	 */

				
			int NB_ITERATE_tFileInputDelimited_3 = 0; //for statistics
			

	
		
		ok_Hash.put("tFlowToIterate_1", false);
		start_Hash.put("tFlowToIterate_1", System.currentTimeMillis());
		
	
	currentComponent="tFlowToIterate_1";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row5");
			
		int tos_count_tFlowToIterate_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tFlowToIterate_1", "tFlowToIterate");
				talendJobLogProcess(globalMap);
			}
			

int nb_line_tFlowToIterate_1 = 0;
int counter_tFlowToIterate_1 = 0;

 



/**
 * [tFlowToIterate_1 begin ] stop
 */



	
	/**
	 * [tFileInputDelimited_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputDelimited_2", false);
		start_Hash.put("tFileInputDelimited_2", System.currentTimeMillis());
		
	
	currentComponent="tFileInputDelimited_2";

	
		int tos_count_tFileInputDelimited_2 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tFileInputDelimited_2", "tFileInputDelimited");
				talendJobLogProcess(globalMap);
			}
			
	
	
	
 
	
	
	final routines.system.RowState rowstate_tFileInputDelimited_2 = new routines.system.RowState();
	
	
				int nb_line_tFileInputDelimited_2 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_2 = null;
				int limit_tFileInputDelimited_2 = -1;
				try{
					
						Object filename_tFileInputDelimited_2 = context.location+"temp_stg.csv";
						if(filename_tFileInputDelimited_2 instanceof java.io.InputStream){
							
			int footer_value_tFileInputDelimited_2 = 0, random_value_tFileInputDelimited_2 = -1;
			if(footer_value_tFileInputDelimited_2 >0 || random_value_tFileInputDelimited_2 > 0){
				throw new java.lang.Exception("When the input source is a stream,footer and random shouldn't be bigger than 0.");				
			}
		
						}
						try {
							fid_tFileInputDelimited_2 = new org.talend.fileprocess.FileInputDelimited(context.location+"temp_stg.csv", "ISO-8859-15",";","\n",false,1,0,
									limit_tFileInputDelimited_2
								,-1, false);
						} catch(java.lang.Exception e) {
							
								
								System.err.println(e.getMessage());
							
						}
					
				    
					while (fid_tFileInputDelimited_2!=null && fid_tFileInputDelimited_2.nextRecord()) {
						rowstate_tFileInputDelimited_2.reset();
						
			    						row5 = null;			
												
									boolean whetherReject_tFileInputDelimited_2 = false;
									row5 = new row5Struct();
									try {
										
				int columnIndexWithD_tFileInputDelimited_2 = 0;
				
					String temp = ""; 
				
					columnIndexWithD_tFileInputDelimited_2 = 0;
					
							row5.GID = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
						
				
					columnIndexWithD_tFileInputDelimited_2 = 1;
					
						temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
						if(temp.length() > 0) {
							
								try {
								
    								row5.count = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_2) {
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"count", "row5", temp, ex_tFileInputDelimited_2), ex_tFileInputDelimited_2));
								}
    							
						} else {						
							
								
									row5.count = null;
								
							
						}
					
				
				
										
										if(rowstate_tFileInputDelimited_2.getException()!=null) {
											throw rowstate_tFileInputDelimited_2.getException();
										}
										
										
							
			    					} catch (java.lang.Exception e) {
			        					whetherReject_tFileInputDelimited_2 = true;
			        					
			                					System.err.println(e.getMessage());
			                					row5 = null;
			                				
			    					}
								

 



/**
 * [tFileInputDelimited_2 begin ] stop
 */
	
	/**
	 * [tFileInputDelimited_2 main ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_2";

	

 


	tos_count_tFileInputDelimited_2++;

/**
 * [tFileInputDelimited_2 main ] stop
 */
	
	/**
	 * [tFileInputDelimited_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_2";

	

 



/**
 * [tFileInputDelimited_2 process_data_begin ] stop
 */
// Start of branch "row5"
if(row5 != null) { 



	
	/**
	 * [tFlowToIterate_1 main ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_1";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"row5");
			

	
    	
              globalMap.put("GID_out", row5.GID); 
	   nb_line_tFlowToIterate_1++;  
       counter_tFlowToIterate_1++;
       globalMap.put("tFlowToIterate_1_CURRENT_ITERATION", counter_tFlowToIterate_1);
 


	tos_count_tFlowToIterate_1++;

/**
 * [tFlowToIterate_1 main ] stop
 */
	
	/**
	 * [tFlowToIterate_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_1";

	

 



/**
 * [tFlowToIterate_1 process_data_begin ] stop
 */
	NB_ITERATE_tFileInputDelimited_3++;
	
	
					if(execStat){				
	       				runStat.updateStatOnConnection("row7", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row14", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnRowsEnd", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row17", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row16", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row8", 3, 0);
					}           			
				
				if(execStat){
					runStat.updateStatOnConnection("iterate1", 1, "exec" + NB_ITERATE_tFileInputDelimited_3);
					//Thread.sleep(1000);
				}				
			



	
	/**
	 * [tSortRow_2_SortOut begin ] start
	 */

	

	
		
		ok_Hash.put("tSortRow_2_SortOut", false);
		start_Hash.put("tSortRow_2_SortOut", System.currentTimeMillis());
		
	
		currentVirtualComponent = "tSortRow_2";
	
	currentComponent="tSortRow_2_SortOut";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row7");
			
		int tos_count_tSortRow_2_SortOut = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tSortRow_2_SortOut", "tSortOut");
				talendJobLogProcess(globalMap);
			}
			


////////////////////////////////////
class row7StructILightSerializable extends row7Struct implements
                        org.talend.designer.components.tsort.io.beans.ILightSerializable<row7StructILightSerializable> {

	public int compareTo(row7StructILightSerializable other) {

		if(this.MBI == null && other.MBI != null){
			return 1;
						
		}else if(this.MBI != null && other.MBI == null){
			return -1;
						
		}else if(this.MBI != null && other.MBI != null){
			if(!this.MBI.equals(other.MBI)){
				return other.MBI.compareTo(this.MBI);
			}
		}
		if(this.Social_Security_Number == null && other.Social_Security_Number != null){
			return 1;
						
		}else if(this.Social_Security_Number != null && other.Social_Security_Number == null){
			return -1;
						
		}else if(this.Social_Security_Number != null && other.Social_Security_Number != null){
			if(!this.Social_Security_Number.equals(other.Social_Security_Number)){
				return other.Social_Security_Number.compareTo(this.Social_Security_Number);
			}
		}
		return 0;
	}

	public org.talend.designer.components.tsort.io.beans.ILightSerializable createInstance(byte[] byteArray) {
		row7StructILightSerializable result = new row7StructILightSerializable();
		java.io.ByteArrayInputStream bai = null;
		java.io.DataInputStream dis = null;

		try {
			bai = new java.io.ByteArrayInputStream(byteArray);
			dis = new java.io.DataInputStream(bai);
			int length = 0;
			            length = dis.readInt();
           				if (length == -1) {
           	    			result.Gender = null;
           				} else {
               				byte[] bytes = new byte[length];
               				dis.read(bytes);
               				result.Gender = new String(bytes, utf8Charset);
           				}
					
			            length = dis.readInt();
           				if (length == -1) {
           	    			result.Date = null;
           				} else {
               				byte[] bytes = new byte[length];
               				dis.read(bytes);
               				result.Date = new String(bytes, utf8Charset);
           				}
					
			            length = dis.readInt();
           				if (length == -1) {
           	    			result.First_Name = null;
           				} else {
               				byte[] bytes = new byte[length];
               				dis.read(bytes);
               				result.First_Name = new String(bytes, utf8Charset);
           				}
					
			            length = dis.readInt();
           				if (length == -1) {
           	    			result.Last_Name = null;
           				} else {
               				byte[] bytes = new byte[length];
               				dis.read(bytes);
               				result.Last_Name = new String(bytes, utf8Charset);
           				}
					
			            length = dis.readInt();
           				if (length == -1) {
           	    			result.State = null;
           				} else {
               				byte[] bytes = new byte[length];
               				dis.read(bytes);
               				result.State = new String(bytes, utf8Charset);
           				}
					
			            length = dis.readInt();
           				if (length == -1) {
           	    			result.City = null;
           				} else {
               				byte[] bytes = new byte[length];
               				dis.read(bytes);
               				result.City = new String(bytes, utf8Charset);
           				}
					
			            length = dis.readInt();
           				if (length == -1) {
           	    			result.Zip_Code = null;
           				} else {
               				byte[] bytes = new byte[length];
               				dis.read(bytes);
               				result.Zip_Code = new String(bytes, utf8Charset);
           				}
					
			            length = dis.readInt();
           				if (length == -1) {
           	    			result.Address_Line_1 = null;
           				} else {
               				byte[] bytes = new byte[length];
               				dis.read(bytes);
               				result.Address_Line_1 = new String(bytes, utf8Charset);
           				}
					
			            length = dis.readInt();
           				if (length == -1) {
           	    			result.Address_Line_2 = null;
           				} else {
               				byte[] bytes = new byte[length];
               				dis.read(bytes);
               				result.Address_Line_2 = new String(bytes, utf8Charset);
           				}
					
			            length = dis.readInt();
           				if (length == -1) {
           	    			result.Phone_Number = null;
           				} else {
               				byte[] bytes = new byte[length];
               				dis.read(bytes);
               				result.Phone_Number = new String(bytes, utf8Charset);
           				}
					
			            length = dis.readInt();
           				if (length == -1) {
           	    			result.Social_Security_Number = null;
           				} else {
               				byte[] bytes = new byte[length];
               				dis.read(bytes);
               				result.Social_Security_Number = new String(bytes, utf8Charset);
           				}
					
			            length = dis.readInt();
           				if (length == -1) {
           	    			result.UPI_ID = null;
           				} else {
               				byte[] bytes = new byte[length];
               				dis.read(bytes);
               				result.UPI_ID = new String(bytes, utf8Charset);
           				}
					
			            length = dis.readInt();
           				if (length == -1) {
           	    			result.MBI = null;
           				} else {
               				byte[] bytes = new byte[length];
               				dis.read(bytes);
               				result.MBI = new String(bytes, utf8Charset);
           				}
					
			            length = dis.readInt();
           				if (length == -1) {
           	    			result.Client_ID = null;
           				} else {
               				byte[] bytes = new byte[length];
               				dis.read(bytes);
               				result.Client_ID = new String(bytes, utf8Charset);
           				}
					
			            length = dis.readInt();
           				if (length == -1) {
           	    			result.Carrier_ID = null;
           				} else {
               				byte[] bytes = new byte[length];
               				dis.read(bytes);
               				result.Carrier_ID = new String(bytes, utf8Charset);
           				}
					
			            length = dis.readInt();
           				if (length == -1) {
           	    			result.Account_ID = null;
           				} else {
               				byte[] bytes = new byte[length];
               				dis.read(bytes);
               				result.Account_ID = new String(bytes, utf8Charset);
           				}
					
			            length = dis.readInt();
           				if (length == -1) {
           	    			result.Group_ID = null;
           				} else {
               				byte[] bytes = new byte[length];
               				dis.read(bytes);
               				result.Group_ID = new String(bytes, utf8Charset);
           				}
					
			            length = dis.readInt();
           				if (length == -1) {
           	    			result.Contract_Family_ID = null;
           				} else {
               				byte[] bytes = new byte[length];
               				dis.read(bytes);
               				result.Contract_Family_ID = new String(bytes, utf8Charset);
           				}
					
			            length = dis.readInt();
           				if (length == -1) {
           	    			result.Multi_Birth_Code = null;
           				} else {
               				byte[] bytes = new byte[length];
               				dis.read(bytes);
               				result.Multi_Birth_Code = new String(bytes, utf8Charset);
           				}
					
			            length = dis.readInt();
           				if (length == -1) {
           	    			result.Member_Key = null;
           				} else {
               				byte[] bytes = new byte[length];
               				dis.read(bytes);
               				result.Member_Key = new String(bytes, utf8Charset);
           				}
					
			            length = dis.readInt();
           				if (length == -1) {
           	    			result.Source = null;
           				} else {
               				byte[] bytes = new byte[length];
               				dis.read(bytes);
               				result.Source = new String(bytes, utf8Charset);
           				}
					
			            length = dis.readInt();
           				if (length == -1) {
           	    			result.year = null;
           				} else {
               				byte[] bytes = new byte[length];
               				dis.read(bytes);
               				result.year = new String(bytes, utf8Charset);
           				}
					
			            length = dis.readInt();
           				if (length == -1) {
           	    			result.GID = null;
           				} else {
               				byte[] bytes = new byte[length];
               				dis.read(bytes);
               				result.GID = new String(bytes, utf8Charset);
           				}
					

		} catch (java.lang.Exception e) {
			e.printStackTrace();
		} finally {
			if (dis != null) {
				try {
					dis.close();
            } catch (java.io.IOException e) {
            	e.printStackTrace();
         	}
        	}
     	}

   	return result;
   }

	public byte[] toByteArray() {
 		java.io.ByteArrayOutputStream bao = null;
		java.io.DataOutputStream dos = null;
		byte[] result = null;

 		try {
			bao = new java.io.ByteArrayOutputStream();
			dos = new java.io.DataOutputStream(bao);
			if(this.Gender == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = this.Gender.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
					
			if(this.Date == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = this.Date.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
					
			if(this.First_Name == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = this.First_Name.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
					
			if(this.Last_Name == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = this.Last_Name.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
					
			if(this.State == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = this.State.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
					
			if(this.City == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = this.City.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
					
			if(this.Zip_Code == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = this.Zip_Code.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
					
			if(this.Address_Line_1 == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = this.Address_Line_1.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
					
			if(this.Address_Line_2 == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = this.Address_Line_2.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
					
			if(this.Phone_Number == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = this.Phone_Number.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
					
			if(this.Social_Security_Number == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = this.Social_Security_Number.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
					
			if(this.UPI_ID == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = this.UPI_ID.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
					
			if(this.MBI == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = this.MBI.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
					
			if(this.Client_ID == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = this.Client_ID.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
					
			if(this.Carrier_ID == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = this.Carrier_ID.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
					
			if(this.Account_ID == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = this.Account_ID.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
					
			if(this.Group_ID == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = this.Group_ID.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
					
			if(this.Contract_Family_ID == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = this.Contract_Family_ID.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
					
			if(this.Multi_Birth_Code == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = this.Multi_Birth_Code.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
					
			if(this.Member_Key == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = this.Member_Key.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
					
			if(this.Source == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = this.Source.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
					
			if(this.year == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = this.year.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
					
			if(this.GID == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = this.GID.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
					
    	} catch (java.lang.Exception e) {
     		throw new RuntimeException(e);
		} finally {
     		if (dos != null) {
         		try {
            		dos.close();
           		} catch (java.io.IOException e) {
        			e.printStackTrace();
          		}
        	}
     	}
     	result = bao.toByteArray();
    	return result;
  	}


}
// /////////////////////////////////
  java.io.File dir_tSortRow_2_SortOut = new java.io.File("C:/Talend/Talend-Studio/UPI_bkp/temp");
  if (!dir_tSortRow_2_SortOut.exists()){
    dir_tSortRow_2_SortOut.mkdirs();
  }
  dir_tSortRow_2_SortOut = null;

org.talend.designer.components.tsort.io.sortimpl.FlowSorterIterator<row7StructILightSerializable> iterator_tSortRow_2_SortOut = new org.talend.designer.components.tsort.io.sortimpl.FlowSorterIterator<row7StructILightSerializable>();
iterator_tSortRow_2_SortOut.setBufferSize(1000000);
iterator_tSortRow_2_SortOut.setILightSerializable(new row7StructILightSerializable());
iterator_tSortRow_2_SortOut.workDirectory = "C:/Talend/Talend-Studio/UPI_bkp/temp" + "/" + jobName + "tSortRow_2_SortOut _" + Thread.currentThread().getId() + "_" + pid;
iterator_tSortRow_2_SortOut.initPut("");


 



/**
 * [tSortRow_2_SortOut begin ] stop
 */



	
	/**
	 * [tFilterRow_9 begin ] start
	 */

	

	
		
		ok_Hash.put("tFilterRow_9", false);
		start_Hash.put("tFilterRow_9", System.currentTimeMillis());
		
	
	currentComponent="tFilterRow_9";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row8");
			
		int tos_count_tFilterRow_9 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tFilterRow_9", "tFilterRow");
				talendJobLogProcess(globalMap);
			}
			
    int nb_line_tFilterRow_9 = 0;
    int nb_line_ok_tFilterRow_9 = 0;
    int nb_line_reject_tFilterRow_9 = 0;

    class Operator_tFilterRow_9 {
      private String sErrorMsg = "";
      private boolean bMatchFlag = true;
      private String sUnionFlag = "&&";

      public Operator_tFilterRow_9(String unionFlag){
        sUnionFlag = unionFlag;
        bMatchFlag =  "||".equals(unionFlag) ? false : true;
      }

      public String getErrorMsg() {
        if (sErrorMsg != null && sErrorMsg.length() > 1)
          return sErrorMsg.substring(1);
        else 
          return null;
      }

      public boolean getMatchFlag() {
        return bMatchFlag;
      }

      public void matches(boolean partMatched, String reason) {
        // no need to care about the next judgement
        if ("||".equals(sUnionFlag) && bMatchFlag){
          return;
        }

        if (!partMatched) {
          sErrorMsg += "|" + reason;
        }

        if ("||".equals(sUnionFlag))
          bMatchFlag = bMatchFlag || partMatched;
        else
          bMatchFlag = bMatchFlag && partMatched;
      }
    }

 



/**
 * [tFilterRow_9 begin ] stop
 */



	
	/**
	 * [tFileInputDelimited_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputDelimited_3", false);
		start_Hash.put("tFileInputDelimited_3", System.currentTimeMillis());
		
	
	currentComponent="tFileInputDelimited_3";

	
		int tos_count_tFileInputDelimited_3 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tFileInputDelimited_3", "tFileInputDelimited");
				talendJobLogProcess(globalMap);
			}
			
	
	
	
 
	
	
	final routines.system.RowState rowstate_tFileInputDelimited_3 = new routines.system.RowState();
	
	
				int nb_line_tFileInputDelimited_3 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_3 = null;
				int limit_tFileInputDelimited_3 = -1;
				try{
					
						Object filename_tFileInputDelimited_3 = context.location+"temp.csv";
						if(filename_tFileInputDelimited_3 instanceof java.io.InputStream){
							
			int footer_value_tFileInputDelimited_3 = 0, random_value_tFileInputDelimited_3 = -1;
			if(footer_value_tFileInputDelimited_3 >0 || random_value_tFileInputDelimited_3 > 0){
				throw new java.lang.Exception("When the input source is a stream,footer and random shouldn't be bigger than 0.");				
			}
		
						}
						try {
							fid_tFileInputDelimited_3 = new org.talend.fileprocess.FileInputDelimited(context.location+"temp.csv", "ISO-8859-15",";","\n",false,1,0,
									limit_tFileInputDelimited_3
								,-1, false);
						} catch(java.lang.Exception e) {
							
								
								System.err.println(e.getMessage());
							
						}
					
				    
					while (fid_tFileInputDelimited_3!=null && fid_tFileInputDelimited_3.nextRecord()) {
						rowstate_tFileInputDelimited_3.reset();
						
			    						row8 = null;			
												
									boolean whetherReject_tFileInputDelimited_3 = false;
									row8 = new row8Struct();
									try {
										
				int columnIndexWithD_tFileInputDelimited_3 = 0;
				
					columnIndexWithD_tFileInputDelimited_3 = 0;
					
							row8.Gender = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 1;
					
							row8.Date = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 2;
					
							row8.First_Name = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 3;
					
							row8.Last_Name = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 4;
					
							row8.State = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 5;
					
							row8.City = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 6;
					
							row8.Zip_Code = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 7;
					
							row8.Address_Line_1 = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 8;
					
							row8.Address_Line_2 = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 9;
					
							row8.Phone_Number = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 10;
					
							row8.Social_Security_Number = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 11;
					
							row8.UPI_ID = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 12;
					
							row8.MBI = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 13;
					
							row8.Client_ID = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 14;
					
							row8.Carrier_ID = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 15;
					
							row8.Account_ID = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 16;
					
							row8.Group_ID = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 17;
					
							row8.Contract_Family_ID = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 18;
					
							row8.Multi_Birth_Code = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 19;
					
							row8.Member_Key = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 20;
					
							row8.Source = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 21;
					
							row8.year = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 22;
					
							row8.GID = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
				
										
										if(rowstate_tFileInputDelimited_3.getException()!=null) {
											throw rowstate_tFileInputDelimited_3.getException();
										}
										
										
							
			    					} catch (java.lang.Exception e) {
			        					whetherReject_tFileInputDelimited_3 = true;
			        					
			                					System.err.println(e.getMessage());
			                					row8 = null;
			                				
			    					}
								

 



/**
 * [tFileInputDelimited_3 begin ] stop
 */
	
	/**
	 * [tFileInputDelimited_3 main ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_3";

	

 


	tos_count_tFileInputDelimited_3++;

/**
 * [tFileInputDelimited_3 main ] stop
 */
	
	/**
	 * [tFileInputDelimited_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_3";

	

 



/**
 * [tFileInputDelimited_3 process_data_begin ] stop
 */
// Start of branch "row8"
if(row8 != null) { 



	
	/**
	 * [tFilterRow_9 main ] start
	 */

	

	
	
	currentComponent="tFilterRow_9";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"row8");
			

          row7 = null;
    Operator_tFilterRow_9 ope_tFilterRow_9 = new Operator_tFilterRow_9("&&");
            ope_tFilterRow_9.matches((row8.GID == null? false : row8.GID.compareTo(((String)globalMap.get("GID_out"))) == 0)
                           , "GID.compareTo(((String)globalMap.get(\"GID_out\"))) == 0 failed");
    
    if (ope_tFilterRow_9.getMatchFlag()) {
              if(row7 == null){ 
                row7 = new row7Struct();
              }
               row7.Gender = row8.Gender;
               row7.Date = row8.Date;
               row7.First_Name = row8.First_Name;
               row7.Last_Name = row8.Last_Name;
               row7.State = row8.State;
               row7.City = row8.City;
               row7.Zip_Code = row8.Zip_Code;
               row7.Address_Line_1 = row8.Address_Line_1;
               row7.Address_Line_2 = row8.Address_Line_2;
               row7.Phone_Number = row8.Phone_Number;
               row7.Social_Security_Number = row8.Social_Security_Number;
               row7.UPI_ID = row8.UPI_ID;
               row7.MBI = row8.MBI;
               row7.Client_ID = row8.Client_ID;
               row7.Carrier_ID = row8.Carrier_ID;
               row7.Account_ID = row8.Account_ID;
               row7.Group_ID = row8.Group_ID;
               row7.Contract_Family_ID = row8.Contract_Family_ID;
               row7.Multi_Birth_Code = row8.Multi_Birth_Code;
               row7.Member_Key = row8.Member_Key;
               row7.Source = row8.Source;
               row7.year = row8.year;
               row7.GID = row8.GID;    
      nb_line_ok_tFilterRow_9++;
    } else {
      nb_line_reject_tFilterRow_9++;
    }

nb_line_tFilterRow_9++;

 


	tos_count_tFilterRow_9++;

/**
 * [tFilterRow_9 main ] stop
 */
	
	/**
	 * [tFilterRow_9 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFilterRow_9";

	

 



/**
 * [tFilterRow_9 process_data_begin ] stop
 */
// Start of branch "row7"
if(row7 != null) { 



	
	/**
	 * [tSortRow_2_SortOut main ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_2";
	
	currentComponent="tSortRow_2_SortOut";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"row7");
			


	row7StructILightSerializable current_tSortRow_2_SortOut = new row7StructILightSerializable();
	current_tSortRow_2_SortOut.Gender = row7.Gender;
	current_tSortRow_2_SortOut.Date = row7.Date;
	current_tSortRow_2_SortOut.First_Name = row7.First_Name;
	current_tSortRow_2_SortOut.Last_Name = row7.Last_Name;
	current_tSortRow_2_SortOut.State = row7.State;
	current_tSortRow_2_SortOut.City = row7.City;
	current_tSortRow_2_SortOut.Zip_Code = row7.Zip_Code;
	current_tSortRow_2_SortOut.Address_Line_1 = row7.Address_Line_1;
	current_tSortRow_2_SortOut.Address_Line_2 = row7.Address_Line_2;
	current_tSortRow_2_SortOut.Phone_Number = row7.Phone_Number;
	current_tSortRow_2_SortOut.Social_Security_Number = row7.Social_Security_Number;
	current_tSortRow_2_SortOut.UPI_ID = row7.UPI_ID;
	current_tSortRow_2_SortOut.MBI = row7.MBI;
	current_tSortRow_2_SortOut.Client_ID = row7.Client_ID;
	current_tSortRow_2_SortOut.Carrier_ID = row7.Carrier_ID;
	current_tSortRow_2_SortOut.Account_ID = row7.Account_ID;
	current_tSortRow_2_SortOut.Group_ID = row7.Group_ID;
	current_tSortRow_2_SortOut.Contract_Family_ID = row7.Contract_Family_ID;
	current_tSortRow_2_SortOut.Multi_Birth_Code = row7.Multi_Birth_Code;
	current_tSortRow_2_SortOut.Member_Key = row7.Member_Key;
	current_tSortRow_2_SortOut.Source = row7.Source;
	current_tSortRow_2_SortOut.year = row7.year;
	current_tSortRow_2_SortOut.GID = row7.GID;	
	iterator_tSortRow_2_SortOut.put("", current_tSortRow_2_SortOut);

 


	tos_count_tSortRow_2_SortOut++;

/**
 * [tSortRow_2_SortOut main ] stop
 */
	
	/**
	 * [tSortRow_2_SortOut process_data_begin ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_2";
	
	currentComponent="tSortRow_2_SortOut";

	

 



/**
 * [tSortRow_2_SortOut process_data_begin ] stop
 */
	
	/**
	 * [tSortRow_2_SortOut process_data_end ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_2";
	
	currentComponent="tSortRow_2_SortOut";

	

 



/**
 * [tSortRow_2_SortOut process_data_end ] stop
 */

} // End of branch "row7"




	
	/**
	 * [tFilterRow_9 process_data_end ] start
	 */

	

	
	
	currentComponent="tFilterRow_9";

	

 



/**
 * [tFilterRow_9 process_data_end ] stop
 */

} // End of branch "row8"




	
	/**
	 * [tFileInputDelimited_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_3";

	

 



/**
 * [tFileInputDelimited_3 process_data_end ] stop
 */
	
	/**
	 * [tFileInputDelimited_3 end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_3";

	



            }
            }finally{
                if(!((Object)(context.location+"temp.csv") instanceof java.io.InputStream)){
                	if(fid_tFileInputDelimited_3!=null){
                		fid_tFileInputDelimited_3.close();
                	}
                }
                if(fid_tFileInputDelimited_3!=null){
                	globalMap.put("tFileInputDelimited_3_NB_LINE", fid_tFileInputDelimited_3.getRowNumber());
					
                }
			}
			  

 

ok_Hash.put("tFileInputDelimited_3", true);
end_Hash.put("tFileInputDelimited_3", System.currentTimeMillis());




/**
 * [tFileInputDelimited_3 end ] stop
 */

	
	/**
	 * [tFilterRow_9 end ] start
	 */

	

	
	
	currentComponent="tFilterRow_9";

	
    globalMap.put("tFilterRow_9_NB_LINE", nb_line_tFilterRow_9);
    globalMap.put("tFilterRow_9_NB_LINE_OK", nb_line_ok_tFilterRow_9);
    globalMap.put("tFilterRow_9_NB_LINE_REJECT", nb_line_reject_tFilterRow_9);
    

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row8",2,0,
			 			talendJobLog,"tFileInputDelimited_3","tFileInputDelimited","tFilterRow_9","tFilterRow","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tFilterRow_9", true);
end_Hash.put("tFilterRow_9", System.currentTimeMillis());




/**
 * [tFilterRow_9 end ] stop
 */

	
	/**
	 * [tSortRow_2_SortOut end ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_2";
	
	currentComponent="tSortRow_2_SortOut";

	

iterator_tSortRow_2_SortOut.endPut();

globalMap.put("tSortRow_2", iterator_tSortRow_2_SortOut);

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row7",2,0,
			 			talendJobLog,"tFilterRow_9","tFilterRow","tSortRow_2_SortOut","tSortOut","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tSortRow_2_SortOut", true);
end_Hash.put("tSortRow_2_SortOut", System.currentTimeMillis());




/**
 * [tSortRow_2_SortOut end ] stop
 */




	
	/**
	 * [tFileOutputDelimited_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileOutputDelimited_4", false);
		start_Hash.put("tFileOutputDelimited_4", System.currentTimeMillis());
		
	
	currentComponent="tFileOutputDelimited_4";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row17");
			
		int tos_count_tFileOutputDelimited_4 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tFileOutputDelimited_4", "tFileOutputDelimited");
				talendJobLogProcess(globalMap);
			}
			

String fileName_tFileOutputDelimited_4 = "";
    fileName_tFileOutputDelimited_4 = (new java.io.File("C:/Talend/Source/UPI_SyntheticTestData_V3_CompleteSet_out.csv")).getAbsolutePath().replace("\\","/");
    String fullName_tFileOutputDelimited_4 = null;
    String extension_tFileOutputDelimited_4 = null;
    String directory_tFileOutputDelimited_4 = null;
    if((fileName_tFileOutputDelimited_4.indexOf("/") != -1)) {
        if(fileName_tFileOutputDelimited_4.lastIndexOf(".") < fileName_tFileOutputDelimited_4.lastIndexOf("/")) {
            fullName_tFileOutputDelimited_4 = fileName_tFileOutputDelimited_4;
            extension_tFileOutputDelimited_4 = "";
        } else {
            fullName_tFileOutputDelimited_4 = fileName_tFileOutputDelimited_4.substring(0, fileName_tFileOutputDelimited_4.lastIndexOf("."));
            extension_tFileOutputDelimited_4 = fileName_tFileOutputDelimited_4.substring(fileName_tFileOutputDelimited_4.lastIndexOf("."));
        }
        directory_tFileOutputDelimited_4 = fileName_tFileOutputDelimited_4.substring(0, fileName_tFileOutputDelimited_4.lastIndexOf("/"));
    } else {
        if(fileName_tFileOutputDelimited_4.lastIndexOf(".") != -1) {
            fullName_tFileOutputDelimited_4 = fileName_tFileOutputDelimited_4.substring(0, fileName_tFileOutputDelimited_4.lastIndexOf("."));
            extension_tFileOutputDelimited_4 = fileName_tFileOutputDelimited_4.substring(fileName_tFileOutputDelimited_4.lastIndexOf("."));
        } else {
            fullName_tFileOutputDelimited_4 = fileName_tFileOutputDelimited_4;
            extension_tFileOutputDelimited_4 = "";
        }
        directory_tFileOutputDelimited_4 = "";
    }
    boolean isFileGenerated_tFileOutputDelimited_4 = true;
    java.io.File filetFileOutputDelimited_4 = new java.io.File(fileName_tFileOutputDelimited_4);
    globalMap.put("tFileOutputDelimited_4_FILE_NAME",fileName_tFileOutputDelimited_4);
        if(filetFileOutputDelimited_4.exists()){
            isFileGenerated_tFileOutputDelimited_4 = false;
        }
            int nb_line_tFileOutputDelimited_4 = 0;
            int splitedFileNo_tFileOutputDelimited_4 = 0;
            int currentRow_tFileOutputDelimited_4 = 0;

            final String OUT_DELIM_tFileOutputDelimited_4 = /** Start field tFileOutputDelimited_4:FIELDSEPARATOR */"|"/** End field tFileOutputDelimited_4:FIELDSEPARATOR */;

            final String OUT_DELIM_ROWSEP_tFileOutputDelimited_4 = /** Start field tFileOutputDelimited_4:ROWSEPARATOR */"\n"/** End field tFileOutputDelimited_4:ROWSEPARATOR */;

                    //create directory only if not exists
                    if(directory_tFileOutputDelimited_4 != null && directory_tFileOutputDelimited_4.trim().length() != 0) {
                        java.io.File dir_tFileOutputDelimited_4 = new java.io.File(directory_tFileOutputDelimited_4);
                        if(!dir_tFileOutputDelimited_4.exists()) {
                            dir_tFileOutputDelimited_4.mkdirs();
                        }
                    }

                        //routines.system.Row
                        java.io.Writer outtFileOutputDelimited_4 = null;

                        outtFileOutputDelimited_4 = new java.io.BufferedWriter(new java.io.OutputStreamWriter(
                        new java.io.FileOutputStream(fileName_tFileOutputDelimited_4, true),"ISO-8859-15"));
                                    if(filetFileOutputDelimited_4.length()==0){
                                        outtFileOutputDelimited_4.write("Gender");
                                            outtFileOutputDelimited_4.write(OUT_DELIM_tFileOutputDelimited_4);
                                        outtFileOutputDelimited_4.write("Date");
                                            outtFileOutputDelimited_4.write(OUT_DELIM_tFileOutputDelimited_4);
                                        outtFileOutputDelimited_4.write("First_Name");
                                            outtFileOutputDelimited_4.write(OUT_DELIM_tFileOutputDelimited_4);
                                        outtFileOutputDelimited_4.write("Last_Name");
                                            outtFileOutputDelimited_4.write(OUT_DELIM_tFileOutputDelimited_4);
                                        outtFileOutputDelimited_4.write("State");
                                            outtFileOutputDelimited_4.write(OUT_DELIM_tFileOutputDelimited_4);
                                        outtFileOutputDelimited_4.write("City");
                                            outtFileOutputDelimited_4.write(OUT_DELIM_tFileOutputDelimited_4);
                                        outtFileOutputDelimited_4.write("Zip_Code");
                                            outtFileOutputDelimited_4.write(OUT_DELIM_tFileOutputDelimited_4);
                                        outtFileOutputDelimited_4.write("Address_Line_1");
                                            outtFileOutputDelimited_4.write(OUT_DELIM_tFileOutputDelimited_4);
                                        outtFileOutputDelimited_4.write("Address_Line_2");
                                            outtFileOutputDelimited_4.write(OUT_DELIM_tFileOutputDelimited_4);
                                        outtFileOutputDelimited_4.write("Phone_Number");
                                            outtFileOutputDelimited_4.write(OUT_DELIM_tFileOutputDelimited_4);
                                        outtFileOutputDelimited_4.write("Social_Security_Number");
                                            outtFileOutputDelimited_4.write(OUT_DELIM_tFileOutputDelimited_4);
                                        outtFileOutputDelimited_4.write("UPI_ID");
                                            outtFileOutputDelimited_4.write(OUT_DELIM_tFileOutputDelimited_4);
                                        outtFileOutputDelimited_4.write("MBI");
                                            outtFileOutputDelimited_4.write(OUT_DELIM_tFileOutputDelimited_4);
                                        outtFileOutputDelimited_4.write("Client_ID");
                                            outtFileOutputDelimited_4.write(OUT_DELIM_tFileOutputDelimited_4);
                                        outtFileOutputDelimited_4.write("Carrier_ID");
                                            outtFileOutputDelimited_4.write(OUT_DELIM_tFileOutputDelimited_4);
                                        outtFileOutputDelimited_4.write("Account_ID");
                                            outtFileOutputDelimited_4.write(OUT_DELIM_tFileOutputDelimited_4);
                                        outtFileOutputDelimited_4.write("Group_ID");
                                            outtFileOutputDelimited_4.write(OUT_DELIM_tFileOutputDelimited_4);
                                        outtFileOutputDelimited_4.write("Contract_Family_ID");
                                            outtFileOutputDelimited_4.write(OUT_DELIM_tFileOutputDelimited_4);
                                        outtFileOutputDelimited_4.write("Multi_Birth_Code");
                                            outtFileOutputDelimited_4.write(OUT_DELIM_tFileOutputDelimited_4);
                                        outtFileOutputDelimited_4.write("Member_Key");
                                            outtFileOutputDelimited_4.write(OUT_DELIM_tFileOutputDelimited_4);
                                        outtFileOutputDelimited_4.write("Source");
                                            outtFileOutputDelimited_4.write(OUT_DELIM_tFileOutputDelimited_4);
                                        outtFileOutputDelimited_4.write("GID");
                                        outtFileOutputDelimited_4.write(OUT_DELIM_ROWSEP_tFileOutputDelimited_4);
                                        outtFileOutputDelimited_4.flush();
                                    }


        resourceMap.put("out_tFileOutputDelimited_4", outtFileOutputDelimited_4);
resourceMap.put("nb_line_tFileOutputDelimited_4", nb_line_tFileOutputDelimited_4);

 



/**
 * [tFileOutputDelimited_4 begin ] stop
 */



	
	/**
	 * [tLogRow_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tLogRow_6", false);
		start_Hash.put("tLogRow_6", System.currentTimeMillis());
		
	
	currentComponent="tLogRow_6";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row14");
			
		int tos_count_tLogRow_6 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tLogRow_6", "tLogRow");
				talendJobLogProcess(globalMap);
			}
			

	///////////////////////
	
         class Util_tLogRow_6 {

        String[] des_top = { ".", ".", "-", "+" };

        String[] des_head = { "|=", "=|", "-", "+" };

        String[] des_bottom = { "'", "'", "-", "+" };

        String name="";

        java.util.List<String[]> list = new java.util.ArrayList<String[]>();

        int[] colLengths = new int[22];

        public void addRow(String[] row) {

            for (int i = 0; i < 22; i++) {
                if (row[i]!=null) {
                  colLengths[i] = Math.max(colLengths[i], row[i].length());
                }
            }
            list.add(row);
        }

        public void setTableName(String name) {

            this.name = name;
        }

            public StringBuilder format() {
            
                StringBuilder sb = new StringBuilder();
  
            
                    sb.append(print(des_top));
    
                    int totals = 0;
                    for (int i = 0; i < colLengths.length; i++) {
                        totals = totals + colLengths[i];
                    }
    
                    // name
                    sb.append("|");
                    int k = 0;
                    for (k = 0; k < (totals + 21 - name.length()) / 2; k++) {
                        sb.append(' ');
                    }
                    sb.append(name);
                    for (int i = 0; i < totals + 21 - name.length() - k; i++) {
                        sb.append(' ');
                    }
                    sb.append("|\n");

                    // head and rows
                    sb.append(print(des_head));
                    for (int i = 0; i < list.size(); i++) {
    
                        String[] row = list.get(i);
    
                        java.util.Formatter formatter = new java.util.Formatter(new StringBuilder());
                        
                        StringBuilder sbformat = new StringBuilder();                                             
        			        sbformat.append("|%1$-");
        			        sbformat.append(colLengths[0]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%2$-");
        			        sbformat.append(colLengths[1]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%3$-");
        			        sbformat.append(colLengths[2]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%4$-");
        			        sbformat.append(colLengths[3]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%5$-");
        			        sbformat.append(colLengths[4]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%6$-");
        			        sbformat.append(colLengths[5]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%7$-");
        			        sbformat.append(colLengths[6]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%8$-");
        			        sbformat.append(colLengths[7]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%9$-");
        			        sbformat.append(colLengths[8]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%10$-");
        			        sbformat.append(colLengths[9]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%11$-");
        			        sbformat.append(colLengths[10]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%12$-");
        			        sbformat.append(colLengths[11]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%13$-");
        			        sbformat.append(colLengths[12]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%14$-");
        			        sbformat.append(colLengths[13]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%15$-");
        			        sbformat.append(colLengths[14]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%16$-");
        			        sbformat.append(colLengths[15]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%17$-");
        			        sbformat.append(colLengths[16]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%18$-");
        			        sbformat.append(colLengths[17]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%19$-");
        			        sbformat.append(colLengths[18]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%20$-");
        			        sbformat.append(colLengths[19]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%21$-");
        			        sbformat.append(colLengths[20]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%22$-");
        			        sbformat.append(colLengths[21]);
        			        sbformat.append("s");
        			                      
                        sbformat.append("|\n");                    
       
                        formatter.format(sbformat.toString(), (Object[])row);	
                                
                        sb.append(formatter.toString());
                        if (i == 0)
                            sb.append(print(des_head)); // print the head
                    }
    
                    // end
                    sb.append(print(des_bottom));
                    return sb;
                }
            

            private StringBuilder print(String[] fillChars) {
                StringBuilder sb = new StringBuilder();
                //first column
                sb.append(fillChars[0]);                
                    for (int i = 0; i < colLengths[0] - fillChars[0].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);	                

                    for (int i = 0; i < colLengths[1] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[2] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[3] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[4] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[5] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[6] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[7] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[8] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[9] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[10] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[11] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[12] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[13] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[14] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[15] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[16] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[17] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[18] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[19] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[20] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                
                    //last column
                    for (int i = 0; i < colLengths[21] - fillChars[1].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }         
                sb.append(fillChars[1]);
                sb.append("\n");               
                return sb;
            }
            
            public boolean isTableEmpty(){
            	if (list.size() > 1)
            		return false;
            	return true;
            }
        }
        Util_tLogRow_6 util_tLogRow_6 = new Util_tLogRow_6();
        util_tLogRow_6.setTableName("tLogRow_6");
        util_tLogRow_6.addRow(new String[]{"Gender","Date","First_Name","Last_Name","State","City","Zip_Code","Address_Line_1","Address_Line_2","Phone_Number","Social_Security_Number","UPI_ID","MBI","Client_ID","Carrier_ID","Account_ID","Group_ID","Contract_Family_ID","Multi_Birth_Code","Member_Key","Source","GID",});        
 		StringBuilder strBuffer_tLogRow_6 = null;
		int nb_line_tLogRow_6 = 0;
///////////////////////    			



 



/**
 * [tLogRow_6 begin ] stop
 */



	
	/**
	 * [tJavaFlex_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tJavaFlex_3", false);
		start_Hash.put("tJavaFlex_3", System.currentTimeMillis());
		
	
	currentComponent="tJavaFlex_3";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row16");
			
		int tos_count_tJavaFlex_3 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tJavaFlex_3", "tJavaFlex");
				talendJobLogProcess(globalMap);
			}
			


int i=0;
MemberUpis memberUpis= new MemberUpis();
Map<Integer,String> upis=null;
Member member;
String upi=null;



 



/**
 * [tJavaFlex_3 begin ] stop
 */



	
	/**
	 * [tSortRow_2_SortIn begin ] start
	 */

	

	
		
		ok_Hash.put("tSortRow_2_SortIn", false);
		start_Hash.put("tSortRow_2_SortIn", System.currentTimeMillis());
		
	
		currentVirtualComponent = "tSortRow_2";
	
	currentComponent="tSortRow_2_SortIn";

	
		int tos_count_tSortRow_2_SortIn = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tSortRow_2_SortIn", "tSortIn");
				talendJobLogProcess(globalMap);
			}
			


java.util.Iterator<row7Struct> iterator_tSortRow_2_SortIn = (java.util.Iterator<row7Struct>) globalMap.remove("tSortRow_2");
int nb_line_tSortRow_2_SortIn = 0;
row7Struct current_tSortRow_2_SortIn = null;

while (iterator_tSortRow_2_SortIn.hasNext()) {
	current_tSortRow_2_SortIn = iterator_tSortRow_2_SortIn.next();
	row16.Gender = current_tSortRow_2_SortIn.Gender;
	row16.Date = current_tSortRow_2_SortIn.Date;
	row16.First_Name = current_tSortRow_2_SortIn.First_Name;
	row16.Last_Name = current_tSortRow_2_SortIn.Last_Name;
	row16.State = current_tSortRow_2_SortIn.State;
	row16.City = current_tSortRow_2_SortIn.City;
	row16.Zip_Code = current_tSortRow_2_SortIn.Zip_Code;
	row16.Address_Line_1 = current_tSortRow_2_SortIn.Address_Line_1;
	row16.Address_Line_2 = current_tSortRow_2_SortIn.Address_Line_2;
	row16.Phone_Number = current_tSortRow_2_SortIn.Phone_Number;
	row16.Social_Security_Number = current_tSortRow_2_SortIn.Social_Security_Number;
	row16.UPI_ID = current_tSortRow_2_SortIn.UPI_ID;
	row16.MBI = current_tSortRow_2_SortIn.MBI;
	row16.Client_ID = current_tSortRow_2_SortIn.Client_ID;
	row16.Carrier_ID = current_tSortRow_2_SortIn.Carrier_ID;
	row16.Account_ID = current_tSortRow_2_SortIn.Account_ID;
	row16.Group_ID = current_tSortRow_2_SortIn.Group_ID;
	row16.Contract_Family_ID = current_tSortRow_2_SortIn.Contract_Family_ID;
	row16.Multi_Birth_Code = current_tSortRow_2_SortIn.Multi_Birth_Code;
	row16.Member_Key = current_tSortRow_2_SortIn.Member_Key;
	row16.Source = current_tSortRow_2_SortIn.Source;
	row16.year = current_tSortRow_2_SortIn.year;
	row16.GID = current_tSortRow_2_SortIn.GID;	
	// increase number of line sorted
	nb_line_tSortRow_2_SortIn++;

 



/**
 * [tSortRow_2_SortIn begin ] stop
 */
	
	/**
	 * [tSortRow_2_SortIn main ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_2";
	
	currentComponent="tSortRow_2_SortIn";

	

 


	tos_count_tSortRow_2_SortIn++;

/**
 * [tSortRow_2_SortIn main ] stop
 */
	
	/**
	 * [tSortRow_2_SortIn process_data_begin ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_2";
	
	currentComponent="tSortRow_2_SortIn";

	

 



/**
 * [tSortRow_2_SortIn process_data_begin ] stop
 */

	
	/**
	 * [tJavaFlex_3 main ] start
	 */

	

	
	
	currentComponent="tJavaFlex_3";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"row16");
			


	        				row14.Gender = row16.Gender;
	        				row14.Date = row16.Date;
	        				row14.First_Name = row16.First_Name;
	        				row14.Last_Name = row16.Last_Name;
	        				row14.State = row16.State;
	        				row14.City = row16.City;
	        				row14.Zip_Code = row16.Zip_Code;
	        				row14.Address_Line_1 = row16.Address_Line_1;
	        				row14.Address_Line_2 = row16.Address_Line_2;
	        				row14.Phone_Number = row16.Phone_Number;
	        				row14.Social_Security_Number = row16.Social_Security_Number;
	        				row14.UPI_ID = row16.UPI_ID;
	        				row14.MBI = row16.MBI;
	        				row14.Client_ID = row16.Client_ID;
	        				row14.Carrier_ID = row16.Carrier_ID;
	        				row14.Account_ID = row16.Account_ID;
	        				row14.Group_ID = row16.Group_ID;
	        				row14.Contract_Family_ID = row16.Contract_Family_ID;
	        				row14.Multi_Birth_Code = row16.Multi_Birth_Code;
	        				row14.Member_Key = row16.Member_Key;
	        				row14.Source = row16.Source;
	        				row14.GID = row16.GID;



member = new Member(row16.Gender, row16.First_Name, row16.Last_Name, row16.Date, row16.State, row16.City, row16.Zip_Code, row16.Address_Line_1,row16.Address_Line_2,row16.Phone_Number,row16.Social_Security_Number,null, row16.MBI,row16.Multi_Birth_Code,row16.Client_ID, row16.Carrier_ID, row16.Account_ID,row16.Group_ID, row16.Contract_Family_ID,null);
//System.out.println(i+": "+ member.toString());
 
upi=memberUpis.addToGraph(member, i, 85);
 
if(upi==null){
      memberUpis.contractGraph();
      upis = memberUpis.getUpis();
      upi = upis.get(i);
}

row14.UPI_ID = upi;
//System.out.println(i+" : '"+row16.MBI+", "+upi+"', '"+row14.UPI_ID+"'");
i++;


 


	tos_count_tJavaFlex_3++;

/**
 * [tJavaFlex_3 main ] stop
 */
	
	/**
	 * [tJavaFlex_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tJavaFlex_3";

	

 



/**
 * [tJavaFlex_3 process_data_begin ] stop
 */

	
	/**
	 * [tLogRow_6 main ] start
	 */

	

	
	
	currentComponent="tLogRow_6";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"row14");
			
///////////////////////		
						

				
				String[] row_tLogRow_6 = new String[22];
   				
	    		if(row14.Gender != null) { //              
                 row_tLogRow_6[0]=    						    
				                String.valueOf(row14.Gender)			
					          ;	
							
	    		} //			
    			   				
	    		if(row14.Date != null) { //              
                 row_tLogRow_6[1]=    						    
				                String.valueOf(row14.Date)			
					          ;	
							
	    		} //			
    			   				
	    		if(row14.First_Name != null) { //              
                 row_tLogRow_6[2]=    						    
				                String.valueOf(row14.First_Name)			
					          ;	
							
	    		} //			
    			   				
	    		if(row14.Last_Name != null) { //              
                 row_tLogRow_6[3]=    						    
				                String.valueOf(row14.Last_Name)			
					          ;	
							
	    		} //			
    			   				
	    		if(row14.State != null) { //              
                 row_tLogRow_6[4]=    						    
				                String.valueOf(row14.State)			
					          ;	
							
	    		} //			
    			   				
	    		if(row14.City != null) { //              
                 row_tLogRow_6[5]=    						    
				                String.valueOf(row14.City)			
					          ;	
							
	    		} //			
    			   				
	    		if(row14.Zip_Code != null) { //              
                 row_tLogRow_6[6]=    						    
				                String.valueOf(row14.Zip_Code)			
					          ;	
							
	    		} //			
    			   				
	    		if(row14.Address_Line_1 != null) { //              
                 row_tLogRow_6[7]=    						    
				                String.valueOf(row14.Address_Line_1)			
					          ;	
							
	    		} //			
    			   				
	    		if(row14.Address_Line_2 != null) { //              
                 row_tLogRow_6[8]=    						    
				                String.valueOf(row14.Address_Line_2)			
					          ;	
							
	    		} //			
    			   				
	    		if(row14.Phone_Number != null) { //              
                 row_tLogRow_6[9]=    						    
				                String.valueOf(row14.Phone_Number)			
					          ;	
							
	    		} //			
    			   				
	    		if(row14.Social_Security_Number != null) { //              
                 row_tLogRow_6[10]=    						    
				                String.valueOf(row14.Social_Security_Number)			
					          ;	
							
	    		} //			
    			   				
	    		if(row14.UPI_ID != null) { //              
                 row_tLogRow_6[11]=    						    
				                String.valueOf(row14.UPI_ID)			
					          ;	
							
	    		} //			
    			   				
	    		if(row14.MBI != null) { //              
                 row_tLogRow_6[12]=    						    
				                String.valueOf(row14.MBI)			
					          ;	
							
	    		} //			
    			   				
	    		if(row14.Client_ID != null) { //              
                 row_tLogRow_6[13]=    						    
				                String.valueOf(row14.Client_ID)			
					          ;	
							
	    		} //			
    			   				
	    		if(row14.Carrier_ID != null) { //              
                 row_tLogRow_6[14]=    						    
				                String.valueOf(row14.Carrier_ID)			
					          ;	
							
	    		} //			
    			   				
	    		if(row14.Account_ID != null) { //              
                 row_tLogRow_6[15]=    						    
				                String.valueOf(row14.Account_ID)			
					          ;	
							
	    		} //			
    			   				
	    		if(row14.Group_ID != null) { //              
                 row_tLogRow_6[16]=    						    
				                String.valueOf(row14.Group_ID)			
					          ;	
							
	    		} //			
    			   				
	    		if(row14.Contract_Family_ID != null) { //              
                 row_tLogRow_6[17]=    						    
				                String.valueOf(row14.Contract_Family_ID)			
					          ;	
							
	    		} //			
    			   				
	    		if(row14.Multi_Birth_Code != null) { //              
                 row_tLogRow_6[18]=    						    
				                String.valueOf(row14.Multi_Birth_Code)			
					          ;	
							
	    		} //			
    			   				
	    		if(row14.Member_Key != null) { //              
                 row_tLogRow_6[19]=    						    
				                String.valueOf(row14.Member_Key)			
					          ;	
							
	    		} //			
    			   				
	    		if(row14.Source != null) { //              
                 row_tLogRow_6[20]=    						    
				                String.valueOf(row14.Source)			
					          ;	
							
	    		} //			
    			   				
	    		if(row14.GID != null) { //              
                 row_tLogRow_6[21]=    						    
				                String.valueOf(row14.GID)			
					          ;	
							
	    		} //			
    			 

				util_tLogRow_6.addRow(row_tLogRow_6);	
				nb_line_tLogRow_6++;
//////

//////                    
                    
///////////////////////    			

 
     row17 = row14;


	tos_count_tLogRow_6++;

/**
 * [tLogRow_6 main ] stop
 */
	
	/**
	 * [tLogRow_6 process_data_begin ] start
	 */

	

	
	
	currentComponent="tLogRow_6";

	

 



/**
 * [tLogRow_6 process_data_begin ] stop
 */

	
	/**
	 * [tFileOutputDelimited_4 main ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_4";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"row17");
			


                    StringBuilder sb_tFileOutputDelimited_4 = new StringBuilder();
                            if(row17.Gender != null) {
                        sb_tFileOutputDelimited_4.append(
                            row17.Gender
                        );
                            }
                            sb_tFileOutputDelimited_4.append(OUT_DELIM_tFileOutputDelimited_4);
                            if(row17.Date != null) {
                        sb_tFileOutputDelimited_4.append(
                            row17.Date
                        );
                            }
                            sb_tFileOutputDelimited_4.append(OUT_DELIM_tFileOutputDelimited_4);
                            if(row17.First_Name != null) {
                        sb_tFileOutputDelimited_4.append(
                            row17.First_Name
                        );
                            }
                            sb_tFileOutputDelimited_4.append(OUT_DELIM_tFileOutputDelimited_4);
                            if(row17.Last_Name != null) {
                        sb_tFileOutputDelimited_4.append(
                            row17.Last_Name
                        );
                            }
                            sb_tFileOutputDelimited_4.append(OUT_DELIM_tFileOutputDelimited_4);
                            if(row17.State != null) {
                        sb_tFileOutputDelimited_4.append(
                            row17.State
                        );
                            }
                            sb_tFileOutputDelimited_4.append(OUT_DELIM_tFileOutputDelimited_4);
                            if(row17.City != null) {
                        sb_tFileOutputDelimited_4.append(
                            row17.City
                        );
                            }
                            sb_tFileOutputDelimited_4.append(OUT_DELIM_tFileOutputDelimited_4);
                            if(row17.Zip_Code != null) {
                        sb_tFileOutputDelimited_4.append(
                            row17.Zip_Code
                        );
                            }
                            sb_tFileOutputDelimited_4.append(OUT_DELIM_tFileOutputDelimited_4);
                            if(row17.Address_Line_1 != null) {
                        sb_tFileOutputDelimited_4.append(
                            row17.Address_Line_1
                        );
                            }
                            sb_tFileOutputDelimited_4.append(OUT_DELIM_tFileOutputDelimited_4);
                            if(row17.Address_Line_2 != null) {
                        sb_tFileOutputDelimited_4.append(
                            row17.Address_Line_2
                        );
                            }
                            sb_tFileOutputDelimited_4.append(OUT_DELIM_tFileOutputDelimited_4);
                            if(row17.Phone_Number != null) {
                        sb_tFileOutputDelimited_4.append(
                            row17.Phone_Number
                        );
                            }
                            sb_tFileOutputDelimited_4.append(OUT_DELIM_tFileOutputDelimited_4);
                            if(row17.Social_Security_Number != null) {
                        sb_tFileOutputDelimited_4.append(
                            row17.Social_Security_Number
                        );
                            }
                            sb_tFileOutputDelimited_4.append(OUT_DELIM_tFileOutputDelimited_4);
                            if(row17.UPI_ID != null) {
                        sb_tFileOutputDelimited_4.append(
                            row17.UPI_ID
                        );
                            }
                            sb_tFileOutputDelimited_4.append(OUT_DELIM_tFileOutputDelimited_4);
                            if(row17.MBI != null) {
                        sb_tFileOutputDelimited_4.append(
                            row17.MBI
                        );
                            }
                            sb_tFileOutputDelimited_4.append(OUT_DELIM_tFileOutputDelimited_4);
                            if(row17.Client_ID != null) {
                        sb_tFileOutputDelimited_4.append(
                            row17.Client_ID
                        );
                            }
                            sb_tFileOutputDelimited_4.append(OUT_DELIM_tFileOutputDelimited_4);
                            if(row17.Carrier_ID != null) {
                        sb_tFileOutputDelimited_4.append(
                            row17.Carrier_ID
                        );
                            }
                            sb_tFileOutputDelimited_4.append(OUT_DELIM_tFileOutputDelimited_4);
                            if(row17.Account_ID != null) {
                        sb_tFileOutputDelimited_4.append(
                            row17.Account_ID
                        );
                            }
                            sb_tFileOutputDelimited_4.append(OUT_DELIM_tFileOutputDelimited_4);
                            if(row17.Group_ID != null) {
                        sb_tFileOutputDelimited_4.append(
                            row17.Group_ID
                        );
                            }
                            sb_tFileOutputDelimited_4.append(OUT_DELIM_tFileOutputDelimited_4);
                            if(row17.Contract_Family_ID != null) {
                        sb_tFileOutputDelimited_4.append(
                            row17.Contract_Family_ID
                        );
                            }
                            sb_tFileOutputDelimited_4.append(OUT_DELIM_tFileOutputDelimited_4);
                            if(row17.Multi_Birth_Code != null) {
                        sb_tFileOutputDelimited_4.append(
                            row17.Multi_Birth_Code
                        );
                            }
                            sb_tFileOutputDelimited_4.append(OUT_DELIM_tFileOutputDelimited_4);
                            if(row17.Member_Key != null) {
                        sb_tFileOutputDelimited_4.append(
                            row17.Member_Key
                        );
                            }
                            sb_tFileOutputDelimited_4.append(OUT_DELIM_tFileOutputDelimited_4);
                            if(row17.Source != null) {
                        sb_tFileOutputDelimited_4.append(
                            row17.Source
                        );
                            }
                            sb_tFileOutputDelimited_4.append(OUT_DELIM_tFileOutputDelimited_4);
                            if(row17.GID != null) {
                        sb_tFileOutputDelimited_4.append(
                            row17.GID
                        );
                            }
                    sb_tFileOutputDelimited_4.append(OUT_DELIM_ROWSEP_tFileOutputDelimited_4);


                    nb_line_tFileOutputDelimited_4++;
                    resourceMap.put("nb_line_tFileOutputDelimited_4", nb_line_tFileOutputDelimited_4);

                        outtFileOutputDelimited_4.write(sb_tFileOutputDelimited_4.toString());




 


	tos_count_tFileOutputDelimited_4++;

/**
 * [tFileOutputDelimited_4 main ] stop
 */
	
	/**
	 * [tFileOutputDelimited_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_4";

	

 



/**
 * [tFileOutputDelimited_4 process_data_begin ] stop
 */
	
	/**
	 * [tFileOutputDelimited_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_4";

	

 



/**
 * [tFileOutputDelimited_4 process_data_end ] stop
 */



	
	/**
	 * [tLogRow_6 process_data_end ] start
	 */

	

	
	
	currentComponent="tLogRow_6";

	

 



/**
 * [tLogRow_6 process_data_end ] stop
 */



	
	/**
	 * [tJavaFlex_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tJavaFlex_3";

	

 



/**
 * [tJavaFlex_3 process_data_end ] stop
 */



	
	/**
	 * [tSortRow_2_SortIn process_data_end ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_2";
	
	currentComponent="tSortRow_2_SortIn";

	

 



/**
 * [tSortRow_2_SortIn process_data_end ] stop
 */
	
	/**
	 * [tSortRow_2_SortIn end ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_2";
	
	currentComponent="tSortRow_2_SortIn";

	


}

globalMap.put("tSortRow_2_SortIn_NB_LINE",nb_line_tSortRow_2_SortIn);

 

ok_Hash.put("tSortRow_2_SortIn", true);
end_Hash.put("tSortRow_2_SortIn", System.currentTimeMillis());




/**
 * [tSortRow_2_SortIn end ] stop
 */

	
	/**
	 * [tJavaFlex_3 end ] start
	 */

	

	
	
	currentComponent="tJavaFlex_3";

	


// end of the component, outside/closing the loop
System.out.println(upis);

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row16",2,0,
			 			talendJobLog,"tSortRow_2_SortIn","tSortIn","tJavaFlex_3","tJavaFlex","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tJavaFlex_3", true);
end_Hash.put("tJavaFlex_3", System.currentTimeMillis());




/**
 * [tJavaFlex_3 end ] stop
 */

	
	/**
	 * [tLogRow_6 end ] start
	 */

	

	
	
	currentComponent="tLogRow_6";

	


//////

                    
                    java.io.PrintStream consoleOut_tLogRow_6 = null;
                    if (globalMap.get("tLogRow_CONSOLE")!=null)
                    {
                    	consoleOut_tLogRow_6 = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
                    }
                    else
                    {
                    	consoleOut_tLogRow_6 = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
                    	globalMap.put("tLogRow_CONSOLE",consoleOut_tLogRow_6);
                    }
                    
                    consoleOut_tLogRow_6.println(util_tLogRow_6.format().toString());
                    consoleOut_tLogRow_6.flush();
//////
globalMap.put("tLogRow_6_NB_LINE",nb_line_tLogRow_6);

///////////////////////    			

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row14",2,0,
			 			talendJobLog,"tJavaFlex_3","tJavaFlex","tLogRow_6","tLogRow","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tLogRow_6", true);
end_Hash.put("tLogRow_6", System.currentTimeMillis());




/**
 * [tLogRow_6 end ] stop
 */

	
	/**
	 * [tFileOutputDelimited_4 end ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_4";

	



		
			
					if(outtFileOutputDelimited_4!=null) {
						outtFileOutputDelimited_4.flush();
						outtFileOutputDelimited_4.close();
					}
				
				globalMap.put("tFileOutputDelimited_4_NB_LINE",nb_line_tFileOutputDelimited_4);
				globalMap.put("tFileOutputDelimited_4_FILE_NAME",fileName_tFileOutputDelimited_4);
			
		
		
		resourceMap.put("finish_tFileOutputDelimited_4", true);
	

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row17",2,0,
			 			talendJobLog,"tLogRow_6","tLogRow","tFileOutputDelimited_4","tFileOutputDelimited","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tFileOutputDelimited_4", true);
end_Hash.put("tFileOutputDelimited_4", System.currentTimeMillis());




/**
 * [tFileOutputDelimited_4 end ] stop
 */


















						if(execStat){
							runStat.updateStatOnConnection("iterate1", 2, "exec" + NB_ITERATE_tFileInputDelimited_3);
						}				
					




	
	/**
	 * [tFlowToIterate_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_1";

	

 



/**
 * [tFlowToIterate_1 process_data_end ] stop
 */

} // End of branch "row5"




	
	/**
	 * [tFileInputDelimited_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_2";

	

 



/**
 * [tFileInputDelimited_2 process_data_end ] stop
 */
	
	/**
	 * [tFileInputDelimited_2 end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_2";

	



            }
            }finally{
                if(!((Object)(context.location+"temp_stg.csv") instanceof java.io.InputStream)){
                	if(fid_tFileInputDelimited_2!=null){
                		fid_tFileInputDelimited_2.close();
                	}
                }
                if(fid_tFileInputDelimited_2!=null){
                	globalMap.put("tFileInputDelimited_2_NB_LINE", fid_tFileInputDelimited_2.getRowNumber());
					
                }
			}
			  

 

ok_Hash.put("tFileInputDelimited_2", true);
end_Hash.put("tFileInputDelimited_2", System.currentTimeMillis());




/**
 * [tFileInputDelimited_2 end ] stop
 */

	
	/**
	 * [tFlowToIterate_1 end ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_1";

	

globalMap.put("tFlowToIterate_1_NB_LINE",nb_line_tFlowToIterate_1);
			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row5",2,0,
			 			talendJobLog,"tFileInputDelimited_2","tFileInputDelimited","tFlowToIterate_1","tFlowToIterate","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tFlowToIterate_1", true);
end_Hash.put("tFlowToIterate_1", System.currentTimeMillis());




/**
 * [tFlowToIterate_1 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
					te.setVirtualComponentName(currentVirtualComponent);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
							//free memory for "tSortRow_2_SortIn"
							globalMap.remove("tSortRow_2");
						
				try{
					
	
	/**
	 * [tFileInputDelimited_2 finally ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_2";

	

 



/**
 * [tFileInputDelimited_2 finally ] stop
 */

	
	/**
	 * [tFlowToIterate_1 finally ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_1";

	

 



/**
 * [tFlowToIterate_1 finally ] stop
 */

	
	/**
	 * [tFileInputDelimited_3 finally ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_3";

	

 



/**
 * [tFileInputDelimited_3 finally ] stop
 */

	
	/**
	 * [tFilterRow_9 finally ] start
	 */

	

	
	
	currentComponent="tFilterRow_9";

	

 



/**
 * [tFilterRow_9 finally ] stop
 */

	
	/**
	 * [tSortRow_2_SortOut finally ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_2";
	
	currentComponent="tSortRow_2_SortOut";

	

 



/**
 * [tSortRow_2_SortOut finally ] stop
 */

	
	/**
	 * [tSortRow_2_SortIn finally ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_2";
	
	currentComponent="tSortRow_2_SortIn";

	

 



/**
 * [tSortRow_2_SortIn finally ] stop
 */

	
	/**
	 * [tJavaFlex_3 finally ] start
	 */

	

	
	
	currentComponent="tJavaFlex_3";

	

 



/**
 * [tJavaFlex_3 finally ] stop
 */

	
	/**
	 * [tLogRow_6 finally ] start
	 */

	

	
	
	currentComponent="tLogRow_6";

	

 



/**
 * [tLogRow_6 finally ] stop
 */

	
	/**
	 * [tFileOutputDelimited_4 finally ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_4";

	


		if(resourceMap.get("finish_tFileOutputDelimited_4") == null){ 
			
				
						java.io.Writer outtFileOutputDelimited_4 = (java.io.Writer)resourceMap.get("out_tFileOutputDelimited_4");
						if(outtFileOutputDelimited_4!=null) {
							outtFileOutputDelimited_4.flush();
							outtFileOutputDelimited_4.close();
						}
					
				
			
		}
	

 



/**
 * [tFileOutputDelimited_4 finally ] stop
 */
























				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileInputDelimited_2_SUBPROCESS_STATE", 1);
	}
	

public void talendJobLogProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("talendJobLog_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [talendJobLog begin ] start
	 */

	

	
		
		ok_Hash.put("talendJobLog", false);
		start_Hash.put("talendJobLog", System.currentTimeMillis());
		
	
	currentComponent="talendJobLog";

	
		int tos_count_talendJobLog = 0;
		

	for (JobStructureCatcherUtils.JobStructureCatcherMessage jcm : talendJobLog.getMessages()) {
		org.talend.logging.audit.Context log_context_talendJobLog = null;
		if(jcm.component_name == null) {//job level log
			if(jcm.status == null) {//job start
				log_context_talendJobLog = org.talend.job.audit.JobContextBuilder.create().jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version).timestamp(jcm.moment).build();
				auditLogger_talendJobLog.jobstart(log_context_talendJobLog);
			} else {//job end
				long timeMS = jcm.end_time - jcm.start_time;
				String duration = String.format(java.util.Locale.US, "%1$.2fs", (timeMS * 1.0)/1000);
			
				log_context_talendJobLog = org.talend.job.audit.JobContextBuilder.create().jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version)
					.timestamp(jcm.moment).duration(duration).status(jcm.status).build();
				auditLogger_talendJobLog.jobstop(log_context_talendJobLog);
			}
		} else if(jcm.current_connector == null) {//component log
			log_context_talendJobLog = org.talend.job.audit.JobContextBuilder.create().jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version)
				.connectorType(jcm.component_name).connectorId(jcm.component_id).build();
			auditLogger_talendJobLog.runcomponent(log_context_talendJobLog);
		} else {//component connector meter log
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.format(java.util.Locale.US, "%1$.2fs", (timeMS * 1.0)/1000);
			
			if(jcm.current_connector_as_input) {//log current component input line
				log_context_talendJobLog = org.talend.job.audit.JobContextBuilder.create().jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version)
					.connectorType(jcm.component_name).connectorId(jcm.component_id)
					.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
					.rows(jcm.total_row_number).duration(duration).build();
				auditLogger_talendJobLog.flowInput(log_context_talendJobLog);
			} else {//log current component output/reject line
				log_context_talendJobLog = org.talend.job.audit.JobContextBuilder.create().jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version)
					.connectorType(jcm.component_name).connectorId(jcm.component_id)
					.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
					.rows(jcm.total_row_number).duration(duration).build();
				auditLogger_talendJobLog.flowOutput(log_context_talendJobLog);
			}
		}
	}

 



/**
 * [talendJobLog begin ] stop
 */
	
	/**
	 * [talendJobLog main ] start
	 */

	

	
	
	currentComponent="talendJobLog";

	

 


	tos_count_talendJobLog++;

/**
 * [talendJobLog main ] stop
 */
	
	/**
	 * [talendJobLog process_data_begin ] start
	 */

	

	
	
	currentComponent="talendJobLog";

	

 



/**
 * [talendJobLog process_data_begin ] stop
 */
	
	/**
	 * [talendJobLog process_data_end ] start
	 */

	

	
	
	currentComponent="talendJobLog";

	

 



/**
 * [talendJobLog process_data_end ] stop
 */
	
	/**
	 * [talendJobLog end ] start
	 */

	

	
	
	currentComponent="talendJobLog";

	

 

ok_Hash.put("talendJobLog", true);
end_Hash.put("talendJobLog", System.currentTimeMillis());




/**
 * [talendJobLog end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [talendJobLog finally ] start
	 */

	

	
	
	currentComponent="talendJobLog";

	

 



/**
 * [talendJobLog finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("talendJobLog_SUBPROCESS_STATE", 1);
	}
	
    public String resuming_logs_dir_path = null;
    public String resuming_checkpoint_path = null;
    public String parent_part_launcher = null;
    private String resumeEntryMethodName = null;
    private boolean globalResumeTicket = false;

    public boolean watch = false;
    // portStats is null, it means don't execute the statistics
    public Integer portStats = null;
    public int portTraces = 4334;
    public String clientHost;
    public String defaultClientHost = "localhost";
    public String contextStr = "Default";
    public boolean isDefaultContext = true;
    public String pid = "0";
    public String rootPid = null;
    public String fatherPid = null;
    public String fatherNode = null;
    public long startTime = 0;
    public boolean isChildJob = false;
    public String log4jLevel = "";
    
    private boolean enableLogStash;

    private boolean execStat = true;

    private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
        protected java.util.Map<String, String> initialValue() {
            java.util.Map<String,String> threadRunResultMap = new java.util.HashMap<String, String>();
            threadRunResultMap.put("errorCode", null);
            threadRunResultMap.put("status", "");
            return threadRunResultMap;
        };
    };


    private PropertiesWithType context_param = new PropertiesWithType();
    public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

    public String status= "";
    

    public static void main(String[] args){
        final IngestRecord_Allrules_T IngestRecord_Allrules_TClass = new IngestRecord_Allrules_T();

        int exitCode = IngestRecord_Allrules_TClass.runJobInTOS(args);

        System.exit(exitCode);
    }


    public String[][] runJob(String[] args) {

        int exitCode = runJobInTOS(args);
        String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

        return bufferValue;
    }

    public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;
    	
        return hastBufferOutput;
    }

    public int runJobInTOS(String[] args) {
	   	// reset status
	   	status = "";
	   	
        String lastStr = "";
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--context_param")) {
                lastStr = arg;
            } else if (lastStr.equals("")) {
                evalParam(arg);
            } else {
                evalParam(lastStr + " " + arg);
                lastStr = "";
            }
        }
        enableLogStash = "true".equalsIgnoreCase(System.getProperty("monitoring"));

    	
    	
			if(enableLogStash) {
				java.util.Properties properties_talendJobLog = new java.util.Properties();
				properties_talendJobLog.setProperty("root.logger", "audit");
				properties_talendJobLog.setProperty("encoding", "UTF-8");
				properties_talendJobLog.setProperty("application.name", "Talend Studio");
				properties_talendJobLog.setProperty("service.name", "Talend Studio Job");
				properties_talendJobLog.setProperty("instance.name", "Talend Studio Job Instance");
				properties_talendJobLog.setProperty("propagate.appender.exceptions", "none");
				properties_talendJobLog.setProperty("log.appender", "file");
				properties_talendJobLog.setProperty("appender.file.path", "audit.json");
				properties_talendJobLog.setProperty("appender.file.maxsize", "52428800");
				properties_talendJobLog.setProperty("appender.file.maxbackup", "20");
				properties_talendJobLog.setProperty("host", "false");

				System.getProperties().stringPropertyNames().stream()
					.filter(it -> it.startsWith("monitoring.audit.logger.properties."))
					.forEach(key -> properties_talendJobLog.setProperty(key.substring("monitoring.audit.logger.properties.".length()), System.getProperty(key)));

				
				
				
				org.apache.logging.log4j.core.config.Configurator.setLevel("audit", org.apache.logging.log4j.Level.DEBUG);
				
				auditLogger_talendJobLog = org.talend.job.audit.JobEventAuditLoggerFactory.createJobAuditLogger(properties_talendJobLog);
			}
		

        if(clientHost == null) {
            clientHost = defaultClientHost;
        }

        if(pid == null || "0".equals(pid)) {
            pid = TalendString.getAsciiRandomString(6);
        }

        if (rootPid==null) {
            rootPid = pid;
        }
        if (fatherPid==null) {
            fatherPid = pid;
        }else{
            isChildJob = true;
        }

        if (portStats != null) {
            // portStats = -1; //for testing
            if (portStats < 0 || portStats > 65535) {
                // issue:10869, the portStats is invalid, so this client socket can't open
                System.err.println("The statistics socket port " + portStats + " is invalid.");
                execStat = false;
            }
        } else {
            execStat = false;
        }

        try {
            //call job/subjob with an existing context, like: --context=production. if without this parameter, there will use the default context instead.
            java.io.InputStream inContext = IngestRecord_Allrules_T.class.getClassLoader().getResourceAsStream("upi_process/ingestrecord_allrules_t_0_1/contexts/" + contextStr + ".properties");
            if (inContext == null) {
                inContext = IngestRecord_Allrules_T.class.getClassLoader().getResourceAsStream("config/contexts/" + contextStr + ".properties");
            }
            if (inContext != null) {
                //defaultProps is in order to keep the original context value
                if(context != null && context.isEmpty()) {
	                defaultProps.load(inContext);
	                context = new ContextProperties(defaultProps);
                }
                
                inContext.close();
            } else if (!isDefaultContext) {
                //print info and job continue to run, for case: context_param is not empty.
                System.err.println("Could not find the context " + contextStr);
            }

            if(!context_param.isEmpty()) {
                context.putAll(context_param);
				//set types for params from parentJobs
				for (Object key: context_param.keySet()){
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
            }
            class ContextProcessing {
                private void processContext_0() {
                        context.setContextType("location", "id_Directory");
                            context.location=(String) context.getProperty("location");
                        context.setContextType("stg_location", "id_Directory");
                            context.stg_location=(String) context.getProperty("stg_location");
                        context.setContextType("fuzzymatch", "id_String");
                            context.fuzzymatch=(String) context.getProperty("fuzzymatch");
                } 
                public void processAllContext() {
                        processContext_0();
                }
            }

            new ContextProcessing().processAllContext();
        } catch (java.io.IOException ie) {
            System.err.println("Could not load context "+contextStr);
            ie.printStackTrace();
        }

        // get context value from parent directly
        if (parentContextMap != null && !parentContextMap.isEmpty()) {if (parentContextMap.containsKey("location")) {
                context.location = (String) parentContextMap.get("location");
            }if (parentContextMap.containsKey("stg_location")) {
                context.stg_location = (String) parentContextMap.get("stg_location");
            }if (parentContextMap.containsKey("fuzzymatch")) {
                context.fuzzymatch = (String) parentContextMap.get("fuzzymatch");
            }
        }

        //Resume: init the resumeUtil
        resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
        resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
        resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
        //Resume: jobStart
        resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,parametersToEncrypt));

if(execStat) {
    try {
        runStat.openSocket(!isChildJob);
        runStat.setAllPID(rootPid, fatherPid, pid, jobName);
        runStat.startThreadStat(clientHost, portStats);
        runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
    } catch (java.io.IOException ioException) {
        ioException.printStackTrace();
    }
}



	
	    java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
	    globalMap.put("concurrentHashMap", concurrentHashMap);
	

    long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    long endUsedMemory = 0;
    long end = 0;

    startTime = System.currentTimeMillis();




this.globalResumeTicket = true;//to run tPreJob



		if(enableLogStash) {
	        talendJobLog.addJobStartMessage();
	        try {
	            talendJobLogProcess(globalMap);
	        } catch (java.lang.Exception e) {
	            e.printStackTrace();
	        }
        }

this.globalResumeTicket = false;//to run others jobs

try {
errorCode = null;tFileInputDelimited_4Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tFileInputDelimited_4) {
globalMap.put("tFileInputDelimited_4_SUBPROCESS_STATE", -1);

e_tFileInputDelimited_4.printStackTrace();

}

this.globalResumeTicket = true;//to run tPostJob




        end = System.currentTimeMillis();

        if (watch) {
            System.out.println((end-startTime)+" milliseconds");
        }

        endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        if (false) {
            System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : IngestRecord_Allrules_T");
        }
		if(enableLogStash) {
	        talendJobLog.addJobEndMessage(startTime, end, status);
	        try {
	            talendJobLogProcess(globalMap);
	        } catch (java.lang.Exception e) {
	            e.printStackTrace();
	        }
        }



if (execStat) {
    runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
    runStat.stopThreadStat();
}
    int returnCode = 0;
    if(errorCode == null) {
         returnCode = status != null && status.equals("failure") ? 1 : 0;
    } else {
         returnCode = errorCode.intValue();
    }
    resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","" + returnCode,"","","");

    return returnCode;

  }

    // only for OSGi env
    public void destroy() {


    }














    private java.util.Map<String, Object> getSharedConnections4REST() {
        java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();







        return connections;
    }

    private void evalParam(String arg) {
        if (arg.startsWith("--resuming_logs_dir_path")) {
            resuming_logs_dir_path = arg.substring(25);
        } else if (arg.startsWith("--resuming_checkpoint_path")) {
            resuming_checkpoint_path = arg.substring(27);
        } else if (arg.startsWith("--parent_part_launcher")) {
            parent_part_launcher = arg.substring(23);
        } else if (arg.startsWith("--watch")) {
            watch = true;
        } else if (arg.startsWith("--stat_port=")) {
            String portStatsStr = arg.substring(12);
            if (portStatsStr != null && !portStatsStr.equals("null")) {
                portStats = Integer.parseInt(portStatsStr);
            }
        } else if (arg.startsWith("--trace_port=")) {
            portTraces = Integer.parseInt(arg.substring(13));
        } else if (arg.startsWith("--client_host=")) {
            clientHost = arg.substring(14);
        } else if (arg.startsWith("--context=")) {
            contextStr = arg.substring(10);
            isDefaultContext = false;
        } else if (arg.startsWith("--father_pid=")) {
            fatherPid = arg.substring(13);
        } else if (arg.startsWith("--root_pid=")) {
            rootPid = arg.substring(11);
        } else if (arg.startsWith("--father_node=")) {
            fatherNode = arg.substring(14);
        } else if (arg.startsWith("--pid=")) {
            pid = arg.substring(6);
        } else if (arg.startsWith("--context_type")) {
            String keyValue = arg.substring(15);
			int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.setContextType(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }

            }

		} else if (arg.startsWith("--context_param")) {
            String keyValue = arg.substring(16);
            int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }
            }
        } else if (arg.startsWith("--log4jLevel=")) {
            log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--monitoring") && arg.contains("=")) {//for trunjob call
		    final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
    }
    
    private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

    private final String[][] escapeChars = {
        {"\\\\","\\"},{"\\n","\n"},{"\\'","\'"},{"\\r","\r"},
        {"\\f","\f"},{"\\b","\b"},{"\\t","\t"}
        };
    private String replaceEscapeChars (String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0],currIndex);
				if (index>=0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0], strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
    }

    public Integer getErrorCode() {
        return errorCode;
    }


    public String getStatus() {
        return status;
    }

    ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 *     388678 characters generated by Talend Data Management Platform 
 *     on the September 11, 2020 11:14:29 PM EDT
 ************************************************************************************************/