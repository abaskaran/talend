
package upi_process.ingestrecords_detokenization_globalparam_0_1;

import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.DataQuality;
import routines.Relational;
import routines.DataQualityDependencies;
import routines.Mathematical;
import routines.SQLike;
import routines.Numeric;
import routines.WordVertex;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringUtils;
import routines.DQTechnical;
import routines.StringHandling;
import routines.DataMasking;
import routines.TalendDate;
import routines.DqStringHandling;
import routines.Tree;
import routines.Member;
import routines.MemberUpis;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;
 




	//the import part of tJavaFlex_2
	//import java.util.List;


//import java.util.ArrayList;
import java.util.Map;


import routines.StringUtils;
import routines.Member;
import routines.MemberUpis;
import routines.Tree;
import routines.WordVertex;




@SuppressWarnings("unused")

/**
 * Job: IngestRecords_Detokenization_globalparam Purpose: <br>
 * Description:  <br>
 * @author Gurubaskaran, Akila
 * @version 7.3.1.20200219_1130
 * @status 
 */
public class IngestRecords_Detokenization_globalparam implements TalendJob {

protected static void logIgnoredError(String message, Throwable cause) {
       System.err.println(message);
       if (cause != null) {
               cause.printStackTrace();
       }

}


	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}
	
	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	
	private final static String utf8Charset = "UTF-8";
	//contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String,String> propertyTypes = new java.util.HashMap<>();
		
		public PropertiesWithType(java.util.Properties properties){
			super(properties);
		}
		public PropertiesWithType(){
			super();
		}
		
		public void setContextType(String key, String type) {
			propertyTypes.put(key,type);
		}
	
		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}
	
	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();
	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties){
			super(properties);
		}
		public ContextProperties(){
			super();
		}

		public void synchronizeContext(){
			
			if(obj != null){
				
					this.setProperty("obj", obj.toString());
				
			}
			
			if(detokenize != null){
				
					this.setProperty("detokenize", detokenize.toString());
				
			}
			
			if(filename != null){
				
					this.setProperty("filename", filename.toString());
				
			}
			
			if(key_store_password != null){
				
					this.setProperty("key_store_password", key_store_password.toString());
				
			}
			
			if(key_store_path != null){
				
					this.setProperty("key_store_path", key_store_path.toString());
				
			}
			
			if(landing != null){
				
					this.setProperty("landing", landing.toString());
				
			}
			
			if(stg_location != null){
				
					this.setProperty("stg_location", stg_location.toString());
				
			}
			
			if(jsonfile_after != null){
				
					this.setProperty("jsonfile_after", jsonfile_after.toString());
				
			}
			
			if(jsonfile_prior != null){
				
					this.setProperty("jsonfile_prior", jsonfile_prior.toString());
				
			}
			
			if(location != null){
				
					this.setProperty("location", location.toString());
				
			}
			
		}

public Object obj;
public Object getObj(){
	return this.obj;
}
		public String detokenize;
		public String getDetokenize(){
			return this.detokenize;
		}
		
public String filename;
public String getFilename(){
	return this.filename;
}
public java.lang.String key_store_password;
public java.lang.String getKey_store_password(){
	return this.key_store_password;
}
		public String key_store_path;
		public String getKey_store_path(){
			return this.key_store_path;
		}
		
		public String landing;
		public String getLanding(){
			return this.landing;
		}
		
		public String stg_location;
		public String getStg_location(){
			return this.stg_location;
		}
		
		public String jsonfile_after;
		public String getJsonfile_after(){
			return this.jsonfile_after;
		}
		
		public String jsonfile_prior;
		public String getJsonfile_prior(){
			return this.jsonfile_prior;
		}
		
public String location;
public String getLocation(){
	return this.location;
}
	}
	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.
	public ContextProperties getContext() {
		return this.context;
	}
	private final String jobVersion = "0.1";
	private final String jobName = "IngestRecords_Detokenization_globalparam";
	private final String projectName = "UPI_PROCESS";
	public Integer errorCode = null;
	private String currentComponent = "";
	
		private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
        private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();
	
		private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
		public  final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();
	

private RunStat runStat = new RunStat();

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";
	
	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(), new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	JobStructureCatcherUtils talendJobLog = new JobStructureCatcherUtils(jobName, "_AulVcPK1EeqOJLy1LxkyZg", "0.1");
	org.talend.job.audit.JobAuditLogger auditLogger_talendJobLog = null;

private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

public String getExceptionStackTrace() {
	if ("failure".equals(this.getStatus())) {
		errorMessagePS.flush();
		return baos.toString();
	}
	return null;
}

private Exception exception;

public Exception getException() {
	if ("failure".equals(this.getStatus())) {
		return this.exception;
	}
	return null;
}

private class TalendException extends Exception {

	private static final long serialVersionUID = 1L;

	private java.util.Map<String, Object> globalMap = null;
	private Exception e = null;
	private String currentComponent = null;
	private String virtualComponentName = null;
	
	public void setVirtualComponentName (String virtualComponentName){
		this.virtualComponentName = virtualComponentName;
	}

	private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
		this.currentComponent= errorComponent;
		this.globalMap = globalMap;
		this.e = e;
	}

	public Exception getException() {
		return this.e;
	}

	public String getCurrentComponent() {
		return this.currentComponent;
	}

	
    public String getExceptionCauseMessage(Exception e){
        Throwable cause = e;
        String message = null;
        int i = 10;
        while (null != cause && 0 < i--) {
            message = cause.getMessage();
            if (null == message) {
                cause = cause.getCause();
            } else {
                break;          
            }
        }
        if (null == message) {
            message = e.getClass().getName();
        }   
        return message;
    }

	@Override
	public void printStackTrace() {
		if (!(e instanceof TalendException || e instanceof TDieException)) {
			if(virtualComponentName!=null && currentComponent.indexOf(virtualComponentName+"_")==0){
				globalMap.put(virtualComponentName+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			}
			globalMap.put(currentComponent+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
		}
		if (!(e instanceof TDieException)) {
			if(e instanceof TalendException){
				e.printStackTrace();
			} else {
				e.printStackTrace();
				e.printStackTrace(errorMessagePS);
				IngestRecords_Detokenization_globalparam.this.exception = e;
			}
		}
		if (!(e instanceof TalendException)) {
		try {
			for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
				if (m.getName().compareTo(currentComponent + "_error") == 0) {
					m.invoke(IngestRecords_Detokenization_globalparam.this, new Object[] { e , currentComponent, globalMap});
					break;
				}
			}

			if(!(e instanceof TDieException)){
			}
		} catch (Exception e) {
			this.e.printStackTrace();
		}
		}
	}
}

			public void tFileInputRaw_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputRaw_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFlowToIterate_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputRaw_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tREST_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputRaw_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tExtractJSONFields_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputRaw_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputRaw_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tBufferOutput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputRaw_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tBufferOutput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tConvertType_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tLogRow_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileOutputDelimited_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileOutputDelimited_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputDelimited_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFlowToIterate_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputDelimited_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFilterRow_23_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJavaFlex_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tBufferOutput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileOutputJSON_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputRaw_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputRaw_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFlowToIterate_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputRaw_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tREST_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputRaw_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tExtractJSONFields_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputRaw_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputRaw_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputRaw_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tLogRow_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputRaw_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileOutputDelimited_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBConnection_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBConnection_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSetKeystore_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSetKeystore_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tCreateTemporaryFile_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tCreateTemporaryFile_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tCreateTemporaryFile_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tCreateTemporaryFile_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tBufferInput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPrejob_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPrejob_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPostjob_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPostjob_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBClose_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBClose_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAdvancedHash_row7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAdvancedHash_row19_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMatchGroup_2_GroupOut_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
							tMatchGroup_2_GroupIn_error(exception, errorComponent, globalMap);
						
						}
					
			public void tMatchGroup_2_GroupIn_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAggregateRow_2_AGGOUT_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
							tAggregateRow_2_AGGIN_error(exception, errorComponent, globalMap);
						
						}
					
			public void tAggregateRow_2_AGGIN_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSortRow_1_SortOut_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
							tSortRow_1_SortIn_error(exception, errorComponent, globalMap);
						
						}
					
			public void tSortRow_1_SortIn_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void talendJobLog_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					talendJobLog_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputRaw_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileInputDelimited_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileInputRaw_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBConnection_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tSetKeystore_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tCreateTemporaryFile_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tCreateTemporaryFile_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tPrejob_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tPostjob_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBClose_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void talendJobLog_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}





	

	

public static class outStruct implements routines.system.IPersistableRow<outStruct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];

	
			    public String firstName;

				public String getFirstName () {
					return this.firstName;
				}
				
			    public String lastName;

				public String getLastName () {
					return this.lastName;
				}
				
			    public String MBI;

				public String getMBI () {
					return this.MBI;
				}
				
			    public String DOB;

				public String getDOB () {
					return this.DOB;
				}
				
			    public String OtherID;

				public String getOtherID () {
					return this.OtherID;
				}
				
			    public String SSN;

				public String getSSN () {
					return this.SSN;
				}
				
			    public int scd_key;

				public int getScd_key () {
					return this.scd_key;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam) {

        	try {

        		int length = 0;
		
					this.firstName = readString(dis);
					
					this.lastName = readString(dis);
					
					this.MBI = readString(dis);
					
					this.DOB = readString(dis);
					
					this.OtherID = readString(dis);
					
					this.SSN = readString(dis);
					
			        this.scd_key = dis.readInt();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.firstName,dos);
					
					// String
				
						writeString(this.lastName,dos);
					
					// String
				
						writeString(this.MBI,dos);
					
					// String
				
						writeString(this.DOB,dos);
					
					// String
				
						writeString(this.OtherID,dos);
					
					// String
				
						writeString(this.SSN,dos);
					
					// int
				
		            	dos.writeInt(this.scd_key);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("firstName="+firstName);
		sb.append(",lastName="+lastName);
		sb.append(",MBI="+MBI);
		sb.append(",DOB="+DOB);
		sb.append(",OtherID="+OtherID);
		sb.append(",SSN="+SSN);
		sb.append(",scd_key="+String.valueOf(scd_key));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(outStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row5Struct implements routines.system.IPersistableRow<row5Struct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];

	
			    public String firstName;

				public String getFirstName () {
					return this.firstName;
				}
				
			    public String lastName;

				public String getLastName () {
					return this.lastName;
				}
				
			    public String MBI;

				public String getMBI () {
					return this.MBI;
				}
				
			    public String DOB;

				public String getDOB () {
					return this.DOB;
				}
				
			    public String OtherID;

				public String getOtherID () {
					return this.OtherID;
				}
				
			    public String SSN;

				public String getSSN () {
					return this.SSN;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam) {

        	try {

        		int length = 0;
		
					this.firstName = readString(dis);
					
					this.lastName = readString(dis);
					
					this.MBI = readString(dis);
					
					this.DOB = readString(dis);
					
					this.OtherID = readString(dis);
					
					this.SSN = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.firstName,dos);
					
					// String
				
						writeString(this.lastName,dos);
					
					// String
				
						writeString(this.MBI,dos);
					
					// String
				
						writeString(this.DOB,dos);
					
					// String
				
						writeString(this.OtherID,dos);
					
					// String
				
						writeString(this.SSN,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("firstName="+firstName);
		sb.append(",lastName="+lastName);
		sb.append(",MBI="+MBI);
		sb.append(",DOB="+DOB);
		sb.append(",OtherID="+OtherID);
		sb.append(",SSN="+SSN);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row5Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];

	
			    public String Body;

				public String getBody () {
					return this.Body;
				}
				
			    public Integer ERROR_CODE;

				public Integer getERROR_CODE () {
					return this.ERROR_CODE;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam) {

        	try {

        		int length = 0;
		
					this.Body = readString(dis);
					
						this.ERROR_CODE = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Body,dos);
					
					// Integer
				
						writeInteger(this.ERROR_CODE,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Body="+Body);
		sb.append(",ERROR_CODE="+String.valueOf(ERROR_CODE));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row2Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row6Struct implements routines.system.IPersistableRow<row6Struct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];

	
			    public Object content;

				public Object getContent () {
					return this.content;
				}
				



    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam) {

        	try {

        		int length = 0;
		
						this.content = (Object) dis.readObject();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Object
				
       			    	dos.writeObject(this.content);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("content="+String.valueOf(content));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row6Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFileInputRaw_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileInputRaw_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row6Struct row6 = new row6Struct();
row2Struct row2 = new row2Struct();
row5Struct row5 = new row5Struct();
outStruct out = new outStruct();




	
	/**
	 * [tFlowToIterate_1 begin ] start
	 */

				
			int NB_ITERATE_tREST_1 = 0; //for statistics
			

	
		
		ok_Hash.put("tFlowToIterate_1", false);
		start_Hash.put("tFlowToIterate_1", System.currentTimeMillis());
		
	
	currentComponent="tFlowToIterate_1";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row6");
			
		int tos_count_tFlowToIterate_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tFlowToIterate_1", "tFlowToIterate");
				talendJobLogProcess(globalMap);
			}
			

int nb_line_tFlowToIterate_1 = 0;
int counter_tFlowToIterate_1 = 0;

 



/**
 * [tFlowToIterate_1 begin ] stop
 */



	
	/**
	 * [tFileInputRaw_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputRaw_1", false);
		start_Hash.put("tFileInputRaw_1", System.currentTimeMillis());
		
	
	currentComponent="tFileInputRaw_1";

	
		int tos_count_tFileInputRaw_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tFileInputRaw_1", "tFileInputRaw");
				talendJobLogProcess(globalMap);
			}
			
	

				try {					
					String content_tFileInputRaw_1 = org.apache.commons.io.FileUtils.readFileToString(new java.io.File(context.jsonfile_prior), "ISO-8859-15");
					row6.content = content_tFileInputRaw_1;					
					globalMap.put("tFileInputRaw_1_FILENAME_PATH", context.jsonfile_prior);
				} catch (java.io.IOException e_tFileInputRaw_1) {
					
					System.err.println(e_tFileInputRaw_1);
				}


 



/**
 * [tFileInputRaw_1 begin ] stop
 */
	
	/**
	 * [tFileInputRaw_1 main ] start
	 */

	

	
	
	currentComponent="tFileInputRaw_1";

	

 


	tos_count_tFileInputRaw_1++;

/**
 * [tFileInputRaw_1 main ] stop
 */
	
	/**
	 * [tFileInputRaw_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileInputRaw_1";

	

 



/**
 * [tFileInputRaw_1 process_data_begin ] stop
 */

	
	/**
	 * [tFlowToIterate_1 main ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_1";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"row6");
			


    	            
            globalMap.put("row6.content", row6.content);
    	
 
	   nb_line_tFlowToIterate_1++;  
       counter_tFlowToIterate_1++;
       globalMap.put("tFlowToIterate_1_CURRENT_ITERATION", counter_tFlowToIterate_1);
 


	tos_count_tFlowToIterate_1++;

/**
 * [tFlowToIterate_1 main ] stop
 */
	
	/**
	 * [tFlowToIterate_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_1";

	

 



/**
 * [tFlowToIterate_1 process_data_begin ] stop
 */
	NB_ITERATE_tREST_1++;
	
	
					if(execStat){				
	       				runStat.updateStatOnConnection("row5", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row2", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("out", 3, 0);
					}           			
				
				if(execStat){
					runStat.updateStatOnConnection("iterate1", 1, "exec" + NB_ITERATE_tREST_1);
					//Thread.sleep(1000);
				}				
			




	
	/**
	 * [tBufferOutput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tBufferOutput_2", false);
		start_Hash.put("tBufferOutput_2", System.currentTimeMillis());
		
	
	currentComponent="tBufferOutput_2";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"out");
			
		int tos_count_tBufferOutput_2 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tBufferOutput_2", "tBufferOutput");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tBufferOutput_2 begin ] stop
 */



	
	/**
	 * [tMap_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_2", false);
		start_Hash.put("tMap_2", System.currentTimeMillis());
		
	
	currentComponent="tMap_2";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row5");
			
		int tos_count_tMap_2 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tMap_2", "tMap");
				talendJobLogProcess(globalMap);
			}
			




// ###############################
// # Lookup's keys initialization
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_2__Struct  {
	int var1;
}
Var__tMap_2__Struct Var__tMap_2 = new Var__tMap_2__Struct();
// ###############################

// ###############################
// # Outputs initialization
outStruct out_tmp = new outStruct();
// ###############################

        
        



        









 



/**
 * [tMap_2 begin ] stop
 */



	
	/**
	 * [tExtractJSONFields_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tExtractJSONFields_1", false);
		start_Hash.put("tExtractJSONFields_1", System.currentTimeMillis());
		
	
	currentComponent="tExtractJSONFields_1";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row2");
			
		int tos_count_tExtractJSONFields_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tExtractJSONFields_1", "tExtractJSONFields");
				talendJobLogProcess(globalMap);
			}
			

int nb_line_tExtractJSONFields_1 = 0;
String jsonStr_tExtractJSONFields_1 = "";

	

class JsonPathCache_tExtractJSONFields_1 {
	final java.util.Map<String,com.jayway.jsonpath.JsonPath> jsonPathString2compiledJsonPath = new java.util.HashMap<String,com.jayway.jsonpath.JsonPath>();
	
	public com.jayway.jsonpath.JsonPath getCompiledJsonPath(String jsonPath) {
		if(jsonPathString2compiledJsonPath.containsKey(jsonPath)) {
			return jsonPathString2compiledJsonPath.get(jsonPath);
		} else {
			com.jayway.jsonpath.JsonPath compiledLoopPath = com.jayway.jsonpath.JsonPath.compile(jsonPath);
			jsonPathString2compiledJsonPath.put(jsonPath,compiledLoopPath);
			return compiledLoopPath;
		}
	}
}

JsonPathCache_tExtractJSONFields_1 jsonPathCache_tExtractJSONFields_1 = new JsonPathCache_tExtractJSONFields_1();

 



/**
 * [tExtractJSONFields_1 begin ] stop
 */



	
	/**
	 * [tREST_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tREST_1", false);
		start_Hash.put("tREST_1", System.currentTimeMillis());
		
	
	currentComponent="tREST_1";

	
		int tos_count_tREST_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tREST_1", "tREST");
				talendJobLogProcess(globalMap);
			}
			
	

	
	String endpoint_tREST_1 = "https://irx.dev1.awse1.anthem.com/static/protect/json";
	
	String trustStoreFile_tREST_1 = System.getProperty("javax.net.ssl.trustStore");
	String trustStoreType_tREST_1 = System.getProperty("javax.net.ssl.trustStoreType");
	String trustStorePWD_tREST_1 = System.getProperty("javax.net.ssl.trustStorePassword");
	
	String keyStoreFile_tREST_1 = System.getProperty("javax.net.ssl.keyStore");
	String keyStoreType_tREST_1 = System.getProperty("javax.net.ssl.keyStoreType");
	String keyStorePWD_tREST_1 = System.getProperty("javax.net.ssl.keyStorePassword");
	
	com.sun.jersey.api.client.config.ClientConfig config_tREST_1 = new com.sun.jersey.api.client.config.DefaultClientConfig();
	javax.net.ssl.SSLContext ctx_tREST_1 = javax.net.ssl.SSLContext.getInstance("SSL");
	
	javax.net.ssl.TrustManager[] tms_tREST_1 = null;
	if(trustStoreFile_tREST_1!=null && trustStoreType_tREST_1!=null){
		char[] password_tREST_1 = null;
		if(trustStorePWD_tREST_1!=null)
			password_tREST_1 = trustStorePWD_tREST_1.toCharArray();
		java.security.KeyStore trustStore_tREST_1 = java.security.KeyStore.getInstance(trustStoreType_tREST_1);
		trustStore_tREST_1.load(new java.io.FileInputStream(trustStoreFile_tREST_1), password_tREST_1);
		
		javax.net.ssl.TrustManagerFactory tmf_tREST_1 = javax.net.ssl.TrustManagerFactory.getInstance(javax.net.ssl.KeyManagerFactory.getDefaultAlgorithm());
        tmf_tREST_1.init(trustStore_tREST_1);
        tms_tREST_1 = tmf_tREST_1.getTrustManagers();
	}
	
	javax.net.ssl.KeyManager[] kms_tREST_1 = null;
	if(keyStoreFile_tREST_1!=null && keyStoreType_tREST_1!=null){
		char[] password_tREST_1 = null;
		if(keyStorePWD_tREST_1!=null)
			password_tREST_1 = keyStorePWD_tREST_1.toCharArray();
		java.security.KeyStore keyStore_tREST_1 = java.security.KeyStore.getInstance(keyStoreType_tREST_1);
		keyStore_tREST_1.load(new java.io.FileInputStream(keyStoreFile_tREST_1), password_tREST_1);
		
		javax.net.ssl.KeyManagerFactory kmf_tREST_1 = javax.net.ssl.KeyManagerFactory.getInstance(javax.net.ssl.KeyManagerFactory.getDefaultAlgorithm());
        kmf_tREST_1.init(keyStore_tREST_1,password_tREST_1);
        kms_tREST_1 = kmf_tREST_1.getKeyManagers();
	}
	
    ctx_tREST_1.init(kms_tREST_1, tms_tREST_1 , null);
    config_tREST_1.getProperties().put(com.sun.jersey.client.urlconnection.HTTPSProperties.PROPERTY_HTTPS_PROPERTIES,
                new com.sun.jersey.client.urlconnection.HTTPSProperties(new javax.net.ssl.HostnameVerifier() {

                    public boolean verify(String hostName, javax.net.ssl.SSLSession session) {
                        return true;
                    }
                }, ctx_tREST_1));

	com.sun.jersey.api.client.Client restClient_tREST_1 = com.sun.jersey.api.client.Client.create(config_tREST_1);
	
	java.util.Map<String, Object> headers_tREST_1 = new java.util.HashMap<String, Object>();
	
    	headers_tREST_1.put("Authorization","Basic U1JDX0lSWF9SRVNUX0lSWEVQOkZvQzIhSGVMJEIzRA==");
	
	
	Object transfer_encoding_tREST_1 = headers_tREST_1.get("Transfer-Encoding");
	if(transfer_encoding_tREST_1!=null && "chunked".equals(transfer_encoding_tREST_1)) {
		restClient_tREST_1.setChunkedEncodingSize(4096);
	}
	
	com.sun.jersey.api.client.WebResource restResource_tREST_1;
	if(endpoint_tREST_1!=null && !("").equals(endpoint_tREST_1)){
		restResource_tREST_1 = restClient_tREST_1.resource(endpoint_tREST_1);
	}else{
		throw new IllegalArgumentException("url can't be empty!");
	}
	
	com.sun.jersey.api.client.ClientResponse errorResponse_tREST_1 = null;
	String restResponse_tREST_1 = "";
	try{
		
		com.sun.jersey.api.client.WebResource.Builder builder_tREST_1 = null;
		for(java.util.Map.Entry<String, Object> header_tREST_1 : headers_tREST_1.entrySet()) {
			if(builder_tREST_1 == null) {
				builder_tREST_1 = restResource_tREST_1.header(header_tREST_1.getKey(), header_tREST_1.getValue());
			} else {
				builder_tREST_1.header(header_tREST_1.getKey(), header_tREST_1.getValue());
			}
		}
		
		
			if(builder_tREST_1!=null) {
				restResponse_tREST_1 = builder_tREST_1.post(String.class,row6.content);
			} else {
				restResponse_tREST_1 = restResource_tREST_1.post(String.class,row6.content);
			}
		
	}catch (com.sun.jersey.api.client.UniformInterfaceException ue) {
        errorResponse_tREST_1 = ue.getResponse();
    }
	
	// for output
			
				row2 = new row2Struct();
				if(errorResponse_tREST_1!=null){
					row2.ERROR_CODE = errorResponse_tREST_1.getStatus();
					if(row2.ERROR_CODE!=204){
					    row2.Body = errorResponse_tREST_1.getEntity(String.class);
					}
				}else{
					row2.Body = restResponse_tREST_1;
				}
			

 



/**
 * [tREST_1 begin ] stop
 */
	
	/**
	 * [tREST_1 main ] start
	 */

	

	
	
	currentComponent="tREST_1";

	

 


	tos_count_tREST_1++;

/**
 * [tREST_1 main ] stop
 */
	
	/**
	 * [tREST_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tREST_1";

	

 



/**
 * [tREST_1 process_data_begin ] stop
 */

	
	/**
	 * [tExtractJSONFields_1 main ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_1";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"row2");
			

            if(row2.Body!=null){// C_01
                jsonStr_tExtractJSONFields_1 = row2.Body.toString();
   
row5 = null;

	

String loopPath_tExtractJSONFields_1 = "$[*]";
java.util.List<Object> resultset_tExtractJSONFields_1 = new java.util.ArrayList<Object>();

boolean isStructError_tExtractJSONFields_1 = true;
com.jayway.jsonpath.ReadContext document_tExtractJSONFields_1 = null;
try {
	document_tExtractJSONFields_1 = com.jayway.jsonpath.JsonPath.parse(jsonStr_tExtractJSONFields_1);
	com.jayway.jsonpath.JsonPath compiledLoopPath_tExtractJSONFields_1 = jsonPathCache_tExtractJSONFields_1.getCompiledJsonPath(loopPath_tExtractJSONFields_1);
	Object result_tExtractJSONFields_1 = document_tExtractJSONFields_1.read(compiledLoopPath_tExtractJSONFields_1,net.minidev.json.JSONObject.class);
	if (result_tExtractJSONFields_1 instanceof net.minidev.json.JSONArray) {
		resultset_tExtractJSONFields_1 = (net.minidev.json.JSONArray) result_tExtractJSONFields_1;
	} else {
		resultset_tExtractJSONFields_1.add(result_tExtractJSONFields_1);
	}
	
	isStructError_tExtractJSONFields_1 = false;
} catch (java.lang.Exception ex_tExtractJSONFields_1) {
		System.err.println(ex_tExtractJSONFields_1.getMessage());
}

String jsonPath_tExtractJSONFields_1 = null;
com.jayway.jsonpath.JsonPath compiledJsonPath_tExtractJSONFields_1 = null;

Object value_tExtractJSONFields_1 = null;

Object root_tExtractJSONFields_1 = null;
for(int i_tExtractJSONFields_1=0; isStructError_tExtractJSONFields_1 || (i_tExtractJSONFields_1 < resultset_tExtractJSONFields_1.size());i_tExtractJSONFields_1++){
	if(!isStructError_tExtractJSONFields_1){
		Object row_tExtractJSONFields_1 = resultset_tExtractJSONFields_1.get(i_tExtractJSONFields_1);
            row5 = null;
	row5 = new row5Struct();
	nb_line_tExtractJSONFields_1++;
	try {
		jsonPath_tExtractJSONFields_1 = "firstName";
		compiledJsonPath_tExtractJSONFields_1 = jsonPathCache_tExtractJSONFields_1.getCompiledJsonPath(jsonPath_tExtractJSONFields_1);
		
		try {
		    
		        value_tExtractJSONFields_1 = compiledJsonPath_tExtractJSONFields_1.read(row_tExtractJSONFields_1);
		    
				row5.firstName = value_tExtractJSONFields_1 == null ? 

		null

 : value_tExtractJSONFields_1.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_1) {
			row5.firstName = 

		null

;
		}
		jsonPath_tExtractJSONFields_1 = "lastName";
		compiledJsonPath_tExtractJSONFields_1 = jsonPathCache_tExtractJSONFields_1.getCompiledJsonPath(jsonPath_tExtractJSONFields_1);
		
		try {
		    
		        value_tExtractJSONFields_1 = compiledJsonPath_tExtractJSONFields_1.read(row_tExtractJSONFields_1);
		    
				row5.lastName = value_tExtractJSONFields_1 == null ? 

		null

 : value_tExtractJSONFields_1.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_1) {
			row5.lastName = 

		null

;
		}
		jsonPath_tExtractJSONFields_1 = "MBI";
		compiledJsonPath_tExtractJSONFields_1 = jsonPathCache_tExtractJSONFields_1.getCompiledJsonPath(jsonPath_tExtractJSONFields_1);
		
		try {
		    
		        value_tExtractJSONFields_1 = compiledJsonPath_tExtractJSONFields_1.read(row_tExtractJSONFields_1);
		    
				row5.MBI = value_tExtractJSONFields_1 == null ? 

		null

 : value_tExtractJSONFields_1.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_1) {
			row5.MBI = 

		null

;
		}
		jsonPath_tExtractJSONFields_1 = "DOB";
		compiledJsonPath_tExtractJSONFields_1 = jsonPathCache_tExtractJSONFields_1.getCompiledJsonPath(jsonPath_tExtractJSONFields_1);
		
		try {
		    
		        value_tExtractJSONFields_1 = compiledJsonPath_tExtractJSONFields_1.read(row_tExtractJSONFields_1);
		    
				row5.DOB = value_tExtractJSONFields_1 == null ? 

		null

 : value_tExtractJSONFields_1.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_1) {
			row5.DOB = 

		null

;
		}
		jsonPath_tExtractJSONFields_1 = "OtherID";
		compiledJsonPath_tExtractJSONFields_1 = jsonPathCache_tExtractJSONFields_1.getCompiledJsonPath(jsonPath_tExtractJSONFields_1);
		
		try {
		    
		        value_tExtractJSONFields_1 = compiledJsonPath_tExtractJSONFields_1.read(row_tExtractJSONFields_1);
		    
				row5.OtherID = value_tExtractJSONFields_1 == null ? 

		null

 : value_tExtractJSONFields_1.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_1) {
			row5.OtherID = 

		null

;
		}
		jsonPath_tExtractJSONFields_1 = "SSN";
		compiledJsonPath_tExtractJSONFields_1 = jsonPathCache_tExtractJSONFields_1.getCompiledJsonPath(jsonPath_tExtractJSONFields_1);
		
		try {
		    
		        value_tExtractJSONFields_1 = compiledJsonPath_tExtractJSONFields_1.read(row_tExtractJSONFields_1);
		    
				row5.SSN = value_tExtractJSONFields_1 == null ? 

		null

 : value_tExtractJSONFields_1.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_1) {
			row5.SSN = 

		null

;
		}	
	} catch (java.lang.Exception ex_tExtractJSONFields_1) {
		    System.err.println(ex_tExtractJSONFields_1.getMessage());
		    row5 = null;	
	}
	
	}
    
	isStructError_tExtractJSONFields_1 = false;
	
//}


 


	tos_count_tExtractJSONFields_1++;

/**
 * [tExtractJSONFields_1 main ] stop
 */
	
	/**
	 * [tExtractJSONFields_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_1";

	

 



/**
 * [tExtractJSONFields_1 process_data_begin ] stop
 */
// Start of branch "row5"
if(row5 != null) { 



	
	/**
	 * [tMap_2 main ] start
	 */

	

	
	
	currentComponent="tMap_2";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"row5");
			

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_2 = false;
		
        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_2 = false;
		  boolean mainRowRejected_tMap_2 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_2__Struct Var = Var__tMap_2;
Var.var1 = Numeric.sequence("s2",1,1) ;// ###############################
        // ###############################
        // # Output tables

out = null;


// # Output table : 'out'
out_tmp.firstName = row5.firstName ;
out_tmp.lastName = row5.lastName ;
out_tmp.MBI = row5.MBI ;
out_tmp.DOB = row5.DOB ;
out_tmp.OtherID = row5.OtherID ;
out_tmp.SSN = row5.SSN ;
out_tmp.scd_key = Var.var1 ;
out = out_tmp;
// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_2 = false;










 


	tos_count_tMap_2++;

/**
 * [tMap_2 main ] stop
 */
	
	/**
	 * [tMap_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_2";

	

 



/**
 * [tMap_2 process_data_begin ] stop
 */
// Start of branch "out"
if(out != null) { 



	
	/**
	 * [tBufferOutput_2 main ] start
	 */

	

	
	
	currentComponent="tBufferOutput_2";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"out");
			



String[] row_tBufferOutput_2=new String[]{"","","","","","","",};		
	    if(out.firstName != null){
	        
	            row_tBufferOutput_2[0] = out.firstName;
	                        			    
	    }else{
	    	row_tBufferOutput_2[0] = null;
	    }
	    if(out.lastName != null){
	        
	            row_tBufferOutput_2[1] = out.lastName;
	                        			    
	    }else{
	    	row_tBufferOutput_2[1] = null;
	    }
	    if(out.MBI != null){
	        
	            row_tBufferOutput_2[2] = out.MBI;
	                        			    
	    }else{
	    	row_tBufferOutput_2[2] = null;
	    }
	    if(out.DOB != null){
	        
	            row_tBufferOutput_2[3] = out.DOB;
	                        			    
	    }else{
	    	row_tBufferOutput_2[3] = null;
	    }
	    if(out.OtherID != null){
	        
	            row_tBufferOutput_2[4] = out.OtherID;
	                        			    
	    }else{
	    	row_tBufferOutput_2[4] = null;
	    }
	    if(out.SSN != null){
	        
	            row_tBufferOutput_2[5] = out.SSN;
	                        			    
	    }else{
	    	row_tBufferOutput_2[5] = null;
	    }
	    row_tBufferOutput_2[6] = String.valueOf(out.scd_key); 
	    
	globalBuffer.add(row_tBufferOutput_2);	
	
 


	tos_count_tBufferOutput_2++;

/**
 * [tBufferOutput_2 main ] stop
 */
	
	/**
	 * [tBufferOutput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tBufferOutput_2";

	

 



/**
 * [tBufferOutput_2 process_data_begin ] stop
 */
	
	/**
	 * [tBufferOutput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tBufferOutput_2";

	

 



/**
 * [tBufferOutput_2 process_data_end ] stop
 */

} // End of branch "out"




	
	/**
	 * [tMap_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_2";

	

 



/**
 * [tMap_2 process_data_end ] stop
 */

} // End of branch "row5"

		// end for
	}


	
		} // C_01
	
	
	/**
	 * [tExtractJSONFields_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_1";

	

 



/**
 * [tExtractJSONFields_1 process_data_end ] stop
 */



	
	/**
	 * [tREST_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tREST_1";

	

 



/**
 * [tREST_1 process_data_end ] stop
 */
	
	/**
	 * [tREST_1 end ] start
	 */

	

	
	
	currentComponent="tREST_1";

	

 

ok_Hash.put("tREST_1", true);
end_Hash.put("tREST_1", System.currentTimeMillis());




/**
 * [tREST_1 end ] stop
 */

	
	/**
	 * [tExtractJSONFields_1 end ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_1";

	
   globalMap.put("tExtractJSONFields_1_NB_LINE", nb_line_tExtractJSONFields_1);


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row2",2,0,
			 			talendJobLog,"tREST_1","tREST","tExtractJSONFields_1","tExtractJSONFields","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tExtractJSONFields_1", true);
end_Hash.put("tExtractJSONFields_1", System.currentTimeMillis());




/**
 * [tExtractJSONFields_1 end ] stop
 */

	
	/**
	 * [tMap_2 end ] start
	 */

	

	
	
	currentComponent="tMap_2";

	


// ###############################
// # Lookup hashes releasing
// ###############################      





			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row5",2,0,
			 			talendJobLog,"tExtractJSONFields_1","tExtractJSONFields","tMap_2","tMap","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tMap_2", true);
end_Hash.put("tMap_2", System.currentTimeMillis());




/**
 * [tMap_2 end ] stop
 */

	
	/**
	 * [tBufferOutput_2 end ] start
	 */

	

	
	
	currentComponent="tBufferOutput_2";

	

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"out",2,0,
			 			talendJobLog,"tMap_2","tMap","tBufferOutput_2","tBufferOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tBufferOutput_2", true);
end_Hash.put("tBufferOutput_2", System.currentTimeMillis());




/**
 * [tBufferOutput_2 end ] stop
 */









						if(execStat){
							runStat.updateStatOnConnection("iterate1", 2, "exec" + NB_ITERATE_tREST_1);
						}				
					




	
	/**
	 * [tFlowToIterate_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_1";

	

 



/**
 * [tFlowToIterate_1 process_data_end ] stop
 */



	
	/**
	 * [tFileInputRaw_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileInputRaw_1";

	

 



/**
 * [tFileInputRaw_1 process_data_end ] stop
 */
	
	/**
	 * [tFileInputRaw_1 end ] start
	 */

	

	
	
	currentComponent="tFileInputRaw_1";

	



 

ok_Hash.put("tFileInputRaw_1", true);
end_Hash.put("tFileInputRaw_1", System.currentTimeMillis());




/**
 * [tFileInputRaw_1 end ] stop
 */

	
	/**
	 * [tFlowToIterate_1 end ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_1";

	

globalMap.put("tFlowToIterate_1_NB_LINE",nb_line_tFlowToIterate_1);
			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row6",2,0,
			 			talendJobLog,"tFileInputRaw_1","tFileInputRaw","tFlowToIterate_1","tFlowToIterate","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tFlowToIterate_1", true);
end_Hash.put("tFlowToIterate_1", System.currentTimeMillis());




/**
 * [tFlowToIterate_1 end ] stop
 */



				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFileInputRaw_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk1", 0, "ok");
								} 
							
							tDBInput_2Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileInputRaw_1 finally ] start
	 */

	

	
	
	currentComponent="tFileInputRaw_1";

	

 



/**
 * [tFileInputRaw_1 finally ] stop
 */

	
	/**
	 * [tFlowToIterate_1 finally ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_1";

	

 



/**
 * [tFlowToIterate_1 finally ] stop
 */

	
	/**
	 * [tREST_1 finally ] start
	 */

	

	
	
	currentComponent="tREST_1";

	

 



/**
 * [tREST_1 finally ] stop
 */

	
	/**
	 * [tExtractJSONFields_1 finally ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_1";

	

 



/**
 * [tExtractJSONFields_1 finally ] stop
 */

	
	/**
	 * [tMap_2 finally ] start
	 */

	

	
	
	currentComponent="tMap_2";

	

 



/**
 * [tMap_2 finally ] stop
 */

	
	/**
	 * [tBufferOutput_2 finally ] start
	 */

	

	
	
	currentComponent="tBufferOutput_2";

	

 



/**
 * [tBufferOutput_2 finally ] stop
 */















				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileInputRaw_1_SUBPROCESS_STATE", 1);
	}
	


public static class copyOfcopyOfoutStruct implements routines.system.IPersistableRow<copyOfcopyOfoutStruct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];

	
			    public String GID;

				public String getGID () {
					return this.GID;
				}
				
			    public Integer count;

				public Integer getCount () {
					return this.count;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam) {

        	try {

        		int length = 0;
		
					this.GID = readString(dis);
					
						this.count = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.GID,dos);
					
					// Integer
				
						writeInteger(this.count,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("GID="+GID);
		sb.append(",count="+String.valueOf(count));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(copyOfcopyOfoutStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row22Struct implements routines.system.IPersistableRow<row22Struct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];

	
			    public String GID;

				public String getGID () {
					return this.GID;
				}
				
			    public Integer count;

				public Integer getCount () {
					return this.count;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam) {

        	try {

        		int length = 0;
		
					this.GID = readString(dis);
					
						this.count = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.GID,dos);
					
					// Integer
				
						writeInteger(this.count,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("GID="+GID);
		sb.append(",count="+String.valueOf(count));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row22Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class OnRowsEndStructtAggregateRow_2 implements routines.system.IPersistableRow<OnRowsEndStructtAggregateRow_2> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];

	
			    public String GID;

				public String getGID () {
					return this.GID;
				}
				
			    public Integer count;

				public Integer getCount () {
					return this.count;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam) {

        	try {

        		int length = 0;
		
					this.GID = readString(dis);
					
						this.count = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.GID,dos);
					
					// Integer
				
						writeInteger(this.count,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("GID="+GID);
		sb.append(",count="+String.valueOf(count));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(OnRowsEndStructtAggregateRow_2 other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row21Struct implements routines.system.IPersistableRow<row21Struct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];

	
			    public String Gender;

				public String getGender () {
					return this.Gender;
				}
				
			    public String Date;

				public String getDate () {
					return this.Date;
				}
				
			    public String First_Name;

				public String getFirst_Name () {
					return this.First_Name;
				}
				
			    public String Last_Name;

				public String getLast_Name () {
					return this.Last_Name;
				}
				
			    public String State;

				public String getState () {
					return this.State;
				}
				
			    public String City;

				public String getCity () {
					return this.City;
				}
				
			    public String Zip_Code;

				public String getZip_Code () {
					return this.Zip_Code;
				}
				
			    public String Address_Line_1;

				public String getAddress_Line_1 () {
					return this.Address_Line_1;
				}
				
			    public String Address_Line_2;

				public String getAddress_Line_2 () {
					return this.Address_Line_2;
				}
				
			    public String Phone_Number;

				public String getPhone_Number () {
					return this.Phone_Number;
				}
				
			    public String Social_Security_Number;

				public String getSocial_Security_Number () {
					return this.Social_Security_Number;
				}
				
			    public String UPI_ID;

				public String getUPI_ID () {
					return this.UPI_ID;
				}
				
			    public String MBI;

				public String getMBI () {
					return this.MBI;
				}
				
			    public String Client_ID;

				public String getClient_ID () {
					return this.Client_ID;
				}
				
			    public String Carrier_ID;

				public String getCarrier_ID () {
					return this.Carrier_ID;
				}
				
			    public String Account_ID;

				public String getAccount_ID () {
					return this.Account_ID;
				}
				
			    public String Group_ID;

				public String getGroup_ID () {
					return this.Group_ID;
				}
				
			    public String Contract_Family_ID;

				public String getContract_Family_ID () {
					return this.Contract_Family_ID;
				}
				
			    public String Multi_Birth_Code;

				public String getMulti_Birth_Code () {
					return this.Multi_Birth_Code;
				}
				
			    public String Member_Key;

				public String getMember_Key () {
					return this.Member_Key;
				}
				
			    public String Source;

				public String getSource () {
					return this.Source;
				}
				
			    public String year;

				public String getYear () {
					return this.year;
				}
				
			    public String GID;

				public String getGID () {
					return this.GID;
				}
				
			    public Integer GRP_SIZE;

				public Integer getGRP_SIZE () {
					return this.GRP_SIZE;
				}
				
			    public Boolean MASTER;

				public Boolean getMASTER () {
					return this.MASTER;
				}
				
			    public Double SCORE;

				public Double getSCORE () {
					return this.SCORE;
				}
				
			    public Double GRP_QUALITY;

				public Double getGRP_QUALITY () {
					return this.GRP_QUALITY;
				}
				
			    public String MATCHING_DISTANCES;

				public String getMATCHING_DISTANCES () {
					return this.MATCHING_DISTANCES;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam) {

        	try {

        		int length = 0;
		
					this.Gender = readString(dis);
					
					this.Date = readString(dis);
					
					this.First_Name = readString(dis);
					
					this.Last_Name = readString(dis);
					
					this.State = readString(dis);
					
					this.City = readString(dis);
					
					this.Zip_Code = readString(dis);
					
					this.Address_Line_1 = readString(dis);
					
					this.Address_Line_2 = readString(dis);
					
					this.Phone_Number = readString(dis);
					
					this.Social_Security_Number = readString(dis);
					
					this.UPI_ID = readString(dis);
					
					this.MBI = readString(dis);
					
					this.Client_ID = readString(dis);
					
					this.Carrier_ID = readString(dis);
					
					this.Account_ID = readString(dis);
					
					this.Group_ID = readString(dis);
					
					this.Contract_Family_ID = readString(dis);
					
					this.Multi_Birth_Code = readString(dis);
					
					this.Member_Key = readString(dis);
					
					this.Source = readString(dis);
					
					this.year = readString(dis);
					
					this.GID = readString(dis);
					
						this.GRP_SIZE = readInteger(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.MASTER = null;
           				} else {
           			    	this.MASTER = dis.readBoolean();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.SCORE = null;
           				} else {
           			    	this.SCORE = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.GRP_QUALITY = null;
           				} else {
           			    	this.GRP_QUALITY = dis.readDouble();
           				}
					
					this.MATCHING_DISTANCES = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Gender,dos);
					
					// String
				
						writeString(this.Date,dos);
					
					// String
				
						writeString(this.First_Name,dos);
					
					// String
				
						writeString(this.Last_Name,dos);
					
					// String
				
						writeString(this.State,dos);
					
					// String
				
						writeString(this.City,dos);
					
					// String
				
						writeString(this.Zip_Code,dos);
					
					// String
				
						writeString(this.Address_Line_1,dos);
					
					// String
				
						writeString(this.Address_Line_2,dos);
					
					// String
				
						writeString(this.Phone_Number,dos);
					
					// String
				
						writeString(this.Social_Security_Number,dos);
					
					// String
				
						writeString(this.UPI_ID,dos);
					
					// String
				
						writeString(this.MBI,dos);
					
					// String
				
						writeString(this.Client_ID,dos);
					
					// String
				
						writeString(this.Carrier_ID,dos);
					
					// String
				
						writeString(this.Account_ID,dos);
					
					// String
				
						writeString(this.Group_ID,dos);
					
					// String
				
						writeString(this.Contract_Family_ID,dos);
					
					// String
				
						writeString(this.Multi_Birth_Code,dos);
					
					// String
				
						writeString(this.Member_Key,dos);
					
					// String
				
						writeString(this.Source,dos);
					
					// String
				
						writeString(this.year,dos);
					
					// String
				
						writeString(this.GID,dos);
					
					// Integer
				
						writeInteger(this.GRP_SIZE,dos);
					
					// Boolean
				
						if(this.MASTER == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeBoolean(this.MASTER);
		            	}
					
					// Double
				
						if(this.SCORE == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.SCORE);
		            	}
					
					// Double
				
						if(this.GRP_QUALITY == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.GRP_QUALITY);
		            	}
					
					// String
				
						writeString(this.MATCHING_DISTANCES,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Gender="+Gender);
		sb.append(",Date="+Date);
		sb.append(",First_Name="+First_Name);
		sb.append(",Last_Name="+Last_Name);
		sb.append(",State="+State);
		sb.append(",City="+City);
		sb.append(",Zip_Code="+Zip_Code);
		sb.append(",Address_Line_1="+Address_Line_1);
		sb.append(",Address_Line_2="+Address_Line_2);
		sb.append(",Phone_Number="+Phone_Number);
		sb.append(",Social_Security_Number="+Social_Security_Number);
		sb.append(",UPI_ID="+UPI_ID);
		sb.append(",MBI="+MBI);
		sb.append(",Client_ID="+Client_ID);
		sb.append(",Carrier_ID="+Carrier_ID);
		sb.append(",Account_ID="+Account_ID);
		sb.append(",Group_ID="+Group_ID);
		sb.append(",Contract_Family_ID="+Contract_Family_ID);
		sb.append(",Multi_Birth_Code="+Multi_Birth_Code);
		sb.append(",Member_Key="+Member_Key);
		sb.append(",Source="+Source);
		sb.append(",year="+year);
		sb.append(",GID="+GID);
		sb.append(",GRP_SIZE="+String.valueOf(GRP_SIZE));
		sb.append(",MASTER="+String.valueOf(MASTER));
		sb.append(",SCORE="+String.valueOf(SCORE));
		sb.append(",GRP_QUALITY="+String.valueOf(GRP_QUALITY));
		sb.append(",MATCHING_DISTANCES="+MATCHING_DISTANCES);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row21Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class UPI_detokenizedStruct implements routines.system.IPersistableRow<UPI_detokenizedStruct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];

	
			    public String Gender;

				public String getGender () {
					return this.Gender;
				}
				
			    public String Date;

				public String getDate () {
					return this.Date;
				}
				
			    public String First_Name;

				public String getFirst_Name () {
					return this.First_Name;
				}
				
			    public String Last_Name;

				public String getLast_Name () {
					return this.Last_Name;
				}
				
			    public String State;

				public String getState () {
					return this.State;
				}
				
			    public String City;

				public String getCity () {
					return this.City;
				}
				
			    public String Zip_Code;

				public String getZip_Code () {
					return this.Zip_Code;
				}
				
			    public String Address_Line_1;

				public String getAddress_Line_1 () {
					return this.Address_Line_1;
				}
				
			    public String Address_Line_2;

				public String getAddress_Line_2 () {
					return this.Address_Line_2;
				}
				
			    public String Phone_Number;

				public String getPhone_Number () {
					return this.Phone_Number;
				}
				
			    public String Social_Security_Number;

				public String getSocial_Security_Number () {
					return this.Social_Security_Number;
				}
				
			    public String UPI_ID;

				public String getUPI_ID () {
					return this.UPI_ID;
				}
				
			    public String MBI;

				public String getMBI () {
					return this.MBI;
				}
				
			    public String Client_ID;

				public String getClient_ID () {
					return this.Client_ID;
				}
				
			    public String Carrier_ID;

				public String getCarrier_ID () {
					return this.Carrier_ID;
				}
				
			    public String Account_ID;

				public String getAccount_ID () {
					return this.Account_ID;
				}
				
			    public String Group_ID;

				public String getGroup_ID () {
					return this.Group_ID;
				}
				
			    public String Contract_Family_ID;

				public String getContract_Family_ID () {
					return this.Contract_Family_ID;
				}
				
			    public String Multi_Birth_Code;

				public String getMulti_Birth_Code () {
					return this.Multi_Birth_Code;
				}
				
			    public String Member_Key;

				public String getMember_Key () {
					return this.Member_Key;
				}
				
			    public String Source;

				public String getSource () {
					return this.Source;
				}
				
			    public String year;

				public String getYear () {
					return this.year;
				}
				
			    public String GID;

				public String getGID () {
					return this.GID;
				}
				
			    public Integer GRP_SIZE;

				public Integer getGRP_SIZE () {
					return this.GRP_SIZE;
				}
				
			    public Boolean MASTER;

				public Boolean getMASTER () {
					return this.MASTER;
				}
				
			    public Double SCORE;

				public Double getSCORE () {
					return this.SCORE;
				}
				
			    public Double GRP_QUALITY;

				public Double getGRP_QUALITY () {
					return this.GRP_QUALITY;
				}
				
			    public String MATCHING_DISTANCES;

				public String getMATCHING_DISTANCES () {
					return this.MATCHING_DISTANCES;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam) {

        	try {

        		int length = 0;
		
					this.Gender = readString(dis);
					
					this.Date = readString(dis);
					
					this.First_Name = readString(dis);
					
					this.Last_Name = readString(dis);
					
					this.State = readString(dis);
					
					this.City = readString(dis);
					
					this.Zip_Code = readString(dis);
					
					this.Address_Line_1 = readString(dis);
					
					this.Address_Line_2 = readString(dis);
					
					this.Phone_Number = readString(dis);
					
					this.Social_Security_Number = readString(dis);
					
					this.UPI_ID = readString(dis);
					
					this.MBI = readString(dis);
					
					this.Client_ID = readString(dis);
					
					this.Carrier_ID = readString(dis);
					
					this.Account_ID = readString(dis);
					
					this.Group_ID = readString(dis);
					
					this.Contract_Family_ID = readString(dis);
					
					this.Multi_Birth_Code = readString(dis);
					
					this.Member_Key = readString(dis);
					
					this.Source = readString(dis);
					
					this.year = readString(dis);
					
					this.GID = readString(dis);
					
						this.GRP_SIZE = readInteger(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.MASTER = null;
           				} else {
           			    	this.MASTER = dis.readBoolean();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.SCORE = null;
           				} else {
           			    	this.SCORE = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.GRP_QUALITY = null;
           				} else {
           			    	this.GRP_QUALITY = dis.readDouble();
           				}
					
					this.MATCHING_DISTANCES = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Gender,dos);
					
					// String
				
						writeString(this.Date,dos);
					
					// String
				
						writeString(this.First_Name,dos);
					
					// String
				
						writeString(this.Last_Name,dos);
					
					// String
				
						writeString(this.State,dos);
					
					// String
				
						writeString(this.City,dos);
					
					// String
				
						writeString(this.Zip_Code,dos);
					
					// String
				
						writeString(this.Address_Line_1,dos);
					
					// String
				
						writeString(this.Address_Line_2,dos);
					
					// String
				
						writeString(this.Phone_Number,dos);
					
					// String
				
						writeString(this.Social_Security_Number,dos);
					
					// String
				
						writeString(this.UPI_ID,dos);
					
					// String
				
						writeString(this.MBI,dos);
					
					// String
				
						writeString(this.Client_ID,dos);
					
					// String
				
						writeString(this.Carrier_ID,dos);
					
					// String
				
						writeString(this.Account_ID,dos);
					
					// String
				
						writeString(this.Group_ID,dos);
					
					// String
				
						writeString(this.Contract_Family_ID,dos);
					
					// String
				
						writeString(this.Multi_Birth_Code,dos);
					
					// String
				
						writeString(this.Member_Key,dos);
					
					// String
				
						writeString(this.Source,dos);
					
					// String
				
						writeString(this.year,dos);
					
					// String
				
						writeString(this.GID,dos);
					
					// Integer
				
						writeInteger(this.GRP_SIZE,dos);
					
					// Boolean
				
						if(this.MASTER == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeBoolean(this.MASTER);
		            	}
					
					// Double
				
						if(this.SCORE == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.SCORE);
		            	}
					
					// Double
				
						if(this.GRP_QUALITY == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.GRP_QUALITY);
		            	}
					
					// String
				
						writeString(this.MATCHING_DISTANCES,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Gender="+Gender);
		sb.append(",Date="+Date);
		sb.append(",First_Name="+First_Name);
		sb.append(",Last_Name="+Last_Name);
		sb.append(",State="+State);
		sb.append(",City="+City);
		sb.append(",Zip_Code="+Zip_Code);
		sb.append(",Address_Line_1="+Address_Line_1);
		sb.append(",Address_Line_2="+Address_Line_2);
		sb.append(",Phone_Number="+Phone_Number);
		sb.append(",Social_Security_Number="+Social_Security_Number);
		sb.append(",UPI_ID="+UPI_ID);
		sb.append(",MBI="+MBI);
		sb.append(",Client_ID="+Client_ID);
		sb.append(",Carrier_ID="+Carrier_ID);
		sb.append(",Account_ID="+Account_ID);
		sb.append(",Group_ID="+Group_ID);
		sb.append(",Contract_Family_ID="+Contract_Family_ID);
		sb.append(",Multi_Birth_Code="+Multi_Birth_Code);
		sb.append(",Member_Key="+Member_Key);
		sb.append(",Source="+Source);
		sb.append(",year="+year);
		sb.append(",GID="+GID);
		sb.append(",GRP_SIZE="+String.valueOf(GRP_SIZE));
		sb.append(",MASTER="+String.valueOf(MASTER));
		sb.append(",SCORE="+String.valueOf(SCORE));
		sb.append(",GRP_QUALITY="+String.valueOf(GRP_QUALITY));
		sb.append(",MATCHING_DISTANCES="+MATCHING_DISTANCES);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(UPI_detokenizedStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row13Struct implements routines.system.IPersistableRow<row13Struct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];

	
			    public String Gender;

				public String getGender () {
					return this.Gender;
				}
				
			    public String Date;

				public String getDate () {
					return this.Date;
				}
				
			    public String First_Name;

				public String getFirst_Name () {
					return this.First_Name;
				}
				
			    public String Last_Name;

				public String getLast_Name () {
					return this.Last_Name;
				}
				
			    public String State;

				public String getState () {
					return this.State;
				}
				
			    public String City;

				public String getCity () {
					return this.City;
				}
				
			    public String Zip_Code;

				public String getZip_Code () {
					return this.Zip_Code;
				}
				
			    public String Address_Line_1;

				public String getAddress_Line_1 () {
					return this.Address_Line_1;
				}
				
			    public String Address_Line_2;

				public String getAddress_Line_2 () {
					return this.Address_Line_2;
				}
				
			    public String Phone_Number;

				public String getPhone_Number () {
					return this.Phone_Number;
				}
				
			    public String Social_Security_Number;

				public String getSocial_Security_Number () {
					return this.Social_Security_Number;
				}
				
			    public String UPI_ID;

				public String getUPI_ID () {
					return this.UPI_ID;
				}
				
			    public String MBI;

				public String getMBI () {
					return this.MBI;
				}
				
			    public String Client_ID;

				public String getClient_ID () {
					return this.Client_ID;
				}
				
			    public String Carrier_ID;

				public String getCarrier_ID () {
					return this.Carrier_ID;
				}
				
			    public String Account_ID;

				public String getAccount_ID () {
					return this.Account_ID;
				}
				
			    public String Group_ID;

				public String getGroup_ID () {
					return this.Group_ID;
				}
				
			    public String Contract_Family_ID;

				public String getContract_Family_ID () {
					return this.Contract_Family_ID;
				}
				
			    public String Multi_Birth_Code;

				public String getMulti_Birth_Code () {
					return this.Multi_Birth_Code;
				}
				
			    public String Member_Key;

				public String getMember_Key () {
					return this.Member_Key;
				}
				
			    public String Source;

				public String getSource () {
					return this.Source;
				}
				
			    public String year;

				public String getYear () {
					return this.year;
				}
				
			    public String GID;

				public String getGID () {
					return this.GID;
				}
				
			    public Integer GRP_SIZE;

				public Integer getGRP_SIZE () {
					return this.GRP_SIZE;
				}
				
			    public Boolean MASTER;

				public Boolean getMASTER () {
					return this.MASTER;
				}
				
			    public Double SCORE;

				public Double getSCORE () {
					return this.SCORE;
				}
				
			    public Double GRP_QUALITY;

				public Double getGRP_QUALITY () {
					return this.GRP_QUALITY;
				}
				
			    public String MATCHING_DISTANCES;

				public String getMATCHING_DISTANCES () {
					return this.MATCHING_DISTANCES;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam) {

        	try {

        		int length = 0;
		
					this.Gender = readString(dis);
					
					this.Date = readString(dis);
					
					this.First_Name = readString(dis);
					
					this.Last_Name = readString(dis);
					
					this.State = readString(dis);
					
					this.City = readString(dis);
					
					this.Zip_Code = readString(dis);
					
					this.Address_Line_1 = readString(dis);
					
					this.Address_Line_2 = readString(dis);
					
					this.Phone_Number = readString(dis);
					
					this.Social_Security_Number = readString(dis);
					
					this.UPI_ID = readString(dis);
					
					this.MBI = readString(dis);
					
					this.Client_ID = readString(dis);
					
					this.Carrier_ID = readString(dis);
					
					this.Account_ID = readString(dis);
					
					this.Group_ID = readString(dis);
					
					this.Contract_Family_ID = readString(dis);
					
					this.Multi_Birth_Code = readString(dis);
					
					this.Member_Key = readString(dis);
					
					this.Source = readString(dis);
					
					this.year = readString(dis);
					
					this.GID = readString(dis);
					
						this.GRP_SIZE = readInteger(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.MASTER = null;
           				} else {
           			    	this.MASTER = dis.readBoolean();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.SCORE = null;
           				} else {
           			    	this.SCORE = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.GRP_QUALITY = null;
           				} else {
           			    	this.GRP_QUALITY = dis.readDouble();
           				}
					
					this.MATCHING_DISTANCES = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Gender,dos);
					
					// String
				
						writeString(this.Date,dos);
					
					// String
				
						writeString(this.First_Name,dos);
					
					// String
				
						writeString(this.Last_Name,dos);
					
					// String
				
						writeString(this.State,dos);
					
					// String
				
						writeString(this.City,dos);
					
					// String
				
						writeString(this.Zip_Code,dos);
					
					// String
				
						writeString(this.Address_Line_1,dos);
					
					// String
				
						writeString(this.Address_Line_2,dos);
					
					// String
				
						writeString(this.Phone_Number,dos);
					
					// String
				
						writeString(this.Social_Security_Number,dos);
					
					// String
				
						writeString(this.UPI_ID,dos);
					
					// String
				
						writeString(this.MBI,dos);
					
					// String
				
						writeString(this.Client_ID,dos);
					
					// String
				
						writeString(this.Carrier_ID,dos);
					
					// String
				
						writeString(this.Account_ID,dos);
					
					// String
				
						writeString(this.Group_ID,dos);
					
					// String
				
						writeString(this.Contract_Family_ID,dos);
					
					// String
				
						writeString(this.Multi_Birth_Code,dos);
					
					// String
				
						writeString(this.Member_Key,dos);
					
					// String
				
						writeString(this.Source,dos);
					
					// String
				
						writeString(this.year,dos);
					
					// String
				
						writeString(this.GID,dos);
					
					// Integer
				
						writeInteger(this.GRP_SIZE,dos);
					
					// Boolean
				
						if(this.MASTER == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeBoolean(this.MASTER);
		            	}
					
					// Double
				
						if(this.SCORE == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.SCORE);
		            	}
					
					// Double
				
						if(this.GRP_QUALITY == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.GRP_QUALITY);
		            	}
					
					// String
				
						writeString(this.MATCHING_DISTANCES,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Gender="+Gender);
		sb.append(",Date="+Date);
		sb.append(",First_Name="+First_Name);
		sb.append(",Last_Name="+Last_Name);
		sb.append(",State="+State);
		sb.append(",City="+City);
		sb.append(",Zip_Code="+Zip_Code);
		sb.append(",Address_Line_1="+Address_Line_1);
		sb.append(",Address_Line_2="+Address_Line_2);
		sb.append(",Phone_Number="+Phone_Number);
		sb.append(",Social_Security_Number="+Social_Security_Number);
		sb.append(",UPI_ID="+UPI_ID);
		sb.append(",MBI="+MBI);
		sb.append(",Client_ID="+Client_ID);
		sb.append(",Carrier_ID="+Carrier_ID);
		sb.append(",Account_ID="+Account_ID);
		sb.append(",Group_ID="+Group_ID);
		sb.append(",Contract_Family_ID="+Contract_Family_ID);
		sb.append(",Multi_Birth_Code="+Multi_Birth_Code);
		sb.append(",Member_Key="+Member_Key);
		sb.append(",Source="+Source);
		sb.append(",year="+year);
		sb.append(",GID="+GID);
		sb.append(",GRP_SIZE="+String.valueOf(GRP_SIZE));
		sb.append(",MASTER="+String.valueOf(MASTER));
		sb.append(",SCORE="+String.valueOf(SCORE));
		sb.append(",GRP_QUALITY="+String.valueOf(GRP_QUALITY));
		sb.append(",MATCHING_DISTANCES="+MATCHING_DISTANCES);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row13Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row8Struct implements routines.system.IPersistableRow<row8Struct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];

	
			    public String Gender;

				public String getGender () {
					return this.Gender;
				}
				
			    public String Date;

				public String getDate () {
					return this.Date;
				}
				
			    public String First_Name;

				public String getFirst_Name () {
					return this.First_Name;
				}
				
			    public String Last_Name;

				public String getLast_Name () {
					return this.Last_Name;
				}
				
			    public String State;

				public String getState () {
					return this.State;
				}
				
			    public String City;

				public String getCity () {
					return this.City;
				}
				
			    public String Zip_Code;

				public String getZip_Code () {
					return this.Zip_Code;
				}
				
			    public String Address_Line_1;

				public String getAddress_Line_1 () {
					return this.Address_Line_1;
				}
				
			    public String Address_Line_2;

				public String getAddress_Line_2 () {
					return this.Address_Line_2;
				}
				
			    public String Phone_Number;

				public String getPhone_Number () {
					return this.Phone_Number;
				}
				
			    public String Social_Security_Number;

				public String getSocial_Security_Number () {
					return this.Social_Security_Number;
				}
				
			    public String UPI_ID;

				public String getUPI_ID () {
					return this.UPI_ID;
				}
				
			    public String MBI;

				public String getMBI () {
					return this.MBI;
				}
				
			    public String Client_ID;

				public String getClient_ID () {
					return this.Client_ID;
				}
				
			    public String Carrier_ID;

				public String getCarrier_ID () {
					return this.Carrier_ID;
				}
				
			    public String Account_ID;

				public String getAccount_ID () {
					return this.Account_ID;
				}
				
			    public String Group_ID;

				public String getGroup_ID () {
					return this.Group_ID;
				}
				
			    public String Contract_Family_ID;

				public String getContract_Family_ID () {
					return this.Contract_Family_ID;
				}
				
			    public String Multi_Birth_Code;

				public String getMulti_Birth_Code () {
					return this.Multi_Birth_Code;
				}
				
			    public String Member_Key;

				public String getMember_Key () {
					return this.Member_Key;
				}
				
			    public String Source;

				public String getSource () {
					return this.Source;
				}
				
			    public String year;

				public String getYear () {
					return this.year;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam) {

        	try {

        		int length = 0;
		
					this.Gender = readString(dis);
					
					this.Date = readString(dis);
					
					this.First_Name = readString(dis);
					
					this.Last_Name = readString(dis);
					
					this.State = readString(dis);
					
					this.City = readString(dis);
					
					this.Zip_Code = readString(dis);
					
					this.Address_Line_1 = readString(dis);
					
					this.Address_Line_2 = readString(dis);
					
					this.Phone_Number = readString(dis);
					
					this.Social_Security_Number = readString(dis);
					
					this.UPI_ID = readString(dis);
					
					this.MBI = readString(dis);
					
					this.Client_ID = readString(dis);
					
					this.Carrier_ID = readString(dis);
					
					this.Account_ID = readString(dis);
					
					this.Group_ID = readString(dis);
					
					this.Contract_Family_ID = readString(dis);
					
					this.Multi_Birth_Code = readString(dis);
					
					this.Member_Key = readString(dis);
					
					this.Source = readString(dis);
					
					this.year = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Gender,dos);
					
					// String
				
						writeString(this.Date,dos);
					
					// String
				
						writeString(this.First_Name,dos);
					
					// String
				
						writeString(this.Last_Name,dos);
					
					// String
				
						writeString(this.State,dos);
					
					// String
				
						writeString(this.City,dos);
					
					// String
				
						writeString(this.Zip_Code,dos);
					
					// String
				
						writeString(this.Address_Line_1,dos);
					
					// String
				
						writeString(this.Address_Line_2,dos);
					
					// String
				
						writeString(this.Phone_Number,dos);
					
					// String
				
						writeString(this.Social_Security_Number,dos);
					
					// String
				
						writeString(this.UPI_ID,dos);
					
					// String
				
						writeString(this.MBI,dos);
					
					// String
				
						writeString(this.Client_ID,dos);
					
					// String
				
						writeString(this.Carrier_ID,dos);
					
					// String
				
						writeString(this.Account_ID,dos);
					
					// String
				
						writeString(this.Group_ID,dos);
					
					// String
				
						writeString(this.Contract_Family_ID,dos);
					
					// String
				
						writeString(this.Multi_Birth_Code,dos);
					
					// String
				
						writeString(this.Member_Key,dos);
					
					// String
				
						writeString(this.Source,dos);
					
					// String
				
						writeString(this.year,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Gender="+Gender);
		sb.append(",Date="+Date);
		sb.append(",First_Name="+First_Name);
		sb.append(",Last_Name="+Last_Name);
		sb.append(",State="+State);
		sb.append(",City="+City);
		sb.append(",Zip_Code="+Zip_Code);
		sb.append(",Address_Line_1="+Address_Line_1);
		sb.append(",Address_Line_2="+Address_Line_2);
		sb.append(",Phone_Number="+Phone_Number);
		sb.append(",Social_Security_Number="+Social_Security_Number);
		sb.append(",UPI_ID="+UPI_ID);
		sb.append(",MBI="+MBI);
		sb.append(",Client_ID="+Client_ID);
		sb.append(",Carrier_ID="+Carrier_ID);
		sb.append(",Account_ID="+Account_ID);
		sb.append(",Group_ID="+Group_ID);
		sb.append(",Contract_Family_ID="+Contract_Family_ID);
		sb.append(",Multi_Birth_Code="+Multi_Birth_Code);
		sb.append(",Member_Key="+Member_Key);
		sb.append(",Source="+Source);
		sb.append(",year="+year);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row8Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class copyOfdobStruct implements routines.system.IPersistableRow<copyOfdobStruct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];

	
			    public String Gender;

				public String getGender () {
					return this.Gender;
				}
				
			    public java.util.Date Date;

				public java.util.Date getDate () {
					return this.Date;
				}
				
			    public String First_Name;

				public String getFirst_Name () {
					return this.First_Name;
				}
				
			    public String Last_Name;

				public String getLast_Name () {
					return this.Last_Name;
				}
				
			    public String State;

				public String getState () {
					return this.State;
				}
				
			    public String City;

				public String getCity () {
					return this.City;
				}
				
			    public String Zip_Code;

				public String getZip_Code () {
					return this.Zip_Code;
				}
				
			    public String Address_Line_1;

				public String getAddress_Line_1 () {
					return this.Address_Line_1;
				}
				
			    public String Address_Line_2;

				public String getAddress_Line_2 () {
					return this.Address_Line_2;
				}
				
			    public String Phone_Number;

				public String getPhone_Number () {
					return this.Phone_Number;
				}
				
			    public String Social_Security_Number;

				public String getSocial_Security_Number () {
					return this.Social_Security_Number;
				}
				
			    public String UPI_ID;

				public String getUPI_ID () {
					return this.UPI_ID;
				}
				
			    public String MBI;

				public String getMBI () {
					return this.MBI;
				}
				
			    public String Client_ID;

				public String getClient_ID () {
					return this.Client_ID;
				}
				
			    public String Carrier_ID;

				public String getCarrier_ID () {
					return this.Carrier_ID;
				}
				
			    public String Account_ID;

				public String getAccount_ID () {
					return this.Account_ID;
				}
				
			    public String Group_ID;

				public String getGroup_ID () {
					return this.Group_ID;
				}
				
			    public String Contract_Family_ID;

				public String getContract_Family_ID () {
					return this.Contract_Family_ID;
				}
				
			    public String Multi_Birth_Code;

				public String getMulti_Birth_Code () {
					return this.Multi_Birth_Code;
				}
				
			    public String Member_Key;

				public String getMember_Key () {
					return this.Member_Key;
				}
				
			    public String Source;

				public String getSource () {
					return this.Source;
				}
				
			    public java.util.Date year;

				public java.util.Date getYear () {
					return this.year;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam) {

        	try {

        		int length = 0;
		
					this.Gender = readString(dis);
					
					this.Date = readDate(dis);
					
					this.First_Name = readString(dis);
					
					this.Last_Name = readString(dis);
					
					this.State = readString(dis);
					
					this.City = readString(dis);
					
					this.Zip_Code = readString(dis);
					
					this.Address_Line_1 = readString(dis);
					
					this.Address_Line_2 = readString(dis);
					
					this.Phone_Number = readString(dis);
					
					this.Social_Security_Number = readString(dis);
					
					this.UPI_ID = readString(dis);
					
					this.MBI = readString(dis);
					
					this.Client_ID = readString(dis);
					
					this.Carrier_ID = readString(dis);
					
					this.Account_ID = readString(dis);
					
					this.Group_ID = readString(dis);
					
					this.Contract_Family_ID = readString(dis);
					
					this.Multi_Birth_Code = readString(dis);
					
					this.Member_Key = readString(dis);
					
					this.Source = readString(dis);
					
					this.year = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Gender,dos);
					
					// java.util.Date
				
						writeDate(this.Date,dos);
					
					// String
				
						writeString(this.First_Name,dos);
					
					// String
				
						writeString(this.Last_Name,dos);
					
					// String
				
						writeString(this.State,dos);
					
					// String
				
						writeString(this.City,dos);
					
					// String
				
						writeString(this.Zip_Code,dos);
					
					// String
				
						writeString(this.Address_Line_1,dos);
					
					// String
				
						writeString(this.Address_Line_2,dos);
					
					// String
				
						writeString(this.Phone_Number,dos);
					
					// String
				
						writeString(this.Social_Security_Number,dos);
					
					// String
				
						writeString(this.UPI_ID,dos);
					
					// String
				
						writeString(this.MBI,dos);
					
					// String
				
						writeString(this.Client_ID,dos);
					
					// String
				
						writeString(this.Carrier_ID,dos);
					
					// String
				
						writeString(this.Account_ID,dos);
					
					// String
				
						writeString(this.Group_ID,dos);
					
					// String
				
						writeString(this.Contract_Family_ID,dos);
					
					// String
				
						writeString(this.Multi_Birth_Code,dos);
					
					// String
				
						writeString(this.Member_Key,dos);
					
					// String
				
						writeString(this.Source,dos);
					
					// java.util.Date
				
						writeDate(this.year,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Gender="+Gender);
		sb.append(",Date="+String.valueOf(Date));
		sb.append(",First_Name="+First_Name);
		sb.append(",Last_Name="+Last_Name);
		sb.append(",State="+State);
		sb.append(",City="+City);
		sb.append(",Zip_Code="+Zip_Code);
		sb.append(",Address_Line_1="+Address_Line_1);
		sb.append(",Address_Line_2="+Address_Line_2);
		sb.append(",Phone_Number="+Phone_Number);
		sb.append(",Social_Security_Number="+Social_Security_Number);
		sb.append(",UPI_ID="+UPI_ID);
		sb.append(",MBI="+MBI);
		sb.append(",Client_ID="+Client_ID);
		sb.append(",Carrier_ID="+Carrier_ID);
		sb.append(",Account_ID="+Account_ID);
		sb.append(",Group_ID="+Group_ID);
		sb.append(",Contract_Family_ID="+Contract_Family_ID);
		sb.append(",Multi_Birth_Code="+Multi_Birth_Code);
		sb.append(",Member_Key="+Member_Key);
		sb.append(",Source="+Source);
		sb.append(",year="+String.valueOf(year));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(copyOfdobStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row18Struct implements routines.system.IPersistableRow<row18Struct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];

	
			    public Character Gender;

				public Character getGender () {
					return this.Gender;
				}
				
			    public String Date_of_Birth;

				public String getDate_of_Birth () {
					return this.Date_of_Birth;
				}
				
			    public String First_Name;

				public String getFirst_Name () {
					return this.First_Name;
				}
				
			    public String Last_Name;

				public String getLast_Name () {
					return this.Last_Name;
				}
				
			    public String State;

				public String getState () {
					return this.State;
				}
				
			    public String City;

				public String getCity () {
					return this.City;
				}
				
			    public String Zip_Code;

				public String getZip_Code () {
					return this.Zip_Code;
				}
				
			    public String Address_Line_1;

				public String getAddress_Line_1 () {
					return this.Address_Line_1;
				}
				
			    public String Address_Line_2;

				public String getAddress_Line_2 () {
					return this.Address_Line_2;
				}
				
			    public String Phone_Number;

				public String getPhone_Number () {
					return this.Phone_Number;
				}
				
			    public String Social_Security_Number;

				public String getSocial_Security_Number () {
					return this.Social_Security_Number;
				}
				
			    public String UPI_ID;

				public String getUPI_ID () {
					return this.UPI_ID;
				}
				
			    public String MBI;

				public String getMBI () {
					return this.MBI;
				}
				
			    public String Client_ID;

				public String getClient_ID () {
					return this.Client_ID;
				}
				
			    public String Carrier_ID;

				public String getCarrier_ID () {
					return this.Carrier_ID;
				}
				
			    public String Account_ID;

				public String getAccount_ID () {
					return this.Account_ID;
				}
				
			    public String Group_ID;

				public String getGroup_ID () {
					return this.Group_ID;
				}
				
			    public String Contract_Family_ID;

				public String getContract_Family_ID () {
					return this.Contract_Family_ID;
				}
				
			    public String Multi_Birth_Code;

				public String getMulti_Birth_Code () {
					return this.Multi_Birth_Code;
				}
				
			    public String Member_Key;

				public String getMember_Key () {
					return this.Member_Key;
				}
				
			    public String Source;

				public String getSource () {
					return this.Source;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam) {

        	try {

        		int length = 0;
		
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.Gender = null;
           				} else {
           			    	this.Gender = dis.readChar();
           				}
					
					this.Date_of_Birth = readString(dis);
					
					this.First_Name = readString(dis);
					
					this.Last_Name = readString(dis);
					
					this.State = readString(dis);
					
					this.City = readString(dis);
					
					this.Zip_Code = readString(dis);
					
					this.Address_Line_1 = readString(dis);
					
					this.Address_Line_2 = readString(dis);
					
					this.Phone_Number = readString(dis);
					
					this.Social_Security_Number = readString(dis);
					
					this.UPI_ID = readString(dis);
					
					this.MBI = readString(dis);
					
					this.Client_ID = readString(dis);
					
					this.Carrier_ID = readString(dis);
					
					this.Account_ID = readString(dis);
					
					this.Group_ID = readString(dis);
					
					this.Contract_Family_ID = readString(dis);
					
					this.Multi_Birth_Code = readString(dis);
					
					this.Member_Key = readString(dis);
					
					this.Source = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Character
				
						if(this.Gender == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeChar(this.Gender);
		            	}
					
					// String
				
						writeString(this.Date_of_Birth,dos);
					
					// String
				
						writeString(this.First_Name,dos);
					
					// String
				
						writeString(this.Last_Name,dos);
					
					// String
				
						writeString(this.State,dos);
					
					// String
				
						writeString(this.City,dos);
					
					// String
				
						writeString(this.Zip_Code,dos);
					
					// String
				
						writeString(this.Address_Line_1,dos);
					
					// String
				
						writeString(this.Address_Line_2,dos);
					
					// String
				
						writeString(this.Phone_Number,dos);
					
					// String
				
						writeString(this.Social_Security_Number,dos);
					
					// String
				
						writeString(this.UPI_ID,dos);
					
					// String
				
						writeString(this.MBI,dos);
					
					// String
				
						writeString(this.Client_ID,dos);
					
					// String
				
						writeString(this.Carrier_ID,dos);
					
					// String
				
						writeString(this.Account_ID,dos);
					
					// String
				
						writeString(this.Group_ID,dos);
					
					// String
				
						writeString(this.Contract_Family_ID,dos);
					
					// String
				
						writeString(this.Multi_Birth_Code,dos);
					
					// String
				
						writeString(this.Member_Key,dos);
					
					// String
				
						writeString(this.Source,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Gender="+String.valueOf(Gender));
		sb.append(",Date_of_Birth="+Date_of_Birth);
		sb.append(",First_Name="+First_Name);
		sb.append(",Last_Name="+Last_Name);
		sb.append(",State="+State);
		sb.append(",City="+City);
		sb.append(",Zip_Code="+Zip_Code);
		sb.append(",Address_Line_1="+Address_Line_1);
		sb.append(",Address_Line_2="+Address_Line_2);
		sb.append(",Phone_Number="+Phone_Number);
		sb.append(",Social_Security_Number="+Social_Security_Number);
		sb.append(",UPI_ID="+UPI_ID);
		sb.append(",MBI="+MBI);
		sb.append(",Client_ID="+Client_ID);
		sb.append(",Carrier_ID="+Carrier_ID);
		sb.append(",Account_ID="+Account_ID);
		sb.append(",Group_ID="+Group_ID);
		sb.append(",Contract_Family_ID="+Contract_Family_ID);
		sb.append(",Multi_Birth_Code="+Multi_Birth_Code);
		sb.append(",Member_Key="+Member_Key);
		sb.append(",Source="+Source);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row18Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class outputStruct implements routines.system.IPersistableRow<outputStruct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];

	
			    public Character Gender;

				public Character getGender () {
					return this.Gender;
				}
				
			    public String Date_of_Birth;

				public String getDate_of_Birth () {
					return this.Date_of_Birth;
				}
				
			    public String First_Name;

				public String getFirst_Name () {
					return this.First_Name;
				}
				
			    public String Last_Name;

				public String getLast_Name () {
					return this.Last_Name;
				}
				
			    public String State;

				public String getState () {
					return this.State;
				}
				
			    public String City;

				public String getCity () {
					return this.City;
				}
				
			    public String Zip_Code;

				public String getZip_Code () {
					return this.Zip_Code;
				}
				
			    public String Address_Line_1;

				public String getAddress_Line_1 () {
					return this.Address_Line_1;
				}
				
			    public String Address_Line_2;

				public String getAddress_Line_2 () {
					return this.Address_Line_2;
				}
				
			    public String Phone_Number;

				public String getPhone_Number () {
					return this.Phone_Number;
				}
				
			    public String Social_Security_Number;

				public String getSocial_Security_Number () {
					return this.Social_Security_Number;
				}
				
			    public String UPI_ID;

				public String getUPI_ID () {
					return this.UPI_ID;
				}
				
			    public String MBI;

				public String getMBI () {
					return this.MBI;
				}
				
			    public String Client_ID;

				public String getClient_ID () {
					return this.Client_ID;
				}
				
			    public String Carrier_ID;

				public String getCarrier_ID () {
					return this.Carrier_ID;
				}
				
			    public String Account_ID;

				public String getAccount_ID () {
					return this.Account_ID;
				}
				
			    public String Group_ID;

				public String getGroup_ID () {
					return this.Group_ID;
				}
				
			    public String Contract_Family_ID;

				public String getContract_Family_ID () {
					return this.Contract_Family_ID;
				}
				
			    public String Multi_Birth_Code;

				public String getMulti_Birth_Code () {
					return this.Multi_Birth_Code;
				}
				
			    public String Member_Key;

				public String getMember_Key () {
					return this.Member_Key;
				}
				
			    public String Source;

				public String getSource () {
					return this.Source;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam) {

        	try {

        		int length = 0;
		
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.Gender = null;
           				} else {
           			    	this.Gender = dis.readChar();
           				}
					
					this.Date_of_Birth = readString(dis);
					
					this.First_Name = readString(dis);
					
					this.Last_Name = readString(dis);
					
					this.State = readString(dis);
					
					this.City = readString(dis);
					
					this.Zip_Code = readString(dis);
					
					this.Address_Line_1 = readString(dis);
					
					this.Address_Line_2 = readString(dis);
					
					this.Phone_Number = readString(dis);
					
					this.Social_Security_Number = readString(dis);
					
					this.UPI_ID = readString(dis);
					
					this.MBI = readString(dis);
					
					this.Client_ID = readString(dis);
					
					this.Carrier_ID = readString(dis);
					
					this.Account_ID = readString(dis);
					
					this.Group_ID = readString(dis);
					
					this.Contract_Family_ID = readString(dis);
					
					this.Multi_Birth_Code = readString(dis);
					
					this.Member_Key = readString(dis);
					
					this.Source = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Character
				
						if(this.Gender == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeChar(this.Gender);
		            	}
					
					// String
				
						writeString(this.Date_of_Birth,dos);
					
					// String
				
						writeString(this.First_Name,dos);
					
					// String
				
						writeString(this.Last_Name,dos);
					
					// String
				
						writeString(this.State,dos);
					
					// String
				
						writeString(this.City,dos);
					
					// String
				
						writeString(this.Zip_Code,dos);
					
					// String
				
						writeString(this.Address_Line_1,dos);
					
					// String
				
						writeString(this.Address_Line_2,dos);
					
					// String
				
						writeString(this.Phone_Number,dos);
					
					// String
				
						writeString(this.Social_Security_Number,dos);
					
					// String
				
						writeString(this.UPI_ID,dos);
					
					// String
				
						writeString(this.MBI,dos);
					
					// String
				
						writeString(this.Client_ID,dos);
					
					// String
				
						writeString(this.Carrier_ID,dos);
					
					// String
				
						writeString(this.Account_ID,dos);
					
					// String
				
						writeString(this.Group_ID,dos);
					
					// String
				
						writeString(this.Contract_Family_ID,dos);
					
					// String
				
						writeString(this.Multi_Birth_Code,dos);
					
					// String
				
						writeString(this.Member_Key,dos);
					
					// String
				
						writeString(this.Source,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Gender="+String.valueOf(Gender));
		sb.append(",Date_of_Birth="+Date_of_Birth);
		sb.append(",First_Name="+First_Name);
		sb.append(",Last_Name="+Last_Name);
		sb.append(",State="+State);
		sb.append(",City="+City);
		sb.append(",Zip_Code="+Zip_Code);
		sb.append(",Address_Line_1="+Address_Line_1);
		sb.append(",Address_Line_2="+Address_Line_2);
		sb.append(",Phone_Number="+Phone_Number);
		sb.append(",Social_Security_Number="+Social_Security_Number);
		sb.append(",UPI_ID="+UPI_ID);
		sb.append(",MBI="+MBI);
		sb.append(",Client_ID="+Client_ID);
		sb.append(",Carrier_ID="+Carrier_ID);
		sb.append(",Account_ID="+Account_ID);
		sb.append(",Group_ID="+Group_ID);
		sb.append(",Contract_Family_ID="+Contract_Family_ID);
		sb.append(",Multi_Birth_Code="+Multi_Birth_Code);
		sb.append(",Member_Key="+Member_Key);
		sb.append(",Source="+Source);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(outputStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];

	
			    public Character Gender;

				public Character getGender () {
					return this.Gender;
				}
				
			    public String State;

				public String getState () {
					return this.State;
				}
				
			    public String City;

				public String getCity () {
					return this.City;
				}
				
			    public String Zip_Code;

				public String getZip_Code () {
					return this.Zip_Code;
				}
				
			    public String Address_Line_1;

				public String getAddress_Line_1 () {
					return this.Address_Line_1;
				}
				
			    public String Address_Line_2;

				public String getAddress_Line_2 () {
					return this.Address_Line_2;
				}
				
			    public String Phone_Number;

				public String getPhone_Number () {
					return this.Phone_Number;
				}
				
			    public String Client_ID;

				public String getClient_ID () {
					return this.Client_ID;
				}
				
			    public String Carrier_ID;

				public String getCarrier_ID () {
					return this.Carrier_ID;
				}
				
			    public String Account_ID;

				public String getAccount_ID () {
					return this.Account_ID;
				}
				
			    public String Group_ID;

				public String getGroup_ID () {
					return this.Group_ID;
				}
				
			    public String Multi_Birth_Code;

				public String getMulti_Birth_Code () {
					return this.Multi_Birth_Code;
				}
				
			    public String Member_Key;

				public String getMember_Key () {
					return this.Member_Key;
				}
				
			    public String Source;

				public String getSource () {
					return this.Source;
				}
				
			    public int scd_key;

				public int getScd_key () {
					return this.scd_key;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam) {

        	try {

        		int length = 0;
		
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.Gender = null;
           				} else {
           			    	this.Gender = dis.readChar();
           				}
					
					this.State = readString(dis);
					
					this.City = readString(dis);
					
					this.Zip_Code = readString(dis);
					
					this.Address_Line_1 = readString(dis);
					
					this.Address_Line_2 = readString(dis);
					
					this.Phone_Number = readString(dis);
					
					this.Client_ID = readString(dis);
					
					this.Carrier_ID = readString(dis);
					
					this.Account_ID = readString(dis);
					
					this.Group_ID = readString(dis);
					
					this.Multi_Birth_Code = readString(dis);
					
					this.Member_Key = readString(dis);
					
					this.Source = readString(dis);
					
			        this.scd_key = dis.readInt();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Character
				
						if(this.Gender == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeChar(this.Gender);
		            	}
					
					// String
				
						writeString(this.State,dos);
					
					// String
				
						writeString(this.City,dos);
					
					// String
				
						writeString(this.Zip_Code,dos);
					
					// String
				
						writeString(this.Address_Line_1,dos);
					
					// String
				
						writeString(this.Address_Line_2,dos);
					
					// String
				
						writeString(this.Phone_Number,dos);
					
					// String
				
						writeString(this.Client_ID,dos);
					
					// String
				
						writeString(this.Carrier_ID,dos);
					
					// String
				
						writeString(this.Account_ID,dos);
					
					// String
				
						writeString(this.Group_ID,dos);
					
					// String
				
						writeString(this.Multi_Birth_Code,dos);
					
					// String
				
						writeString(this.Member_Key,dos);
					
					// String
				
						writeString(this.Source,dos);
					
					// int
				
		            	dos.writeInt(this.scd_key);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Gender="+String.valueOf(Gender));
		sb.append(",State="+State);
		sb.append(",City="+City);
		sb.append(",Zip_Code="+Zip_Code);
		sb.append(",Address_Line_1="+Address_Line_1);
		sb.append(",Address_Line_2="+Address_Line_2);
		sb.append(",Phone_Number="+Phone_Number);
		sb.append(",Client_ID="+Client_ID);
		sb.append(",Carrier_ID="+Carrier_ID);
		sb.append(",Account_ID="+Account_ID);
		sb.append(",Group_ID="+Group_ID);
		sb.append(",Multi_Birth_Code="+Multi_Birth_Code);
		sb.append(",Member_Key="+Member_Key);
		sb.append(",Source="+Source);
		sb.append(",scd_key="+String.valueOf(scd_key));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row1Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class after_tDBInput_2Struct implements routines.system.IPersistableRow<after_tDBInput_2Struct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];

	
			    public Character Gender;

				public Character getGender () {
					return this.Gender;
				}
				
			    public String State;

				public String getState () {
					return this.State;
				}
				
			    public String City;

				public String getCity () {
					return this.City;
				}
				
			    public String Zip_Code;

				public String getZip_Code () {
					return this.Zip_Code;
				}
				
			    public String Address_Line_1;

				public String getAddress_Line_1 () {
					return this.Address_Line_1;
				}
				
			    public String Address_Line_2;

				public String getAddress_Line_2 () {
					return this.Address_Line_2;
				}
				
			    public String Phone_Number;

				public String getPhone_Number () {
					return this.Phone_Number;
				}
				
			    public String Client_ID;

				public String getClient_ID () {
					return this.Client_ID;
				}
				
			    public String Carrier_ID;

				public String getCarrier_ID () {
					return this.Carrier_ID;
				}
				
			    public String Account_ID;

				public String getAccount_ID () {
					return this.Account_ID;
				}
				
			    public String Group_ID;

				public String getGroup_ID () {
					return this.Group_ID;
				}
				
			    public String Multi_Birth_Code;

				public String getMulti_Birth_Code () {
					return this.Multi_Birth_Code;
				}
				
			    public String Member_Key;

				public String getMember_Key () {
					return this.Member_Key;
				}
				
			    public String Source;

				public String getSource () {
					return this.Source;
				}
				
			    public int scd_key;

				public int getScd_key () {
					return this.scd_key;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam) {

        	try {

        		int length = 0;
		
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.Gender = null;
           				} else {
           			    	this.Gender = dis.readChar();
           				}
					
					this.State = readString(dis);
					
					this.City = readString(dis);
					
					this.Zip_Code = readString(dis);
					
					this.Address_Line_1 = readString(dis);
					
					this.Address_Line_2 = readString(dis);
					
					this.Phone_Number = readString(dis);
					
					this.Client_ID = readString(dis);
					
					this.Carrier_ID = readString(dis);
					
					this.Account_ID = readString(dis);
					
					this.Group_ID = readString(dis);
					
					this.Multi_Birth_Code = readString(dis);
					
					this.Member_Key = readString(dis);
					
					this.Source = readString(dis);
					
			        this.scd_key = dis.readInt();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Character
				
						if(this.Gender == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeChar(this.Gender);
		            	}
					
					// String
				
						writeString(this.State,dos);
					
					// String
				
						writeString(this.City,dos);
					
					// String
				
						writeString(this.Zip_Code,dos);
					
					// String
				
						writeString(this.Address_Line_1,dos);
					
					// String
				
						writeString(this.Address_Line_2,dos);
					
					// String
				
						writeString(this.Phone_Number,dos);
					
					// String
				
						writeString(this.Client_ID,dos);
					
					// String
				
						writeString(this.Carrier_ID,dos);
					
					// String
				
						writeString(this.Account_ID,dos);
					
					// String
				
						writeString(this.Group_ID,dos);
					
					// String
				
						writeString(this.Multi_Birth_Code,dos);
					
					// String
				
						writeString(this.Member_Key,dos);
					
					// String
				
						writeString(this.Source,dos);
					
					// int
				
		            	dos.writeInt(this.scd_key);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Gender="+String.valueOf(Gender));
		sb.append(",State="+State);
		sb.append(",City="+City);
		sb.append(",Zip_Code="+Zip_Code);
		sb.append(",Address_Line_1="+Address_Line_1);
		sb.append(",Address_Line_2="+Address_Line_2);
		sb.append(",Phone_Number="+Phone_Number);
		sb.append(",Client_ID="+Client_ID);
		sb.append(",Carrier_ID="+Carrier_ID);
		sb.append(",Account_ID="+Account_ID);
		sb.append(",Group_ID="+Group_ID);
		sb.append(",Multi_Birth_Code="+Multi_Birth_Code);
		sb.append(",Member_Key="+Member_Key);
		sb.append(",Source="+Source);
		sb.append(",scd_key="+String.valueOf(scd_key));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(after_tDBInput_2Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tDBInput_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
		String currentVirtualComponent = null;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;


		tBufferInput_2Process(globalMap);

		row1Struct row1 = new row1Struct();
outputStruct output = new outputStruct();
outputStruct row18 = output;
copyOfdobStruct copyOfdob = new copyOfdobStruct();
row8Struct row8 = new row8Struct();
row13Struct row13 = new row13Struct();
row13Struct UPI_detokenized = row13;
row13Struct row21 = row13;
row22Struct row22 = new row22Struct();
copyOfcopyOfoutStruct copyOfcopyOfout = new copyOfcopyOfoutStruct();








	
	/**
	 * [tMatchGroup_2_GroupOut begin ] start
	 */

	

	
		
		ok_Hash.put("tMatchGroup_2_GroupOut", false);
		start_Hash.put("tMatchGroup_2_GroupOut", System.currentTimeMillis());
		
	
		currentVirtualComponent = "tMatchGroup_2";
	
	currentComponent="tMatchGroup_2_GroupOut";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row8");
			
		int tos_count_tMatchGroup_2_GroupOut = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tMatchGroup_2_GroupOut", "tMatchGroupOut");
				talendJobLogProcess(globalMap);
			}
			
class tMatchGroup_2Struct implements routines.system.IPersistableRow<tMatchGroup_2Struct> {
  final byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];
  byte[] commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];
    public String Gender;

    public String getGender () {
      return this.Gender;
    }
    public String Date;

    public String getDate () {
      return this.Date;
    }
    public String First_Name;

    public String getFirst_Name () {
      return this.First_Name;
    }
    public String Last_Name;

    public String getLast_Name () {
      return this.Last_Name;
    }
    public String State;

    public String getState () {
      return this.State;
    }
    public String City;

    public String getCity () {
      return this.City;
    }
    public String Zip_Code;

    public String getZip_Code () {
      return this.Zip_Code;
    }
    public String Address_Line_1;

    public String getAddress_Line_1 () {
      return this.Address_Line_1;
    }
    public String Address_Line_2;

    public String getAddress_Line_2 () {
      return this.Address_Line_2;
    }
    public String Phone_Number;

    public String getPhone_Number () {
      return this.Phone_Number;
    }
    public String Social_Security_Number;

    public String getSocial_Security_Number () {
      return this.Social_Security_Number;
    }
    public String UPI_ID;

    public String getUPI_ID () {
      return this.UPI_ID;
    }
    public String MBI;

    public String getMBI () {
      return this.MBI;
    }
    public String Client_ID;

    public String getClient_ID () {
      return this.Client_ID;
    }
    public String Carrier_ID;

    public String getCarrier_ID () {
      return this.Carrier_ID;
    }
    public String Account_ID;

    public String getAccount_ID () {
      return this.Account_ID;
    }
    public String Group_ID;

    public String getGroup_ID () {
      return this.Group_ID;
    }
    public String Contract_Family_ID;

    public String getContract_Family_ID () {
      return this.Contract_Family_ID;
    }
    public String Multi_Birth_Code;

    public String getMulti_Birth_Code () {
      return this.Multi_Birth_Code;
    }
    public String Member_Key;

    public String getMember_Key () {
      return this.Member_Key;
    }
    public String Source;

    public String getSource () {
      return this.Source;
    }
    public String year;

    public String getYear () {
      return this.year;
    }
  public void copyDateToOut(row13Struct other){
      other.Gender = this.Gender;
      other.Date = this.Date;
      other.First_Name = this.First_Name;
      other.Last_Name = this.Last_Name;
      other.State = this.State;
      other.City = this.City;
      other.Zip_Code = this.Zip_Code;
      other.Address_Line_1 = this.Address_Line_1;
      other.Address_Line_2 = this.Address_Line_2;
      other.Phone_Number = this.Phone_Number;
      other.Social_Security_Number = this.Social_Security_Number;
      other.UPI_ID = this.UPI_ID;
      other.MBI = this.MBI;
      other.Client_ID = this.Client_ID;
      other.Carrier_ID = this.Carrier_ID;
      other.Account_ID = this.Account_ID;
      other.Group_ID = this.Group_ID;
      other.Contract_Family_ID = this.Contract_Family_ID;
      other.Multi_Birth_Code = this.Multi_Birth_Code;
      other.Member_Key = this.Member_Key;
      other.Source = this.Source;
      other.year = this.year;
  }
    
        private String readString(ObjectInputStream dis) throws IOException{
          String strReturn = null;
          int length = 0;
          length = dis.readInt();
          
          if (length == -1) {
            strReturn = null;
          } else {
            if (length > commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length) {
              if (length < 1024 && commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length == 0) {
                commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[1024];
              } else {
                commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[2 * length];
              }
            }
            dis.readFully(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length);
            strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length, utf8Charset);
          }
          return strReturn;
        }
  
        private void writeString(String str, ObjectOutputStream dos) throws IOException{
          if (str == null) {
            dos.writeInt(-1);
          } else {
            byte[] byteArray = str.getBytes(utf8Charset);
            dos.writeInt(byteArray.length);
            dos.write(byteArray);
          }
        }
          
     
  public void readData(ObjectInputStream dis) {
    synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam) {
      try {
        int length = 0;
              this.Gender = readString(dis);
              this.Date = readString(dis);
              this.First_Name = readString(dis);
              this.Last_Name = readString(dis);
              this.State = readString(dis);
              this.City = readString(dis);
              this.Zip_Code = readString(dis);
              this.Address_Line_1 = readString(dis);
              this.Address_Line_2 = readString(dis);
              this.Phone_Number = readString(dis);
              this.Social_Security_Number = readString(dis);
              this.UPI_ID = readString(dis);
              this.MBI = readString(dis);
              this.Client_ID = readString(dis);
              this.Carrier_ID = readString(dis);
              this.Account_ID = readString(dis);
              this.Group_ID = readString(dis);
              this.Contract_Family_ID = readString(dis);
              this.Multi_Birth_Code = readString(dis);
              this.Member_Key = readString(dis);
              this.Source = readString(dis);
              this.year = readString(dis);
          } catch (IOException e) {
            throw new RuntimeException(e);
      }
    }
  }

  public void writeData(ObjectOutputStream dos) {
    try {
           // String
            writeString(this.Gender,dos);
           // String
            writeString(this.Date,dos);
           // String
            writeString(this.First_Name,dos);
           // String
            writeString(this.Last_Name,dos);
           // String
            writeString(this.State,dos);
           // String
            writeString(this.City,dos);
           // String
            writeString(this.Zip_Code,dos);
           // String
            writeString(this.Address_Line_1,dos);
           // String
            writeString(this.Address_Line_2,dos);
           // String
            writeString(this.Phone_Number,dos);
           // String
            writeString(this.Social_Security_Number,dos);
           // String
            writeString(this.UPI_ID,dos);
           // String
            writeString(this.MBI,dos);
           // String
            writeString(this.Client_ID,dos);
           // String
            writeString(this.Carrier_ID,dos);
           // String
            writeString(this.Account_ID,dos);
           // String
            writeString(this.Group_ID,dos);
           // String
            writeString(this.Contract_Family_ID,dos);
           // String
            writeString(this.Multi_Birth_Code,dos);
           // String
            writeString(this.Member_Key,dos);
           // String
            writeString(this.Source,dos);
           // String
            writeString(this.year,dos);
        } catch (IOException e) {
          throw new RuntimeException(e);
    }
  }


  public String toString() {
    
    StringBuilder sb = new StringBuilder();
    sb.append(super.toString());
    sb.append("[");
        sb.append(","+ "Gender="+Gender);
        sb.append(","+ "Date="+Date);
        sb.append(","+ "First_Name="+First_Name);
        sb.append(","+ "Last_Name="+Last_Name);
        sb.append(","+ "State="+State);
        sb.append(","+ "City="+City);
        sb.append(","+ "Zip_Code="+Zip_Code);
        sb.append(","+ "Address_Line_1="+Address_Line_1);
        sb.append(","+ "Address_Line_2="+Address_Line_2);
        sb.append(","+ "Phone_Number="+Phone_Number);
        sb.append(","+ "Social_Security_Number="+Social_Security_Number);
        sb.append(","+ "UPI_ID="+UPI_ID);
        sb.append(","+ "MBI="+MBI);
        sb.append(","+ "Client_ID="+Client_ID);
        sb.append(","+ "Carrier_ID="+Carrier_ID);
        sb.append(","+ "Account_ID="+Account_ID);
        sb.append(","+ "Group_ID="+Group_ID);
        sb.append(","+ "Contract_Family_ID="+Contract_Family_ID);
        sb.append(","+ "Multi_Birth_Code="+Multi_Birth_Code);
        sb.append(","+ "Member_Key="+Member_Key);
        sb.append(","+ "Source="+Source);
        sb.append(","+ "year="+year);
    sb.append("]");
    return sb.toString();
  }
    
  /** 
   * Compare keys
   */
  public int compareTo(tMatchGroup_2Struct other) {
    int returnValue = -1;
  return returnValue;
  }
    
  private int checkNullsAndCompare(Object object1, Object object2) {
    int returnValue = 0;
    if (object1 instanceof Comparable && object2 instanceof Comparable) {
      returnValue = ((Comparable) object1).compareTo(object2);
    } else if (object1 != null && object2 != null) {
      returnValue = compareStrings(object1.toString(), object2.toString());
    } else if (object1 == null && object2 != null) {
      returnValue = 1;
    } else if (object1 != null && object2 == null) {
      returnValue = -1;
    } else {
      returnValue = 0;
    }
    return returnValue;
  }

  private int compareStrings(String string1, String string2) {
    return string1.compareTo(string2);
  }
}
 

class tMatchGroup_2_2Struct implements routines.system.IPersistableComparableLookupRow<tMatchGroup_2_2Struct>,org.talend.dataquality.indicators.mapdb.helper.IObjectConvertArray {
  final byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];
  byte[] commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];
    private  final int DEFAULT_HASHCODE = 1;
    private  final int PRIME = 31;
    private int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;
  public void copyDateToOut(tMatchGroup_2_2Struct other){
  }
    
    @Override
    public int hashCode() {
      if (this.hashCodeDirty) {
        final int prime = PRIME;
        int result = DEFAULT_HASHCODE;
        
        this.hashCode = result;
        this.hashCodeDirty = false;
      }
      return this.hashCode;
    }
    
    @Override
    public boolean equals(Object obj) {
      if (this == obj)
        return true;
      if (obj == null)
        return false;
      if (getClass() != obj.getClass())
        return false;
      final tMatchGroup_2_2Struct other = (tMatchGroup_2_2Struct) obj;
      
      return true;
    }
    public void copyDataTo(tMatchGroup_2_2Struct other) {
      }
      
      public void copyKeysDataTo(tMatchGroup_2_2Struct other) {
      }
    
      public void readKeysData(ObjectInputStream dis) {
          synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam) {
            try {
              int length = 0;
                }
              finally {}
          }
        }
      public void writeKeysData(ObjectOutputStream dos) {
          try {
          }
            finally {}
        }
      /** 
       * Fill Values data by reading ObjectInputStream.
       */
      public void readValuesData(DataInputStream dis, ObjectInputStream ois) {
   
      }

      /** 
       * Return a byte array which represents Values data.
       */
      public void writeValuesData(DataOutputStream dos, ObjectOutputStream oos) {

      }

    public String toString() {
      
      StringBuilder sb = new StringBuilder();
      sb.append(super.toString());
      sb.append("[");
      sb.append("]");
      return sb.toString();
    }
      
    /** 
     * Compare keys
     */
    public int compareTo(tMatchGroup_2_2Struct other) {
      int returnValue = -1;
    return returnValue;
    }
      
    private int checkNullsAndCompare(Object object1, Object object2) {
      int returnValue = 0;
      if (object1 instanceof Comparable && object2 instanceof Comparable) {
        returnValue = ((Comparable) object1).compareTo(object2);
      } else if (object1 != null && object2 != null) {
        returnValue = compareStrings(object1.toString(), object2.toString());
      } else if (object1 == null && object2 != null) {
        returnValue = 1;
      } else if (object1 != null && object2 == null) {
        returnValue = -1;
      } else {
        returnValue = 0;
      }
      return returnValue;
    }

    private int compareStrings(String string1, String string2) {
      return string1.compareTo(string2);
    }
    
    @Override
    public Object[] getArrays() {
        Object[] array=new Object[0];
        return array;
    }
    @Override
    public void restoreObjectByArrays(Object[] elements) {
    }
}//end of _2struct



org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE 
  matchingModeEnum_tMatchGroup_2 = org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.ALL_ROWS;
  org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<tMatchGroup_2Struct> 
    tHash_Lookup_row8 = org.talend.designer.components.lookup.memory.AdvancedMemoryLookup.<tMatchGroup_2Struct>getLookup(matchingModeEnum_tMatchGroup_2);
globalMap.put("tHash_Lookup_row8", tHash_Lookup_row8);

/*store all block rows*/  
  java.util.Map<tMatchGroup_2_2Struct, String> blockRows_row8 = new java.util.HashMap<tMatchGroup_2_2Struct, String>();
 



/**
 * [tMatchGroup_2_GroupOut begin ] stop
 */



	
	/**
	 * [tConvertType_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tConvertType_1", false);
		start_Hash.put("tConvertType_1", System.currentTimeMillis());
		
	
	currentComponent="tConvertType_1";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"copyOfdob");
			
		int tos_count_tConvertType_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tConvertType_1", "tConvertType");
				talendJobLogProcess(globalMap);
			}
			
	int nb_line_tConvertType_1 = 0;  
 



/**
 * [tConvertType_1 begin ] stop
 */



	
	/**
	 * [tMap_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_5", false);
		start_Hash.put("tMap_5", System.currentTimeMillis());
		
	
	currentComponent="tMap_5";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row18");
			
		int tos_count_tMap_5 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tMap_5", "tMap");
				talendJobLogProcess(globalMap);
			}
			




// ###############################
// # Lookup's keys initialization
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_5__Struct  {
}
Var__tMap_5__Struct Var__tMap_5 = new Var__tMap_5__Struct();
// ###############################

// ###############################
// # Outputs initialization
copyOfdobStruct copyOfdob_tmp = new copyOfdobStruct();
// ###############################

        
        



        









 



/**
 * [tMap_5 begin ] stop
 */



	
	/**
	 * [tBufferOutput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tBufferOutput_1", false);
		start_Hash.put("tBufferOutput_1", System.currentTimeMillis());
		
	
	currentComponent="tBufferOutput_1";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"output");
			
		int tos_count_tBufferOutput_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tBufferOutput_1", "tBufferOutput");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tBufferOutput_1 begin ] stop
 */



	
	/**
	 * [tMap_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_1", false);
		start_Hash.put("tMap_1", System.currentTimeMillis());
		
	
	currentComponent="tMap_1";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row1");
			
		int tos_count_tMap_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tMap_1", "tMap");
				talendJobLogProcess(globalMap);
			}
			




// ###############################
// # Lookup's keys initialization
	
		org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row7Struct> tHash_Lookup_row7 = (org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row7Struct>) 
				((org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row7Struct>) 
					globalMap.get( "tHash_Lookup_row7" ))
					;					
					
	

row7Struct row7HashKey = new row7Struct();
row7Struct row7Default = new row7Struct();
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_1__Struct  {
}
Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
// ###############################

// ###############################
// # Outputs initialization
outputStruct output_tmp = new outputStruct();
// ###############################

        
        



        









 



/**
 * [tMap_1 begin ] stop
 */



	
	/**
	 * [tDBInput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_2", false);
		start_Hash.put("tDBInput_2", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_2";

	
		int tos_count_tDBInput_2 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_2", "tOracleInput");
				talendJobLogProcess(globalMap);
			}
			
	


	
		    int nb_line_tDBInput_2 = 0;
		    java.sql.Connection conn_tDBInput_2 = null;
				conn_tDBInput_2 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
                boolean isTimeZoneNull_tDBInput_2 = false;
				boolean isConnectionWrapped_tDBInput_2 = !(conn_tDBInput_2 instanceof oracle.jdbc.OracleConnection) && conn_tDBInput_2.isWrapperFor(oracle.jdbc.OracleConnection.class);
				oracle.jdbc.OracleConnection unwrappedOraConn_tDBInput_2 = null;
                if (isConnectionWrapped_tDBInput_2) {
					unwrappedOraConn_tDBInput_2 = conn_tDBInput_2.unwrap(oracle.jdbc.OracleConnection.class);
                    if (unwrappedOraConn_tDBInput_2 != null) {
                        isTimeZoneNull_tDBInput_2 = (unwrappedOraConn_tDBInput_2.getSessionTimeZone() == null);
                    }
                } else {
                    isTimeZoneNull_tDBInput_2 = (((oracle.jdbc.OracleConnection)conn_tDBInput_2).getSessionTimeZone() == null);
                }

				if(isTimeZoneNull_tDBInput_2) {
					java.sql.Statement stmtGetTZ_tDBInput_2 = conn_tDBInput_2.createStatement();
					java.sql.ResultSet rsGetTZ_tDBInput_2 = stmtGetTZ_tDBInput_2.executeQuery("select sessiontimezone from dual");
					String sessionTimezone_tDBInput_2 = java.util.TimeZone.getDefault().getID();
					while (rsGetTZ_tDBInput_2.next()) {
						sessionTimezone_tDBInput_2 = rsGetTZ_tDBInput_2.getString(1);
					}
					if (isConnectionWrapped_tDBInput_2 && unwrappedOraConn_tDBInput_2 != null) {
                        unwrappedOraConn_tDBInput_2.setSessionTimeZone(sessionTimezone_tDBInput_2);
                    } else {
                        ((oracle.jdbc.OracleConnection)conn_tDBInput_2).setSessionTimeZone(sessionTimezone_tDBInput_2);
                    }
				}
			
		    
			java.sql.Statement stmt_tDBInput_2 = conn_tDBInput_2.createStatement();

		    String dbquery_tDBInput_2 = "SELECT * from IRXMDM_DEV.TokenizationNotRequired_prior";
			

            	globalMap.put("tDBInput_2_QUERY",dbquery_tDBInput_2);
		    java.sql.ResultSet rs_tDBInput_2 = null;

		    try {
		    	rs_tDBInput_2 = stmt_tDBInput_2.executeQuery(dbquery_tDBInput_2);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_2 = rs_tDBInput_2.getMetaData();
		    	int colQtyInRs_tDBInput_2 = rsmd_tDBInput_2.getColumnCount();

		    String tmpContent_tDBInput_2 = null;
		    
		    
		    while (rs_tDBInput_2.next()) {
		        nb_line_tDBInput_2++;
		        
							if(colQtyInRs_tDBInput_2 < 1) {
								row1.Gender = null;
							} else {
									
					tmpContent_tDBInput_2 = rs_tDBInput_2.getString(1);
                    if(tmpContent_tDBInput_2 != null && tmpContent_tDBInput_2.length() > 0) {			  	
                        row1.Gender = tmpContent_tDBInput_2.charAt(0);			  		
                    } else {			  				  	    
                            if(tmpContent_tDBInput_2 == null) {			  	   	
                                row1.Gender = null;			  			
                            } else {			  		
                                row1.Gender = '\0';			  			
                            }
                    }
		                    }
							if(colQtyInRs_tDBInput_2 < 2) {
								row1.State = null;
							} else {
	                         		
        	row1.State = routines.system.JDBCUtil.getString(rs_tDBInput_2, 2, false);
		                    }
							if(colQtyInRs_tDBInput_2 < 3) {
								row1.City = null;
							} else {
	                         		
        	row1.City = routines.system.JDBCUtil.getString(rs_tDBInput_2, 3, false);
		                    }
							if(colQtyInRs_tDBInput_2 < 4) {
								row1.Zip_Code = null;
							} else {
	                         		
        	row1.Zip_Code = routines.system.JDBCUtil.getString(rs_tDBInput_2, 4, false);
		                    }
							if(colQtyInRs_tDBInput_2 < 5) {
								row1.Address_Line_1 = null;
							} else {
	                         		
        	row1.Address_Line_1 = routines.system.JDBCUtil.getString(rs_tDBInput_2, 5, false);
		                    }
							if(colQtyInRs_tDBInput_2 < 6) {
								row1.Address_Line_2 = null;
							} else {
	                         		
        	row1.Address_Line_2 = routines.system.JDBCUtil.getString(rs_tDBInput_2, 6, false);
		                    }
							if(colQtyInRs_tDBInput_2 < 7) {
								row1.Phone_Number = null;
							} else {
	                         		
        	row1.Phone_Number = routines.system.JDBCUtil.getString(rs_tDBInput_2, 7, false);
		                    }
							if(colQtyInRs_tDBInput_2 < 8) {
								row1.Client_ID = null;
							} else {
	                         		
        	row1.Client_ID = routines.system.JDBCUtil.getString(rs_tDBInput_2, 8, false);
		                    }
							if(colQtyInRs_tDBInput_2 < 9) {
								row1.Carrier_ID = null;
							} else {
	                         		
        	row1.Carrier_ID = routines.system.JDBCUtil.getString(rs_tDBInput_2, 9, false);
		                    }
							if(colQtyInRs_tDBInput_2 < 10) {
								row1.Account_ID = null;
							} else {
	                         		
        	row1.Account_ID = routines.system.JDBCUtil.getString(rs_tDBInput_2, 10, false);
		                    }
							if(colQtyInRs_tDBInput_2 < 11) {
								row1.Group_ID = null;
							} else {
	                         		
        	row1.Group_ID = routines.system.JDBCUtil.getString(rs_tDBInput_2, 11, false);
		                    }
							if(colQtyInRs_tDBInput_2 < 12) {
								row1.Multi_Birth_Code = null;
							} else {
	                         		
        	row1.Multi_Birth_Code = routines.system.JDBCUtil.getString(rs_tDBInput_2, 12, false);
		                    }
							if(colQtyInRs_tDBInput_2 < 13) {
								row1.Member_Key = null;
							} else {
	                         		
        	row1.Member_Key = routines.system.JDBCUtil.getString(rs_tDBInput_2, 13, false);
		                    }
							if(colQtyInRs_tDBInput_2 < 14) {
								row1.Source = null;
							} else {
	                         		
        	row1.Source = routines.system.JDBCUtil.getString(rs_tDBInput_2, 14, false);
		                    }
							if(colQtyInRs_tDBInput_2 < 15) {
								row1.scd_key = 0;
							} else {
		                          
					if(rs_tDBInput_2.getObject(15) != null) {
						row1.scd_key = rs_tDBInput_2.getInt(15);
					} else {
				
 	                	throw new RuntimeException("Null value in non-Nullable column");
					}
		                    }
					




 



/**
 * [tDBInput_2 begin ] stop
 */
	
	/**
	 * [tDBInput_2 main ] start
	 */

	

	
	
	currentComponent="tDBInput_2";

	

 


	tos_count_tDBInput_2++;

/**
 * [tDBInput_2 main ] stop
 */
	
	/**
	 * [tDBInput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_2";

	

 



/**
 * [tDBInput_2 process_data_begin ] stop
 */

	
	/**
	 * [tMap_1 main ] start
	 */

	

	
	
	currentComponent="tMap_1";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"row1");
			

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;
		
        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_1 = false;
		  boolean mainRowRejected_tMap_1 = false;
            				    								  
		

				///////////////////////////////////////////////
				// Starting Lookup Table "row7" 
				///////////////////////////////////////////////


				
				
                            
 					    boolean forceLooprow7 = false;
       		  	    	
       		  	    	
 							row7Struct row7ObjectFromLookup = null;
                          
		           		  	if(!rejectedInnerJoin_tMap_1) { // G_TM_M_020

								
								hasCasePrimitiveKeyWithNull_tMap_1 = false;
								
	                        		    	Object exprKeyValue_row7__scd_key = row1.scd_key ;
	                        		    	if(exprKeyValue_row7__scd_key == null) {
	                        		    		hasCasePrimitiveKeyWithNull_tMap_1 = true;
	                        		    	} else {
                        		    			row7HashKey.scd_key = (int)(Integer) exprKeyValue_row7__scd_key;
                        		    		}
                        		    		

								
		                        	row7HashKey.hashCodeDirty = true;
                        		
	  					
	  							
	
		  							if(!hasCasePrimitiveKeyWithNull_tMap_1) { // G_TM_M_091
		  							
			  					
			  					
			  					
	  					
		  							tHash_Lookup_row7.lookup( row7HashKey );

	  							

	  							

			  						} // G_TM_M_091
			  						
			  					

 								
								  
								  if(hasCasePrimitiveKeyWithNull_tMap_1 || !tHash_Lookup_row7.hasNext()) { // G_TM_M_090

  								
		  				
	  								
			  							rejectedInnerJoin_tMap_1 = true;
	  								
						
									
  									  		
 								
								  
								  } // G_TM_M_090

  								



							} // G_TM_M_020
			           		  	  
							
				           		if(tHash_Lookup_row7 != null && tHash_Lookup_row7.getCount(row7HashKey) > 1) { // G 071
			  							
			  						
									 		
									//System.out.println("WARNING: UNIQUE MATCH is configured for the lookup 'row7' and it contains more one result from keys :  row7.scd_key = '" + row7HashKey.scd_key + "'");
								} // G 071
							

							row7Struct row7 = null;
                    		  	 
							   
                    		  	 
	       		  	    	row7Struct fromLookup_row7 = null;
							row7 = row7Default;
										 
							
								 
							
							
								if (tHash_Lookup_row7 !=null && tHash_Lookup_row7.hasNext()) { // G 099
								
							
								
								fromLookup_row7 = tHash_Lookup_row7.next();

							
							
								} // G 099
							
							

							if(fromLookup_row7 != null) {
								row7 = fromLookup_row7;
							}
							
							
							
			  							
								
	                    		  	
		                    
	            	
	            	
	            // ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_1__Struct Var = Var__tMap_1;// ###############################
        // ###############################
        // # Output tables

output = null;

if(!rejectedInnerJoin_tMap_1 ) {

// # Output table : 'output'
output_tmp.Gender = row1.Gender;
output_tmp.Date_of_Birth = row7.DOB ;
output_tmp.First_Name = row7.firstName ;
output_tmp.Last_Name = row7.lastName ;
output_tmp.State = row1.State;
output_tmp.City = row1.City;
output_tmp.Zip_Code = row1.Zip_Code;
output_tmp.Address_Line_1 = row1.Address_Line_1;
output_tmp.Address_Line_2 = row1.Address_Line_2;
output_tmp.Phone_Number = row1.Phone_Number;
output_tmp.Social_Security_Number = row7.SSN ;
output_tmp.UPI_ID = "";
output_tmp.MBI = row7.MBI;
output_tmp.Client_ID = row1.Client_ID;
output_tmp.Carrier_ID = row1.Carrier_ID;
output_tmp.Account_ID = row1.Account_ID;
output_tmp.Group_ID = row1.Group_ID;
output_tmp.Contract_Family_ID = row7.OtherID ;
output_tmp.Multi_Birth_Code = row1.Multi_Birth_Code;
output_tmp.Member_Key = row1.Member_Key;
output_tmp.Source = row1.Source;
output = output_tmp;
}  // closing inner join bracket (2)
// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_1 = false;










 


	tos_count_tMap_1++;

/**
 * [tMap_1 main ] stop
 */
	
	/**
	 * [tMap_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

 



/**
 * [tMap_1 process_data_begin ] stop
 */
// Start of branch "output"
if(output != null) { 



	
	/**
	 * [tBufferOutput_1 main ] start
	 */

	

	
	
	currentComponent="tBufferOutput_1";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"output");
			



String[] row_tBufferOutput_1=new String[]{"","","","","","","","","","","","","","","","","","","","","",};		
	    if(output.Gender != null){
	        
	            row_tBufferOutput_1[0] = String.valueOf(output.Gender);
	                        			    
	    }else{
	    	row_tBufferOutput_1[0] = null;
	    }
	    if(output.Date_of_Birth != null){
	        
	            row_tBufferOutput_1[1] = output.Date_of_Birth;
	                        			    
	    }else{
	    	row_tBufferOutput_1[1] = null;
	    }
	    if(output.First_Name != null){
	        
	            row_tBufferOutput_1[2] = output.First_Name;
	                        			    
	    }else{
	    	row_tBufferOutput_1[2] = null;
	    }
	    if(output.Last_Name != null){
	        
	            row_tBufferOutput_1[3] = output.Last_Name;
	                        			    
	    }else{
	    	row_tBufferOutput_1[3] = null;
	    }
	    if(output.State != null){
	        
	            row_tBufferOutput_1[4] = output.State;
	                        			    
	    }else{
	    	row_tBufferOutput_1[4] = null;
	    }
	    if(output.City != null){
	        
	            row_tBufferOutput_1[5] = output.City;
	                        			    
	    }else{
	    	row_tBufferOutput_1[5] = null;
	    }
	    if(output.Zip_Code != null){
	        
	            row_tBufferOutput_1[6] = output.Zip_Code;
	                        			    
	    }else{
	    	row_tBufferOutput_1[6] = null;
	    }
	    if(output.Address_Line_1 != null){
	        
	            row_tBufferOutput_1[7] = output.Address_Line_1;
	                        			    
	    }else{
	    	row_tBufferOutput_1[7] = null;
	    }
	    if(output.Address_Line_2 != null){
	        
	            row_tBufferOutput_1[8] = output.Address_Line_2;
	                        			    
	    }else{
	    	row_tBufferOutput_1[8] = null;
	    }
	    if(output.Phone_Number != null){
	        
	            row_tBufferOutput_1[9] = output.Phone_Number;
	                        			    
	    }else{
	    	row_tBufferOutput_1[9] = null;
	    }
	    if(output.Social_Security_Number != null){
	        
	            row_tBufferOutput_1[10] = output.Social_Security_Number;
	                        			    
	    }else{
	    	row_tBufferOutput_1[10] = null;
	    }
	    if(output.UPI_ID != null){
	        
	            row_tBufferOutput_1[11] = output.UPI_ID;
	                        			    
	    }else{
	    	row_tBufferOutput_1[11] = null;
	    }
	    if(output.MBI != null){
	        
	            row_tBufferOutput_1[12] = output.MBI;
	                        			    
	    }else{
	    	row_tBufferOutput_1[12] = null;
	    }
	    if(output.Client_ID != null){
	        
	            row_tBufferOutput_1[13] = output.Client_ID;
	                        			    
	    }else{
	    	row_tBufferOutput_1[13] = null;
	    }
	    if(output.Carrier_ID != null){
	        
	            row_tBufferOutput_1[14] = output.Carrier_ID;
	                        			    
	    }else{
	    	row_tBufferOutput_1[14] = null;
	    }
	    if(output.Account_ID != null){
	        
	            row_tBufferOutput_1[15] = output.Account_ID;
	                        			    
	    }else{
	    	row_tBufferOutput_1[15] = null;
	    }
	    if(output.Group_ID != null){
	        
	            row_tBufferOutput_1[16] = output.Group_ID;
	                        			    
	    }else{
	    	row_tBufferOutput_1[16] = null;
	    }
	    if(output.Contract_Family_ID != null){
	        
	            row_tBufferOutput_1[17] = output.Contract_Family_ID;
	                        			    
	    }else{
	    	row_tBufferOutput_1[17] = null;
	    }
	    if(output.Multi_Birth_Code != null){
	        
	            row_tBufferOutput_1[18] = output.Multi_Birth_Code;
	                        			    
	    }else{
	    	row_tBufferOutput_1[18] = null;
	    }
	    if(output.Member_Key != null){
	        
	            row_tBufferOutput_1[19] = output.Member_Key;
	                        			    
	    }else{
	    	row_tBufferOutput_1[19] = null;
	    }
	    if(output.Source != null){
	        
	            row_tBufferOutput_1[20] = output.Source;
	                        			    
	    }else{
	    	row_tBufferOutput_1[20] = null;
	    }
	globalBuffer.add(row_tBufferOutput_1);	
	
 
     row18 = output;


	tos_count_tBufferOutput_1++;

/**
 * [tBufferOutput_1 main ] stop
 */
	
	/**
	 * [tBufferOutput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tBufferOutput_1";

	

 



/**
 * [tBufferOutput_1 process_data_begin ] stop
 */

	
	/**
	 * [tMap_5 main ] start
	 */

	

	
	
	currentComponent="tMap_5";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"row18");
			

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_5 = false;
		
        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_5 = false;
		  boolean mainRowRejected_tMap_5 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_5__Struct Var = Var__tMap_5;// ###############################
        // ###############################
        // # Output tables

copyOfdob = null;


// # Output table : 'copyOfdob'
copyOfdob_tmp.Gender = String.valueOf(row18.Gender);
copyOfdob_tmp.Date = TalendDate.parseDate("yyyy-dd-MM",TalendDate.formatDate("yyyy-dd-MM",TalendDate.parseDate("yyyyddMM",row18.Date_of_Birth))) ;
copyOfdob_tmp.First_Name = row18.First_Name;
copyOfdob_tmp.Last_Name = row18.Last_Name;
copyOfdob_tmp.State = row18.State;
copyOfdob_tmp.City = row18.City;
copyOfdob_tmp.Zip_Code = row18.Zip_Code;
copyOfdob_tmp.Address_Line_1 = row18.Address_Line_1;
copyOfdob_tmp.Address_Line_2 = row18.Address_Line_2;
copyOfdob_tmp.Phone_Number = row18.Phone_Number;
copyOfdob_tmp.Social_Security_Number = row18.Social_Security_Number;
copyOfdob_tmp.UPI_ID = row18.UPI_ID;
copyOfdob_tmp.MBI = row18.MBI ;
copyOfdob_tmp.Client_ID = row18.Client_ID;
copyOfdob_tmp.Carrier_ID = row18.Carrier_ID;
copyOfdob_tmp.Account_ID = row18.Account_ID;
copyOfdob_tmp.Group_ID = row18.Group_ID;
copyOfdob_tmp.Contract_Family_ID = row18.Contract_Family_ID;
copyOfdob_tmp.Multi_Birth_Code = row18.Multi_Birth_Code;
copyOfdob_tmp.Member_Key = row18.Member_Key;
copyOfdob_tmp.Source = row18.Source;
copyOfdob_tmp.year = TalendDate.parseDate("yyyy",TalendDate.formatDate("yyyy",TalendDate.parseDate("yyyyddMM",row18.Date_of_Birth))) ;
copyOfdob = copyOfdob_tmp;
// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_5 = false;










 


	tos_count_tMap_5++;

/**
 * [tMap_5 main ] stop
 */
	
	/**
	 * [tMap_5 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_5";

	

 



/**
 * [tMap_5 process_data_begin ] stop
 */
// Start of branch "copyOfdob"
if(copyOfdob != null) { 



	
	/**
	 * [tConvertType_1 main ] start
	 */

	

	
	
	currentComponent="tConvertType_1";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"copyOfdob");
			


  row8 = new row8Struct();
  boolean bHasError_tConvertType_1 = false;             
          try {
              row8.Gender=TypeConvert.String2String(copyOfdob.Gender);            
          } catch(java.lang.Exception e){
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row8.Date=TypeConvert.Date2String(copyOfdob.Date, "dd-MM-yyyy");
        	            
          } catch(java.lang.Exception e){
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row8.First_Name=TypeConvert.String2String(copyOfdob.First_Name);            
          } catch(java.lang.Exception e){
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row8.Last_Name=TypeConvert.String2String(copyOfdob.Last_Name);            
          } catch(java.lang.Exception e){
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row8.State=TypeConvert.String2String(copyOfdob.State);            
          } catch(java.lang.Exception e){
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row8.City=TypeConvert.String2String(copyOfdob.City);            
          } catch(java.lang.Exception e){
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row8.Zip_Code=TypeConvert.String2String(copyOfdob.Zip_Code);            
          } catch(java.lang.Exception e){
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row8.Address_Line_1=TypeConvert.String2String(copyOfdob.Address_Line_1);            
          } catch(java.lang.Exception e){
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row8.Address_Line_2=TypeConvert.String2String(copyOfdob.Address_Line_2);            
          } catch(java.lang.Exception e){
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row8.Phone_Number=TypeConvert.String2String(copyOfdob.Phone_Number);            
          } catch(java.lang.Exception e){
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row8.Social_Security_Number=TypeConvert.String2String(copyOfdob.Social_Security_Number);            
          } catch(java.lang.Exception e){
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row8.UPI_ID=TypeConvert.String2String(copyOfdob.UPI_ID);            
          } catch(java.lang.Exception e){
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row8.MBI=TypeConvert.String2String(copyOfdob.MBI);            
          } catch(java.lang.Exception e){
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row8.Client_ID=TypeConvert.String2String(copyOfdob.Client_ID);            
          } catch(java.lang.Exception e){
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row8.Carrier_ID=TypeConvert.String2String(copyOfdob.Carrier_ID);            
          } catch(java.lang.Exception e){
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row8.Account_ID=TypeConvert.String2String(copyOfdob.Account_ID);            
          } catch(java.lang.Exception e){
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row8.Group_ID=TypeConvert.String2String(copyOfdob.Group_ID);            
          } catch(java.lang.Exception e){
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row8.Contract_Family_ID=TypeConvert.String2String(copyOfdob.Contract_Family_ID);            
          } catch(java.lang.Exception e){
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row8.Multi_Birth_Code=TypeConvert.String2String(copyOfdob.Multi_Birth_Code);            
          } catch(java.lang.Exception e){
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row8.Member_Key=TypeConvert.String2String(copyOfdob.Member_Key);            
          } catch(java.lang.Exception e){
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row8.Source=TypeConvert.String2String(copyOfdob.Source);            
          } catch(java.lang.Exception e){
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }           
          try {
              row8.year=TypeConvert.Date2String(copyOfdob.year, "dd-MM-yyyy");
        	            
          } catch(java.lang.Exception e){
            bHasError_tConvertType_1 = true;            
              System.err.println(e.getMessage());          
          }
      if (bHasError_tConvertType_1) {row8 = null;}

  nb_line_tConvertType_1 ++ ;
 


	tos_count_tConvertType_1++;

/**
 * [tConvertType_1 main ] stop
 */
	
	/**
	 * [tConvertType_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tConvertType_1";

	

 



/**
 * [tConvertType_1 process_data_begin ] stop
 */
// Start of branch "row8"
if(row8 != null) { 



	
	/**
	 * [tMatchGroup_2_GroupOut main ] start
	 */

	

	
	
		currentVirtualComponent = "tMatchGroup_2";
	
	currentComponent="tMatchGroup_2_GroupOut";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"row8");
			
  tMatchGroup_2Struct row8_HashRow = new tMatchGroup_2Struct();
        
      row8_HashRow.Gender =  row8.Gender;
        
      row8_HashRow.Date =  row8.Date;
        
      row8_HashRow.First_Name =  row8.First_Name;
        
      row8_HashRow.Last_Name =  row8.Last_Name;
        
      row8_HashRow.State =  row8.State;
        
      row8_HashRow.City =  row8.City;
        
      row8_HashRow.Zip_Code =  row8.Zip_Code;
        
      row8_HashRow.Address_Line_1 =  row8.Address_Line_1;
        
      row8_HashRow.Address_Line_2 =  row8.Address_Line_2;
        
      row8_HashRow.Phone_Number =  row8.Phone_Number;
        
      row8_HashRow.Social_Security_Number =  row8.Social_Security_Number;
        
      row8_HashRow.UPI_ID =  row8.UPI_ID;
        
      row8_HashRow.MBI =  row8.MBI;
        
      row8_HashRow.Client_ID =  row8.Client_ID;
        
      row8_HashRow.Carrier_ID =  row8.Carrier_ID;
        
      row8_HashRow.Account_ID =  row8.Account_ID;
        
      row8_HashRow.Group_ID =  row8.Group_ID;
        
      row8_HashRow.Contract_Family_ID =  row8.Contract_Family_ID;
        
      row8_HashRow.Multi_Birth_Code =  row8.Multi_Birth_Code;
        
      row8_HashRow.Member_Key =  row8.Member_Key;
        
      row8_HashRow.Source =  row8.Source;
        
      row8_HashRow.year =  row8.year;
tHash_Lookup_row8.put(row8_HashRow);
 


	tos_count_tMatchGroup_2_GroupOut++;

/**
 * [tMatchGroup_2_GroupOut main ] stop
 */
	
	/**
	 * [tMatchGroup_2_GroupOut process_data_begin ] start
	 */

	

	
	
		currentVirtualComponent = "tMatchGroup_2";
	
	currentComponent="tMatchGroup_2_GroupOut";

	

 



/**
 * [tMatchGroup_2_GroupOut process_data_begin ] stop
 */
	
	/**
	 * [tMatchGroup_2_GroupOut process_data_end ] start
	 */

	

	
	
		currentVirtualComponent = "tMatchGroup_2";
	
	currentComponent="tMatchGroup_2_GroupOut";

	

 



/**
 * [tMatchGroup_2_GroupOut process_data_end ] stop
 */

} // End of branch "row8"




	
	/**
	 * [tConvertType_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tConvertType_1";

	

 



/**
 * [tConvertType_1 process_data_end ] stop
 */

} // End of branch "copyOfdob"




	
	/**
	 * [tMap_5 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_5";

	

 



/**
 * [tMap_5 process_data_end ] stop
 */



	
	/**
	 * [tBufferOutput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tBufferOutput_1";

	

 



/**
 * [tBufferOutput_1 process_data_end ] stop
 */

} // End of branch "output"




	
	/**
	 * [tMap_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

 



/**
 * [tMap_1 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_2";

	

 



/**
 * [tDBInput_2 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_2 end ] start
	 */

	

	
	
	currentComponent="tDBInput_2";

	

}
}finally{
	if (rs_tDBInput_2 != null) {
		rs_tDBInput_2.close();
	}
	if (stmt_tDBInput_2 != null) {
		stmt_tDBInput_2.close();
	}
}

globalMap.put("tDBInput_2_NB_LINE",nb_line_tDBInput_2);
 

ok_Hash.put("tDBInput_2", true);
end_Hash.put("tDBInput_2", System.currentTimeMillis());




/**
 * [tDBInput_2 end ] stop
 */

	
	/**
	 * [tMap_1 end ] start
	 */

	

	
	
	currentComponent="tMap_1";

	


// ###############################
// # Lookup hashes releasing
					if(tHash_Lookup_row7 != null) {
						tHash_Lookup_row7.endGet();
					}
					globalMap.remove( "tHash_Lookup_row7" );

					
					
				
// ###############################      





			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row1",2,0,
			 			talendJobLog,"tDBInput_2","tOracleInput","tMap_1","tMap","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tMap_1", true);
end_Hash.put("tMap_1", System.currentTimeMillis());




/**
 * [tMap_1 end ] stop
 */

	
	/**
	 * [tBufferOutput_1 end ] start
	 */

	

	
	
	currentComponent="tBufferOutput_1";

	

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"output",2,0,
			 			talendJobLog,"tMap_1","tMap","tBufferOutput_1","tBufferOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tBufferOutput_1", true);
end_Hash.put("tBufferOutput_1", System.currentTimeMillis());




/**
 * [tBufferOutput_1 end ] stop
 */

	
	/**
	 * [tMap_5 end ] start
	 */

	

	
	
	currentComponent="tMap_5";

	


// ###############################
// # Lookup hashes releasing
// ###############################      





			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row18",2,0,
			 			talendJobLog,"tBufferOutput_1","tBufferOutput","tMap_5","tMap","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tMap_5", true);
end_Hash.put("tMap_5", System.currentTimeMillis());




/**
 * [tMap_5 end ] stop
 */

	
	/**
	 * [tConvertType_1 end ] start
	 */

	

	
	
	currentComponent="tConvertType_1";

	
      globalMap.put("tConvertType_1_NB_LINE", nb_line_tConvertType_1);
			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"copyOfdob",2,0,
			 			talendJobLog,"tMap_5","tMap","tConvertType_1","tConvertType","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tConvertType_1", true);
end_Hash.put("tConvertType_1", System.currentTimeMillis());




/**
 * [tConvertType_1 end ] stop
 */

	
	/**
	 * [tMatchGroup_2_GroupOut end ] start
	 */

	

	
	
		currentVirtualComponent = "tMatchGroup_2";
	
	currentComponent="tMatchGroup_2_GroupOut";

	
tHash_Lookup_row8.endPut();
			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row8",2,0,
			 			talendJobLog,"tConvertType_1","tConvertType","tMatchGroup_2_GroupOut","tMatchGroupOut","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tMatchGroup_2_GroupOut", true);
end_Hash.put("tMatchGroup_2_GroupOut", System.currentTimeMillis());




/**
 * [tMatchGroup_2_GroupOut end ] stop
 */




	
	/**
	 * [tAggregateRow_2_AGGOUT begin ] start
	 */

	

	
		
		ok_Hash.put("tAggregateRow_2_AGGOUT", false);
		start_Hash.put("tAggregateRow_2_AGGOUT", System.currentTimeMillis());
		
	
		currentVirtualComponent = "tAggregateRow_2";
	
	currentComponent="tAggregateRow_2_AGGOUT";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row21");
			
		int tos_count_tAggregateRow_2_AGGOUT = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAggregateRow_2_AGGOUT", "tAggregateOut");
				talendJobLogProcess(globalMap);
			}
			

// ------------ Seems it is not used

java.util.Map hashAggreg_tAggregateRow_2 = new java.util.HashMap(); 

// ------------

	class UtilClass_tAggregateRow_2 { // G_OutBegin_AggR_144

		public double sd(Double[] data) {
	        final int n = data.length;
        	if (n < 2) {
	            return Double.NaN;
        	}
        	double d1 = 0d;
        	double d2 =0d;
	        
	        for (int i = 0; i < data.length; i++) {
            	d1 += (data[i]*data[i]);
            	d2 += data[i];
        	}
        
	        return Math.sqrt((n*d1 - d2*d2)/n/(n-1));
	    }
	    
		public void checkedIADD(byte a, byte b, boolean checkTypeOverFlow, boolean checkUlp) {
		    byte r = (byte) (a + b);
		    if (checkTypeOverFlow && ((a ^ r) & (b ^ r)) < 0) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'short/Short'", "'byte/Byte'"));
		    }
		}
		
		public void checkedIADD(short a, short b, boolean checkTypeOverFlow, boolean checkUlp) {
		    short r = (short) (a + b);
		    if (checkTypeOverFlow && ((a ^ r) & (b ^ r)) < 0) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'int/Integer'", "'short/Short'"));
		    }
		}
		
		public void checkedIADD(int a, int b, boolean checkTypeOverFlow, boolean checkUlp) {
		    int r = a + b;
		    if (checkTypeOverFlow && ((a ^ r) & (b ^ r)) < 0) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'long/Long'", "'int/Integer'"));
		    }
		}
		
		public void checkedIADD(long a, long b, boolean checkTypeOverFlow, boolean checkUlp) {
		    long r = a + b;
		    if (checkTypeOverFlow && ((a ^ r) & (b ^ r)) < 0) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'BigDecimal'", "'long/Long'"));
		    }
		}
		
		public void checkedIADD(float a, float b, boolean checkTypeOverFlow, boolean checkUlp) {
		
			if(checkUlp) {
			    float minAddedValue = Math.ulp(a);
			    if (minAddedValue > Math.abs(b)) {
			        throw new RuntimeException(buildPrecisionMessage(String.valueOf(a), String.valueOf(b), "'double' or 'BigDecimal'", "'float/Float'"));
			    }
			}
			
		    if (checkTypeOverFlow && ((double) a + (double) b > (double) Float.MAX_VALUE) || ((double) a + (double) b < (double) -Float.MAX_VALUE)) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'double' or 'BigDecimal'", "'float/Float'"));
		    }
		}
		
		public void checkedIADD(double a, double b, boolean checkTypeOverFlow, boolean checkUlp) {
		
			if(checkUlp) {
			    double minAddedValue = Math.ulp(a);
			    if (minAddedValue > Math.abs(b)) {
			        throw new RuntimeException(buildPrecisionMessage(String.valueOf(a), String.valueOf(a), "'BigDecimal'", "'double/Double'"));
			    }
			}
		
		    if (checkTypeOverFlow && (a + b > (double) Double.MAX_VALUE) || (a + b < -Double.MAX_VALUE )) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'BigDecimal'", "'double/Double'"));
		    }
		}
		
		public void checkedIADD(double a, byte b, boolean checkTypeOverFlow, boolean checkUlp) {
		
		    if (checkTypeOverFlow && (a + b > (double) Double.MAX_VALUE) || (a + b < -Double.MAX_VALUE )) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'BigDecimal'", "'double/Double'"));
		    }
		}
		
		public void checkedIADD(double a, short b, boolean checkTypeOverFlow, boolean checkUlp) {
		
		    if (checkTypeOverFlow && (a + b > (double) Double.MAX_VALUE) || (a + b < -Double.MAX_VALUE )) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'BigDecimal'", "'double/Double'"));
		    }
		}
		
		public void checkedIADD(double a, int b, boolean checkTypeOverFlow, boolean checkUlp) {
		
		    if (checkTypeOverFlow && (a + b > (double) Double.MAX_VALUE) || (a + b < -Double.MAX_VALUE )) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'BigDecimal'", "'double/Double'"));
		    }
		}
		
		public void checkedIADD(double a, float b, boolean checkTypeOverFlow, boolean checkUlp) {
		
			if(checkUlp) {
			    double minAddedValue = Math.ulp(a);
			    if (minAddedValue > Math.abs(b)) {
			        throw new RuntimeException(buildPrecisionMessage(String.valueOf(a), String.valueOf(a), "'BigDecimal'", "'double/Double'"));
			    }
			}
		
		    if (checkTypeOverFlow && (a + b > (double) Double.MAX_VALUE) || (a + b < -Double.MAX_VALUE )) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'BigDecimal'", "'double/Double'"));
		    }
		}
		
		private String buildOverflowMessage(String a, String b, String advicedTypes, String originalType) {
		    return "Type overflow when adding " + b + " to " + a
		    + ", to resolve this problem, increase the precision by using "+ advicedTypes +" type in place of "+ originalType +".";
		}
		
		private String buildPrecisionMessage(String a, String b, String advicedTypes, String originalType) {
		    return "The double precision is unsufficient to add the value " + b + " to " + a
		    + ", to resolve this problem, increase the precision by using "+ advicedTypes +" type in place of "+ originalType +".";
		}

	} // G_OutBegin_AggR_144

	UtilClass_tAggregateRow_2 utilClass_tAggregateRow_2 = new UtilClass_tAggregateRow_2();

	

	class AggOperationStruct_tAggregateRow_2 { // G_OutBegin_AggR_100

		private static final int DEFAULT_HASHCODE = 1;
	    private static final int PRIME = 31;
	    private int hashCode = DEFAULT_HASHCODE;
	    public boolean hashCodeDirty = true;

    				String GID;int count = 0;
       			int count_clmCount = 0;
           			
        
	    @Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;
		
							result = prime * result + ((this.GID == null) ? 0 : this.GID.hashCode());
							
	    		this.hashCode = result;
	    		this.hashCodeDirty = false;		
			}
			return this.hashCode;
		}
		
		@Override
		public boolean equals(Object obj) {
			if (this == obj) return true;
			if (obj == null) return false;
			if (getClass() != obj.getClass()) return false;
			final AggOperationStruct_tAggregateRow_2 other = (AggOperationStruct_tAggregateRow_2) obj;
			
							if (this.GID == null) {
								if (other.GID != null) 
									return false;
							} else if (!this.GID.equals(other.GID)) 
								return false;
						
			
			return true;
		}
  
        
	} // G_OutBegin_AggR_100

	AggOperationStruct_tAggregateRow_2 operation_result_tAggregateRow_2 = null;
	AggOperationStruct_tAggregateRow_2 operation_finder_tAggregateRow_2 = new AggOperationStruct_tAggregateRow_2();
	java.util.Map<AggOperationStruct_tAggregateRow_2,AggOperationStruct_tAggregateRow_2> hash_tAggregateRow_2 = new java.util.HashMap<AggOperationStruct_tAggregateRow_2,AggOperationStruct_tAggregateRow_2>();
	

 



/**
 * [tAggregateRow_2_AGGOUT begin ] stop
 */



	
	/**
	 * [tFileOutputDelimited_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileOutputDelimited_2", false);
		start_Hash.put("tFileOutputDelimited_2", System.currentTimeMillis());
		
	
	currentComponent="tFileOutputDelimited_2";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"UPI_detokenized");
			
		int tos_count_tFileOutputDelimited_2 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tFileOutputDelimited_2", "tFileOutputDelimited");
				talendJobLogProcess(globalMap);
			}
			

String fileName_tFileOutputDelimited_2 = "";
    fileName_tFileOutputDelimited_2 = (new java.io.File(((String)globalMap.get("tCreateTemporaryFile_1_FILEPATH")))).getAbsolutePath().replace("\\","/");
    String fullName_tFileOutputDelimited_2 = null;
    String extension_tFileOutputDelimited_2 = null;
    String directory_tFileOutputDelimited_2 = null;
    if((fileName_tFileOutputDelimited_2.indexOf("/") != -1)) {
        if(fileName_tFileOutputDelimited_2.lastIndexOf(".") < fileName_tFileOutputDelimited_2.lastIndexOf("/")) {
            fullName_tFileOutputDelimited_2 = fileName_tFileOutputDelimited_2;
            extension_tFileOutputDelimited_2 = "";
        } else {
            fullName_tFileOutputDelimited_2 = fileName_tFileOutputDelimited_2.substring(0, fileName_tFileOutputDelimited_2.lastIndexOf("."));
            extension_tFileOutputDelimited_2 = fileName_tFileOutputDelimited_2.substring(fileName_tFileOutputDelimited_2.lastIndexOf("."));
        }
        directory_tFileOutputDelimited_2 = fileName_tFileOutputDelimited_2.substring(0, fileName_tFileOutputDelimited_2.lastIndexOf("/"));
    } else {
        if(fileName_tFileOutputDelimited_2.lastIndexOf(".") != -1) {
            fullName_tFileOutputDelimited_2 = fileName_tFileOutputDelimited_2.substring(0, fileName_tFileOutputDelimited_2.lastIndexOf("."));
            extension_tFileOutputDelimited_2 = fileName_tFileOutputDelimited_2.substring(fileName_tFileOutputDelimited_2.lastIndexOf("."));
        } else {
            fullName_tFileOutputDelimited_2 = fileName_tFileOutputDelimited_2;
            extension_tFileOutputDelimited_2 = "";
        }
        directory_tFileOutputDelimited_2 = "";
    }
    boolean isFileGenerated_tFileOutputDelimited_2 = true;
    java.io.File filetFileOutputDelimited_2 = new java.io.File(fileName_tFileOutputDelimited_2);
    globalMap.put("tFileOutputDelimited_2_FILE_NAME",fileName_tFileOutputDelimited_2);
            int nb_line_tFileOutputDelimited_2 = 0;
            int splitedFileNo_tFileOutputDelimited_2 = 0;
            int currentRow_tFileOutputDelimited_2 = 0;

            final String OUT_DELIM_tFileOutputDelimited_2 = /** Start field tFileOutputDelimited_2:FIELDSEPARATOR */";"/** End field tFileOutputDelimited_2:FIELDSEPARATOR */;

            final String OUT_DELIM_ROWSEP_tFileOutputDelimited_2 = /** Start field tFileOutputDelimited_2:ROWSEPARATOR */"\n"/** End field tFileOutputDelimited_2:ROWSEPARATOR */;

                    //create directory only if not exists
                    if(directory_tFileOutputDelimited_2 != null && directory_tFileOutputDelimited_2.trim().length() != 0) {
                        java.io.File dir_tFileOutputDelimited_2 = new java.io.File(directory_tFileOutputDelimited_2);
                        if(!dir_tFileOutputDelimited_2.exists()) {
                            dir_tFileOutputDelimited_2.mkdirs();
                        }
                    }

                        //routines.system.Row
                        java.io.Writer outtFileOutputDelimited_2 = null;

                        java.io.File fileToDelete_tFileOutputDelimited_2 = new java.io.File(fileName_tFileOutputDelimited_2);
                        if(fileToDelete_tFileOutputDelimited_2.exists()) {
                            fileToDelete_tFileOutputDelimited_2.delete();
                        }
                        outtFileOutputDelimited_2 = new java.io.BufferedWriter(new java.io.OutputStreamWriter(
                        new java.io.FileOutputStream(fileName_tFileOutputDelimited_2, false),"ISO-8859-15"));


        resourceMap.put("out_tFileOutputDelimited_2", outtFileOutputDelimited_2);
resourceMap.put("nb_line_tFileOutputDelimited_2", nb_line_tFileOutputDelimited_2);

 



/**
 * [tFileOutputDelimited_2 begin ] stop
 */



	
	/**
	 * [tLogRow_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tLogRow_5", false);
		start_Hash.put("tLogRow_5", System.currentTimeMillis());
		
	
	currentComponent="tLogRow_5";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row13");
			
		int tos_count_tLogRow_5 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tLogRow_5", "tLogRow");
				talendJobLogProcess(globalMap);
			}
			

	///////////////////////
	
         class Util_tLogRow_5 {

        String[] des_top = { ".", ".", "-", "+" };

        String[] des_head = { "|=", "=|", "-", "+" };

        String[] des_bottom = { "'", "'", "-", "+" };

        String name="";

        java.util.List<String[]> list = new java.util.ArrayList<String[]>();

        int[] colLengths = new int[28];

        public void addRow(String[] row) {

            for (int i = 0; i < 28; i++) {
                if (row[i]!=null) {
                  colLengths[i] = Math.max(colLengths[i], row[i].length());
                }
            }
            list.add(row);
        }

        public void setTableName(String name) {

            this.name = name;
        }

            public StringBuilder format() {
            
                StringBuilder sb = new StringBuilder();
  
            
                    sb.append(print(des_top));
    
                    int totals = 0;
                    for (int i = 0; i < colLengths.length; i++) {
                        totals = totals + colLengths[i];
                    }
    
                    // name
                    sb.append("|");
                    int k = 0;
                    for (k = 0; k < (totals + 27 - name.length()) / 2; k++) {
                        sb.append(' ');
                    }
                    sb.append(name);
                    for (int i = 0; i < totals + 27 - name.length() - k; i++) {
                        sb.append(' ');
                    }
                    sb.append("|\n");

                    // head and rows
                    sb.append(print(des_head));
                    for (int i = 0; i < list.size(); i++) {
    
                        String[] row = list.get(i);
    
                        java.util.Formatter formatter = new java.util.Formatter(new StringBuilder());
                        
                        StringBuilder sbformat = new StringBuilder();                                             
        			        sbformat.append("|%1$-");
        			        sbformat.append(colLengths[0]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%2$-");
        			        sbformat.append(colLengths[1]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%3$-");
        			        sbformat.append(colLengths[2]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%4$-");
        			        sbformat.append(colLengths[3]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%5$-");
        			        sbformat.append(colLengths[4]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%6$-");
        			        sbformat.append(colLengths[5]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%7$-");
        			        sbformat.append(colLengths[6]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%8$-");
        			        sbformat.append(colLengths[7]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%9$-");
        			        sbformat.append(colLengths[8]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%10$-");
        			        sbformat.append(colLengths[9]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%11$-");
        			        sbformat.append(colLengths[10]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%12$-");
        			        sbformat.append(colLengths[11]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%13$-");
        			        sbformat.append(colLengths[12]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%14$-");
        			        sbformat.append(colLengths[13]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%15$-");
        			        sbformat.append(colLengths[14]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%16$-");
        			        sbformat.append(colLengths[15]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%17$-");
        			        sbformat.append(colLengths[16]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%18$-");
        			        sbformat.append(colLengths[17]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%19$-");
        			        sbformat.append(colLengths[18]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%20$-");
        			        sbformat.append(colLengths[19]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%21$-");
        			        sbformat.append(colLengths[20]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%22$-");
        			        sbformat.append(colLengths[21]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%23$-");
        			        sbformat.append(colLengths[22]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%24$-");
        			        sbformat.append(colLengths[23]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%25$-");
        			        sbformat.append(colLengths[24]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%26$-");
        			        sbformat.append(colLengths[25]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%27$-");
        			        sbformat.append(colLengths[26]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%28$-");
        			        sbformat.append(colLengths[27]);
        			        sbformat.append("s");
        			                      
                        sbformat.append("|\n");                    
       
                        formatter.format(sbformat.toString(), (Object[])row);	
                                
                        sb.append(formatter.toString());
                        if (i == 0)
                            sb.append(print(des_head)); // print the head
                    }
    
                    // end
                    sb.append(print(des_bottom));
                    return sb;
                }
            

            private StringBuilder print(String[] fillChars) {
                StringBuilder sb = new StringBuilder();
                //first column
                sb.append(fillChars[0]);                
                    for (int i = 0; i < colLengths[0] - fillChars[0].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);	                

                    for (int i = 0; i < colLengths[1] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[2] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[3] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[4] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[5] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[6] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[7] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[8] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[9] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[10] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[11] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[12] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[13] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[14] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[15] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[16] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[17] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[18] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[19] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[20] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[21] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[22] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[23] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[24] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[25] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[26] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                
                    //last column
                    for (int i = 0; i < colLengths[27] - fillChars[1].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }         
                sb.append(fillChars[1]);
                sb.append("\n");               
                return sb;
            }
            
            public boolean isTableEmpty(){
            	if (list.size() > 1)
            		return false;
            	return true;
            }
        }
        Util_tLogRow_5 util_tLogRow_5 = new Util_tLogRow_5();
        util_tLogRow_5.setTableName("UPI_detokenized");
        util_tLogRow_5.addRow(new String[]{"Gender","Date","First_Name","Last_Name","State","City","Zip_Code","Address_Line_1","Address_Line_2","Phone_Number","Social_Security_Number","UPI_ID","MBI","Client_ID","Carrier_ID","Account_ID","Group_ID","Contract_Family_ID","Multi_Birth_Code","Member_Key","Source","year","GID","GRP_SIZE","MASTER","SCORE","GRP_QUALITY","MATCHING_DISTANCES",});        
 		StringBuilder strBuffer_tLogRow_5 = null;
		int nb_line_tLogRow_5 = 0;
///////////////////////    			



 



/**
 * [tLogRow_5 begin ] stop
 */



	
	/**
	 * [tMatchGroup_2_GroupIn begin ] start
	 */

	

	
		
		ok_Hash.put("tMatchGroup_2_GroupIn", false);
		start_Hash.put("tMatchGroup_2_GroupIn", System.currentTimeMillis());
		
	
		currentVirtualComponent = "tMatchGroup_2";
	
	currentComponent="tMatchGroup_2_GroupIn";

	
		int tos_count_tMatchGroup_2_GroupIn = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tMatchGroup_2_GroupIn", "tMatchGroupIn");
				talendJobLogProcess(globalMap);
			}
			


 



/**
 * [tMatchGroup_2_GroupIn begin ] stop
 */
	
	/**
	 * [tMatchGroup_2_GroupIn main ] start
	 */

	

	
	
		currentVirtualComponent = "tMatchGroup_2";
	
	currentComponent="tMatchGroup_2_GroupIn";

	
java.util.List<java.util.List<java.util.Map<String, String>>> matchingRulesAll_tMatchGroup_2 = new java.util.ArrayList<java.util.List<java.util.Map<String, String>>>();
java.util.List<java.util.Map<String, String>> matcherList_tMatchGroup_2 = null;
java.util.Map<String,String> tmpMap_tMatchGroup_2 =null;
java.util.Map<String,String> paramMapTmp_tMatchGroup_2 =null;
java.util.List<java.util.Map<String, String>> defaultSurvivorshipRules_tMatchGroup_2 = new java.util.ArrayList<java.util.Map<String, String>>();
java.util.List<java.util.Map<String, String>> particularSurvivorshipRules_tMatchGroup_2 = new java.util.ArrayList<java.util.Map<String, String>>();
        matcherList_tMatchGroup_2 = new java.util.ArrayList<java.util.Map<String, String>>();
                tmpMap_tMatchGroup_2=new java.util.HashMap<String,String>();
                       tmpMap_tMatchGroup_2.put("MATCHING_TYPE","Exact - ignore case");
                       tmpMap_tMatchGroup_2.put("RECORD_MATCH_THRESHOLD",0.90+"");
                       tmpMap_tMatchGroup_2.put("ATTRIBUTE_NAME","Address_Line_1");
                       tmpMap_tMatchGroup_2.put("SURVIVORSHIP_FUNCTION","Concatenate");
                       tmpMap_tMatchGroup_2.put("HANDLE_NULL","nullMatchNull");
                       tmpMap_tMatchGroup_2.put("ATTRIBUTE_THRESHOLD",1.0+"");
                       tmpMap_tMatchGroup_2.put("CONFIDENCE_WEIGHT",1+"");
                       tmpMap_tMatchGroup_2.put("COLUMN_IDX","7");
                       tmpMap_tMatchGroup_2.put("MATCHING_ALGORITHM","Simple VSR Matcher");
                       tmpMap_tMatchGroup_2.put("TOKENIZATION_TYPE","No");
                matcherList_tMatchGroup_2.add(tmpMap_tMatchGroup_2);
                tmpMap_tMatchGroup_2=new java.util.HashMap<String,String>();
                       tmpMap_tMatchGroup_2.put("MATCHING_TYPE","Exact - ignore case");
                       tmpMap_tMatchGroup_2.put("RECORD_MATCH_THRESHOLD",0.90+"");
                       tmpMap_tMatchGroup_2.put("ATTRIBUTE_NAME","Address_Line_2");
                       tmpMap_tMatchGroup_2.put("SURVIVORSHIP_FUNCTION","Concatenate");
                       tmpMap_tMatchGroup_2.put("HANDLE_NULL","nullMatchNull");
                       tmpMap_tMatchGroup_2.put("ATTRIBUTE_THRESHOLD",1.0+"");
                       tmpMap_tMatchGroup_2.put("CONFIDENCE_WEIGHT",1+"");
                       tmpMap_tMatchGroup_2.put("COLUMN_IDX","8");
                       tmpMap_tMatchGroup_2.put("MATCHING_ALGORITHM","Simple VSR Matcher");
                       tmpMap_tMatchGroup_2.put("TOKENIZATION_TYPE","No");
                matcherList_tMatchGroup_2.add(tmpMap_tMatchGroup_2);
                tmpMap_tMatchGroup_2=new java.util.HashMap<String,String>();
                       tmpMap_tMatchGroup_2.put("MATCHING_TYPE","Exact - ignore case");
                       tmpMap_tMatchGroup_2.put("RECORD_MATCH_THRESHOLD",0.90+"");
                       tmpMap_tMatchGroup_2.put("ATTRIBUTE_NAME","City");
                       tmpMap_tMatchGroup_2.put("SURVIVORSHIP_FUNCTION","Concatenate");
                       tmpMap_tMatchGroup_2.put("HANDLE_NULL","nullMatchNull");
                       tmpMap_tMatchGroup_2.put("ATTRIBUTE_THRESHOLD",1.0+"");
                       tmpMap_tMatchGroup_2.put("CONFIDENCE_WEIGHT",1+"");
                       tmpMap_tMatchGroup_2.put("COLUMN_IDX","5");
                       tmpMap_tMatchGroup_2.put("MATCHING_ALGORITHM","Simple VSR Matcher");
                       tmpMap_tMatchGroup_2.put("TOKENIZATION_TYPE","No");
                matcherList_tMatchGroup_2.add(tmpMap_tMatchGroup_2);
                tmpMap_tMatchGroup_2=new java.util.HashMap<String,String>();
                       tmpMap_tMatchGroup_2.put("MATCHING_TYPE","Exact - ignore case");
                       tmpMap_tMatchGroup_2.put("RECORD_MATCH_THRESHOLD",0.90+"");
                       tmpMap_tMatchGroup_2.put("ATTRIBUTE_NAME","Date");
                       tmpMap_tMatchGroup_2.put("SURVIVORSHIP_FUNCTION","Concatenate");
                       tmpMap_tMatchGroup_2.put("HANDLE_NULL","nullMatchNull");
                       tmpMap_tMatchGroup_2.put("ATTRIBUTE_THRESHOLD",1.0+"");
                       tmpMap_tMatchGroup_2.put("CONFIDENCE_WEIGHT",10+"");
                       tmpMap_tMatchGroup_2.put("COLUMN_IDX","1");
                       tmpMap_tMatchGroup_2.put("MATCHING_ALGORITHM","Simple VSR Matcher");
                       tmpMap_tMatchGroup_2.put("TOKENIZATION_TYPE","No");
                matcherList_tMatchGroup_2.add(tmpMap_tMatchGroup_2);
                tmpMap_tMatchGroup_2=new java.util.HashMap<String,String>();
                       tmpMap_tMatchGroup_2.put("MATCHING_TYPE","Exact - ignore case");
                       tmpMap_tMatchGroup_2.put("RECORD_MATCH_THRESHOLD",0.90+"");
                       tmpMap_tMatchGroup_2.put("ATTRIBUTE_NAME","First_Name");
                       tmpMap_tMatchGroup_2.put("SURVIVORSHIP_FUNCTION","Concatenate");
                       tmpMap_tMatchGroup_2.put("HANDLE_NULL","nullMatchNull");
                       tmpMap_tMatchGroup_2.put("ATTRIBUTE_THRESHOLD",1.0+"");
                       tmpMap_tMatchGroup_2.put("CONFIDENCE_WEIGHT",1+"");
                       tmpMap_tMatchGroup_2.put("COLUMN_IDX","2");
                       tmpMap_tMatchGroup_2.put("MATCHING_ALGORITHM","Simple VSR Matcher");
                       tmpMap_tMatchGroup_2.put("TOKENIZATION_TYPE","No");
                matcherList_tMatchGroup_2.add(tmpMap_tMatchGroup_2);
                tmpMap_tMatchGroup_2=new java.util.HashMap<String,String>();
                       tmpMap_tMatchGroup_2.put("MATCHING_TYPE","Exact - ignore case");
                       tmpMap_tMatchGroup_2.put("RECORD_MATCH_THRESHOLD",0.90+"");
                       tmpMap_tMatchGroup_2.put("ATTRIBUTE_NAME","Gender");
                       tmpMap_tMatchGroup_2.put("SURVIVORSHIP_FUNCTION","Concatenate");
                       tmpMap_tMatchGroup_2.put("HANDLE_NULL","nullMatchNull");
                       tmpMap_tMatchGroup_2.put("ATTRIBUTE_THRESHOLD",1.0+"");
                       tmpMap_tMatchGroup_2.put("CONFIDENCE_WEIGHT",1+"");
                       tmpMap_tMatchGroup_2.put("COLUMN_IDX","0");
                       tmpMap_tMatchGroup_2.put("MATCHING_ALGORITHM","Simple VSR Matcher");
                       tmpMap_tMatchGroup_2.put("TOKENIZATION_TYPE","No");
                matcherList_tMatchGroup_2.add(tmpMap_tMatchGroup_2);
                tmpMap_tMatchGroup_2=new java.util.HashMap<String,String>();
                       tmpMap_tMatchGroup_2.put("MATCHING_TYPE","Exact - ignore case");
                       tmpMap_tMatchGroup_2.put("RECORD_MATCH_THRESHOLD",0.90+"");
                       tmpMap_tMatchGroup_2.put("ATTRIBUTE_NAME","Last_Name");
                       tmpMap_tMatchGroup_2.put("SURVIVORSHIP_FUNCTION","Concatenate");
                       tmpMap_tMatchGroup_2.put("HANDLE_NULL","nullMatchNull");
                       tmpMap_tMatchGroup_2.put("ATTRIBUTE_THRESHOLD",1.0+"");
                       tmpMap_tMatchGroup_2.put("CONFIDENCE_WEIGHT",1+"");
                       tmpMap_tMatchGroup_2.put("COLUMN_IDX","3");
                       tmpMap_tMatchGroup_2.put("MATCHING_ALGORITHM","Simple VSR Matcher");
                       tmpMap_tMatchGroup_2.put("TOKENIZATION_TYPE","No");
                matcherList_tMatchGroup_2.add(tmpMap_tMatchGroup_2);
                tmpMap_tMatchGroup_2=new java.util.HashMap<String,String>();
                       tmpMap_tMatchGroup_2.put("MATCHING_TYPE","Exact - ignore case");
                       tmpMap_tMatchGroup_2.put("RECORD_MATCH_THRESHOLD",0.90+"");
                       tmpMap_tMatchGroup_2.put("ATTRIBUTE_NAME","MBI");
                       tmpMap_tMatchGroup_2.put("SURVIVORSHIP_FUNCTION","Concatenate");
                       tmpMap_tMatchGroup_2.put("HANDLE_NULL","nullMatchAll");
                       tmpMap_tMatchGroup_2.put("ATTRIBUTE_THRESHOLD",1.0+"");
                       tmpMap_tMatchGroup_2.put("CONFIDENCE_WEIGHT",5+"");
                       tmpMap_tMatchGroup_2.put("COLUMN_IDX","12");
                       tmpMap_tMatchGroup_2.put("MATCHING_ALGORITHM","Simple VSR Matcher");
                       tmpMap_tMatchGroup_2.put("TOKENIZATION_TYPE","No");
                matcherList_tMatchGroup_2.add(tmpMap_tMatchGroup_2);
                tmpMap_tMatchGroup_2=new java.util.HashMap<String,String>();
                       tmpMap_tMatchGroup_2.put("MATCHING_TYPE","Exact - ignore case");
                       tmpMap_tMatchGroup_2.put("RECORD_MATCH_THRESHOLD",0.90+"");
                       tmpMap_tMatchGroup_2.put("ATTRIBUTE_NAME","Social_Security_Number");
                       tmpMap_tMatchGroup_2.put("SURVIVORSHIP_FUNCTION","Concatenate");
                       tmpMap_tMatchGroup_2.put("HANDLE_NULL","nullMatchAll");
                       tmpMap_tMatchGroup_2.put("ATTRIBUTE_THRESHOLD",1.0+"");
                       tmpMap_tMatchGroup_2.put("CONFIDENCE_WEIGHT",5+"");
                       tmpMap_tMatchGroup_2.put("COLUMN_IDX","10");
                       tmpMap_tMatchGroup_2.put("MATCHING_ALGORITHM","Simple VSR Matcher");
                       tmpMap_tMatchGroup_2.put("TOKENIZATION_TYPE","No");
                matcherList_tMatchGroup_2.add(tmpMap_tMatchGroup_2);
                tmpMap_tMatchGroup_2=new java.util.HashMap<String,String>();
                       tmpMap_tMatchGroup_2.put("MATCHING_TYPE","Exact - ignore case");
                       tmpMap_tMatchGroup_2.put("RECORD_MATCH_THRESHOLD",0.90+"");
                       tmpMap_tMatchGroup_2.put("ATTRIBUTE_NAME","State");
                       tmpMap_tMatchGroup_2.put("SURVIVORSHIP_FUNCTION","Concatenate");
                       tmpMap_tMatchGroup_2.put("HANDLE_NULL","nullMatchNull");
                       tmpMap_tMatchGroup_2.put("ATTRIBUTE_THRESHOLD",1.0+"");
                       tmpMap_tMatchGroup_2.put("CONFIDENCE_WEIGHT",1+"");
                       tmpMap_tMatchGroup_2.put("COLUMN_IDX","4");
                       tmpMap_tMatchGroup_2.put("MATCHING_ALGORITHM","Simple VSR Matcher");
                       tmpMap_tMatchGroup_2.put("TOKENIZATION_TYPE","No");
                matcherList_tMatchGroup_2.add(tmpMap_tMatchGroup_2);
                tmpMap_tMatchGroup_2=new java.util.HashMap<String,String>();
                       tmpMap_tMatchGroup_2.put("MATCHING_TYPE","Exact - ignore case");
                       tmpMap_tMatchGroup_2.put("RECORD_MATCH_THRESHOLD",0.90+"");
                       tmpMap_tMatchGroup_2.put("ATTRIBUTE_NAME","Zip_Code");
                       tmpMap_tMatchGroup_2.put("SURVIVORSHIP_FUNCTION","Concatenate");
                       tmpMap_tMatchGroup_2.put("HANDLE_NULL","nullMatchNull");
                       tmpMap_tMatchGroup_2.put("ATTRIBUTE_THRESHOLD",1.0+"");
                       tmpMap_tMatchGroup_2.put("CONFIDENCE_WEIGHT",1+"");
                       tmpMap_tMatchGroup_2.put("COLUMN_IDX","6");
                       tmpMap_tMatchGroup_2.put("MATCHING_ALGORITHM","Simple VSR Matcher");
                       tmpMap_tMatchGroup_2.put("TOKENIZATION_TYPE","No");
                matcherList_tMatchGroup_2.add(tmpMap_tMatchGroup_2);
                tmpMap_tMatchGroup_2=new java.util.HashMap<String,String>();
                       tmpMap_tMatchGroup_2.put("MATCHING_TYPE","Exact - ignore case");
                       tmpMap_tMatchGroup_2.put("RECORD_MATCH_THRESHOLD",0.90+"");
                       tmpMap_tMatchGroup_2.put("ATTRIBUTE_NAME","year");
                       tmpMap_tMatchGroup_2.put("SURVIVORSHIP_FUNCTION","Concatenate");
                       tmpMap_tMatchGroup_2.put("HANDLE_NULL","nullMatchNull");
                       tmpMap_tMatchGroup_2.put("ATTRIBUTE_THRESHOLD",1.0+"");
                       tmpMap_tMatchGroup_2.put("CONFIDENCE_WEIGHT",10+"");
                       tmpMap_tMatchGroup_2.put("COLUMN_IDX","21");
                       tmpMap_tMatchGroup_2.put("MATCHING_ALGORITHM","Simple VSR Matcher");
                       tmpMap_tMatchGroup_2.put("TOKENIZATION_TYPE","No");
                matcherList_tMatchGroup_2.add(tmpMap_tMatchGroup_2);
                tmpMap_tMatchGroup_2=new java.util.HashMap<String,String>();
                       tmpMap_tMatchGroup_2.put("REFERENCE_COLUMN_IDX","9");
                       tmpMap_tMatchGroup_2.put("REFERENCE_COLUMN","Phone_Number");
                       tmpMap_tMatchGroup_2.put("MATCHING_TYPE","dummy");
                       tmpMap_tMatchGroup_2.put("ATTRIBUTE_NAME","Phone_Number");
                       tmpMap_tMatchGroup_2.put("COLUMN_IDX","9");
                       tmpMap_tMatchGroup_2.put("CONFIDENCE_WEIGHT",0+"");
                matcherList_tMatchGroup_2.add(tmpMap_tMatchGroup_2);
                tmpMap_tMatchGroup_2=new java.util.HashMap<String,String>();
                       tmpMap_tMatchGroup_2.put("REFERENCE_COLUMN_IDX","11");
                       tmpMap_tMatchGroup_2.put("REFERENCE_COLUMN","UPI_ID");
                       tmpMap_tMatchGroup_2.put("MATCHING_TYPE","dummy");
                       tmpMap_tMatchGroup_2.put("ATTRIBUTE_NAME","UPI_ID");
                       tmpMap_tMatchGroup_2.put("COLUMN_IDX","11");
                       tmpMap_tMatchGroup_2.put("CONFIDENCE_WEIGHT",0+"");
                matcherList_tMatchGroup_2.add(tmpMap_tMatchGroup_2);
                tmpMap_tMatchGroup_2=new java.util.HashMap<String,String>();
                       tmpMap_tMatchGroup_2.put("REFERENCE_COLUMN_IDX","13");
                       tmpMap_tMatchGroup_2.put("REFERENCE_COLUMN","Client_ID");
                       tmpMap_tMatchGroup_2.put("MATCHING_TYPE","dummy");
                       tmpMap_tMatchGroup_2.put("ATTRIBUTE_NAME","Client_ID");
                       tmpMap_tMatchGroup_2.put("COLUMN_IDX","13");
                       tmpMap_tMatchGroup_2.put("CONFIDENCE_WEIGHT",0+"");
                matcherList_tMatchGroup_2.add(tmpMap_tMatchGroup_2);
                tmpMap_tMatchGroup_2=new java.util.HashMap<String,String>();
                       tmpMap_tMatchGroup_2.put("REFERENCE_COLUMN_IDX","14");
                       tmpMap_tMatchGroup_2.put("REFERENCE_COLUMN","Carrier_ID");
                       tmpMap_tMatchGroup_2.put("MATCHING_TYPE","dummy");
                       tmpMap_tMatchGroup_2.put("ATTRIBUTE_NAME","Carrier_ID");
                       tmpMap_tMatchGroup_2.put("COLUMN_IDX","14");
                       tmpMap_tMatchGroup_2.put("CONFIDENCE_WEIGHT",0+"");
                matcherList_tMatchGroup_2.add(tmpMap_tMatchGroup_2);
                tmpMap_tMatchGroup_2=new java.util.HashMap<String,String>();
                       tmpMap_tMatchGroup_2.put("REFERENCE_COLUMN_IDX","15");
                       tmpMap_tMatchGroup_2.put("REFERENCE_COLUMN","Account_ID");
                       tmpMap_tMatchGroup_2.put("MATCHING_TYPE","dummy");
                       tmpMap_tMatchGroup_2.put("ATTRIBUTE_NAME","Account_ID");
                       tmpMap_tMatchGroup_2.put("COLUMN_IDX","15");
                       tmpMap_tMatchGroup_2.put("CONFIDENCE_WEIGHT",0+"");
                matcherList_tMatchGroup_2.add(tmpMap_tMatchGroup_2);
                tmpMap_tMatchGroup_2=new java.util.HashMap<String,String>();
                       tmpMap_tMatchGroup_2.put("REFERENCE_COLUMN_IDX","16");
                       tmpMap_tMatchGroup_2.put("REFERENCE_COLUMN","Group_ID");
                       tmpMap_tMatchGroup_2.put("MATCHING_TYPE","dummy");
                       tmpMap_tMatchGroup_2.put("ATTRIBUTE_NAME","Group_ID");
                       tmpMap_tMatchGroup_2.put("COLUMN_IDX","16");
                       tmpMap_tMatchGroup_2.put("CONFIDENCE_WEIGHT",0+"");
                matcherList_tMatchGroup_2.add(tmpMap_tMatchGroup_2);
                tmpMap_tMatchGroup_2=new java.util.HashMap<String,String>();
                       tmpMap_tMatchGroup_2.put("REFERENCE_COLUMN_IDX","17");
                       tmpMap_tMatchGroup_2.put("REFERENCE_COLUMN","Contract_Family_ID");
                       tmpMap_tMatchGroup_2.put("MATCHING_TYPE","dummy");
                       tmpMap_tMatchGroup_2.put("ATTRIBUTE_NAME","Contract_Family_ID");
                       tmpMap_tMatchGroup_2.put("COLUMN_IDX","17");
                       tmpMap_tMatchGroup_2.put("CONFIDENCE_WEIGHT",0+"");
                matcherList_tMatchGroup_2.add(tmpMap_tMatchGroup_2);
                tmpMap_tMatchGroup_2=new java.util.HashMap<String,String>();
                       tmpMap_tMatchGroup_2.put("REFERENCE_COLUMN_IDX","18");
                       tmpMap_tMatchGroup_2.put("REFERENCE_COLUMN","Multi_Birth_Code");
                       tmpMap_tMatchGroup_2.put("MATCHING_TYPE","dummy");
                       tmpMap_tMatchGroup_2.put("ATTRIBUTE_NAME","Multi_Birth_Code");
                       tmpMap_tMatchGroup_2.put("COLUMN_IDX","18");
                       tmpMap_tMatchGroup_2.put("CONFIDENCE_WEIGHT",0+"");
                matcherList_tMatchGroup_2.add(tmpMap_tMatchGroup_2);
                tmpMap_tMatchGroup_2=new java.util.HashMap<String,String>();
                       tmpMap_tMatchGroup_2.put("REFERENCE_COLUMN_IDX","19");
                       tmpMap_tMatchGroup_2.put("REFERENCE_COLUMN","Member_Key");
                       tmpMap_tMatchGroup_2.put("MATCHING_TYPE","dummy");
                       tmpMap_tMatchGroup_2.put("ATTRIBUTE_NAME","Member_Key");
                       tmpMap_tMatchGroup_2.put("COLUMN_IDX","19");
                       tmpMap_tMatchGroup_2.put("CONFIDENCE_WEIGHT",0+"");
                matcherList_tMatchGroup_2.add(tmpMap_tMatchGroup_2);
                tmpMap_tMatchGroup_2=new java.util.HashMap<String,String>();
                       tmpMap_tMatchGroup_2.put("REFERENCE_COLUMN_IDX","20");
                       tmpMap_tMatchGroup_2.put("REFERENCE_COLUMN","Source");
                       tmpMap_tMatchGroup_2.put("MATCHING_TYPE","dummy");
                       tmpMap_tMatchGroup_2.put("ATTRIBUTE_NAME","Source");
                       tmpMap_tMatchGroup_2.put("COLUMN_IDX","20");
                       tmpMap_tMatchGroup_2.put("CONFIDENCE_WEIGHT",0+"");
                matcherList_tMatchGroup_2.add(tmpMap_tMatchGroup_2);
        java.util.Collections.sort(matcherList_tMatchGroup_2,new Comparator<java.util.Map<String, String>>() {

            @Override
            public int compare(java.util.Map<String, String> map1, java.util.Map<String, String> map2) {

                return Integer.valueOf(map1.get("COLUMN_IDX")).compareTo(Integer.valueOf(map2.get("COLUMN_IDX")));
            }

        });
            matchingRulesAll_tMatchGroup_2.add(matcherList_tMatchGroup_2);
    java.util.Map<String,String> realSurShipMap_tMatchGroup_2=null;
    realSurShipMap_tMatchGroup_2=null;
if(matchingRulesAll_tMatchGroup_2.size()==0){
   //If no matching rules in external data, try to get to rule from JOIN_KEY table (which will be compatible to old version less than 5.3)    
}


row13Struct masterRow_tMatchGroup_2 = null; // a master-row in a group
row13Struct subRow_tMatchGroup_2 = null; // a sub-row in a group.
// key row
tMatchGroup_2Struct hashKey_row8 = new tMatchGroup_2Struct();  
// rows respond to key row 
tMatchGroup_2Struct hashValue_row8 = new tMatchGroup_2Struct();
java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap_tMatchGroup_2 = (java.util.concurrent.ConcurrentHashMap) globalMap.get("concurrentHashMap");
concurrentHashMap_tMatchGroup_2.putIfAbsent("gid_tMatchGroup_2", new java.util.concurrent.atomic.AtomicLong(0L));
java.util.concurrent.atomic.AtomicLong gid_tMatchGroup_2 = (java.util.concurrent.atomic.AtomicLong) concurrentHashMap_tMatchGroup_2.get("gid_tMatchGroup_2");
// master rows in a group
final java.util.List<row13Struct> masterRows_tMatchGroup_2 = new java.util.ArrayList<row13Struct>();
// all rows in a group 
final java.util.List<row13Struct> groupRows_tMatchGroup_2 = new java.util.ArrayList<row13Struct>();
// this Map key is MASTER GID,value is this MASTER index of all MASTERS.it will be used to get DUPLICATE GRP_QUALITY from MASTER and only in case of separate output.
final java.util.Map<String,Double> gID2GQMap_tMatchGroup_2 = new java.util.HashMap<String,Double>();
final double CONFIDENCE_THRESHOLD_tMatchGroup_2 = Double.valueOf(0.95);



//Long gid_tMatchGroup_2 = 0L;
boolean forceLoop_tMatchGroup_2 = (blockRows_row8.isEmpty());
        java.util.Iterator<tMatchGroup_2_2Struct> iter_tMatchGroup_2 = blockRows_row8.keySet().iterator();

//TDQ-9172 reuse JAVA API at here.


org.talend.dataquality.record.linkage.grouping.AbstractRecordGrouping<Object> recordGroupImp_tMatchGroup_2;
 recordGroupImp_tMatchGroup_2=new org.talend.dataquality.record.linkage.grouping.AbstractRecordGrouping<Object>(){
    @Override
    protected void outputRow(Object[] row) {
        row13Struct outStuct_tMatchGroup_2 = new row13Struct ();
        boolean isMaster=false; 
           
              if(0 <row.length){
                  outStuct_tMatchGroup_2.Gender=row[0]==null?null:(String)row[0];
              }
              
           
              if(1 <row.length){
                  outStuct_tMatchGroup_2.Date=row[1]==null?null:(String)row[1];
              }
              
           
              if(2 <row.length){
                  outStuct_tMatchGroup_2.First_Name=row[2]==null?null:(String)row[2];
              }
              
           
              if(3 <row.length){
                  outStuct_tMatchGroup_2.Last_Name=row[3]==null?null:(String)row[3];
              }
              
           
              if(4 <row.length){
                  outStuct_tMatchGroup_2.State=row[4]==null?null:(String)row[4];
              }
              
           
              if(5 <row.length){
                  outStuct_tMatchGroup_2.City=row[5]==null?null:(String)row[5];
              }
              
           
              if(6 <row.length){
                  outStuct_tMatchGroup_2.Zip_Code=row[6]==null?null:(String)row[6];
              }
              
           
              if(7 <row.length){
                  outStuct_tMatchGroup_2.Address_Line_1=row[7]==null?null:(String)row[7];
              }
              
           
              if(8 <row.length){
                  outStuct_tMatchGroup_2.Address_Line_2=row[8]==null?null:(String)row[8];
              }
              
           
              if(9 <row.length){
                  outStuct_tMatchGroup_2.Phone_Number=row[9]==null?null:(String)row[9];
              }
              
           
              if(10 <row.length){
                  outStuct_tMatchGroup_2.Social_Security_Number=row[10]==null?null:(String)row[10];
              }
              
           
              if(11 <row.length){
                  outStuct_tMatchGroup_2.UPI_ID=row[11]==null?null:(String)row[11];
              }
              
           
              if(12 <row.length){
                  outStuct_tMatchGroup_2.MBI=row[12]==null?null:(String)row[12];
              }
              
           
              if(13 <row.length){
                  outStuct_tMatchGroup_2.Client_ID=row[13]==null?null:(String)row[13];
              }
              
           
              if(14 <row.length){
                  outStuct_tMatchGroup_2.Carrier_ID=row[14]==null?null:(String)row[14];
              }
              
           
              if(15 <row.length){
                  outStuct_tMatchGroup_2.Account_ID=row[15]==null?null:(String)row[15];
              }
              
           
              if(16 <row.length){
                  outStuct_tMatchGroup_2.Group_ID=row[16]==null?null:(String)row[16];
              }
              
           
              if(17 <row.length){
                  outStuct_tMatchGroup_2.Contract_Family_ID=row[17]==null?null:(String)row[17];
              }
              
           
              if(18 <row.length){
                  outStuct_tMatchGroup_2.Multi_Birth_Code=row[18]==null?null:(String)row[18];
              }
              
           
              if(19 <row.length){
                  outStuct_tMatchGroup_2.Member_Key=row[19]==null?null:(String)row[19];
              }
              
           
              if(20 <row.length){
                  outStuct_tMatchGroup_2.Source=row[20]==null?null:(String)row[20];
              }
              
           
              if(21 <row.length){
                  outStuct_tMatchGroup_2.year=row[21]==null?null:(String)row[21];
              }
              
           
              if(22 <row.length){
                  outStuct_tMatchGroup_2.GID=row[22]==null?null:(String)row[22];
              }
              
           
              if(23 <row.length){
                  outStuct_tMatchGroup_2.GRP_SIZE=row[23]==null?null:(Integer)row[23];
              }
              
           
              if(24 <row.length){
                  outStuct_tMatchGroup_2.MASTER=row[24]==null?null:(Boolean)row[24];
              }
              
           
              if(25 <row.length){
                  outStuct_tMatchGroup_2.SCORE=row[25]==null?null:(Double)row[25];
              }
              
           
              if(26 <row.length){
                  outStuct_tMatchGroup_2.GRP_QUALITY=row[26]==null?null:(Double)row[26];
              }
              
           
              if(27 <row.length){
                  outStuct_tMatchGroup_2.MATCHING_DISTANCES=row[27]==null?null:(String)row[27];
              }
              
          if(outStuct_tMatchGroup_2.MASTER==true){
             masterRows_tMatchGroup_2.add(outStuct_tMatchGroup_2);
         }else{
             groupRows_tMatchGroup_2.add(outStuct_tMatchGroup_2);
         }
    }
    @Override
    protected boolean isMaster(Object col) {
        return String.valueOf(col).equals("true");
    }
    @Override
    protected Object incrementGroupSize(Object oldGroupSize) {
        return Integer.parseInt(String.valueOf(oldGroupSize)) + 1;
    }
    @Override
    protected Object[] createTYPEArray(int size) {
        return  new Object[size];
    }
    @Override
    protected Object castAsType(Object objectValue) {
        return objectValue;
    }
   @Override
   protected void outputRow(org.talend.dataquality.record.linkage.grouping.swoosh.RichRecord row) {
       // No implementation temporarily.

   }      
};
recordGroupImp_tMatchGroup_2.setOrginalInputColumnSize(22);

recordGroupImp_tMatchGroup_2.setColumnDelimiter(";");
recordGroupImp_tMatchGroup_2.setIsOutputDistDetails(true);

recordGroupImp_tMatchGroup_2.setAcceptableThreshold(Float.valueOf(0.85+""));
recordGroupImp_tMatchGroup_2.setIsLinkToPrevious(false&&true);
recordGroupImp_tMatchGroup_2.setIsDisplayAttLabels(false);
recordGroupImp_tMatchGroup_2.setIsGIDStringType("true".equals("true")?true :false);
recordGroupImp_tMatchGroup_2.setIsPassOriginalValue(false&&false);
recordGroupImp_tMatchGroup_2.setIsStoreOndisk(false);
gID2GQMap_tMatchGroup_2.clear();

while (iter_tMatchGroup_2.hasNext() || forceLoop_tMatchGroup_2){ // C_01

  if (forceLoop_tMatchGroup_2){
    forceLoop_tMatchGroup_2 = false;
  } else {
    // block existing

  }
  tHash_Lookup_row8.lookup(hashKey_row8);
  masterRows_tMatchGroup_2.clear();
  groupRows_tMatchGroup_2.clear();
  
  
  //add mutch rules
  for(java.util.List<java.util.Map<String, String>> matcherList:matchingRulesAll_tMatchGroup_2){
     recordGroupImp_tMatchGroup_2.addMatchRule(matcherList);
  }
  recordGroupImp_tMatchGroup_2.initialize();
 
  while (tHash_Lookup_row8.hasNext()){  // loop on each data in one block
    hashValue_row8 = tHash_Lookup_row8.next();
    // set the a loop data into inputTexts one column by one column. 
    java.util.List<Object> inputTexts=new java.util.ArrayList<Object>();
          inputTexts.add(hashValue_row8.Gender);
          
          inputTexts.add(hashValue_row8.Date);
          
          inputTexts.add(hashValue_row8.First_Name);
          
          inputTexts.add(hashValue_row8.Last_Name);
          
          inputTexts.add(hashValue_row8.State);
          
          inputTexts.add(hashValue_row8.City);
          
          inputTexts.add(hashValue_row8.Zip_Code);
          
          inputTexts.add(hashValue_row8.Address_Line_1);
          
          inputTexts.add(hashValue_row8.Address_Line_2);
          
          inputTexts.add(hashValue_row8.Phone_Number);
          
          inputTexts.add(hashValue_row8.Social_Security_Number);
          
          inputTexts.add(hashValue_row8.UPI_ID);
          
          inputTexts.add(hashValue_row8.MBI);
          
          inputTexts.add(hashValue_row8.Client_ID);
          
          inputTexts.add(hashValue_row8.Carrier_ID);
          
          inputTexts.add(hashValue_row8.Account_ID);
          
          inputTexts.add(hashValue_row8.Group_ID);
          
          inputTexts.add(hashValue_row8.Contract_Family_ID);
          
          inputTexts.add(hashValue_row8.Multi_Birth_Code);
          
          inputTexts.add(hashValue_row8.Member_Key);
          
          inputTexts.add(hashValue_row8.Source);
          
          inputTexts.add(hashValue_row8.year);
          
    
    recordGroupImp_tMatchGroup_2.doGroup((Object[]) inputTexts.toArray(new Object[inputTexts.size()]));
    
  } // while

  recordGroupImp_tMatchGroup_2.end();
  groupRows_tMatchGroup_2.addAll(masterRows_tMatchGroup_2);
    
    java.util.Collections.sort(groupRows_tMatchGroup_2, 
      new Comparator<row13Struct>(){
        public int compare(row13Struct row1, row13Struct row2){
          if (!(row1.GID).equals(row2.GID)){
            return (row1.GID).compareTo(row2.GID);
          } else {
            // false < true
            return (row2.MASTER).compareTo(row1.MASTER); 
          }
        }
      }
    );

  // output data
  for (row13Struct out_tMatchGroup_2 : groupRows_tMatchGroup_2){ // C_02
  
    if (out_tMatchGroup_2 != null){ // C_03


      // all output
      row13 = new row13Struct(); 
          row13.Gender = out_tMatchGroup_2.Gender; 
          row13.Date = out_tMatchGroup_2.Date; 
          row13.First_Name = out_tMatchGroup_2.First_Name; 
          row13.Last_Name = out_tMatchGroup_2.Last_Name; 
          row13.State = out_tMatchGroup_2.State; 
          row13.City = out_tMatchGroup_2.City; 
          row13.Zip_Code = out_tMatchGroup_2.Zip_Code; 
          row13.Address_Line_1 = out_tMatchGroup_2.Address_Line_1; 
          row13.Address_Line_2 = out_tMatchGroup_2.Address_Line_2; 
          row13.Phone_Number = out_tMatchGroup_2.Phone_Number; 
          row13.Social_Security_Number = out_tMatchGroup_2.Social_Security_Number; 
          row13.UPI_ID = out_tMatchGroup_2.UPI_ID; 
          row13.MBI = out_tMatchGroup_2.MBI; 
          row13.Client_ID = out_tMatchGroup_2.Client_ID; 
          row13.Carrier_ID = out_tMatchGroup_2.Carrier_ID; 
          row13.Account_ID = out_tMatchGroup_2.Account_ID; 
          row13.Group_ID = out_tMatchGroup_2.Group_ID; 
          row13.Contract_Family_ID = out_tMatchGroup_2.Contract_Family_ID; 
          row13.Multi_Birth_Code = out_tMatchGroup_2.Multi_Birth_Code; 
          row13.Member_Key = out_tMatchGroup_2.Member_Key; 
          row13.Source = out_tMatchGroup_2.Source; 
          row13.year = out_tMatchGroup_2.year; 
          row13.GID = out_tMatchGroup_2.GID; 
          row13.GRP_SIZE = out_tMatchGroup_2.GRP_SIZE; 
          row13.MASTER = out_tMatchGroup_2.MASTER; 
          row13.SCORE = out_tMatchGroup_2.SCORE; 
          row13.GRP_QUALITY = out_tMatchGroup_2.GRP_QUALITY; 
          row13.MATCHING_DISTANCES = out_tMatchGroup_2.MATCHING_DISTANCES;
 


	tos_count_tMatchGroup_2_GroupIn++;

/**
 * [tMatchGroup_2_GroupIn main ] stop
 */
	
	/**
	 * [tMatchGroup_2_GroupIn process_data_begin ] start
	 */

	

	
	
		currentVirtualComponent = "tMatchGroup_2";
	
	currentComponent="tMatchGroup_2_GroupIn";

	

 



/**
 * [tMatchGroup_2_GroupIn process_data_begin ] stop
 */
// Start of branch "row13"
if(row13 != null) { 



	
	/**
	 * [tLogRow_5 main ] start
	 */

	

	
	
	currentComponent="tLogRow_5";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"row13");
			
///////////////////////		
						

				
				String[] row_tLogRow_5 = new String[28];
   				
	    		if(row13.Gender != null) { //              
                 row_tLogRow_5[0]=    						    
				                String.valueOf(row13.Gender)			
					          ;	
							
	    		} //			
    			   				
	    		if(row13.Date != null) { //              
                 row_tLogRow_5[1]=    						    
				                String.valueOf(row13.Date)			
					          ;	
							
	    		} //			
    			   				
	    		if(row13.First_Name != null) { //              
                 row_tLogRow_5[2]=    						    
				                String.valueOf(row13.First_Name)			
					          ;	
							
	    		} //			
    			   				
	    		if(row13.Last_Name != null) { //              
                 row_tLogRow_5[3]=    						    
				                String.valueOf(row13.Last_Name)			
					          ;	
							
	    		} //			
    			   				
	    		if(row13.State != null) { //              
                 row_tLogRow_5[4]=    						    
				                String.valueOf(row13.State)			
					          ;	
							
	    		} //			
    			   				
	    		if(row13.City != null) { //              
                 row_tLogRow_5[5]=    						    
				                String.valueOf(row13.City)			
					          ;	
							
	    		} //			
    			   				
	    		if(row13.Zip_Code != null) { //              
                 row_tLogRow_5[6]=    						    
				                String.valueOf(row13.Zip_Code)			
					          ;	
							
	    		} //			
    			   				
	    		if(row13.Address_Line_1 != null) { //              
                 row_tLogRow_5[7]=    						    
				                String.valueOf(row13.Address_Line_1)			
					          ;	
							
	    		} //			
    			   				
	    		if(row13.Address_Line_2 != null) { //              
                 row_tLogRow_5[8]=    						    
				                String.valueOf(row13.Address_Line_2)			
					          ;	
							
	    		} //			
    			   				
	    		if(row13.Phone_Number != null) { //              
                 row_tLogRow_5[9]=    						    
				                String.valueOf(row13.Phone_Number)			
					          ;	
							
	    		} //			
    			   				
	    		if(row13.Social_Security_Number != null) { //              
                 row_tLogRow_5[10]=    						    
				                String.valueOf(row13.Social_Security_Number)			
					          ;	
							
	    		} //			
    			   				
	    		if(row13.UPI_ID != null) { //              
                 row_tLogRow_5[11]=    						    
				                String.valueOf(row13.UPI_ID)			
					          ;	
							
	    		} //			
    			   				
	    		if(row13.MBI != null) { //              
                 row_tLogRow_5[12]=    						    
				                String.valueOf(row13.MBI)			
					          ;	
							
	    		} //			
    			   				
	    		if(row13.Client_ID != null) { //              
                 row_tLogRow_5[13]=    						    
				                String.valueOf(row13.Client_ID)			
					          ;	
							
	    		} //			
    			   				
	    		if(row13.Carrier_ID != null) { //              
                 row_tLogRow_5[14]=    						    
				                String.valueOf(row13.Carrier_ID)			
					          ;	
							
	    		} //			
    			   				
	    		if(row13.Account_ID != null) { //              
                 row_tLogRow_5[15]=    						    
				                String.valueOf(row13.Account_ID)			
					          ;	
							
	    		} //			
    			   				
	    		if(row13.Group_ID != null) { //              
                 row_tLogRow_5[16]=    						    
				                String.valueOf(row13.Group_ID)			
					          ;	
							
	    		} //			
    			   				
	    		if(row13.Contract_Family_ID != null) { //              
                 row_tLogRow_5[17]=    						    
				                String.valueOf(row13.Contract_Family_ID)			
					          ;	
							
	    		} //			
    			   				
	    		if(row13.Multi_Birth_Code != null) { //              
                 row_tLogRow_5[18]=    						    
				                String.valueOf(row13.Multi_Birth_Code)			
					          ;	
							
	    		} //			
    			   				
	    		if(row13.Member_Key != null) { //              
                 row_tLogRow_5[19]=    						    
				                String.valueOf(row13.Member_Key)			
					          ;	
							
	    		} //			
    			   				
	    		if(row13.Source != null) { //              
                 row_tLogRow_5[20]=    						    
				                String.valueOf(row13.Source)			
					          ;	
							
	    		} //			
    			   				
	    		if(row13.year != null) { //              
                 row_tLogRow_5[21]=    						    
				                String.valueOf(row13.year)			
					          ;	
							
	    		} //			
    			   				
	    		if(row13.GID != null) { //              
                 row_tLogRow_5[22]=    						    
				                String.valueOf(row13.GID)			
					          ;	
							
	    		} //			
    			   				
	    		if(row13.GRP_SIZE != null) { //              
                 row_tLogRow_5[23]=    						    
				                String.valueOf(row13.GRP_SIZE)			
					          ;	
							
	    		} //			
    			   				
	    		if(row13.MASTER != null) { //              
                 row_tLogRow_5[24]=    						    
				                String.valueOf(row13.MASTER)			
					          ;	
							
	    		} //			
    			   				
	    		if(row13.SCORE != null) { //              
                 row_tLogRow_5[25]=    						
								FormatterUtils.formatUnwithE(row13.SCORE)
					          ;	
							
	    		} //			
    			   				
	    		if(row13.GRP_QUALITY != null) { //              
                 row_tLogRow_5[26]=    						
								FormatterUtils.formatUnwithE(row13.GRP_QUALITY)
					          ;	
							
	    		} //			
    			   				
	    		if(row13.MATCHING_DISTANCES != null) { //              
                 row_tLogRow_5[27]=    						    
				                String.valueOf(row13.MATCHING_DISTANCES)			
					          ;	
							
	    		} //			
    			 

				util_tLogRow_5.addRow(row_tLogRow_5);	
				nb_line_tLogRow_5++;
//////

//////                    
                    
///////////////////////    			

 
     UPI_detokenized = row13;


	tos_count_tLogRow_5++;

/**
 * [tLogRow_5 main ] stop
 */
	
	/**
	 * [tLogRow_5 process_data_begin ] start
	 */

	

	
	
	currentComponent="tLogRow_5";

	

 



/**
 * [tLogRow_5 process_data_begin ] stop
 */

	
	/**
	 * [tFileOutputDelimited_2 main ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_2";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"UPI_detokenized");
			


                    StringBuilder sb_tFileOutputDelimited_2 = new StringBuilder();
                            if(UPI_detokenized.Gender != null) {
                        sb_tFileOutputDelimited_2.append(
                            UPI_detokenized.Gender
                        );
                            }
                            sb_tFileOutputDelimited_2.append(OUT_DELIM_tFileOutputDelimited_2);
                            if(UPI_detokenized.Date != null) {
                        sb_tFileOutputDelimited_2.append(
                            UPI_detokenized.Date
                        );
                            }
                            sb_tFileOutputDelimited_2.append(OUT_DELIM_tFileOutputDelimited_2);
                            if(UPI_detokenized.First_Name != null) {
                        sb_tFileOutputDelimited_2.append(
                            UPI_detokenized.First_Name
                        );
                            }
                            sb_tFileOutputDelimited_2.append(OUT_DELIM_tFileOutputDelimited_2);
                            if(UPI_detokenized.Last_Name != null) {
                        sb_tFileOutputDelimited_2.append(
                            UPI_detokenized.Last_Name
                        );
                            }
                            sb_tFileOutputDelimited_2.append(OUT_DELIM_tFileOutputDelimited_2);
                            if(UPI_detokenized.State != null) {
                        sb_tFileOutputDelimited_2.append(
                            UPI_detokenized.State
                        );
                            }
                            sb_tFileOutputDelimited_2.append(OUT_DELIM_tFileOutputDelimited_2);
                            if(UPI_detokenized.City != null) {
                        sb_tFileOutputDelimited_2.append(
                            UPI_detokenized.City
                        );
                            }
                            sb_tFileOutputDelimited_2.append(OUT_DELIM_tFileOutputDelimited_2);
                            if(UPI_detokenized.Zip_Code != null) {
                        sb_tFileOutputDelimited_2.append(
                            UPI_detokenized.Zip_Code
                        );
                            }
                            sb_tFileOutputDelimited_2.append(OUT_DELIM_tFileOutputDelimited_2);
                            if(UPI_detokenized.Address_Line_1 != null) {
                        sb_tFileOutputDelimited_2.append(
                            UPI_detokenized.Address_Line_1
                        );
                            }
                            sb_tFileOutputDelimited_2.append(OUT_DELIM_tFileOutputDelimited_2);
                            if(UPI_detokenized.Address_Line_2 != null) {
                        sb_tFileOutputDelimited_2.append(
                            UPI_detokenized.Address_Line_2
                        );
                            }
                            sb_tFileOutputDelimited_2.append(OUT_DELIM_tFileOutputDelimited_2);
                            if(UPI_detokenized.Phone_Number != null) {
                        sb_tFileOutputDelimited_2.append(
                            UPI_detokenized.Phone_Number
                        );
                            }
                            sb_tFileOutputDelimited_2.append(OUT_DELIM_tFileOutputDelimited_2);
                            if(UPI_detokenized.Social_Security_Number != null) {
                        sb_tFileOutputDelimited_2.append(
                            UPI_detokenized.Social_Security_Number
                        );
                            }
                            sb_tFileOutputDelimited_2.append(OUT_DELIM_tFileOutputDelimited_2);
                            if(UPI_detokenized.UPI_ID != null) {
                        sb_tFileOutputDelimited_2.append(
                            UPI_detokenized.UPI_ID
                        );
                            }
                            sb_tFileOutputDelimited_2.append(OUT_DELIM_tFileOutputDelimited_2);
                            if(UPI_detokenized.MBI != null) {
                        sb_tFileOutputDelimited_2.append(
                            UPI_detokenized.MBI
                        );
                            }
                            sb_tFileOutputDelimited_2.append(OUT_DELIM_tFileOutputDelimited_2);
                            if(UPI_detokenized.Client_ID != null) {
                        sb_tFileOutputDelimited_2.append(
                            UPI_detokenized.Client_ID
                        );
                            }
                            sb_tFileOutputDelimited_2.append(OUT_DELIM_tFileOutputDelimited_2);
                            if(UPI_detokenized.Carrier_ID != null) {
                        sb_tFileOutputDelimited_2.append(
                            UPI_detokenized.Carrier_ID
                        );
                            }
                            sb_tFileOutputDelimited_2.append(OUT_DELIM_tFileOutputDelimited_2);
                            if(UPI_detokenized.Account_ID != null) {
                        sb_tFileOutputDelimited_2.append(
                            UPI_detokenized.Account_ID
                        );
                            }
                            sb_tFileOutputDelimited_2.append(OUT_DELIM_tFileOutputDelimited_2);
                            if(UPI_detokenized.Group_ID != null) {
                        sb_tFileOutputDelimited_2.append(
                            UPI_detokenized.Group_ID
                        );
                            }
                            sb_tFileOutputDelimited_2.append(OUT_DELIM_tFileOutputDelimited_2);
                            if(UPI_detokenized.Contract_Family_ID != null) {
                        sb_tFileOutputDelimited_2.append(
                            UPI_detokenized.Contract_Family_ID
                        );
                            }
                            sb_tFileOutputDelimited_2.append(OUT_DELIM_tFileOutputDelimited_2);
                            if(UPI_detokenized.Multi_Birth_Code != null) {
                        sb_tFileOutputDelimited_2.append(
                            UPI_detokenized.Multi_Birth_Code
                        );
                            }
                            sb_tFileOutputDelimited_2.append(OUT_DELIM_tFileOutputDelimited_2);
                            if(UPI_detokenized.Member_Key != null) {
                        sb_tFileOutputDelimited_2.append(
                            UPI_detokenized.Member_Key
                        );
                            }
                            sb_tFileOutputDelimited_2.append(OUT_DELIM_tFileOutputDelimited_2);
                            if(UPI_detokenized.Source != null) {
                        sb_tFileOutputDelimited_2.append(
                            UPI_detokenized.Source
                        );
                            }
                            sb_tFileOutputDelimited_2.append(OUT_DELIM_tFileOutputDelimited_2);
                            if(UPI_detokenized.year != null) {
                        sb_tFileOutputDelimited_2.append(
                            UPI_detokenized.year
                        );
                            }
                            sb_tFileOutputDelimited_2.append(OUT_DELIM_tFileOutputDelimited_2);
                            if(UPI_detokenized.GID != null) {
                        sb_tFileOutputDelimited_2.append(
                            UPI_detokenized.GID
                        );
                            }
                            sb_tFileOutputDelimited_2.append(OUT_DELIM_tFileOutputDelimited_2);
                            if(UPI_detokenized.GRP_SIZE != null) {
                        sb_tFileOutputDelimited_2.append(
                            UPI_detokenized.GRP_SIZE
                        );
                            }
                            sb_tFileOutputDelimited_2.append(OUT_DELIM_tFileOutputDelimited_2);
                            if(UPI_detokenized.MASTER != null) {
                        sb_tFileOutputDelimited_2.append(
                            UPI_detokenized.MASTER
                        );
                            }
                            sb_tFileOutputDelimited_2.append(OUT_DELIM_tFileOutputDelimited_2);
                            if(UPI_detokenized.SCORE != null) {
                        sb_tFileOutputDelimited_2.append(
                            UPI_detokenized.SCORE
                        );
                            }
                            sb_tFileOutputDelimited_2.append(OUT_DELIM_tFileOutputDelimited_2);
                            if(UPI_detokenized.GRP_QUALITY != null) {
                        sb_tFileOutputDelimited_2.append(
                            UPI_detokenized.GRP_QUALITY
                        );
                            }
                            sb_tFileOutputDelimited_2.append(OUT_DELIM_tFileOutputDelimited_2);
                            if(UPI_detokenized.MATCHING_DISTANCES != null) {
                        sb_tFileOutputDelimited_2.append(
                            UPI_detokenized.MATCHING_DISTANCES
                        );
                            }
                    sb_tFileOutputDelimited_2.append(OUT_DELIM_ROWSEP_tFileOutputDelimited_2);


                    nb_line_tFileOutputDelimited_2++;
                    resourceMap.put("nb_line_tFileOutputDelimited_2", nb_line_tFileOutputDelimited_2);

                        outtFileOutputDelimited_2.write(sb_tFileOutputDelimited_2.toString());




 
     row21 = UPI_detokenized;


	tos_count_tFileOutputDelimited_2++;

/**
 * [tFileOutputDelimited_2 main ] stop
 */
	
	/**
	 * [tFileOutputDelimited_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_2";

	

 



/**
 * [tFileOutputDelimited_2 process_data_begin ] stop
 */

	
	/**
	 * [tAggregateRow_2_AGGOUT main ] start
	 */

	

	
	
		currentVirtualComponent = "tAggregateRow_2";
	
	currentComponent="tAggregateRow_2_AGGOUT";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"row21");
			
	
operation_finder_tAggregateRow_2.GID = row21.GID;
			

	operation_finder_tAggregateRow_2.hashCodeDirty = true;
	
	operation_result_tAggregateRow_2 = hash_tAggregateRow_2.get(operation_finder_tAggregateRow_2);

	

	if(operation_result_tAggregateRow_2 == null) { // G_OutMain_AggR_001

		operation_result_tAggregateRow_2 = new AggOperationStruct_tAggregateRow_2();

		operation_result_tAggregateRow_2.GID = operation_finder_tAggregateRow_2.GID;
				
		
		

		hash_tAggregateRow_2.put(operation_result_tAggregateRow_2, operation_result_tAggregateRow_2);
	
	} // G_OutMain_AggR_001


	
				operation_result_tAggregateRow_2.count_clmCount++;
				operation_result_tAggregateRow_2.count++;
				


 


	tos_count_tAggregateRow_2_AGGOUT++;

/**
 * [tAggregateRow_2_AGGOUT main ] stop
 */
	
	/**
	 * [tAggregateRow_2_AGGOUT process_data_begin ] start
	 */

	

	
	
		currentVirtualComponent = "tAggregateRow_2";
	
	currentComponent="tAggregateRow_2_AGGOUT";

	

 



/**
 * [tAggregateRow_2_AGGOUT process_data_begin ] stop
 */
	
	/**
	 * [tAggregateRow_2_AGGOUT process_data_end ] start
	 */

	

	
	
		currentVirtualComponent = "tAggregateRow_2";
	
	currentComponent="tAggregateRow_2_AGGOUT";

	

 



/**
 * [tAggregateRow_2_AGGOUT process_data_end ] stop
 */



	
	/**
	 * [tFileOutputDelimited_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_2";

	

 



/**
 * [tFileOutputDelimited_2 process_data_end ] stop
 */



	
	/**
	 * [tLogRow_5 process_data_end ] start
	 */

	

	
	
	currentComponent="tLogRow_5";

	

 



/**
 * [tLogRow_5 process_data_end ] stop
 */

} // End of branch "row13"



	
		} // C_03
		
		} // C_02
		
		} // C_01
	
	
	/**
	 * [tMatchGroup_2_GroupIn process_data_end ] start
	 */

	

	
	
		currentVirtualComponent = "tMatchGroup_2";
	
	currentComponent="tMatchGroup_2_GroupIn";

	

 



/**
 * [tMatchGroup_2_GroupIn process_data_end ] stop
 */
	
	/**
	 * [tMatchGroup_2_GroupIn end ] start
	 */

	

	
	
		currentVirtualComponent = "tMatchGroup_2";
	
	currentComponent="tMatchGroup_2_GroupIn";

	
blockRows_row8.clear();
blockRows_row8 = null;
masterRows_tMatchGroup_2.clear();
groupRows_tMatchGroup_2.clear();

if (tHash_Lookup_row8 != null) {
  tHash_Lookup_row8.endGet();
}
globalMap.remove("tHash_Lookup_row8");
 

ok_Hash.put("tMatchGroup_2_GroupIn", true);
end_Hash.put("tMatchGroup_2_GroupIn", System.currentTimeMillis());




/**
 * [tMatchGroup_2_GroupIn end ] stop
 */

	
	/**
	 * [tLogRow_5 end ] start
	 */

	

	
	
	currentComponent="tLogRow_5";

	


//////

                    
                    java.io.PrintStream consoleOut_tLogRow_5 = null;
                    if (globalMap.get("tLogRow_CONSOLE")!=null)
                    {
                    	consoleOut_tLogRow_5 = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
                    }
                    else
                    {
                    	consoleOut_tLogRow_5 = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
                    	globalMap.put("tLogRow_CONSOLE",consoleOut_tLogRow_5);
                    }
                    
                    consoleOut_tLogRow_5.println(util_tLogRow_5.format().toString());
                    consoleOut_tLogRow_5.flush();
//////
globalMap.put("tLogRow_5_NB_LINE",nb_line_tLogRow_5);

///////////////////////    			

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row13",2,0,
			 			talendJobLog,"tMatchGroup_2_GroupIn","tMatchGroupIn","tLogRow_5","tLogRow","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tLogRow_5", true);
end_Hash.put("tLogRow_5", System.currentTimeMillis());




/**
 * [tLogRow_5 end ] stop
 */

	
	/**
	 * [tFileOutputDelimited_2 end ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_2";

	



		
			
					if(outtFileOutputDelimited_2!=null) {
						outtFileOutputDelimited_2.flush();
						outtFileOutputDelimited_2.close();
					}
				
				globalMap.put("tFileOutputDelimited_2_NB_LINE",nb_line_tFileOutputDelimited_2);
				globalMap.put("tFileOutputDelimited_2_FILE_NAME",fileName_tFileOutputDelimited_2);
			
		
		
		resourceMap.put("finish_tFileOutputDelimited_2", true);
	

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"UPI_detokenized",2,0,
			 			talendJobLog,"tLogRow_5","tLogRow","tFileOutputDelimited_2","tFileOutputDelimited","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tFileOutputDelimited_2", true);
end_Hash.put("tFileOutputDelimited_2", System.currentTimeMillis());




/**
 * [tFileOutputDelimited_2 end ] stop
 */

	
	/**
	 * [tAggregateRow_2_AGGOUT end ] start
	 */

	

	
	
		currentVirtualComponent = "tAggregateRow_2";
	
	currentComponent="tAggregateRow_2_AGGOUT";

	

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row21",2,0,
			 			talendJobLog,"tFileOutputDelimited_2","tFileOutputDelimited","tAggregateRow_2_AGGOUT","tAggregateOut","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tAggregateRow_2_AGGOUT", true);
end_Hash.put("tAggregateRow_2_AGGOUT", System.currentTimeMillis());




/**
 * [tAggregateRow_2_AGGOUT end ] stop
 */



	
	/**
	 * [tFileOutputDelimited_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileOutputDelimited_4", false);
		start_Hash.put("tFileOutputDelimited_4", System.currentTimeMillis());
		
	
	currentComponent="tFileOutputDelimited_4";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"copyOfcopyOfout");
			
		int tos_count_tFileOutputDelimited_4 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tFileOutputDelimited_4", "tFileOutputDelimited");
				talendJobLogProcess(globalMap);
			}
			

String fileName_tFileOutputDelimited_4 = "";
    fileName_tFileOutputDelimited_4 = (new java.io.File(context.location+"GroupID.csv")).getAbsolutePath().replace("\\","/");
    String fullName_tFileOutputDelimited_4 = null;
    String extension_tFileOutputDelimited_4 = null;
    String directory_tFileOutputDelimited_4 = null;
    if((fileName_tFileOutputDelimited_4.indexOf("/") != -1)) {
        if(fileName_tFileOutputDelimited_4.lastIndexOf(".") < fileName_tFileOutputDelimited_4.lastIndexOf("/")) {
            fullName_tFileOutputDelimited_4 = fileName_tFileOutputDelimited_4;
            extension_tFileOutputDelimited_4 = "";
        } else {
            fullName_tFileOutputDelimited_4 = fileName_tFileOutputDelimited_4.substring(0, fileName_tFileOutputDelimited_4.lastIndexOf("."));
            extension_tFileOutputDelimited_4 = fileName_tFileOutputDelimited_4.substring(fileName_tFileOutputDelimited_4.lastIndexOf("."));
        }
        directory_tFileOutputDelimited_4 = fileName_tFileOutputDelimited_4.substring(0, fileName_tFileOutputDelimited_4.lastIndexOf("/"));
    } else {
        if(fileName_tFileOutputDelimited_4.lastIndexOf(".") != -1) {
            fullName_tFileOutputDelimited_4 = fileName_tFileOutputDelimited_4.substring(0, fileName_tFileOutputDelimited_4.lastIndexOf("."));
            extension_tFileOutputDelimited_4 = fileName_tFileOutputDelimited_4.substring(fileName_tFileOutputDelimited_4.lastIndexOf("."));
        } else {
            fullName_tFileOutputDelimited_4 = fileName_tFileOutputDelimited_4;
            extension_tFileOutputDelimited_4 = "";
        }
        directory_tFileOutputDelimited_4 = "";
    }
    boolean isFileGenerated_tFileOutputDelimited_4 = true;
    java.io.File filetFileOutputDelimited_4 = new java.io.File(fileName_tFileOutputDelimited_4);
    globalMap.put("tFileOutputDelimited_4_FILE_NAME",fileName_tFileOutputDelimited_4);
            int nb_line_tFileOutputDelimited_4 = 0;
            int splitedFileNo_tFileOutputDelimited_4 = 0;
            int currentRow_tFileOutputDelimited_4 = 0;

            final String OUT_DELIM_tFileOutputDelimited_4 = /** Start field tFileOutputDelimited_4:FIELDSEPARATOR */";"/** End field tFileOutputDelimited_4:FIELDSEPARATOR */;

            final String OUT_DELIM_ROWSEP_tFileOutputDelimited_4 = /** Start field tFileOutputDelimited_4:ROWSEPARATOR */"\n"/** End field tFileOutputDelimited_4:ROWSEPARATOR */;

                    //create directory only if not exists
                    if(directory_tFileOutputDelimited_4 != null && directory_tFileOutputDelimited_4.trim().length() != 0) {
                        java.io.File dir_tFileOutputDelimited_4 = new java.io.File(directory_tFileOutputDelimited_4);
                        if(!dir_tFileOutputDelimited_4.exists()) {
                            dir_tFileOutputDelimited_4.mkdirs();
                        }
                    }

                        //routines.system.Row
                        java.io.Writer outtFileOutputDelimited_4 = null;

                        java.io.File fileToDelete_tFileOutputDelimited_4 = new java.io.File(fileName_tFileOutputDelimited_4);
                        if(fileToDelete_tFileOutputDelimited_4.exists()) {
                            fileToDelete_tFileOutputDelimited_4.delete();
                        }
                        outtFileOutputDelimited_4 = new java.io.BufferedWriter(new java.io.OutputStreamWriter(
                        new java.io.FileOutputStream(fileName_tFileOutputDelimited_4, false),"ISO-8859-15"));
                                    if(filetFileOutputDelimited_4.length()==0){
                                        outtFileOutputDelimited_4.write("GID");
                                            outtFileOutputDelimited_4.write(OUT_DELIM_tFileOutputDelimited_4);
                                        outtFileOutputDelimited_4.write("count");
                                        outtFileOutputDelimited_4.write(OUT_DELIM_ROWSEP_tFileOutputDelimited_4);
                                        outtFileOutputDelimited_4.flush();
                                    }


        resourceMap.put("out_tFileOutputDelimited_4", outtFileOutputDelimited_4);
resourceMap.put("nb_line_tFileOutputDelimited_4", nb_line_tFileOutputDelimited_4);

 



/**
 * [tFileOutputDelimited_4 begin ] stop
 */



	
	/**
	 * [tMap_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_6", false);
		start_Hash.put("tMap_6", System.currentTimeMillis());
		
	
	currentComponent="tMap_6";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row22");
			
		int tos_count_tMap_6 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tMap_6", "tMap");
				talendJobLogProcess(globalMap);
			}
			




// ###############################
// # Lookup's keys initialization
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_6__Struct  {
}
Var__tMap_6__Struct Var__tMap_6 = new Var__tMap_6__Struct();
// ###############################

// ###############################
// # Outputs initialization
copyOfcopyOfoutStruct copyOfcopyOfout_tmp = new copyOfcopyOfoutStruct();
// ###############################

        
        



        









 



/**
 * [tMap_6 begin ] stop
 */



	
	/**
	 * [tAggregateRow_2_AGGIN begin ] start
	 */

	

	
		
		ok_Hash.put("tAggregateRow_2_AGGIN", false);
		start_Hash.put("tAggregateRow_2_AGGIN", System.currentTimeMillis());
		
	
		currentVirtualComponent = "tAggregateRow_2";
	
	currentComponent="tAggregateRow_2_AGGIN";

	
		int tos_count_tAggregateRow_2_AGGIN = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAggregateRow_2_AGGIN", "tAggregateIn");
				talendJobLogProcess(globalMap);
			}
			

java.util.Collection<AggOperationStruct_tAggregateRow_2> values_tAggregateRow_2 = hash_tAggregateRow_2.values();

globalMap.put("tAggregateRow_2_NB_LINE", values_tAggregateRow_2.size());

for(AggOperationStruct_tAggregateRow_2 aggregated_row_tAggregateRow_2 : values_tAggregateRow_2) { // G_AggR_600



 



/**
 * [tAggregateRow_2_AGGIN begin ] stop
 */
	
	/**
	 * [tAggregateRow_2_AGGIN main ] start
	 */

	

	
	
		currentVirtualComponent = "tAggregateRow_2";
	
	currentComponent="tAggregateRow_2_AGGIN";

	

            				    row22.GID = aggregated_row_tAggregateRow_2.GID;
            				    row22.count = (int) aggregated_row_tAggregateRow_2.count;
	                                	row22.count = (int) aggregated_row_tAggregateRow_2.count_clmCount;
	                                	

 


	tos_count_tAggregateRow_2_AGGIN++;

/**
 * [tAggregateRow_2_AGGIN main ] stop
 */
	
	/**
	 * [tAggregateRow_2_AGGIN process_data_begin ] start
	 */

	

	
	
		currentVirtualComponent = "tAggregateRow_2";
	
	currentComponent="tAggregateRow_2_AGGIN";

	

 



/**
 * [tAggregateRow_2_AGGIN process_data_begin ] stop
 */

	
	/**
	 * [tMap_6 main ] start
	 */

	

	
	
	currentComponent="tMap_6";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"row22");
			

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_6 = false;
		
        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_6 = false;
		  boolean mainRowRejected_tMap_6 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_6__Struct Var = Var__tMap_6;// ###############################
        // ###############################
        // # Output tables

copyOfcopyOfout = null;


// # Output table : 'copyOfcopyOfout'
copyOfcopyOfout_tmp.GID = row22.GID;
copyOfcopyOfout_tmp.count = row22.count;
copyOfcopyOfout = copyOfcopyOfout_tmp;
// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_6 = false;










 


	tos_count_tMap_6++;

/**
 * [tMap_6 main ] stop
 */
	
	/**
	 * [tMap_6 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_6";

	

 



/**
 * [tMap_6 process_data_begin ] stop
 */
// Start of branch "copyOfcopyOfout"
if(copyOfcopyOfout != null) { 



	
	/**
	 * [tFileOutputDelimited_4 main ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_4";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"copyOfcopyOfout");
			


                    StringBuilder sb_tFileOutputDelimited_4 = new StringBuilder();
                            if(copyOfcopyOfout.GID != null) {
                        sb_tFileOutputDelimited_4.append(
                            copyOfcopyOfout.GID
                        );
                            }
                            sb_tFileOutputDelimited_4.append(OUT_DELIM_tFileOutputDelimited_4);
                            if(copyOfcopyOfout.count != null) {
                        sb_tFileOutputDelimited_4.append(
                            copyOfcopyOfout.count
                        );
                            }
                    sb_tFileOutputDelimited_4.append(OUT_DELIM_ROWSEP_tFileOutputDelimited_4);


                    nb_line_tFileOutputDelimited_4++;
                    resourceMap.put("nb_line_tFileOutputDelimited_4", nb_line_tFileOutputDelimited_4);

                        outtFileOutputDelimited_4.write(sb_tFileOutputDelimited_4.toString());




 


	tos_count_tFileOutputDelimited_4++;

/**
 * [tFileOutputDelimited_4 main ] stop
 */
	
	/**
	 * [tFileOutputDelimited_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_4";

	

 



/**
 * [tFileOutputDelimited_4 process_data_begin ] stop
 */
	
	/**
	 * [tFileOutputDelimited_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_4";

	

 



/**
 * [tFileOutputDelimited_4 process_data_end ] stop
 */

} // End of branch "copyOfcopyOfout"




	
	/**
	 * [tMap_6 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_6";

	

 



/**
 * [tMap_6 process_data_end ] stop
 */



	
	/**
	 * [tAggregateRow_2_AGGIN process_data_end ] start
	 */

	

	
	
		currentVirtualComponent = "tAggregateRow_2";
	
	currentComponent="tAggregateRow_2_AGGIN";

	

 



/**
 * [tAggregateRow_2_AGGIN process_data_end ] stop
 */
	
	/**
	 * [tAggregateRow_2_AGGIN end ] start
	 */

	

	
	
		currentVirtualComponent = "tAggregateRow_2";
	
	currentComponent="tAggregateRow_2_AGGIN";

	

} // G_AggR_600

 

ok_Hash.put("tAggregateRow_2_AGGIN", true);
end_Hash.put("tAggregateRow_2_AGGIN", System.currentTimeMillis());




/**
 * [tAggregateRow_2_AGGIN end ] stop
 */

	
	/**
	 * [tMap_6 end ] start
	 */

	

	
	
	currentComponent="tMap_6";

	


// ###############################
// # Lookup hashes releasing
// ###############################      





			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row22",2,0,
			 			talendJobLog,"tAggregateRow_2_AGGIN","tAggregateIn","tMap_6","tMap","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tMap_6", true);
end_Hash.put("tMap_6", System.currentTimeMillis());




/**
 * [tMap_6 end ] stop
 */

	
	/**
	 * [tFileOutputDelimited_4 end ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_4";

	



		
			
					if(outtFileOutputDelimited_4!=null) {
						outtFileOutputDelimited_4.flush();
						outtFileOutputDelimited_4.close();
					}
				
				globalMap.put("tFileOutputDelimited_4_NB_LINE",nb_line_tFileOutputDelimited_4);
				globalMap.put("tFileOutputDelimited_4_FILE_NAME",fileName_tFileOutputDelimited_4);
			
		
		
		resourceMap.put("finish_tFileOutputDelimited_4", true);
	

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"copyOfcopyOfout",2,0,
			 			talendJobLog,"tMap_6","tMap","tFileOutputDelimited_4","tFileOutputDelimited","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tFileOutputDelimited_4", true);
end_Hash.put("tFileOutputDelimited_4", System.currentTimeMillis());




/**
 * [tFileOutputDelimited_4 end ] stop
 */




































				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tDBInput_2:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk3", 0, "ok");
								} 
							
							tFileInputDelimited_2Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
					te.setVirtualComponentName(currentVirtualComponent);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
							//free memory for "tAggregateRow_2_AGGIN"
							globalMap.remove("tAggregateRow_2");
						
					     			//free memory for "tMap_1"
					     			globalMap.remove("tHash_Lookup_row7"); 
				     			
				try{
					
	
	/**
	 * [tDBInput_2 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_2";

	

 



/**
 * [tDBInput_2 finally ] stop
 */

	
	/**
	 * [tMap_1 finally ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

 



/**
 * [tMap_1 finally ] stop
 */

	
	/**
	 * [tBufferOutput_1 finally ] start
	 */

	

	
	
	currentComponent="tBufferOutput_1";

	

 



/**
 * [tBufferOutput_1 finally ] stop
 */

	
	/**
	 * [tMap_5 finally ] start
	 */

	

	
	
	currentComponent="tMap_5";

	

 



/**
 * [tMap_5 finally ] stop
 */

	
	/**
	 * [tConvertType_1 finally ] start
	 */

	

	
	
	currentComponent="tConvertType_1";

	

 



/**
 * [tConvertType_1 finally ] stop
 */

	
	/**
	 * [tMatchGroup_2_GroupOut finally ] start
	 */

	

	
	
		currentVirtualComponent = "tMatchGroup_2";
	
	currentComponent="tMatchGroup_2_GroupOut";

	

 



/**
 * [tMatchGroup_2_GroupOut finally ] stop
 */

	
	/**
	 * [tMatchGroup_2_GroupIn finally ] start
	 */

	

	
	
		currentVirtualComponent = "tMatchGroup_2";
	
	currentComponent="tMatchGroup_2_GroupIn";

	

 



/**
 * [tMatchGroup_2_GroupIn finally ] stop
 */

	
	/**
	 * [tLogRow_5 finally ] start
	 */

	

	
	
	currentComponent="tLogRow_5";

	

 



/**
 * [tLogRow_5 finally ] stop
 */

	
	/**
	 * [tFileOutputDelimited_2 finally ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_2";

	


		if(resourceMap.get("finish_tFileOutputDelimited_2") == null){ 
			
				
						java.io.Writer outtFileOutputDelimited_2 = (java.io.Writer)resourceMap.get("out_tFileOutputDelimited_2");
						if(outtFileOutputDelimited_2!=null) {
							outtFileOutputDelimited_2.flush();
							outtFileOutputDelimited_2.close();
						}
					
				
			
		}
	

 



/**
 * [tFileOutputDelimited_2 finally ] stop
 */

	
	/**
	 * [tAggregateRow_2_AGGOUT finally ] start
	 */

	

	
	
		currentVirtualComponent = "tAggregateRow_2";
	
	currentComponent="tAggregateRow_2_AGGOUT";

	

 



/**
 * [tAggregateRow_2_AGGOUT finally ] stop
 */

	
	/**
	 * [tAggregateRow_2_AGGIN finally ] start
	 */

	

	
	
		currentVirtualComponent = "tAggregateRow_2";
	
	currentComponent="tAggregateRow_2_AGGIN";

	

 



/**
 * [tAggregateRow_2_AGGIN finally ] stop
 */

	
	/**
	 * [tMap_6 finally ] start
	 */

	

	
	
	currentComponent="tMap_6";

	

 



/**
 * [tMap_6 finally ] stop
 */

	
	/**
	 * [tFileOutputDelimited_4 finally ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_4";

	


		if(resourceMap.get("finish_tFileOutputDelimited_4") == null){ 
			
				
						java.io.Writer outtFileOutputDelimited_4 = (java.io.Writer)resourceMap.get("out_tFileOutputDelimited_4");
						if(outtFileOutputDelimited_4!=null) {
							outtFileOutputDelimited_4.flush();
							outtFileOutputDelimited_4.close();
						}
					
				
			
		}
	

 



/**
 * [tFileOutputDelimited_4 finally ] stop
 */




































				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_2_SUBPROCESS_STATE", 1);
	}
	


public static class copyOfNoTokenizationStruct implements routines.system.IPersistableRow<copyOfNoTokenizationStruct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];

	
			    public String Gender;

				public String getGender () {
					return this.Gender;
				}
				
			    public String State;

				public String getState () {
					return this.State;
				}
				
			    public String City;

				public String getCity () {
					return this.City;
				}
				
			    public String Zip_Code;

				public String getZip_Code () {
					return this.Zip_Code;
				}
				
			    public String Address_Line_1;

				public String getAddress_Line_1 () {
					return this.Address_Line_1;
				}
				
			    public String Address_Line_2;

				public String getAddress_Line_2 () {
					return this.Address_Line_2;
				}
				
			    public String Phone_Number;

				public String getPhone_Number () {
					return this.Phone_Number;
				}
				
			    public String UPI_ID;

				public String getUPI_ID () {
					return this.UPI_ID;
				}
				
			    public String Client_ID;

				public String getClient_ID () {
					return this.Client_ID;
				}
				
			    public String Carrier_ID;

				public String getCarrier_ID () {
					return this.Carrier_ID;
				}
				
			    public String Account_ID;

				public String getAccount_ID () {
					return this.Account_ID;
				}
				
			    public String Group_ID;

				public String getGroup_ID () {
					return this.Group_ID;
				}
				
			    public String Multi_Birth_Code;

				public String getMulti_Birth_Code () {
					return this.Multi_Birth_Code;
				}
				
			    public String Member_Key;

				public String getMember_Key () {
					return this.Member_Key;
				}
				
			    public String Source;

				public String getSource () {
					return this.Source;
				}
				
			    public int scd_key;

				public int getScd_key () {
					return this.scd_key;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam) {

        	try {

        		int length = 0;
		
					this.Gender = readString(dis);
					
					this.State = readString(dis);
					
					this.City = readString(dis);
					
					this.Zip_Code = readString(dis);
					
					this.Address_Line_1 = readString(dis);
					
					this.Address_Line_2 = readString(dis);
					
					this.Phone_Number = readString(dis);
					
					this.UPI_ID = readString(dis);
					
					this.Client_ID = readString(dis);
					
					this.Carrier_ID = readString(dis);
					
					this.Account_ID = readString(dis);
					
					this.Group_ID = readString(dis);
					
					this.Multi_Birth_Code = readString(dis);
					
					this.Member_Key = readString(dis);
					
					this.Source = readString(dis);
					
			        this.scd_key = dis.readInt();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Gender,dos);
					
					// String
				
						writeString(this.State,dos);
					
					// String
				
						writeString(this.City,dos);
					
					// String
				
						writeString(this.Zip_Code,dos);
					
					// String
				
						writeString(this.Address_Line_1,dos);
					
					// String
				
						writeString(this.Address_Line_2,dos);
					
					// String
				
						writeString(this.Phone_Number,dos);
					
					// String
				
						writeString(this.UPI_ID,dos);
					
					// String
				
						writeString(this.Client_ID,dos);
					
					// String
				
						writeString(this.Carrier_ID,dos);
					
					// String
				
						writeString(this.Account_ID,dos);
					
					// String
				
						writeString(this.Group_ID,dos);
					
					// String
				
						writeString(this.Multi_Birth_Code,dos);
					
					// String
				
						writeString(this.Member_Key,dos);
					
					// String
				
						writeString(this.Source,dos);
					
					// int
				
		            	dos.writeInt(this.scd_key);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Gender="+Gender);
		sb.append(",State="+State);
		sb.append(",City="+City);
		sb.append(",Zip_Code="+Zip_Code);
		sb.append(",Address_Line_1="+Address_Line_1);
		sb.append(",Address_Line_2="+Address_Line_2);
		sb.append(",Phone_Number="+Phone_Number);
		sb.append(",UPI_ID="+UPI_ID);
		sb.append(",Client_ID="+Client_ID);
		sb.append(",Carrier_ID="+Carrier_ID);
		sb.append(",Account_ID="+Account_ID);
		sb.append(",Group_ID="+Group_ID);
		sb.append(",Multi_Birth_Code="+Multi_Birth_Code);
		sb.append(",Member_Key="+Member_Key);
		sb.append(",Source="+Source);
		sb.append(",scd_key="+String.valueOf(scd_key));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(copyOfNoTokenizationStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class copyOfTokenization1Struct implements routines.system.IPersistableRow<copyOfTokenization1Struct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];

	
			    public String DOB;

				public String getDOB () {
					return this.DOB;
				}
				
			    public String firstName;

				public String getFirstName () {
					return this.firstName;
				}
				
			    public String lastName;

				public String getLastName () {
					return this.lastName;
				}
				
			    public String SSN;

				public String getSSN () {
					return this.SSN;
				}
				
			    public String MBI;

				public String getMBI () {
					return this.MBI;
				}
				
			    public String OtherID;

				public String getOtherID () {
					return this.OtherID;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam) {

        	try {

        		int length = 0;
		
					this.DOB = readString(dis);
					
					this.firstName = readString(dis);
					
					this.lastName = readString(dis);
					
					this.SSN = readString(dis);
					
					this.MBI = readString(dis);
					
					this.OtherID = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.DOB,dos);
					
					// String
				
						writeString(this.firstName,dos);
					
					// String
				
						writeString(this.lastName,dos);
					
					// String
				
						writeString(this.SSN,dos);
					
					// String
				
						writeString(this.MBI,dos);
					
					// String
				
						writeString(this.OtherID,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("DOB="+DOB);
		sb.append(",firstName="+firstName);
		sb.append(",lastName="+lastName);
		sb.append(",SSN="+SSN);
		sb.append(",MBI="+MBI);
		sb.append(",OtherID="+OtherID);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(copyOfTokenization1Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row12Struct implements routines.system.IPersistableRow<row12Struct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];

	
			    public String Gender;

				public String getGender () {
					return this.Gender;
				}
				
			    public String Date;

				public String getDate () {
					return this.Date;
				}
				
			    public String First_Name;

				public String getFirst_Name () {
					return this.First_Name;
				}
				
			    public String Last_Name;

				public String getLast_Name () {
					return this.Last_Name;
				}
				
			    public String State;

				public String getState () {
					return this.State;
				}
				
			    public String City;

				public String getCity () {
					return this.City;
				}
				
			    public String Zip_Code;

				public String getZip_Code () {
					return this.Zip_Code;
				}
				
			    public String Address_Line_1;

				public String getAddress_Line_1 () {
					return this.Address_Line_1;
				}
				
			    public String Address_Line_2;

				public String getAddress_Line_2 () {
					return this.Address_Line_2;
				}
				
			    public String Phone_Number;

				public String getPhone_Number () {
					return this.Phone_Number;
				}
				
			    public String Social_Security_Number;

				public String getSocial_Security_Number () {
					return this.Social_Security_Number;
				}
				
			    public String UPI_ID;

				public String getUPI_ID () {
					return this.UPI_ID;
				}
				
			    public String MBI;

				public String getMBI () {
					return this.MBI;
				}
				
			    public String Client_ID;

				public String getClient_ID () {
					return this.Client_ID;
				}
				
			    public String Carrier_ID;

				public String getCarrier_ID () {
					return this.Carrier_ID;
				}
				
			    public String Account_ID;

				public String getAccount_ID () {
					return this.Account_ID;
				}
				
			    public String Group_ID;

				public String getGroup_ID () {
					return this.Group_ID;
				}
				
			    public String Contract_Family_ID;

				public String getContract_Family_ID () {
					return this.Contract_Family_ID;
				}
				
			    public String Multi_Birth_Code;

				public String getMulti_Birth_Code () {
					return this.Multi_Birth_Code;
				}
				
			    public String Member_Key;

				public String getMember_Key () {
					return this.Member_Key;
				}
				
			    public String Source;

				public String getSource () {
					return this.Source;
				}
				
			    public String GID;

				public String getGID () {
					return this.GID;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam) {

        	try {

        		int length = 0;
		
					this.Gender = readString(dis);
					
					this.Date = readString(dis);
					
					this.First_Name = readString(dis);
					
					this.Last_Name = readString(dis);
					
					this.State = readString(dis);
					
					this.City = readString(dis);
					
					this.Zip_Code = readString(dis);
					
					this.Address_Line_1 = readString(dis);
					
					this.Address_Line_2 = readString(dis);
					
					this.Phone_Number = readString(dis);
					
					this.Social_Security_Number = readString(dis);
					
					this.UPI_ID = readString(dis);
					
					this.MBI = readString(dis);
					
					this.Client_ID = readString(dis);
					
					this.Carrier_ID = readString(dis);
					
					this.Account_ID = readString(dis);
					
					this.Group_ID = readString(dis);
					
					this.Contract_Family_ID = readString(dis);
					
					this.Multi_Birth_Code = readString(dis);
					
					this.Member_Key = readString(dis);
					
					this.Source = readString(dis);
					
					this.GID = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Gender,dos);
					
					// String
				
						writeString(this.Date,dos);
					
					// String
				
						writeString(this.First_Name,dos);
					
					// String
				
						writeString(this.Last_Name,dos);
					
					// String
				
						writeString(this.State,dos);
					
					// String
				
						writeString(this.City,dos);
					
					// String
				
						writeString(this.Zip_Code,dos);
					
					// String
				
						writeString(this.Address_Line_1,dos);
					
					// String
				
						writeString(this.Address_Line_2,dos);
					
					// String
				
						writeString(this.Phone_Number,dos);
					
					// String
				
						writeString(this.Social_Security_Number,dos);
					
					// String
				
						writeString(this.UPI_ID,dos);
					
					// String
				
						writeString(this.MBI,dos);
					
					// String
				
						writeString(this.Client_ID,dos);
					
					// String
				
						writeString(this.Carrier_ID,dos);
					
					// String
				
						writeString(this.Account_ID,dos);
					
					// String
				
						writeString(this.Group_ID,dos);
					
					// String
				
						writeString(this.Contract_Family_ID,dos);
					
					// String
				
						writeString(this.Multi_Birth_Code,dos);
					
					// String
				
						writeString(this.Member_Key,dos);
					
					// String
				
						writeString(this.Source,dos);
					
					// String
				
						writeString(this.GID,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Gender="+Gender);
		sb.append(",Date="+Date);
		sb.append(",First_Name="+First_Name);
		sb.append(",Last_Name="+Last_Name);
		sb.append(",State="+State);
		sb.append(",City="+City);
		sb.append(",Zip_Code="+Zip_Code);
		sb.append(",Address_Line_1="+Address_Line_1);
		sb.append(",Address_Line_2="+Address_Line_2);
		sb.append(",Phone_Number="+Phone_Number);
		sb.append(",Social_Security_Number="+Social_Security_Number);
		sb.append(",UPI_ID="+UPI_ID);
		sb.append(",MBI="+MBI);
		sb.append(",Client_ID="+Client_ID);
		sb.append(",Carrier_ID="+Carrier_ID);
		sb.append(",Account_ID="+Account_ID);
		sb.append(",Group_ID="+Group_ID);
		sb.append(",Contract_Family_ID="+Contract_Family_ID);
		sb.append(",Multi_Birth_Code="+Multi_Birth_Code);
		sb.append(",Member_Key="+Member_Key);
		sb.append(",Source="+Source);
		sb.append(",GID="+GID);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row12Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row25Struct implements routines.system.IPersistableRow<row25Struct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];

	
			    public String Gender;

				public String getGender () {
					return this.Gender;
				}
				
			    public String Date;

				public String getDate () {
					return this.Date;
				}
				
			    public String First_Name;

				public String getFirst_Name () {
					return this.First_Name;
				}
				
			    public String Last_Name;

				public String getLast_Name () {
					return this.Last_Name;
				}
				
			    public String State;

				public String getState () {
					return this.State;
				}
				
			    public String City;

				public String getCity () {
					return this.City;
				}
				
			    public String Zip_Code;

				public String getZip_Code () {
					return this.Zip_Code;
				}
				
			    public String Address_Line_1;

				public String getAddress_Line_1 () {
					return this.Address_Line_1;
				}
				
			    public String Address_Line_2;

				public String getAddress_Line_2 () {
					return this.Address_Line_2;
				}
				
			    public String Phone_Number;

				public String getPhone_Number () {
					return this.Phone_Number;
				}
				
			    public String Social_Security_Number;

				public String getSocial_Security_Number () {
					return this.Social_Security_Number;
				}
				
			    public String UPI_ID;

				public String getUPI_ID () {
					return this.UPI_ID;
				}
				
			    public String MBI;

				public String getMBI () {
					return this.MBI;
				}
				
			    public String Client_ID;

				public String getClient_ID () {
					return this.Client_ID;
				}
				
			    public String Carrier_ID;

				public String getCarrier_ID () {
					return this.Carrier_ID;
				}
				
			    public String Account_ID;

				public String getAccount_ID () {
					return this.Account_ID;
				}
				
			    public String Group_ID;

				public String getGroup_ID () {
					return this.Group_ID;
				}
				
			    public String Contract_Family_ID;

				public String getContract_Family_ID () {
					return this.Contract_Family_ID;
				}
				
			    public String Multi_Birth_Code;

				public String getMulti_Birth_Code () {
					return this.Multi_Birth_Code;
				}
				
			    public String Member_Key;

				public String getMember_Key () {
					return this.Member_Key;
				}
				
			    public String Source;

				public String getSource () {
					return this.Source;
				}
				
			    public String GID;

				public String getGID () {
					return this.GID;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam) {

        	try {

        		int length = 0;
		
					this.Gender = readString(dis);
					
					this.Date = readString(dis);
					
					this.First_Name = readString(dis);
					
					this.Last_Name = readString(dis);
					
					this.State = readString(dis);
					
					this.City = readString(dis);
					
					this.Zip_Code = readString(dis);
					
					this.Address_Line_1 = readString(dis);
					
					this.Address_Line_2 = readString(dis);
					
					this.Phone_Number = readString(dis);
					
					this.Social_Security_Number = readString(dis);
					
					this.UPI_ID = readString(dis);
					
					this.MBI = readString(dis);
					
					this.Client_ID = readString(dis);
					
					this.Carrier_ID = readString(dis);
					
					this.Account_ID = readString(dis);
					
					this.Group_ID = readString(dis);
					
					this.Contract_Family_ID = readString(dis);
					
					this.Multi_Birth_Code = readString(dis);
					
					this.Member_Key = readString(dis);
					
					this.Source = readString(dis);
					
					this.GID = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Gender,dos);
					
					// String
				
						writeString(this.Date,dos);
					
					// String
				
						writeString(this.First_Name,dos);
					
					// String
				
						writeString(this.Last_Name,dos);
					
					// String
				
						writeString(this.State,dos);
					
					// String
				
						writeString(this.City,dos);
					
					// String
				
						writeString(this.Zip_Code,dos);
					
					// String
				
						writeString(this.Address_Line_1,dos);
					
					// String
				
						writeString(this.Address_Line_2,dos);
					
					// String
				
						writeString(this.Phone_Number,dos);
					
					// String
				
						writeString(this.Social_Security_Number,dos);
					
					// String
				
						writeString(this.UPI_ID,dos);
					
					// String
				
						writeString(this.MBI,dos);
					
					// String
				
						writeString(this.Client_ID,dos);
					
					// String
				
						writeString(this.Carrier_ID,dos);
					
					// String
				
						writeString(this.Account_ID,dos);
					
					// String
				
						writeString(this.Group_ID,dos);
					
					// String
				
						writeString(this.Contract_Family_ID,dos);
					
					// String
				
						writeString(this.Multi_Birth_Code,dos);
					
					// String
				
						writeString(this.Member_Key,dos);
					
					// String
				
						writeString(this.Source,dos);
					
					// String
				
						writeString(this.GID,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Gender="+Gender);
		sb.append(",Date="+Date);
		sb.append(",First_Name="+First_Name);
		sb.append(",Last_Name="+Last_Name);
		sb.append(",State="+State);
		sb.append(",City="+City);
		sb.append(",Zip_Code="+Zip_Code);
		sb.append(",Address_Line_1="+Address_Line_1);
		sb.append(",Address_Line_2="+Address_Line_2);
		sb.append(",Phone_Number="+Phone_Number);
		sb.append(",Social_Security_Number="+Social_Security_Number);
		sb.append(",UPI_ID="+UPI_ID);
		sb.append(",MBI="+MBI);
		sb.append(",Client_ID="+Client_ID);
		sb.append(",Carrier_ID="+Carrier_ID);
		sb.append(",Account_ID="+Account_ID);
		sb.append(",Group_ID="+Group_ID);
		sb.append(",Contract_Family_ID="+Contract_Family_ID);
		sb.append(",Multi_Birth_Code="+Multi_Birth_Code);
		sb.append(",Member_Key="+Member_Key);
		sb.append(",Source="+Source);
		sb.append(",GID="+GID);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row25Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row24Struct implements routines.system.IPersistableRow<row24Struct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];

	
			    public String Gender;

				public String getGender () {
					return this.Gender;
				}
				
			    public String Date;

				public String getDate () {
					return this.Date;
				}
				
			    public String First_Name;

				public String getFirst_Name () {
					return this.First_Name;
				}
				
			    public String Last_Name;

				public String getLast_Name () {
					return this.Last_Name;
				}
				
			    public String State;

				public String getState () {
					return this.State;
				}
				
			    public String City;

				public String getCity () {
					return this.City;
				}
				
			    public String Zip_Code;

				public String getZip_Code () {
					return this.Zip_Code;
				}
				
			    public String Address_Line_1;

				public String getAddress_Line_1 () {
					return this.Address_Line_1;
				}
				
			    public String Address_Line_2;

				public String getAddress_Line_2 () {
					return this.Address_Line_2;
				}
				
			    public String Phone_Number;

				public String getPhone_Number () {
					return this.Phone_Number;
				}
				
			    public String Social_Security_Number;

				public String getSocial_Security_Number () {
					return this.Social_Security_Number;
				}
				
			    public String UPI_ID;

				public String getUPI_ID () {
					return this.UPI_ID;
				}
				
			    public String MBI;

				public String getMBI () {
					return this.MBI;
				}
				
			    public String Client_ID;

				public String getClient_ID () {
					return this.Client_ID;
				}
				
			    public String Carrier_ID;

				public String getCarrier_ID () {
					return this.Carrier_ID;
				}
				
			    public String Account_ID;

				public String getAccount_ID () {
					return this.Account_ID;
				}
				
			    public String Group_ID;

				public String getGroup_ID () {
					return this.Group_ID;
				}
				
			    public String Contract_Family_ID;

				public String getContract_Family_ID () {
					return this.Contract_Family_ID;
				}
				
			    public String Multi_Birth_Code;

				public String getMulti_Birth_Code () {
					return this.Multi_Birth_Code;
				}
				
			    public String Member_Key;

				public String getMember_Key () {
					return this.Member_Key;
				}
				
			    public String Source;

				public String getSource () {
					return this.Source;
				}
				
			    public String year;

				public String getYear () {
					return this.year;
				}
				
			    public String GID;

				public String getGID () {
					return this.GID;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam) {

        	try {

        		int length = 0;
		
					this.Gender = readString(dis);
					
					this.Date = readString(dis);
					
					this.First_Name = readString(dis);
					
					this.Last_Name = readString(dis);
					
					this.State = readString(dis);
					
					this.City = readString(dis);
					
					this.Zip_Code = readString(dis);
					
					this.Address_Line_1 = readString(dis);
					
					this.Address_Line_2 = readString(dis);
					
					this.Phone_Number = readString(dis);
					
					this.Social_Security_Number = readString(dis);
					
					this.UPI_ID = readString(dis);
					
					this.MBI = readString(dis);
					
					this.Client_ID = readString(dis);
					
					this.Carrier_ID = readString(dis);
					
					this.Account_ID = readString(dis);
					
					this.Group_ID = readString(dis);
					
					this.Contract_Family_ID = readString(dis);
					
					this.Multi_Birth_Code = readString(dis);
					
					this.Member_Key = readString(dis);
					
					this.Source = readString(dis);
					
					this.year = readString(dis);
					
					this.GID = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Gender,dos);
					
					// String
				
						writeString(this.Date,dos);
					
					// String
				
						writeString(this.First_Name,dos);
					
					// String
				
						writeString(this.Last_Name,dos);
					
					// String
				
						writeString(this.State,dos);
					
					// String
				
						writeString(this.City,dos);
					
					// String
				
						writeString(this.Zip_Code,dos);
					
					// String
				
						writeString(this.Address_Line_1,dos);
					
					// String
				
						writeString(this.Address_Line_2,dos);
					
					// String
				
						writeString(this.Phone_Number,dos);
					
					// String
				
						writeString(this.Social_Security_Number,dos);
					
					// String
				
						writeString(this.UPI_ID,dos);
					
					// String
				
						writeString(this.MBI,dos);
					
					// String
				
						writeString(this.Client_ID,dos);
					
					// String
				
						writeString(this.Carrier_ID,dos);
					
					// String
				
						writeString(this.Account_ID,dos);
					
					// String
				
						writeString(this.Group_ID,dos);
					
					// String
				
						writeString(this.Contract_Family_ID,dos);
					
					// String
				
						writeString(this.Multi_Birth_Code,dos);
					
					// String
				
						writeString(this.Member_Key,dos);
					
					// String
				
						writeString(this.Source,dos);
					
					// String
				
						writeString(this.year,dos);
					
					// String
				
						writeString(this.GID,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Gender="+Gender);
		sb.append(",Date="+Date);
		sb.append(",First_Name="+First_Name);
		sb.append(",Last_Name="+Last_Name);
		sb.append(",State="+State);
		sb.append(",City="+City);
		sb.append(",Zip_Code="+Zip_Code);
		sb.append(",Address_Line_1="+Address_Line_1);
		sb.append(",Address_Line_2="+Address_Line_2);
		sb.append(",Phone_Number="+Phone_Number);
		sb.append(",Social_Security_Number="+Social_Security_Number);
		sb.append(",UPI_ID="+UPI_ID);
		sb.append(",MBI="+MBI);
		sb.append(",Client_ID="+Client_ID);
		sb.append(",Carrier_ID="+Carrier_ID);
		sb.append(",Account_ID="+Account_ID);
		sb.append(",Group_ID="+Group_ID);
		sb.append(",Contract_Family_ID="+Contract_Family_ID);
		sb.append(",Multi_Birth_Code="+Multi_Birth_Code);
		sb.append(",Member_Key="+Member_Key);
		sb.append(",Source="+Source);
		sb.append(",year="+year);
		sb.append(",GID="+GID);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row24Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class OnRowsEndStructtSortRow_1 implements routines.system.IPersistableRow<OnRowsEndStructtSortRow_1> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];

	
			    public String Gender;

				public String getGender () {
					return this.Gender;
				}
				
			    public String Date;

				public String getDate () {
					return this.Date;
				}
				
			    public String First_Name;

				public String getFirst_Name () {
					return this.First_Name;
				}
				
			    public String Last_Name;

				public String getLast_Name () {
					return this.Last_Name;
				}
				
			    public String State;

				public String getState () {
					return this.State;
				}
				
			    public String City;

				public String getCity () {
					return this.City;
				}
				
			    public String Zip_Code;

				public String getZip_Code () {
					return this.Zip_Code;
				}
				
			    public String Address_Line_1;

				public String getAddress_Line_1 () {
					return this.Address_Line_1;
				}
				
			    public String Address_Line_2;

				public String getAddress_Line_2 () {
					return this.Address_Line_2;
				}
				
			    public String Phone_Number;

				public String getPhone_Number () {
					return this.Phone_Number;
				}
				
			    public String Social_Security_Number;

				public String getSocial_Security_Number () {
					return this.Social_Security_Number;
				}
				
			    public String UPI_ID;

				public String getUPI_ID () {
					return this.UPI_ID;
				}
				
			    public String MBI;

				public String getMBI () {
					return this.MBI;
				}
				
			    public String Client_ID;

				public String getClient_ID () {
					return this.Client_ID;
				}
				
			    public String Carrier_ID;

				public String getCarrier_ID () {
					return this.Carrier_ID;
				}
				
			    public String Account_ID;

				public String getAccount_ID () {
					return this.Account_ID;
				}
				
			    public String Group_ID;

				public String getGroup_ID () {
					return this.Group_ID;
				}
				
			    public String Contract_Family_ID;

				public String getContract_Family_ID () {
					return this.Contract_Family_ID;
				}
				
			    public String Multi_Birth_Code;

				public String getMulti_Birth_Code () {
					return this.Multi_Birth_Code;
				}
				
			    public String Member_Key;

				public String getMember_Key () {
					return this.Member_Key;
				}
				
			    public String Source;

				public String getSource () {
					return this.Source;
				}
				
			    public String year;

				public String getYear () {
					return this.year;
				}
				
			    public String GID;

				public String getGID () {
					return this.GID;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam) {

        	try {

        		int length = 0;
		
					this.Gender = readString(dis);
					
					this.Date = readString(dis);
					
					this.First_Name = readString(dis);
					
					this.Last_Name = readString(dis);
					
					this.State = readString(dis);
					
					this.City = readString(dis);
					
					this.Zip_Code = readString(dis);
					
					this.Address_Line_1 = readString(dis);
					
					this.Address_Line_2 = readString(dis);
					
					this.Phone_Number = readString(dis);
					
					this.Social_Security_Number = readString(dis);
					
					this.UPI_ID = readString(dis);
					
					this.MBI = readString(dis);
					
					this.Client_ID = readString(dis);
					
					this.Carrier_ID = readString(dis);
					
					this.Account_ID = readString(dis);
					
					this.Group_ID = readString(dis);
					
					this.Contract_Family_ID = readString(dis);
					
					this.Multi_Birth_Code = readString(dis);
					
					this.Member_Key = readString(dis);
					
					this.Source = readString(dis);
					
					this.year = readString(dis);
					
					this.GID = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Gender,dos);
					
					// String
				
						writeString(this.Date,dos);
					
					// String
				
						writeString(this.First_Name,dos);
					
					// String
				
						writeString(this.Last_Name,dos);
					
					// String
				
						writeString(this.State,dos);
					
					// String
				
						writeString(this.City,dos);
					
					// String
				
						writeString(this.Zip_Code,dos);
					
					// String
				
						writeString(this.Address_Line_1,dos);
					
					// String
				
						writeString(this.Address_Line_2,dos);
					
					// String
				
						writeString(this.Phone_Number,dos);
					
					// String
				
						writeString(this.Social_Security_Number,dos);
					
					// String
				
						writeString(this.UPI_ID,dos);
					
					// String
				
						writeString(this.MBI,dos);
					
					// String
				
						writeString(this.Client_ID,dos);
					
					// String
				
						writeString(this.Carrier_ID,dos);
					
					// String
				
						writeString(this.Account_ID,dos);
					
					// String
				
						writeString(this.Group_ID,dos);
					
					// String
				
						writeString(this.Contract_Family_ID,dos);
					
					// String
				
						writeString(this.Multi_Birth_Code,dos);
					
					// String
				
						writeString(this.Member_Key,dos);
					
					// String
				
						writeString(this.Source,dos);
					
					// String
				
						writeString(this.year,dos);
					
					// String
				
						writeString(this.GID,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Gender="+Gender);
		sb.append(",Date="+Date);
		sb.append(",First_Name="+First_Name);
		sb.append(",Last_Name="+Last_Name);
		sb.append(",State="+State);
		sb.append(",City="+City);
		sb.append(",Zip_Code="+Zip_Code);
		sb.append(",Address_Line_1="+Address_Line_1);
		sb.append(",Address_Line_2="+Address_Line_2);
		sb.append(",Phone_Number="+Phone_Number);
		sb.append(",Social_Security_Number="+Social_Security_Number);
		sb.append(",UPI_ID="+UPI_ID);
		sb.append(",MBI="+MBI);
		sb.append(",Client_ID="+Client_ID);
		sb.append(",Carrier_ID="+Carrier_ID);
		sb.append(",Account_ID="+Account_ID);
		sb.append(",Group_ID="+Group_ID);
		sb.append(",Contract_Family_ID="+Contract_Family_ID);
		sb.append(",Multi_Birth_Code="+Multi_Birth_Code);
		sb.append(",Member_Key="+Member_Key);
		sb.append(",Source="+Source);
		sb.append(",year="+year);
		sb.append(",GID="+GID);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(OnRowsEndStructtSortRow_1 other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row23Struct implements routines.system.IPersistableRow<row23Struct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];

	
			    public String Gender;

				public String getGender () {
					return this.Gender;
				}
				
			    public String Date;

				public String getDate () {
					return this.Date;
				}
				
			    public String First_Name;

				public String getFirst_Name () {
					return this.First_Name;
				}
				
			    public String Last_Name;

				public String getLast_Name () {
					return this.Last_Name;
				}
				
			    public String State;

				public String getState () {
					return this.State;
				}
				
			    public String City;

				public String getCity () {
					return this.City;
				}
				
			    public String Zip_Code;

				public String getZip_Code () {
					return this.Zip_Code;
				}
				
			    public String Address_Line_1;

				public String getAddress_Line_1 () {
					return this.Address_Line_1;
				}
				
			    public String Address_Line_2;

				public String getAddress_Line_2 () {
					return this.Address_Line_2;
				}
				
			    public String Phone_Number;

				public String getPhone_Number () {
					return this.Phone_Number;
				}
				
			    public String Social_Security_Number;

				public String getSocial_Security_Number () {
					return this.Social_Security_Number;
				}
				
			    public String UPI_ID;

				public String getUPI_ID () {
					return this.UPI_ID;
				}
				
			    public String MBI;

				public String getMBI () {
					return this.MBI;
				}
				
			    public String Client_ID;

				public String getClient_ID () {
					return this.Client_ID;
				}
				
			    public String Carrier_ID;

				public String getCarrier_ID () {
					return this.Carrier_ID;
				}
				
			    public String Account_ID;

				public String getAccount_ID () {
					return this.Account_ID;
				}
				
			    public String Group_ID;

				public String getGroup_ID () {
					return this.Group_ID;
				}
				
			    public String Contract_Family_ID;

				public String getContract_Family_ID () {
					return this.Contract_Family_ID;
				}
				
			    public String Multi_Birth_Code;

				public String getMulti_Birth_Code () {
					return this.Multi_Birth_Code;
				}
				
			    public String Member_Key;

				public String getMember_Key () {
					return this.Member_Key;
				}
				
			    public String Source;

				public String getSource () {
					return this.Source;
				}
				
			    public String year;

				public String getYear () {
					return this.year;
				}
				
			    public String GID;

				public String getGID () {
					return this.GID;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam) {

        	try {

        		int length = 0;
		
					this.Gender = readString(dis);
					
					this.Date = readString(dis);
					
					this.First_Name = readString(dis);
					
					this.Last_Name = readString(dis);
					
					this.State = readString(dis);
					
					this.City = readString(dis);
					
					this.Zip_Code = readString(dis);
					
					this.Address_Line_1 = readString(dis);
					
					this.Address_Line_2 = readString(dis);
					
					this.Phone_Number = readString(dis);
					
					this.Social_Security_Number = readString(dis);
					
					this.UPI_ID = readString(dis);
					
					this.MBI = readString(dis);
					
					this.Client_ID = readString(dis);
					
					this.Carrier_ID = readString(dis);
					
					this.Account_ID = readString(dis);
					
					this.Group_ID = readString(dis);
					
					this.Contract_Family_ID = readString(dis);
					
					this.Multi_Birth_Code = readString(dis);
					
					this.Member_Key = readString(dis);
					
					this.Source = readString(dis);
					
					this.year = readString(dis);
					
					this.GID = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Gender,dos);
					
					// String
				
						writeString(this.Date,dos);
					
					// String
				
						writeString(this.First_Name,dos);
					
					// String
				
						writeString(this.Last_Name,dos);
					
					// String
				
						writeString(this.State,dos);
					
					// String
				
						writeString(this.City,dos);
					
					// String
				
						writeString(this.Zip_Code,dos);
					
					// String
				
						writeString(this.Address_Line_1,dos);
					
					// String
				
						writeString(this.Address_Line_2,dos);
					
					// String
				
						writeString(this.Phone_Number,dos);
					
					// String
				
						writeString(this.Social_Security_Number,dos);
					
					// String
				
						writeString(this.UPI_ID,dos);
					
					// String
				
						writeString(this.MBI,dos);
					
					// String
				
						writeString(this.Client_ID,dos);
					
					// String
				
						writeString(this.Carrier_ID,dos);
					
					// String
				
						writeString(this.Account_ID,dos);
					
					// String
				
						writeString(this.Group_ID,dos);
					
					// String
				
						writeString(this.Contract_Family_ID,dos);
					
					// String
				
						writeString(this.Multi_Birth_Code,dos);
					
					// String
				
						writeString(this.Member_Key,dos);
					
					// String
				
						writeString(this.Source,dos);
					
					// String
				
						writeString(this.year,dos);
					
					// String
				
						writeString(this.GID,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Gender="+Gender);
		sb.append(",Date="+Date);
		sb.append(",First_Name="+First_Name);
		sb.append(",Last_Name="+Last_Name);
		sb.append(",State="+State);
		sb.append(",City="+City);
		sb.append(",Zip_Code="+Zip_Code);
		sb.append(",Address_Line_1="+Address_Line_1);
		sb.append(",Address_Line_2="+Address_Line_2);
		sb.append(",Phone_Number="+Phone_Number);
		sb.append(",Social_Security_Number="+Social_Security_Number);
		sb.append(",UPI_ID="+UPI_ID);
		sb.append(",MBI="+MBI);
		sb.append(",Client_ID="+Client_ID);
		sb.append(",Carrier_ID="+Carrier_ID);
		sb.append(",Account_ID="+Account_ID);
		sb.append(",Group_ID="+Group_ID);
		sb.append(",Contract_Family_ID="+Contract_Family_ID);
		sb.append(",Multi_Birth_Code="+Multi_Birth_Code);
		sb.append(",Member_Key="+Member_Key);
		sb.append(",Source="+Source);
		sb.append(",year="+year);
		sb.append(",GID="+GID);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row23Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row17Struct implements routines.system.IPersistableRow<row17Struct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];

	
			    public String Gender;

				public String getGender () {
					return this.Gender;
				}
				
			    public String Date;

				public String getDate () {
					return this.Date;
				}
				
			    public String First_Name;

				public String getFirst_Name () {
					return this.First_Name;
				}
				
			    public String Last_Name;

				public String getLast_Name () {
					return this.Last_Name;
				}
				
			    public String State;

				public String getState () {
					return this.State;
				}
				
			    public String City;

				public String getCity () {
					return this.City;
				}
				
			    public String Zip_Code;

				public String getZip_Code () {
					return this.Zip_Code;
				}
				
			    public String Address_Line_1;

				public String getAddress_Line_1 () {
					return this.Address_Line_1;
				}
				
			    public String Address_Line_2;

				public String getAddress_Line_2 () {
					return this.Address_Line_2;
				}
				
			    public String Phone_Number;

				public String getPhone_Number () {
					return this.Phone_Number;
				}
				
			    public String Social_Security_Number;

				public String getSocial_Security_Number () {
					return this.Social_Security_Number;
				}
				
			    public String UPI_ID;

				public String getUPI_ID () {
					return this.UPI_ID;
				}
				
			    public String MBI;

				public String getMBI () {
					return this.MBI;
				}
				
			    public String Client_ID;

				public String getClient_ID () {
					return this.Client_ID;
				}
				
			    public String Carrier_ID;

				public String getCarrier_ID () {
					return this.Carrier_ID;
				}
				
			    public String Account_ID;

				public String getAccount_ID () {
					return this.Account_ID;
				}
				
			    public String Group_ID;

				public String getGroup_ID () {
					return this.Group_ID;
				}
				
			    public String Contract_Family_ID;

				public String getContract_Family_ID () {
					return this.Contract_Family_ID;
				}
				
			    public String Multi_Birth_Code;

				public String getMulti_Birth_Code () {
					return this.Multi_Birth_Code;
				}
				
			    public String Member_Key;

				public String getMember_Key () {
					return this.Member_Key;
				}
				
			    public String Source;

				public String getSource () {
					return this.Source;
				}
				
			    public String year;

				public String getYear () {
					return this.year;
				}
				
			    public String GID;

				public String getGID () {
					return this.GID;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam) {

        	try {

        		int length = 0;
		
					this.Gender = readString(dis);
					
					this.Date = readString(dis);
					
					this.First_Name = readString(dis);
					
					this.Last_Name = readString(dis);
					
					this.State = readString(dis);
					
					this.City = readString(dis);
					
					this.Zip_Code = readString(dis);
					
					this.Address_Line_1 = readString(dis);
					
					this.Address_Line_2 = readString(dis);
					
					this.Phone_Number = readString(dis);
					
					this.Social_Security_Number = readString(dis);
					
					this.UPI_ID = readString(dis);
					
					this.MBI = readString(dis);
					
					this.Client_ID = readString(dis);
					
					this.Carrier_ID = readString(dis);
					
					this.Account_ID = readString(dis);
					
					this.Group_ID = readString(dis);
					
					this.Contract_Family_ID = readString(dis);
					
					this.Multi_Birth_Code = readString(dis);
					
					this.Member_Key = readString(dis);
					
					this.Source = readString(dis);
					
					this.year = readString(dis);
					
					this.GID = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Gender,dos);
					
					// String
				
						writeString(this.Date,dos);
					
					// String
				
						writeString(this.First_Name,dos);
					
					// String
				
						writeString(this.Last_Name,dos);
					
					// String
				
						writeString(this.State,dos);
					
					// String
				
						writeString(this.City,dos);
					
					// String
				
						writeString(this.Zip_Code,dos);
					
					// String
				
						writeString(this.Address_Line_1,dos);
					
					// String
				
						writeString(this.Address_Line_2,dos);
					
					// String
				
						writeString(this.Phone_Number,dos);
					
					// String
				
						writeString(this.Social_Security_Number,dos);
					
					// String
				
						writeString(this.UPI_ID,dos);
					
					// String
				
						writeString(this.MBI,dos);
					
					// String
				
						writeString(this.Client_ID,dos);
					
					// String
				
						writeString(this.Carrier_ID,dos);
					
					// String
				
						writeString(this.Account_ID,dos);
					
					// String
				
						writeString(this.Group_ID,dos);
					
					// String
				
						writeString(this.Contract_Family_ID,dos);
					
					// String
				
						writeString(this.Multi_Birth_Code,dos);
					
					// String
				
						writeString(this.Member_Key,dos);
					
					// String
				
						writeString(this.Source,dos);
					
					// String
				
						writeString(this.year,dos);
					
					// String
				
						writeString(this.GID,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Gender="+Gender);
		sb.append(",Date="+Date);
		sb.append(",First_Name="+First_Name);
		sb.append(",Last_Name="+Last_Name);
		sb.append(",State="+State);
		sb.append(",City="+City);
		sb.append(",Zip_Code="+Zip_Code);
		sb.append(",Address_Line_1="+Address_Line_1);
		sb.append(",Address_Line_2="+Address_Line_2);
		sb.append(",Phone_Number="+Phone_Number);
		sb.append(",Social_Security_Number="+Social_Security_Number);
		sb.append(",UPI_ID="+UPI_ID);
		sb.append(",MBI="+MBI);
		sb.append(",Client_ID="+Client_ID);
		sb.append(",Carrier_ID="+Carrier_ID);
		sb.append(",Account_ID="+Account_ID);
		sb.append(",Group_ID="+Group_ID);
		sb.append(",Contract_Family_ID="+Contract_Family_ID);
		sb.append(",Multi_Birth_Code="+Multi_Birth_Code);
		sb.append(",Member_Key="+Member_Key);
		sb.append(",Source="+Source);
		sb.append(",year="+year);
		sb.append(",GID="+GID);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row17Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row15Struct implements routines.system.IPersistableRow<row15Struct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];

	
			    public String GID;

				public String getGID () {
					return this.GID;
				}
				
			    public Integer count;

				public Integer getCount () {
					return this.count;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam) {

        	try {

        		int length = 0;
		
					this.GID = readString(dis);
					
						this.count = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.GID,dos);
					
					// Integer
				
						writeInteger(this.count,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("GID="+GID);
		sb.append(",count="+String.valueOf(count));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row15Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFileInputDelimited_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileInputDelimited_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
		String currentVirtualComponent = null;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row15Struct row15 = new row15Struct();
row17Struct row17 = new row17Struct();
row23Struct row23 = new row23Struct();
row24Struct row24 = new row24Struct();
row25Struct row25 = new row25Struct();
row25Struct row12 = row25;
copyOfNoTokenizationStruct copyOfNoTokenization = new copyOfNoTokenizationStruct();
copyOfTokenization1Struct copyOfTokenization1 = new copyOfTokenization1Struct();




	
	/**
	 * [tFlowToIterate_3 begin ] start
	 */

				
			int NB_ITERATE_tFileInputDelimited_3 = 0; //for statistics
			

	
		
		ok_Hash.put("tFlowToIterate_3", false);
		start_Hash.put("tFlowToIterate_3", System.currentTimeMillis());
		
	
	currentComponent="tFlowToIterate_3";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row15");
			
		int tos_count_tFlowToIterate_3 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tFlowToIterate_3", "tFlowToIterate");
				talendJobLogProcess(globalMap);
			}
			

int nb_line_tFlowToIterate_3 = 0;
int counter_tFlowToIterate_3 = 0;

 



/**
 * [tFlowToIterate_3 begin ] stop
 */



	
	/**
	 * [tFileInputDelimited_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputDelimited_2", false);
		start_Hash.put("tFileInputDelimited_2", System.currentTimeMillis());
		
	
	currentComponent="tFileInputDelimited_2";

	
		int tos_count_tFileInputDelimited_2 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tFileInputDelimited_2", "tFileInputDelimited");
				talendJobLogProcess(globalMap);
			}
			
	
	
	
 
	
	
	final routines.system.RowState rowstate_tFileInputDelimited_2 = new routines.system.RowState();
	
	
				int nb_line_tFileInputDelimited_2 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_2 = null;
				int limit_tFileInputDelimited_2 = -1;
				try{
					
						Object filename_tFileInputDelimited_2 = context.location+"GroupID.csv";
						if(filename_tFileInputDelimited_2 instanceof java.io.InputStream){
							
			int footer_value_tFileInputDelimited_2 = 0, random_value_tFileInputDelimited_2 = -1;
			if(footer_value_tFileInputDelimited_2 >0 || random_value_tFileInputDelimited_2 > 0){
				throw new java.lang.Exception("When the input source is a stream,footer and random shouldn't be bigger than 0.");				
			}
		
						}
						try {
							fid_tFileInputDelimited_2 = new org.talend.fileprocess.FileInputDelimited(context.location+"GroupID.csv", "ISO-8859-15",";","\n",false,1,0,
									limit_tFileInputDelimited_2
								,-1, false);
						} catch(java.lang.Exception e) {
							
								
								System.err.println(e.getMessage());
							
						}
					
				    
					while (fid_tFileInputDelimited_2!=null && fid_tFileInputDelimited_2.nextRecord()) {
						rowstate_tFileInputDelimited_2.reset();
						
			    						row15 = null;			
												
									boolean whetherReject_tFileInputDelimited_2 = false;
									row15 = new row15Struct();
									try {
										
				int columnIndexWithD_tFileInputDelimited_2 = 0;
				
					String temp = ""; 
				
					columnIndexWithD_tFileInputDelimited_2 = 0;
					
							row15.GID = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
						
				
					columnIndexWithD_tFileInputDelimited_2 = 1;
					
						temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
						if(temp.length() > 0) {
							
								try {
								
    								row15.count = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_2) {
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"count", "row15", temp, ex_tFileInputDelimited_2), ex_tFileInputDelimited_2));
								}
    							
						} else {						
							
								
									row15.count = null;
								
							
						}
					
				
				
										
										if(rowstate_tFileInputDelimited_2.getException()!=null) {
											throw rowstate_tFileInputDelimited_2.getException();
										}
										
										
							
			    					} catch (java.lang.Exception e) {
			        					whetherReject_tFileInputDelimited_2 = true;
			        					
			                					System.err.println(e.getMessage());
			                					row15 = null;
			                				
			    					}
								

 



/**
 * [tFileInputDelimited_2 begin ] stop
 */
	
	/**
	 * [tFileInputDelimited_2 main ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_2";

	

 


	tos_count_tFileInputDelimited_2++;

/**
 * [tFileInputDelimited_2 main ] stop
 */
	
	/**
	 * [tFileInputDelimited_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_2";

	

 



/**
 * [tFileInputDelimited_2 process_data_begin ] stop
 */
// Start of branch "row15"
if(row15 != null) { 



	
	/**
	 * [tFlowToIterate_3 main ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_3";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"row15");
			

	
    	
              globalMap.put("GID_out", row15.GID); 
	   nb_line_tFlowToIterate_3++;  
       counter_tFlowToIterate_3++;
       globalMap.put("tFlowToIterate_3_CURRENT_ITERATION", counter_tFlowToIterate_3);
 


	tos_count_tFlowToIterate_3++;

/**
 * [tFlowToIterate_3 main ] stop
 */
	
	/**
	 * [tFlowToIterate_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_3";

	

 



/**
 * [tFlowToIterate_3 process_data_begin ] stop
 */
	NB_ITERATE_tFileInputDelimited_3++;
	
	
					if(execStat){				
	       				runStat.updateStatOnConnection("row17", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("copyOfTokenization1", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row25", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row12", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row23", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("copyOfNoTokenization", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnRowsEnd", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row24", 3, 0);
					}           			
				
				if(execStat){
					runStat.updateStatOnConnection("iterate3", 1, "exec" + NB_ITERATE_tFileInputDelimited_3);
					//Thread.sleep(1000);
				}				
			



	
	/**
	 * [tSortRow_1_SortOut begin ] start
	 */

	

	
		
		ok_Hash.put("tSortRow_1_SortOut", false);
		start_Hash.put("tSortRow_1_SortOut", System.currentTimeMillis());
		
	
		currentVirtualComponent = "tSortRow_1";
	
	currentComponent="tSortRow_1_SortOut";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row23");
			
		int tos_count_tSortRow_1_SortOut = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tSortRow_1_SortOut", "tSortOut");
				talendJobLogProcess(globalMap);
			}
			


////////////////////////////////////
class row23StructILightSerializable extends row23Struct implements
                        org.talend.designer.components.tsort.io.beans.ILightSerializable<row23StructILightSerializable> {

	public int compareTo(row23StructILightSerializable other) {

		if(this.MBI == null && other.MBI != null){
			return 1;
						
		}else if(this.MBI != null && other.MBI == null){
			return -1;
						
		}else if(this.MBI != null && other.MBI != null){
			if(!this.MBI.equals(other.MBI)){
				return other.MBI.compareTo(this.MBI);
			}
		}
		if(this.Social_Security_Number == null && other.Social_Security_Number != null){
			return 1;
						
		}else if(this.Social_Security_Number != null && other.Social_Security_Number == null){
			return -1;
						
		}else if(this.Social_Security_Number != null && other.Social_Security_Number != null){
			if(!this.Social_Security_Number.equals(other.Social_Security_Number)){
				return other.Social_Security_Number.compareTo(this.Social_Security_Number);
			}
		}
		return 0;
	}

	public org.talend.designer.components.tsort.io.beans.ILightSerializable createInstance(byte[] byteArray) {
		row23StructILightSerializable result = new row23StructILightSerializable();
		java.io.ByteArrayInputStream bai = null;
		java.io.DataInputStream dis = null;

		try {
			bai = new java.io.ByteArrayInputStream(byteArray);
			dis = new java.io.DataInputStream(bai);
			int length = 0;
			            length = dis.readInt();
           				if (length == -1) {
           	    			result.Gender = null;
           				} else {
               				byte[] bytes = new byte[length];
               				dis.read(bytes);
               				result.Gender = new String(bytes, utf8Charset);
           				}
					
			            length = dis.readInt();
           				if (length == -1) {
           	    			result.Date = null;
           				} else {
               				byte[] bytes = new byte[length];
               				dis.read(bytes);
               				result.Date = new String(bytes, utf8Charset);
           				}
					
			            length = dis.readInt();
           				if (length == -1) {
           	    			result.First_Name = null;
           				} else {
               				byte[] bytes = new byte[length];
               				dis.read(bytes);
               				result.First_Name = new String(bytes, utf8Charset);
           				}
					
			            length = dis.readInt();
           				if (length == -1) {
           	    			result.Last_Name = null;
           				} else {
               				byte[] bytes = new byte[length];
               				dis.read(bytes);
               				result.Last_Name = new String(bytes, utf8Charset);
           				}
					
			            length = dis.readInt();
           				if (length == -1) {
           	    			result.State = null;
           				} else {
               				byte[] bytes = new byte[length];
               				dis.read(bytes);
               				result.State = new String(bytes, utf8Charset);
           				}
					
			            length = dis.readInt();
           				if (length == -1) {
           	    			result.City = null;
           				} else {
               				byte[] bytes = new byte[length];
               				dis.read(bytes);
               				result.City = new String(bytes, utf8Charset);
           				}
					
			            length = dis.readInt();
           				if (length == -1) {
           	    			result.Zip_Code = null;
           				} else {
               				byte[] bytes = new byte[length];
               				dis.read(bytes);
               				result.Zip_Code = new String(bytes, utf8Charset);
           				}
					
			            length = dis.readInt();
           				if (length == -1) {
           	    			result.Address_Line_1 = null;
           				} else {
               				byte[] bytes = new byte[length];
               				dis.read(bytes);
               				result.Address_Line_1 = new String(bytes, utf8Charset);
           				}
					
			            length = dis.readInt();
           				if (length == -1) {
           	    			result.Address_Line_2 = null;
           				} else {
               				byte[] bytes = new byte[length];
               				dis.read(bytes);
               				result.Address_Line_2 = new String(bytes, utf8Charset);
           				}
					
			            length = dis.readInt();
           				if (length == -1) {
           	    			result.Phone_Number = null;
           				} else {
               				byte[] bytes = new byte[length];
               				dis.read(bytes);
               				result.Phone_Number = new String(bytes, utf8Charset);
           				}
					
			            length = dis.readInt();
           				if (length == -1) {
           	    			result.Social_Security_Number = null;
           				} else {
               				byte[] bytes = new byte[length];
               				dis.read(bytes);
               				result.Social_Security_Number = new String(bytes, utf8Charset);
           				}
					
			            length = dis.readInt();
           				if (length == -1) {
           	    			result.UPI_ID = null;
           				} else {
               				byte[] bytes = new byte[length];
               				dis.read(bytes);
               				result.UPI_ID = new String(bytes, utf8Charset);
           				}
					
			            length = dis.readInt();
           				if (length == -1) {
           	    			result.MBI = null;
           				} else {
               				byte[] bytes = new byte[length];
               				dis.read(bytes);
               				result.MBI = new String(bytes, utf8Charset);
           				}
					
			            length = dis.readInt();
           				if (length == -1) {
           	    			result.Client_ID = null;
           				} else {
               				byte[] bytes = new byte[length];
               				dis.read(bytes);
               				result.Client_ID = new String(bytes, utf8Charset);
           				}
					
			            length = dis.readInt();
           				if (length == -1) {
           	    			result.Carrier_ID = null;
           				} else {
               				byte[] bytes = new byte[length];
               				dis.read(bytes);
               				result.Carrier_ID = new String(bytes, utf8Charset);
           				}
					
			            length = dis.readInt();
           				if (length == -1) {
           	    			result.Account_ID = null;
           				} else {
               				byte[] bytes = new byte[length];
               				dis.read(bytes);
               				result.Account_ID = new String(bytes, utf8Charset);
           				}
					
			            length = dis.readInt();
           				if (length == -1) {
           	    			result.Group_ID = null;
           				} else {
               				byte[] bytes = new byte[length];
               				dis.read(bytes);
               				result.Group_ID = new String(bytes, utf8Charset);
           				}
					
			            length = dis.readInt();
           				if (length == -1) {
           	    			result.Contract_Family_ID = null;
           				} else {
               				byte[] bytes = new byte[length];
               				dis.read(bytes);
               				result.Contract_Family_ID = new String(bytes, utf8Charset);
           				}
					
			            length = dis.readInt();
           				if (length == -1) {
           	    			result.Multi_Birth_Code = null;
           				} else {
               				byte[] bytes = new byte[length];
               				dis.read(bytes);
               				result.Multi_Birth_Code = new String(bytes, utf8Charset);
           				}
					
			            length = dis.readInt();
           				if (length == -1) {
           	    			result.Member_Key = null;
           				} else {
               				byte[] bytes = new byte[length];
               				dis.read(bytes);
               				result.Member_Key = new String(bytes, utf8Charset);
           				}
					
			            length = dis.readInt();
           				if (length == -1) {
           	    			result.Source = null;
           				} else {
               				byte[] bytes = new byte[length];
               				dis.read(bytes);
               				result.Source = new String(bytes, utf8Charset);
           				}
					
			            length = dis.readInt();
           				if (length == -1) {
           	    			result.year = null;
           				} else {
               				byte[] bytes = new byte[length];
               				dis.read(bytes);
               				result.year = new String(bytes, utf8Charset);
           				}
					
			            length = dis.readInt();
           				if (length == -1) {
           	    			result.GID = null;
           				} else {
               				byte[] bytes = new byte[length];
               				dis.read(bytes);
               				result.GID = new String(bytes, utf8Charset);
           				}
					

		} catch (java.lang.Exception e) {
			e.printStackTrace();
		} finally {
			if (dis != null) {
				try {
					dis.close();
            } catch (java.io.IOException e) {
            	e.printStackTrace();
         	}
        	}
     	}

   	return result;
   }

	public byte[] toByteArray() {
 		java.io.ByteArrayOutputStream bao = null;
		java.io.DataOutputStream dos = null;
		byte[] result = null;

 		try {
			bao = new java.io.ByteArrayOutputStream();
			dos = new java.io.DataOutputStream(bao);
			if(this.Gender == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = this.Gender.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
					
			if(this.Date == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = this.Date.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
					
			if(this.First_Name == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = this.First_Name.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
					
			if(this.Last_Name == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = this.Last_Name.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
					
			if(this.State == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = this.State.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
					
			if(this.City == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = this.City.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
					
			if(this.Zip_Code == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = this.Zip_Code.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
					
			if(this.Address_Line_1 == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = this.Address_Line_1.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
					
			if(this.Address_Line_2 == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = this.Address_Line_2.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
					
			if(this.Phone_Number == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = this.Phone_Number.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
					
			if(this.Social_Security_Number == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = this.Social_Security_Number.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
					
			if(this.UPI_ID == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = this.UPI_ID.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
					
			if(this.MBI == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = this.MBI.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
					
			if(this.Client_ID == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = this.Client_ID.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
					
			if(this.Carrier_ID == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = this.Carrier_ID.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
					
			if(this.Account_ID == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = this.Account_ID.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
					
			if(this.Group_ID == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = this.Group_ID.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
					
			if(this.Contract_Family_ID == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = this.Contract_Family_ID.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
					
			if(this.Multi_Birth_Code == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = this.Multi_Birth_Code.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
					
			if(this.Member_Key == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = this.Member_Key.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
					
			if(this.Source == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = this.Source.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
					
			if(this.year == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = this.year.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
					
			if(this.GID == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = this.GID.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
					
    	} catch (java.lang.Exception e) {
     		throw new RuntimeException(e);
		} finally {
     		if (dos != null) {
         		try {
            		dos.close();
           		} catch (java.io.IOException e) {
        			e.printStackTrace();
          		}
        	}
     	}
     	result = bao.toByteArray();
    	return result;
  	}


}
// /////////////////////////////////
  java.io.File dir_tSortRow_1_SortOut = new java.io.File("C:/Talend/Talend-Studio/UPI_bkp/temp");
  if (!dir_tSortRow_1_SortOut.exists()){
    dir_tSortRow_1_SortOut.mkdirs();
  }
  dir_tSortRow_1_SortOut = null;

org.talend.designer.components.tsort.io.sortimpl.FlowSorterIterator<row23StructILightSerializable> iterator_tSortRow_1_SortOut = new org.talend.designer.components.tsort.io.sortimpl.FlowSorterIterator<row23StructILightSerializable>();
iterator_tSortRow_1_SortOut.setBufferSize(1000000);
iterator_tSortRow_1_SortOut.setILightSerializable(new row23StructILightSerializable());
iterator_tSortRow_1_SortOut.workDirectory = "C:/Talend/Talend-Studio/UPI_bkp/temp" + "/" + jobName + "tSortRow_1_SortOut _" + Thread.currentThread().getId() + "_" + pid;
iterator_tSortRow_1_SortOut.initPut("");


 



/**
 * [tSortRow_1_SortOut begin ] stop
 */



	
	/**
	 * [tFilterRow_23 begin ] start
	 */

	

	
		
		ok_Hash.put("tFilterRow_23", false);
		start_Hash.put("tFilterRow_23", System.currentTimeMillis());
		
	
	currentComponent="tFilterRow_23";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row17");
			
		int tos_count_tFilterRow_23 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tFilterRow_23", "tFilterRow");
				talendJobLogProcess(globalMap);
			}
			
    int nb_line_tFilterRow_23 = 0;
    int nb_line_ok_tFilterRow_23 = 0;
    int nb_line_reject_tFilterRow_23 = 0;

    class Operator_tFilterRow_23 {
      private String sErrorMsg = "";
      private boolean bMatchFlag = true;
      private String sUnionFlag = "&&";

      public Operator_tFilterRow_23(String unionFlag){
        sUnionFlag = unionFlag;
        bMatchFlag =  "||".equals(unionFlag) ? false : true;
      }

      public String getErrorMsg() {
        if (sErrorMsg != null && sErrorMsg.length() > 1)
          return sErrorMsg.substring(1);
        else 
          return null;
      }

      public boolean getMatchFlag() {
        return bMatchFlag;
      }

      public void matches(boolean partMatched, String reason) {
        // no need to care about the next judgement
        if ("||".equals(sUnionFlag) && bMatchFlag){
          return;
        }

        if (!partMatched) {
          sErrorMsg += "|" + reason;
        }

        if ("||".equals(sUnionFlag))
          bMatchFlag = bMatchFlag || partMatched;
        else
          bMatchFlag = bMatchFlag && partMatched;
      }
    }

 



/**
 * [tFilterRow_23 begin ] stop
 */



	
	/**
	 * [tFileInputDelimited_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputDelimited_3", false);
		start_Hash.put("tFileInputDelimited_3", System.currentTimeMillis());
		
	
	currentComponent="tFileInputDelimited_3";

	
		int tos_count_tFileInputDelimited_3 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tFileInputDelimited_3", "tFileInputDelimited");
				talendJobLogProcess(globalMap);
			}
			
	
	
	
 
	
	
	final routines.system.RowState rowstate_tFileInputDelimited_3 = new routines.system.RowState();
	
	
				int nb_line_tFileInputDelimited_3 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_3 = null;
				int limit_tFileInputDelimited_3 = -1;
				try{
					
						Object filename_tFileInputDelimited_3 = ((String)globalMap.get("tCreateTemporaryFile_1_FILEPATH"));
						if(filename_tFileInputDelimited_3 instanceof java.io.InputStream){
							
			int footer_value_tFileInputDelimited_3 = 0, random_value_tFileInputDelimited_3 = -1;
			if(footer_value_tFileInputDelimited_3 >0 || random_value_tFileInputDelimited_3 > 0){
				throw new java.lang.Exception("When the input source is a stream,footer and random shouldn't be bigger than 0.");				
			}
		
						}
						try {
							fid_tFileInputDelimited_3 = new org.talend.fileprocess.FileInputDelimited(((String)globalMap.get("tCreateTemporaryFile_1_FILEPATH")), "ISO-8859-15",";","\n",false,1,0,
									limit_tFileInputDelimited_3
								,-1, false);
						} catch(java.lang.Exception e) {
							
								
								System.err.println(e.getMessage());
							
						}
					
				    
					while (fid_tFileInputDelimited_3!=null && fid_tFileInputDelimited_3.nextRecord()) {
						rowstate_tFileInputDelimited_3.reset();
						
			    						row17 = null;			
												
									boolean whetherReject_tFileInputDelimited_3 = false;
									row17 = new row17Struct();
									try {
										
				int columnIndexWithD_tFileInputDelimited_3 = 0;
				
					columnIndexWithD_tFileInputDelimited_3 = 0;
					
							row17.Gender = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 1;
					
							row17.Date = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 2;
					
							row17.First_Name = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 3;
					
							row17.Last_Name = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 4;
					
							row17.State = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 5;
					
							row17.City = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 6;
					
							row17.Zip_Code = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 7;
					
							row17.Address_Line_1 = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 8;
					
							row17.Address_Line_2 = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 9;
					
							row17.Phone_Number = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 10;
					
							row17.Social_Security_Number = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 11;
					
							row17.UPI_ID = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 12;
					
							row17.MBI = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 13;
					
							row17.Client_ID = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 14;
					
							row17.Carrier_ID = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 15;
					
							row17.Account_ID = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 16;
					
							row17.Group_ID = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 17;
					
							row17.Contract_Family_ID = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 18;
					
							row17.Multi_Birth_Code = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 19;
					
							row17.Member_Key = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 20;
					
							row17.Source = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 21;
					
							row17.year = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 22;
					
							row17.GID = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
				
										
										if(rowstate_tFileInputDelimited_3.getException()!=null) {
											throw rowstate_tFileInputDelimited_3.getException();
										}
										
										
							
			    					} catch (java.lang.Exception e) {
			        					whetherReject_tFileInputDelimited_3 = true;
			        					
			                					System.err.println(e.getMessage());
			                					row17 = null;
			                				
			    					}
								

 



/**
 * [tFileInputDelimited_3 begin ] stop
 */
	
	/**
	 * [tFileInputDelimited_3 main ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_3";

	

 


	tos_count_tFileInputDelimited_3++;

/**
 * [tFileInputDelimited_3 main ] stop
 */
	
	/**
	 * [tFileInputDelimited_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_3";

	

 



/**
 * [tFileInputDelimited_3 process_data_begin ] stop
 */
// Start of branch "row17"
if(row17 != null) { 



	
	/**
	 * [tFilterRow_23 main ] start
	 */

	

	
	
	currentComponent="tFilterRow_23";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"row17");
			

          row23 = null;
    Operator_tFilterRow_23 ope_tFilterRow_23 = new Operator_tFilterRow_23("&&");
            ope_tFilterRow_23.matches((row17.GID == null? false : row17.GID.compareTo(((String)globalMap.get("GID_out"))) == 0)
                           , "GID.compareTo(((String)globalMap.get(\"GID_out\"))) == 0 failed");
    
    if (ope_tFilterRow_23.getMatchFlag()) {
              if(row23 == null){ 
                row23 = new row23Struct();
              }
               row23.Gender = row17.Gender;
               row23.Date = row17.Date;
               row23.First_Name = row17.First_Name;
               row23.Last_Name = row17.Last_Name;
               row23.State = row17.State;
               row23.City = row17.City;
               row23.Zip_Code = row17.Zip_Code;
               row23.Address_Line_1 = row17.Address_Line_1;
               row23.Address_Line_2 = row17.Address_Line_2;
               row23.Phone_Number = row17.Phone_Number;
               row23.Social_Security_Number = row17.Social_Security_Number;
               row23.UPI_ID = row17.UPI_ID;
               row23.MBI = row17.MBI;
               row23.Client_ID = row17.Client_ID;
               row23.Carrier_ID = row17.Carrier_ID;
               row23.Account_ID = row17.Account_ID;
               row23.Group_ID = row17.Group_ID;
               row23.Contract_Family_ID = row17.Contract_Family_ID;
               row23.Multi_Birth_Code = row17.Multi_Birth_Code;
               row23.Member_Key = row17.Member_Key;
               row23.Source = row17.Source;
               row23.year = row17.year;
               row23.GID = row17.GID;    
      nb_line_ok_tFilterRow_23++;
    } else {
      nb_line_reject_tFilterRow_23++;
    }

nb_line_tFilterRow_23++;

 


	tos_count_tFilterRow_23++;

/**
 * [tFilterRow_23 main ] stop
 */
	
	/**
	 * [tFilterRow_23 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFilterRow_23";

	

 



/**
 * [tFilterRow_23 process_data_begin ] stop
 */
// Start of branch "row23"
if(row23 != null) { 



	
	/**
	 * [tSortRow_1_SortOut main ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_1";
	
	currentComponent="tSortRow_1_SortOut";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"row23");
			


	row23StructILightSerializable current_tSortRow_1_SortOut = new row23StructILightSerializable();
	current_tSortRow_1_SortOut.Gender = row23.Gender;
	current_tSortRow_1_SortOut.Date = row23.Date;
	current_tSortRow_1_SortOut.First_Name = row23.First_Name;
	current_tSortRow_1_SortOut.Last_Name = row23.Last_Name;
	current_tSortRow_1_SortOut.State = row23.State;
	current_tSortRow_1_SortOut.City = row23.City;
	current_tSortRow_1_SortOut.Zip_Code = row23.Zip_Code;
	current_tSortRow_1_SortOut.Address_Line_1 = row23.Address_Line_1;
	current_tSortRow_1_SortOut.Address_Line_2 = row23.Address_Line_2;
	current_tSortRow_1_SortOut.Phone_Number = row23.Phone_Number;
	current_tSortRow_1_SortOut.Social_Security_Number = row23.Social_Security_Number;
	current_tSortRow_1_SortOut.UPI_ID = row23.UPI_ID;
	current_tSortRow_1_SortOut.MBI = row23.MBI;
	current_tSortRow_1_SortOut.Client_ID = row23.Client_ID;
	current_tSortRow_1_SortOut.Carrier_ID = row23.Carrier_ID;
	current_tSortRow_1_SortOut.Account_ID = row23.Account_ID;
	current_tSortRow_1_SortOut.Group_ID = row23.Group_ID;
	current_tSortRow_1_SortOut.Contract_Family_ID = row23.Contract_Family_ID;
	current_tSortRow_1_SortOut.Multi_Birth_Code = row23.Multi_Birth_Code;
	current_tSortRow_1_SortOut.Member_Key = row23.Member_Key;
	current_tSortRow_1_SortOut.Source = row23.Source;
	current_tSortRow_1_SortOut.year = row23.year;
	current_tSortRow_1_SortOut.GID = row23.GID;	
	iterator_tSortRow_1_SortOut.put("", current_tSortRow_1_SortOut);

 


	tos_count_tSortRow_1_SortOut++;

/**
 * [tSortRow_1_SortOut main ] stop
 */
	
	/**
	 * [tSortRow_1_SortOut process_data_begin ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_1";
	
	currentComponent="tSortRow_1_SortOut";

	

 



/**
 * [tSortRow_1_SortOut process_data_begin ] stop
 */
	
	/**
	 * [tSortRow_1_SortOut process_data_end ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_1";
	
	currentComponent="tSortRow_1_SortOut";

	

 



/**
 * [tSortRow_1_SortOut process_data_end ] stop
 */

} // End of branch "row23"




	
	/**
	 * [tFilterRow_23 process_data_end ] start
	 */

	

	
	
	currentComponent="tFilterRow_23";

	

 



/**
 * [tFilterRow_23 process_data_end ] stop
 */

} // End of branch "row17"




	
	/**
	 * [tFileInputDelimited_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_3";

	

 



/**
 * [tFileInputDelimited_3 process_data_end ] stop
 */
	
	/**
	 * [tFileInputDelimited_3 end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_3";

	



            }
            }finally{
                if(!((Object)(((String)globalMap.get("tCreateTemporaryFile_1_FILEPATH"))) instanceof java.io.InputStream)){
                	if(fid_tFileInputDelimited_3!=null){
                		fid_tFileInputDelimited_3.close();
                	}
                }
                if(fid_tFileInputDelimited_3!=null){
                	globalMap.put("tFileInputDelimited_3_NB_LINE", fid_tFileInputDelimited_3.getRowNumber());
					
                }
			}
			  

 

ok_Hash.put("tFileInputDelimited_3", true);
end_Hash.put("tFileInputDelimited_3", System.currentTimeMillis());




/**
 * [tFileInputDelimited_3 end ] stop
 */

	
	/**
	 * [tFilterRow_23 end ] start
	 */

	

	
	
	currentComponent="tFilterRow_23";

	
    globalMap.put("tFilterRow_23_NB_LINE", nb_line_tFilterRow_23);
    globalMap.put("tFilterRow_23_NB_LINE_OK", nb_line_ok_tFilterRow_23);
    globalMap.put("tFilterRow_23_NB_LINE_REJECT", nb_line_reject_tFilterRow_23);
    

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row17",2,0,
			 			talendJobLog,"tFileInputDelimited_3","tFileInputDelimited","tFilterRow_23","tFilterRow","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tFilterRow_23", true);
end_Hash.put("tFilterRow_23", System.currentTimeMillis());




/**
 * [tFilterRow_23 end ] stop
 */

	
	/**
	 * [tSortRow_1_SortOut end ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_1";
	
	currentComponent="tSortRow_1_SortOut";

	

iterator_tSortRow_1_SortOut.endPut();

globalMap.put("tSortRow_1", iterator_tSortRow_1_SortOut);

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row23",2,0,
			 			talendJobLog,"tFilterRow_23","tFilterRow","tSortRow_1_SortOut","tSortOut","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tSortRow_1_SortOut", true);
end_Hash.put("tSortRow_1_SortOut", System.currentTimeMillis());




/**
 * [tSortRow_1_SortOut end ] stop
 */





	
	/**
	 * [tDBOutput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_1", false);
		start_Hash.put("tDBOutput_1", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_1";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"copyOfNoTokenization");
			
		int tos_count_tDBOutput_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_1", "tOracleOutput");
				talendJobLogProcess(globalMap);
			}
			






    int nb_line_tDBOutput_1 = 0;
    int nb_line_update_tDBOutput_1 = 0;
    int nb_line_inserted_tDBOutput_1 = 0;
    int nb_line_deleted_tDBOutput_1 = 0;
    int nb_line_rejected_tDBOutput_1 = 0;

    int tmp_batchUpdateCount_tDBOutput_1 = 0;

    int deletedCount_tDBOutput_1=0;
    int updatedCount_tDBOutput_1=0;
    int insertedCount_tDBOutput_1=0;
    int rejectedCount_tDBOutput_1=0;

    boolean whetherReject_tDBOutput_1 = false;

    java.sql.Connection conn_tDBOutput_1 = null;

    //optional table
    String dbschema_tDBOutput_1 = null;
    String tableName_tDBOutput_1 = null;
        dbschema_tDBOutput_1 = (String)globalMap.get("dbschema_tDBConnection_1");
		
        conn_tDBOutput_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
        int count_tDBOutput_1=0;

        if(dbschema_tDBOutput_1 == null || dbschema_tDBOutput_1.trim().length() == 0) {
            tableName_tDBOutput_1 = ("TokenizationNotRequired_after");
        } else {
            tableName_tDBOutput_1 = dbschema_tDBOutput_1 + "." + ("TokenizationNotRequired_after");
        }
                                String tableNameForSearch_tDBOutput_1= "" + ((String)"TokenizationNotRequired_after") + "";
String dbschemaForSearch_tDBOutput_1= null;
if(dbschema_tDBOutput_1== null || dbschema_tDBOutput_1.trim().length() == 0) {
dbschemaForSearch_tDBOutput_1= ((String)globalMap.get("username_tDBConnection_1")).toUpperCase();
} else {
dbschemaForSearch_tDBOutput_1= dbschema_tDBOutput_1.toUpperCase();
}

                                java.sql.DatabaseMetaData dbMetaData_tDBOutput_1 = conn_tDBOutput_1.getMetaData();
                                if(tableNameForSearch_tDBOutput_1.indexOf("\"")==-1){
                                    tableNameForSearch_tDBOutput_1 = tableNameForSearch_tDBOutput_1.toUpperCase();
                                }else{
                                    tableNameForSearch_tDBOutput_1 = tableNameForSearch_tDBOutput_1.replaceAll("\"","");
                                }
                                boolean whetherExist_tDBOutput_1 = false;
                                try (java.sql.ResultSet rsTable_tDBOutput_1 = dbMetaData_tDBOutput_1.getTables(null, dbschemaForSearch_tDBOutput_1, tableNameForSearch_tDBOutput_1, new String[]{"TABLE"})) {
                                    if(rsTable_tDBOutput_1.next()) {
                                        whetherExist_tDBOutput_1 = true;
                                    }
                                }

                                if(whetherExist_tDBOutput_1) {
                                    try (java.sql.Statement stmtDrop_tDBOutput_1 = conn_tDBOutput_1.createStatement()) {
                                        stmtDrop_tDBOutput_1.execute("DROP TABLE " + tableName_tDBOutput_1 + "" );
                                    }
                                }
                                try(java.sql.Statement stmtCreate_tDBOutput_1 = conn_tDBOutput_1.createStatement()) {
                                    stmtCreate_tDBOutput_1.execute("CREATE TABLE " + tableName_tDBOutput_1 + "(Gender VARCHAR2(1)  ,State VARCHAR2(2)  ,City VARCHAR2(50)  ,Zip_Code VARCHAR2(15)  ,Address_Line_1 VARCHAR2(50)  ,Address_Line_2 VARCHAR2(50)  ,Phone_Number VARCHAR2(10)  ,UPI_ID VARCHAR2(40)  ,Client_ID VARCHAR2(32)  ,Carrier_ID VARCHAR2(32)  ,Account_ID VARCHAR2(32)  ,Group_ID VARCHAR2(32)  ,Multi_Birth_Code VARCHAR2(10)  ,Member_Key VARCHAR2(38)  ,Source VARCHAR2(15)  ,scd_key INT  not null )");
                                }
                String insert_tDBOutput_1 = "INSERT INTO " + tableName_tDBOutput_1 + " (Gender,State,City,Zip_Code,Address_Line_1,Address_Line_2,Phone_Number,UPI_ID,Client_ID,Carrier_ID,Account_ID,Group_ID,Multi_Birth_Code,Member_Key,Source,scd_key) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";    

                        java.sql.PreparedStatement pstmt_tDBOutput_1 = conn_tDBOutput_1.prepareStatement(insert_tDBOutput_1);
                        resourceMap.put("pstmt_tDBOutput_1", pstmt_tDBOutput_1);





 



/**
 * [tDBOutput_1 begin ] stop
 */




	
	/**
	 * [tFileOutputJSON_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileOutputJSON_1", false);
		start_Hash.put("tFileOutputJSON_1", System.currentTimeMillis());
		
	
	currentComponent="tFileOutputJSON_1";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"copyOfTokenization1");
			
		int tos_count_tFileOutputJSON_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tFileOutputJSON_1", "tFileOutputJSON");
				talendJobLogProcess(globalMap);
			}
			
int nb_line_tFileOutputJSON_1 = 0;
java.io.File file_tFileOutputJSON_1 = new java.io.File(context.jsonfile_after);
java.io.File dir_tFileOutputJSON_1 = file_tFileOutputJSON_1.getParentFile();
	if(dir_tFileOutputJSON_1!=null && !dir_tFileOutputJSON_1.exists()){
		dir_tFileOutputJSON_1.mkdirs();
	}
java.io.PrintWriter outtFileOutputJSON_1 = new java.io.PrintWriter(new java.io.BufferedWriter(new java.io.FileWriter(context.jsonfile_after)));
	outtFileOutputJSON_1.append("[");
boolean isFirst_tFileOutputJSON_1 = true;
 



/**
 * [tFileOutputJSON_1 begin ] stop
 */



	
	/**
	 * [tMap_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_3", false);
		start_Hash.put("tMap_3", System.currentTimeMillis());
		
	
	currentComponent="tMap_3";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row12");
			
		int tos_count_tMap_3 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tMap_3", "tMap");
				talendJobLogProcess(globalMap);
			}
			




// ###############################
// # Lookup's keys initialization
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_3__Struct  {
	int var1;
}
Var__tMap_3__Struct Var__tMap_3 = new Var__tMap_3__Struct();
// ###############################

// ###############################
// # Outputs initialization
copyOfNoTokenizationStruct copyOfNoTokenization_tmp = new copyOfNoTokenizationStruct();
copyOfTokenization1Struct copyOfTokenization1_tmp = new copyOfTokenization1Struct();
// ###############################

        
        



        









 



/**
 * [tMap_3 begin ] stop
 */



	
	/**
	 * [tBufferOutput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tBufferOutput_3", false);
		start_Hash.put("tBufferOutput_3", System.currentTimeMillis());
		
	
	currentComponent="tBufferOutput_3";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row25");
			
		int tos_count_tBufferOutput_3 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tBufferOutput_3", "tBufferOutput");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tBufferOutput_3 begin ] stop
 */



	
	/**
	 * [tJavaFlex_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tJavaFlex_2", false);
		start_Hash.put("tJavaFlex_2", System.currentTimeMillis());
		
	
	currentComponent="tJavaFlex_2";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row24");
			
		int tos_count_tJavaFlex_2 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tJavaFlex_2", "tJavaFlex");
				talendJobLogProcess(globalMap);
			}
			


int i=0;
MemberUpis memberUpis= new MemberUpis();
Map<Integer,String> upis=null;
Member member;
String upi=null;



 



/**
 * [tJavaFlex_2 begin ] stop
 */



	
	/**
	 * [tSortRow_1_SortIn begin ] start
	 */

	

	
		
		ok_Hash.put("tSortRow_1_SortIn", false);
		start_Hash.put("tSortRow_1_SortIn", System.currentTimeMillis());
		
	
		currentVirtualComponent = "tSortRow_1";
	
	currentComponent="tSortRow_1_SortIn";

	
		int tos_count_tSortRow_1_SortIn = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tSortRow_1_SortIn", "tSortIn");
				talendJobLogProcess(globalMap);
			}
			


java.util.Iterator<row23Struct> iterator_tSortRow_1_SortIn = (java.util.Iterator<row23Struct>) globalMap.remove("tSortRow_1");
int nb_line_tSortRow_1_SortIn = 0;
row23Struct current_tSortRow_1_SortIn = null;

while (iterator_tSortRow_1_SortIn.hasNext()) {
	current_tSortRow_1_SortIn = iterator_tSortRow_1_SortIn.next();
	row24.Gender = current_tSortRow_1_SortIn.Gender;
	row24.Date = current_tSortRow_1_SortIn.Date;
	row24.First_Name = current_tSortRow_1_SortIn.First_Name;
	row24.Last_Name = current_tSortRow_1_SortIn.Last_Name;
	row24.State = current_tSortRow_1_SortIn.State;
	row24.City = current_tSortRow_1_SortIn.City;
	row24.Zip_Code = current_tSortRow_1_SortIn.Zip_Code;
	row24.Address_Line_1 = current_tSortRow_1_SortIn.Address_Line_1;
	row24.Address_Line_2 = current_tSortRow_1_SortIn.Address_Line_2;
	row24.Phone_Number = current_tSortRow_1_SortIn.Phone_Number;
	row24.Social_Security_Number = current_tSortRow_1_SortIn.Social_Security_Number;
	row24.UPI_ID = current_tSortRow_1_SortIn.UPI_ID;
	row24.MBI = current_tSortRow_1_SortIn.MBI;
	row24.Client_ID = current_tSortRow_1_SortIn.Client_ID;
	row24.Carrier_ID = current_tSortRow_1_SortIn.Carrier_ID;
	row24.Account_ID = current_tSortRow_1_SortIn.Account_ID;
	row24.Group_ID = current_tSortRow_1_SortIn.Group_ID;
	row24.Contract_Family_ID = current_tSortRow_1_SortIn.Contract_Family_ID;
	row24.Multi_Birth_Code = current_tSortRow_1_SortIn.Multi_Birth_Code;
	row24.Member_Key = current_tSortRow_1_SortIn.Member_Key;
	row24.Source = current_tSortRow_1_SortIn.Source;
	row24.year = current_tSortRow_1_SortIn.year;
	row24.GID = current_tSortRow_1_SortIn.GID;	
	// increase number of line sorted
	nb_line_tSortRow_1_SortIn++;

 



/**
 * [tSortRow_1_SortIn begin ] stop
 */
	
	/**
	 * [tSortRow_1_SortIn main ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_1";
	
	currentComponent="tSortRow_1_SortIn";

	

 


	tos_count_tSortRow_1_SortIn++;

/**
 * [tSortRow_1_SortIn main ] stop
 */
	
	/**
	 * [tSortRow_1_SortIn process_data_begin ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_1";
	
	currentComponent="tSortRow_1_SortIn";

	

 



/**
 * [tSortRow_1_SortIn process_data_begin ] stop
 */

	
	/**
	 * [tJavaFlex_2 main ] start
	 */

	

	
	
	currentComponent="tJavaFlex_2";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"row24");
			


	        				row25.Gender = row24.Gender;
	        				row25.Date = row24.Date;
	        				row25.First_Name = row24.First_Name;
	        				row25.Last_Name = row24.Last_Name;
	        				row25.State = row24.State;
	        				row25.City = row24.City;
	        				row25.Zip_Code = row24.Zip_Code;
	        				row25.Address_Line_1 = row24.Address_Line_1;
	        				row25.Address_Line_2 = row24.Address_Line_2;
	        				row25.Phone_Number = row24.Phone_Number;
	        				row25.Social_Security_Number = row24.Social_Security_Number;
	        				row25.UPI_ID = row24.UPI_ID;
	        				row25.MBI = row24.MBI;
	        				row25.Client_ID = row24.Client_ID;
	        				row25.Carrier_ID = row24.Carrier_ID;
	        				row25.Account_ID = row24.Account_ID;
	        				row25.Group_ID = row24.Group_ID;
	        				row25.Contract_Family_ID = row24.Contract_Family_ID;
	        				row25.Multi_Birth_Code = row24.Multi_Birth_Code;
	        				row25.Member_Key = row24.Member_Key;
	        				row25.Source = row24.Source;
	        				row25.GID = row24.GID;



member = new Member(row24.Gender, row24.First_Name, row24.Last_Name, row24.Date, row24.State, row24.City, row24.Zip_Code, row24.Address_Line_1,row24.Address_Line_2,row24.Phone_Number,row24.Social_Security_Number,null, row24.MBI,row24.Multi_Birth_Code,row24.Client_ID, row24.Carrier_ID, row24.Account_ID,row24.Group_ID, row24.Contract_Family_ID,null);
//System.out.println(i+": "+ member.toString());
 
upi=memberUpis.addToGraph(member, i, 85);
 
if(upi==null){
      memberUpis.contractGraph();
      upis = memberUpis.getUpis();
      upi = upis.get(i);
}

row25.UPI_ID = upi;
//System.out.println(i+" : '"+row16.MBI+", "+upi+"', '"+row14.UPI_ID+"'");
i++;


 


	tos_count_tJavaFlex_2++;

/**
 * [tJavaFlex_2 main ] stop
 */
	
	/**
	 * [tJavaFlex_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tJavaFlex_2";

	

 



/**
 * [tJavaFlex_2 process_data_begin ] stop
 */

	
	/**
	 * [tBufferOutput_3 main ] start
	 */

	

	
	
	currentComponent="tBufferOutput_3";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"row25");
			



String[] row_tBufferOutput_3=new String[]{"","","","","","","","","","","","","","","","","","","","","","",};		
	    if(row25.Gender != null){
	        
	            row_tBufferOutput_3[0] = row25.Gender;
	                        			    
	    }else{
	    	row_tBufferOutput_3[0] = null;
	    }
	    if(row25.Date != null){
	        
	            row_tBufferOutput_3[1] = row25.Date;
	                        			    
	    }else{
	    	row_tBufferOutput_3[1] = null;
	    }
	    if(row25.First_Name != null){
	        
	            row_tBufferOutput_3[2] = row25.First_Name;
	                        			    
	    }else{
	    	row_tBufferOutput_3[2] = null;
	    }
	    if(row25.Last_Name != null){
	        
	            row_tBufferOutput_3[3] = row25.Last_Name;
	                        			    
	    }else{
	    	row_tBufferOutput_3[3] = null;
	    }
	    if(row25.State != null){
	        
	            row_tBufferOutput_3[4] = row25.State;
	                        			    
	    }else{
	    	row_tBufferOutput_3[4] = null;
	    }
	    if(row25.City != null){
	        
	            row_tBufferOutput_3[5] = row25.City;
	                        			    
	    }else{
	    	row_tBufferOutput_3[5] = null;
	    }
	    if(row25.Zip_Code != null){
	        
	            row_tBufferOutput_3[6] = row25.Zip_Code;
	                        			    
	    }else{
	    	row_tBufferOutput_3[6] = null;
	    }
	    if(row25.Address_Line_1 != null){
	        
	            row_tBufferOutput_3[7] = row25.Address_Line_1;
	                        			    
	    }else{
	    	row_tBufferOutput_3[7] = null;
	    }
	    if(row25.Address_Line_2 != null){
	        
	            row_tBufferOutput_3[8] = row25.Address_Line_2;
	                        			    
	    }else{
	    	row_tBufferOutput_3[8] = null;
	    }
	    if(row25.Phone_Number != null){
	        
	            row_tBufferOutput_3[9] = row25.Phone_Number;
	                        			    
	    }else{
	    	row_tBufferOutput_3[9] = null;
	    }
	    if(row25.Social_Security_Number != null){
	        
	            row_tBufferOutput_3[10] = row25.Social_Security_Number;
	                        			    
	    }else{
	    	row_tBufferOutput_3[10] = null;
	    }
	    if(row25.UPI_ID != null){
	        
	            row_tBufferOutput_3[11] = row25.UPI_ID;
	                        			    
	    }else{
	    	row_tBufferOutput_3[11] = null;
	    }
	    if(row25.MBI != null){
	        
	            row_tBufferOutput_3[12] = row25.MBI;
	                        			    
	    }else{
	    	row_tBufferOutput_3[12] = null;
	    }
	    if(row25.Client_ID != null){
	        
	            row_tBufferOutput_3[13] = row25.Client_ID;
	                        			    
	    }else{
	    	row_tBufferOutput_3[13] = null;
	    }
	    if(row25.Carrier_ID != null){
	        
	            row_tBufferOutput_3[14] = row25.Carrier_ID;
	                        			    
	    }else{
	    	row_tBufferOutput_3[14] = null;
	    }
	    if(row25.Account_ID != null){
	        
	            row_tBufferOutput_3[15] = row25.Account_ID;
	                        			    
	    }else{
	    	row_tBufferOutput_3[15] = null;
	    }
	    if(row25.Group_ID != null){
	        
	            row_tBufferOutput_3[16] = row25.Group_ID;
	                        			    
	    }else{
	    	row_tBufferOutput_3[16] = null;
	    }
	    if(row25.Contract_Family_ID != null){
	        
	            row_tBufferOutput_3[17] = row25.Contract_Family_ID;
	                        			    
	    }else{
	    	row_tBufferOutput_3[17] = null;
	    }
	    if(row25.Multi_Birth_Code != null){
	        
	            row_tBufferOutput_3[18] = row25.Multi_Birth_Code;
	                        			    
	    }else{
	    	row_tBufferOutput_3[18] = null;
	    }
	    if(row25.Member_Key != null){
	        
	            row_tBufferOutput_3[19] = row25.Member_Key;
	                        			    
	    }else{
	    	row_tBufferOutput_3[19] = null;
	    }
	    if(row25.Source != null){
	        
	            row_tBufferOutput_3[20] = row25.Source;
	                        			    
	    }else{
	    	row_tBufferOutput_3[20] = null;
	    }
	    if(row25.GID != null){
	        
	            row_tBufferOutput_3[21] = row25.GID;
	                        			    
	    }else{
	    	row_tBufferOutput_3[21] = null;
	    }
	globalBuffer.add(row_tBufferOutput_3);	
	
 
     row12 = row25;


	tos_count_tBufferOutput_3++;

/**
 * [tBufferOutput_3 main ] stop
 */
	
	/**
	 * [tBufferOutput_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tBufferOutput_3";

	

 



/**
 * [tBufferOutput_3 process_data_begin ] stop
 */

	
	/**
	 * [tMap_3 main ] start
	 */

	

	
	
	currentComponent="tMap_3";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"row12");
			

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_3 = false;
		
        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_3 = false;
		  boolean mainRowRejected_tMap_3 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_3__Struct Var = Var__tMap_3;
Var.var1 = Numeric.sequence("s3",1,1) ;// ###############################
        // ###############################
        // # Output tables

copyOfNoTokenization = null;
copyOfTokenization1 = null;


// # Output table : 'copyOfNoTokenization'
copyOfNoTokenization_tmp.Gender = row12.Gender ;
copyOfNoTokenization_tmp.State = row12.State ;
copyOfNoTokenization_tmp.City = row12.City ;
copyOfNoTokenization_tmp.Zip_Code = row12.Zip_Code ;
copyOfNoTokenization_tmp.Address_Line_1 = row12.Address_Line_1 ;
copyOfNoTokenization_tmp.Address_Line_2 = row12.Address_Line_2 ;
copyOfNoTokenization_tmp.Phone_Number = row12.Phone_Number ;
copyOfNoTokenization_tmp.UPI_ID = row12.UPI_ID ;
copyOfNoTokenization_tmp.Client_ID = row12.Client_ID ;
copyOfNoTokenization_tmp.Carrier_ID = row12.Carrier_ID ;
copyOfNoTokenization_tmp.Account_ID = row12.Account_ID ;
copyOfNoTokenization_tmp.Group_ID = row12.Group_ID ;
copyOfNoTokenization_tmp.Multi_Birth_Code = row12.Multi_Birth_Code ;
copyOfNoTokenization_tmp.Member_Key = row12.Member_Key ;
copyOfNoTokenization_tmp.Source = row12.Source ;
copyOfNoTokenization_tmp.scd_key = Var.var1 ;
copyOfNoTokenization = copyOfNoTokenization_tmp;

// # Output table : 'copyOfTokenization1'
copyOfTokenization1_tmp.DOB = row12.Date ;
copyOfTokenization1_tmp.firstName = row12.First_Name ;
copyOfTokenization1_tmp.lastName = row12.Last_Name ;
copyOfTokenization1_tmp.SSN = row12.Social_Security_Number ;
copyOfTokenization1_tmp.MBI = row12.MBI ;
copyOfTokenization1_tmp.OtherID = row12.Contract_Family_ID ;
copyOfTokenization1 = copyOfTokenization1_tmp;
// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_3 = false;










 


	tos_count_tMap_3++;

/**
 * [tMap_3 main ] stop
 */
	
	/**
	 * [tMap_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_3";

	

 



/**
 * [tMap_3 process_data_begin ] stop
 */
// Start of branch "copyOfNoTokenization"
if(copyOfNoTokenization != null) { 



	
	/**
	 * [tDBOutput_1 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"copyOfNoTokenization");
			



        whetherReject_tDBOutput_1 = false;
                        if(copyOfNoTokenization.Gender == null) {
pstmt_tDBOutput_1.setNull(1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(1, copyOfNoTokenization.Gender);
}

                        if(copyOfNoTokenization.State == null) {
pstmt_tDBOutput_1.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(2, copyOfNoTokenization.State);
}

                        if(copyOfNoTokenization.City == null) {
pstmt_tDBOutput_1.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(3, copyOfNoTokenization.City);
}

                        if(copyOfNoTokenization.Zip_Code == null) {
pstmt_tDBOutput_1.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(4, copyOfNoTokenization.Zip_Code);
}

                        if(copyOfNoTokenization.Address_Line_1 == null) {
pstmt_tDBOutput_1.setNull(5, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(5, copyOfNoTokenization.Address_Line_1);
}

                        if(copyOfNoTokenization.Address_Line_2 == null) {
pstmt_tDBOutput_1.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(6, copyOfNoTokenization.Address_Line_2);
}

                        if(copyOfNoTokenization.Phone_Number == null) {
pstmt_tDBOutput_1.setNull(7, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(7, copyOfNoTokenization.Phone_Number);
}

                        if(copyOfNoTokenization.UPI_ID == null) {
pstmt_tDBOutput_1.setNull(8, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(8, copyOfNoTokenization.UPI_ID);
}

                        if(copyOfNoTokenization.Client_ID == null) {
pstmt_tDBOutput_1.setNull(9, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(9, copyOfNoTokenization.Client_ID);
}

                        if(copyOfNoTokenization.Carrier_ID == null) {
pstmt_tDBOutput_1.setNull(10, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(10, copyOfNoTokenization.Carrier_ID);
}

                        if(copyOfNoTokenization.Account_ID == null) {
pstmt_tDBOutput_1.setNull(11, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(11, copyOfNoTokenization.Account_ID);
}

                        if(copyOfNoTokenization.Group_ID == null) {
pstmt_tDBOutput_1.setNull(12, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(12, copyOfNoTokenization.Group_ID);
}

                        if(copyOfNoTokenization.Multi_Birth_Code == null) {
pstmt_tDBOutput_1.setNull(13, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(13, copyOfNoTokenization.Multi_Birth_Code);
}

                        if(copyOfNoTokenization.Member_Key == null) {
pstmt_tDBOutput_1.setNull(14, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(14, copyOfNoTokenization.Member_Key);
}

                        if(copyOfNoTokenization.Source == null) {
pstmt_tDBOutput_1.setNull(15, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(15, copyOfNoTokenization.Source);
}

                        pstmt_tDBOutput_1.setInt(16, copyOfNoTokenization.scd_key);

                try {
                    nb_line_tDBOutput_1++;
                    insertedCount_tDBOutput_1 = insertedCount_tDBOutput_1 + pstmt_tDBOutput_1.executeUpdate();
                } catch(java.lang.Exception e_tDBOutput_1) {
                    whetherReject_tDBOutput_1 = true;
                            System.err.print(e_tDBOutput_1.getMessage());
                }

 


	tos_count_tDBOutput_1++;

/**
 * [tDBOutput_1 main ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	

 



/**
 * [tDBOutput_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	

 



/**
 * [tDBOutput_1 process_data_end ] stop
 */

} // End of branch "copyOfNoTokenization"




// Start of branch "copyOfTokenization1"
if(copyOfTokenization1 != null) { 



	
	/**
	 * [tFileOutputJSON_1 main ] start
	 */

	

	
	
	currentComponent="tFileOutputJSON_1";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"copyOfTokenization1");
			


org.json.simple.JSONObject jsonRowtFileOutputJSON_1 = new org.json.simple.JSONObject();
			    	if(copyOfTokenization1.DOB != null){
			    
					jsonRowtFileOutputJSON_1.put("DOB", copyOfTokenization1.DOB);
				
					}else{
						jsonRowtFileOutputJSON_1.put("DOB", null);
					}
				
			    	if(copyOfTokenization1.firstName != null){
			    
					jsonRowtFileOutputJSON_1.put("firstName", copyOfTokenization1.firstName);
				
					}else{
						jsonRowtFileOutputJSON_1.put("firstName", null);
					}
				
			    	if(copyOfTokenization1.lastName != null){
			    
					jsonRowtFileOutputJSON_1.put("lastName", copyOfTokenization1.lastName);
				
					}else{
						jsonRowtFileOutputJSON_1.put("lastName", null);
					}
				
			    	if(copyOfTokenization1.SSN != null){
			    
					jsonRowtFileOutputJSON_1.put("SSN", copyOfTokenization1.SSN);
				
					}else{
						jsonRowtFileOutputJSON_1.put("SSN", null);
					}
				
			    	if(copyOfTokenization1.MBI != null){
			    
					jsonRowtFileOutputJSON_1.put("MBI", copyOfTokenization1.MBI);
				
					}else{
						jsonRowtFileOutputJSON_1.put("MBI", null);
					}
				
			    	if(copyOfTokenization1.OtherID != null){
			    
					jsonRowtFileOutputJSON_1.put("OtherID", copyOfTokenization1.OtherID);
				
					}else{
						jsonRowtFileOutputJSON_1.put("OtherID", null);
					}
				

if(!isFirst_tFileOutputJSON_1){
	outtFileOutputJSON_1.append(",");
}
isFirst_tFileOutputJSON_1 = false;
outtFileOutputJSON_1.append(jsonRowtFileOutputJSON_1.toJSONString());
nb_line_tFileOutputJSON_1++;

 


	tos_count_tFileOutputJSON_1++;

/**
 * [tFileOutputJSON_1 main ] stop
 */
	
	/**
	 * [tFileOutputJSON_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileOutputJSON_1";

	

 



/**
 * [tFileOutputJSON_1 process_data_begin ] stop
 */
	
	/**
	 * [tFileOutputJSON_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileOutputJSON_1";

	

 



/**
 * [tFileOutputJSON_1 process_data_end ] stop
 */

} // End of branch "copyOfTokenization1"




	
	/**
	 * [tMap_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_3";

	

 



/**
 * [tMap_3 process_data_end ] stop
 */



	
	/**
	 * [tBufferOutput_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tBufferOutput_3";

	

 



/**
 * [tBufferOutput_3 process_data_end ] stop
 */



	
	/**
	 * [tJavaFlex_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tJavaFlex_2";

	

 



/**
 * [tJavaFlex_2 process_data_end ] stop
 */



	
	/**
	 * [tSortRow_1_SortIn process_data_end ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_1";
	
	currentComponent="tSortRow_1_SortIn";

	

 



/**
 * [tSortRow_1_SortIn process_data_end ] stop
 */
	
	/**
	 * [tSortRow_1_SortIn end ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_1";
	
	currentComponent="tSortRow_1_SortIn";

	


}

globalMap.put("tSortRow_1_SortIn_NB_LINE",nb_line_tSortRow_1_SortIn);

 

ok_Hash.put("tSortRow_1_SortIn", true);
end_Hash.put("tSortRow_1_SortIn", System.currentTimeMillis());




/**
 * [tSortRow_1_SortIn end ] stop
 */

	
	/**
	 * [tJavaFlex_2 end ] start
	 */

	

	
	
	currentComponent="tJavaFlex_2";

	


// end of the component, outside/closing the loop
System.out.println(upis);

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row24",2,0,
			 			talendJobLog,"tSortRow_1_SortIn","tSortIn","tJavaFlex_2","tJavaFlex","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tJavaFlex_2", true);
end_Hash.put("tJavaFlex_2", System.currentTimeMillis());




/**
 * [tJavaFlex_2 end ] stop
 */

	
	/**
	 * [tBufferOutput_3 end ] start
	 */

	

	
	
	currentComponent="tBufferOutput_3";

	

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row25",2,0,
			 			talendJobLog,"tJavaFlex_2","tJavaFlex","tBufferOutput_3","tBufferOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tBufferOutput_3", true);
end_Hash.put("tBufferOutput_3", System.currentTimeMillis());




/**
 * [tBufferOutput_3 end ] stop
 */

	
	/**
	 * [tMap_3 end ] start
	 */

	

	
	
	currentComponent="tMap_3";

	


// ###############################
// # Lookup hashes releasing
// ###############################      





			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row12",2,0,
			 			talendJobLog,"tBufferOutput_3","tBufferOutput","tMap_3","tMap","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tMap_3", true);
end_Hash.put("tMap_3", System.currentTimeMillis());




/**
 * [tMap_3 end ] stop
 */

	
	/**
	 * [tDBOutput_1 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	
	



	
        if(pstmt_tDBOutput_1 != null) {
			
				pstmt_tDBOutput_1.close();
				resourceMap.remove("pstmt_tDBOutput_1");
			
        }
    resourceMap.put("statementClosed_tDBOutput_1", true);


	
	nb_line_deleted_tDBOutput_1=nb_line_deleted_tDBOutput_1+ deletedCount_tDBOutput_1;
	nb_line_update_tDBOutput_1=nb_line_update_tDBOutput_1 + updatedCount_tDBOutput_1;
	nb_line_inserted_tDBOutput_1=nb_line_inserted_tDBOutput_1 + insertedCount_tDBOutput_1;
	nb_line_rejected_tDBOutput_1=nb_line_rejected_tDBOutput_1 + rejectedCount_tDBOutput_1;
	
        globalMap.put("tDBOutput_1_NB_LINE",nb_line_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_UPDATED",nb_line_update_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_DELETED",nb_line_deleted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_1);
    
	



			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"copyOfNoTokenization",2,0,
			 			talendJobLog,"tMap_3","tMap","tDBOutput_1","tOracleOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tDBOutput_1", true);
end_Hash.put("tDBOutput_1", System.currentTimeMillis());




/**
 * [tDBOutput_1 end ] stop
 */




	
	/**
	 * [tFileOutputJSON_1 end ] start
	 */

	

	
	
	currentComponent="tFileOutputJSON_1";

	

	outtFileOutputJSON_1.print("]");
outtFileOutputJSON_1.close();
globalMap.put("tFileOutputJSON_1_NB_LINE",nb_line_tFileOutputJSON_1);

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"copyOfTokenization1",2,0,
			 			talendJobLog,"tMap_3","tMap","tFileOutputJSON_1","tFileOutputJSON","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tFileOutputJSON_1", true);
end_Hash.put("tFileOutputJSON_1", System.currentTimeMillis());




/**
 * [tFileOutputJSON_1 end ] stop
 */





















						if(execStat){
							runStat.updateStatOnConnection("iterate3", 2, "exec" + NB_ITERATE_tFileInputDelimited_3);
						}				
					




	
	/**
	 * [tFlowToIterate_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_3";

	

 



/**
 * [tFlowToIterate_3 process_data_end ] stop
 */

} // End of branch "row15"




	
	/**
	 * [tFileInputDelimited_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_2";

	

 



/**
 * [tFileInputDelimited_2 process_data_end ] stop
 */
	
	/**
	 * [tFileInputDelimited_2 end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_2";

	



            }
            }finally{
                if(!((Object)(context.location+"GroupID.csv") instanceof java.io.InputStream)){
                	if(fid_tFileInputDelimited_2!=null){
                		fid_tFileInputDelimited_2.close();
                	}
                }
                if(fid_tFileInputDelimited_2!=null){
                	globalMap.put("tFileInputDelimited_2_NB_LINE", fid_tFileInputDelimited_2.getRowNumber());
					
                }
			}
			  

 

ok_Hash.put("tFileInputDelimited_2", true);
end_Hash.put("tFileInputDelimited_2", System.currentTimeMillis());




/**
 * [tFileInputDelimited_2 end ] stop
 */

	
	/**
	 * [tFlowToIterate_3 end ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_3";

	

globalMap.put("tFlowToIterate_3_NB_LINE",nb_line_tFlowToIterate_3);
			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row15",2,0,
			 			talendJobLog,"tFileInputDelimited_2","tFileInputDelimited","tFlowToIterate_3","tFlowToIterate","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tFlowToIterate_3", true);
end_Hash.put("tFlowToIterate_3", System.currentTimeMillis());




/**
 * [tFlowToIterate_3 end ] stop
 */



				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFileInputDelimited_2:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk4", 0, "ok");
								} 
							
							tFileInputRaw_2Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
					te.setVirtualComponentName(currentVirtualComponent);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
							//free memory for "tSortRow_1_SortIn"
							globalMap.remove("tSortRow_1");
						
				try{
					
	
	/**
	 * [tFileInputDelimited_2 finally ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_2";

	

 



/**
 * [tFileInputDelimited_2 finally ] stop
 */

	
	/**
	 * [tFlowToIterate_3 finally ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_3";

	

 



/**
 * [tFlowToIterate_3 finally ] stop
 */

	
	/**
	 * [tFileInputDelimited_3 finally ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_3";

	

 



/**
 * [tFileInputDelimited_3 finally ] stop
 */

	
	/**
	 * [tFilterRow_23 finally ] start
	 */

	

	
	
	currentComponent="tFilterRow_23";

	

 



/**
 * [tFilterRow_23 finally ] stop
 */

	
	/**
	 * [tSortRow_1_SortOut finally ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_1";
	
	currentComponent="tSortRow_1_SortOut";

	

 



/**
 * [tSortRow_1_SortOut finally ] stop
 */

	
	/**
	 * [tSortRow_1_SortIn finally ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_1";
	
	currentComponent="tSortRow_1_SortIn";

	

 



/**
 * [tSortRow_1_SortIn finally ] stop
 */

	
	/**
	 * [tJavaFlex_2 finally ] start
	 */

	

	
	
	currentComponent="tJavaFlex_2";

	

 



/**
 * [tJavaFlex_2 finally ] stop
 */

	
	/**
	 * [tBufferOutput_3 finally ] start
	 */

	

	
	
	currentComponent="tBufferOutput_3";

	

 



/**
 * [tBufferOutput_3 finally ] stop
 */

	
	/**
	 * [tMap_3 finally ] start
	 */

	

	
	
	currentComponent="tMap_3";

	

 



/**
 * [tMap_3 finally ] stop
 */

	
	/**
	 * [tDBOutput_1 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	



    if (resourceMap.get("statementClosed_tDBOutput_1") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_1 = null;
                if ((pstmtToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_1")) != null) {
                    pstmtToClose_tDBOutput_1.close();
                }
    }
 



/**
 * [tDBOutput_1 finally ] stop
 */




	
	/**
	 * [tFileOutputJSON_1 finally ] start
	 */

	

	
	
	currentComponent="tFileOutputJSON_1";

	

 



/**
 * [tFileOutputJSON_1 finally ] stop
 */



























				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileInputDelimited_2_SUBPROCESS_STATE", 1);
	}
	


public static class row16Struct implements routines.system.IPersistableRow<row16Struct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];

	
			    public String firstName;

				public String getFirstName () {
					return this.firstName;
				}
				
			    public String lastName;

				public String getLastName () {
					return this.lastName;
				}
				
			    public String MBI;

				public String getMBI () {
					return this.MBI;
				}
				
			    public String DOB;

				public String getDOB () {
					return this.DOB;
				}
				
			    public String OtherID;

				public String getOtherID () {
					return this.OtherID;
				}
				
			    public String SSN;

				public String getSSN () {
					return this.SSN;
				}
				
			    public int scd_key;

				public int getScd_key () {
					return this.scd_key;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam) {

        	try {

        		int length = 0;
		
					this.firstName = readString(dis);
					
					this.lastName = readString(dis);
					
					this.MBI = readString(dis);
					
					this.DOB = readString(dis);
					
					this.OtherID = readString(dis);
					
					this.SSN = readString(dis);
					
			        this.scd_key = dis.readInt();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.firstName,dos);
					
					// String
				
						writeString(this.lastName,dos);
					
					// String
				
						writeString(this.MBI,dos);
					
					// String
				
						writeString(this.DOB,dos);
					
					// String
				
						writeString(this.OtherID,dos);
					
					// String
				
						writeString(this.SSN,dos);
					
					// int
				
		            	dos.writeInt(this.scd_key);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("firstName="+firstName);
		sb.append(",lastName="+lastName);
		sb.append(",MBI="+MBI);
		sb.append(",DOB="+DOB);
		sb.append(",OtherID="+OtherID);
		sb.append(",SSN="+SSN);
		sb.append(",scd_key="+String.valueOf(scd_key));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row16Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class copyOfoutStruct implements routines.system.IPersistableRow<copyOfoutStruct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];

	
			    public String firstName;

				public String getFirstName () {
					return this.firstName;
				}
				
			    public String lastName;

				public String getLastName () {
					return this.lastName;
				}
				
			    public String MBI;

				public String getMBI () {
					return this.MBI;
				}
				
			    public String DOB;

				public String getDOB () {
					return this.DOB;
				}
				
			    public String OtherID;

				public String getOtherID () {
					return this.OtherID;
				}
				
			    public String SSN;

				public String getSSN () {
					return this.SSN;
				}
				
			    public int scd_key;

				public int getScd_key () {
					return this.scd_key;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam) {

        	try {

        		int length = 0;
		
					this.firstName = readString(dis);
					
					this.lastName = readString(dis);
					
					this.MBI = readString(dis);
					
					this.DOB = readString(dis);
					
					this.OtherID = readString(dis);
					
					this.SSN = readString(dis);
					
			        this.scd_key = dis.readInt();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.firstName,dos);
					
					// String
				
						writeString(this.lastName,dos);
					
					// String
				
						writeString(this.MBI,dos);
					
					// String
				
						writeString(this.DOB,dos);
					
					// String
				
						writeString(this.OtherID,dos);
					
					// String
				
						writeString(this.SSN,dos);
					
					// int
				
		            	dos.writeInt(this.scd_key);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("firstName="+firstName);
		sb.append(",lastName="+lastName);
		sb.append(",MBI="+MBI);
		sb.append(",DOB="+DOB);
		sb.append(",OtherID="+OtherID);
		sb.append(",SSN="+SSN);
		sb.append(",scd_key="+String.valueOf(scd_key));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(copyOfoutStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row14Struct implements routines.system.IPersistableRow<row14Struct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];

	
			    public String firstName;

				public String getFirstName () {
					return this.firstName;
				}
				
			    public String lastName;

				public String getLastName () {
					return this.lastName;
				}
				
			    public String MBI;

				public String getMBI () {
					return this.MBI;
				}
				
			    public String DOB;

				public String getDOB () {
					return this.DOB;
				}
				
			    public String OtherID;

				public String getOtherID () {
					return this.OtherID;
				}
				
			    public String SSN;

				public String getSSN () {
					return this.SSN;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam) {

        	try {

        		int length = 0;
		
					this.firstName = readString(dis);
					
					this.lastName = readString(dis);
					
					this.MBI = readString(dis);
					
					this.DOB = readString(dis);
					
					this.OtherID = readString(dis);
					
					this.SSN = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.firstName,dos);
					
					// String
				
						writeString(this.lastName,dos);
					
					// String
				
						writeString(this.MBI,dos);
					
					// String
				
						writeString(this.DOB,dos);
					
					// String
				
						writeString(this.OtherID,dos);
					
					// String
				
						writeString(this.SSN,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("firstName="+firstName);
		sb.append(",lastName="+lastName);
		sb.append(",MBI="+MBI);
		sb.append(",DOB="+DOB);
		sb.append(",OtherID="+OtherID);
		sb.append(",SSN="+SSN);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row14Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row10Struct implements routines.system.IPersistableRow<row10Struct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];

	
			    public String Body;

				public String getBody () {
					return this.Body;
				}
				
			    public Integer ERROR_CODE;

				public Integer getERROR_CODE () {
					return this.ERROR_CODE;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam) {

        	try {

        		int length = 0;
		
					this.Body = readString(dis);
					
						this.ERROR_CODE = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Body,dos);
					
					// Integer
				
						writeInteger(this.ERROR_CODE,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Body="+Body);
		sb.append(",ERROR_CODE="+String.valueOf(ERROR_CODE));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row10Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row9Struct implements routines.system.IPersistableRow<row9Struct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];

	
			    public Object content;

				public Object getContent () {
					return this.content;
				}
				



    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam) {

        	try {

        		int length = 0;
		
						this.content = (Object) dis.readObject();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Object
				
       			    	dos.writeObject(this.content);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("content="+String.valueOf(content));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row9Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFileInputRaw_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileInputRaw_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row9Struct row9 = new row9Struct();
row10Struct row10 = new row10Struct();
row14Struct row14 = new row14Struct();
copyOfoutStruct copyOfout = new copyOfoutStruct();
row16Struct row16 = new row16Struct();




	
	/**
	 * [tFlowToIterate_2 begin ] start
	 */

				
			int NB_ITERATE_tREST_2 = 0; //for statistics
			

	
		
		ok_Hash.put("tFlowToIterate_2", false);
		start_Hash.put("tFlowToIterate_2", System.currentTimeMillis());
		
	
	currentComponent="tFlowToIterate_2";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row9");
			
		int tos_count_tFlowToIterate_2 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tFlowToIterate_2", "tFlowToIterate");
				talendJobLogProcess(globalMap);
			}
			

int nb_line_tFlowToIterate_2 = 0;
int counter_tFlowToIterate_2 = 0;

 



/**
 * [tFlowToIterate_2 begin ] stop
 */



	
	/**
	 * [tFileInputRaw_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputRaw_2", false);
		start_Hash.put("tFileInputRaw_2", System.currentTimeMillis());
		
	
	currentComponent="tFileInputRaw_2";

	
		int tos_count_tFileInputRaw_2 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tFileInputRaw_2", "tFileInputRaw");
				talendJobLogProcess(globalMap);
			}
			
	

				try {					
					String content_tFileInputRaw_2 = org.apache.commons.io.FileUtils.readFileToString(new java.io.File(context.jsonfile_after), "ISO-8859-15");
					row9.content = content_tFileInputRaw_2;					
					globalMap.put("tFileInputRaw_2_FILENAME_PATH", context.jsonfile_after);
				} catch (java.io.IOException e_tFileInputRaw_2) {
					
					System.err.println(e_tFileInputRaw_2);
				}


 



/**
 * [tFileInputRaw_2 begin ] stop
 */
	
	/**
	 * [tFileInputRaw_2 main ] start
	 */

	

	
	
	currentComponent="tFileInputRaw_2";

	

 


	tos_count_tFileInputRaw_2++;

/**
 * [tFileInputRaw_2 main ] stop
 */
	
	/**
	 * [tFileInputRaw_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileInputRaw_2";

	

 



/**
 * [tFileInputRaw_2 process_data_begin ] stop
 */

	
	/**
	 * [tFlowToIterate_2 main ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_2";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"row9");
			


    	            
            globalMap.put("row9.content", row9.content);
    	
 
	   nb_line_tFlowToIterate_2++;  
       counter_tFlowToIterate_2++;
       globalMap.put("tFlowToIterate_2_CURRENT_ITERATION", counter_tFlowToIterate_2);
 


	tos_count_tFlowToIterate_2++;

/**
 * [tFlowToIterate_2 main ] stop
 */
	
	/**
	 * [tFlowToIterate_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_2";

	

 



/**
 * [tFlowToIterate_2 process_data_begin ] stop
 */
	NB_ITERATE_tREST_2++;
	
	
					if(execStat){				
	       				runStat.updateStatOnConnection("row16", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("copyOfout", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row14", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row10", 3, 0);
					}           			
				
				if(execStat){
					runStat.updateStatOnConnection("iterate4", 1, "exec" + NB_ITERATE_tREST_2);
					//Thread.sleep(1000);
				}				
			





	
	/**
	 * [tLogRow_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tLogRow_3", false);
		start_Hash.put("tLogRow_3", System.currentTimeMillis());
		
	
	currentComponent="tLogRow_3";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row16");
			
		int tos_count_tLogRow_3 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tLogRow_3", "tLogRow");
				talendJobLogProcess(globalMap);
			}
			

	///////////////////////
	
         class Util_tLogRow_3 {

        String[] des_top = { ".", ".", "-", "+" };

        String[] des_head = { "|=", "=|", "-", "+" };

        String[] des_bottom = { "'", "'", "-", "+" };

        String name="";

        java.util.List<String[]> list = new java.util.ArrayList<String[]>();

        int[] colLengths = new int[7];

        public void addRow(String[] row) {

            for (int i = 0; i < 7; i++) {
                if (row[i]!=null) {
                  colLengths[i] = Math.max(colLengths[i], row[i].length());
                }
            }
            list.add(row);
        }

        public void setTableName(String name) {

            this.name = name;
        }

            public StringBuilder format() {
            
                StringBuilder sb = new StringBuilder();
  
            
                    sb.append(print(des_top));
    
                    int totals = 0;
                    for (int i = 0; i < colLengths.length; i++) {
                        totals = totals + colLengths[i];
                    }
    
                    // name
                    sb.append("|");
                    int k = 0;
                    for (k = 0; k < (totals + 6 - name.length()) / 2; k++) {
                        sb.append(' ');
                    }
                    sb.append(name);
                    for (int i = 0; i < totals + 6 - name.length() - k; i++) {
                        sb.append(' ');
                    }
                    sb.append("|\n");

                    // head and rows
                    sb.append(print(des_head));
                    for (int i = 0; i < list.size(); i++) {
    
                        String[] row = list.get(i);
    
                        java.util.Formatter formatter = new java.util.Formatter(new StringBuilder());
                        
                        StringBuilder sbformat = new StringBuilder();                                             
        			        sbformat.append("|%1$-");
        			        sbformat.append(colLengths[0]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%2$-");
        			        sbformat.append(colLengths[1]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%3$-");
        			        sbformat.append(colLengths[2]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%4$-");
        			        sbformat.append(colLengths[3]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%5$-");
        			        sbformat.append(colLengths[4]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%6$-");
        			        sbformat.append(colLengths[5]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%7$-");
        			        sbformat.append(colLengths[6]);
        			        sbformat.append("s");
        			                      
                        sbformat.append("|\n");                    
       
                        formatter.format(sbformat.toString(), (Object[])row);	
                                
                        sb.append(formatter.toString());
                        if (i == 0)
                            sb.append(print(des_head)); // print the head
                    }
    
                    // end
                    sb.append(print(des_bottom));
                    return sb;
                }
            

            private StringBuilder print(String[] fillChars) {
                StringBuilder sb = new StringBuilder();
                //first column
                sb.append(fillChars[0]);                
                    for (int i = 0; i < colLengths[0] - fillChars[0].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);	                

                    for (int i = 0; i < colLengths[1] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[2] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[3] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[4] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[5] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                
                    //last column
                    for (int i = 0; i < colLengths[6] - fillChars[1].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }         
                sb.append(fillChars[1]);
                sb.append("\n");               
                return sb;
            }
            
            public boolean isTableEmpty(){
            	if (list.size() > 1)
            		return false;
            	return true;
            }
        }
        Util_tLogRow_3 util_tLogRow_3 = new Util_tLogRow_3();
        util_tLogRow_3.setTableName("tLogRow_3");
        util_tLogRow_3.addRow(new String[]{"firstName","lastName","MBI","DOB","OtherID","SSN","scd_key",});        
 		StringBuilder strBuffer_tLogRow_3 = null;
		int nb_line_tLogRow_3 = 0;
///////////////////////    			



 



/**
 * [tLogRow_3 begin ] stop
 */



	
	/**
	 * [tDBOutput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_2", false);
		start_Hash.put("tDBOutput_2", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_2";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"copyOfout");
			
		int tos_count_tDBOutput_2 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_2", "tOracleOutput");
				talendJobLogProcess(globalMap);
			}
			






    int nb_line_tDBOutput_2 = 0;
    int nb_line_update_tDBOutput_2 = 0;
    int nb_line_inserted_tDBOutput_2 = 0;
    int nb_line_deleted_tDBOutput_2 = 0;
    int nb_line_rejected_tDBOutput_2 = 0;

    int tmp_batchUpdateCount_tDBOutput_2 = 0;

    int deletedCount_tDBOutput_2=0;
    int updatedCount_tDBOutput_2=0;
    int insertedCount_tDBOutput_2=0;
    int rejectedCount_tDBOutput_2=0;

    boolean whetherReject_tDBOutput_2 = false;

    java.sql.Connection conn_tDBOutput_2 = null;

    //optional table
    String dbschema_tDBOutput_2 = null;
    String tableName_tDBOutput_2 = null;
        dbschema_tDBOutput_2 = (String)globalMap.get("dbschema_tDBConnection_1");
		
        conn_tDBOutput_2 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
        int count_tDBOutput_2=0;

        if(dbschema_tDBOutput_2 == null || dbschema_tDBOutput_2.trim().length() == 0) {
            tableName_tDBOutput_2 = ("tokenized_landing");
        } else {
            tableName_tDBOutput_2 = dbschema_tDBOutput_2 + "." + ("tokenized_landing");
        }
            try (java.sql.Statement stmtClear_tDBOutput_2 = conn_tDBOutput_2.createStatement()) {
                stmtClear_tDBOutput_2.executeUpdate("DELETE FROM " + tableName_tDBOutput_2 + "");
            }
                String insert_tDBOutput_2 = "INSERT INTO " + tableName_tDBOutput_2 + " (firstName,lastName,MBI,DOB,OtherID,SSN,scd_key) VALUES (?,?,?,?,?,?,?)";    

                        java.sql.PreparedStatement pstmt_tDBOutput_2 = conn_tDBOutput_2.prepareStatement(insert_tDBOutput_2);
                        resourceMap.put("pstmt_tDBOutput_2", pstmt_tDBOutput_2);
                StringBuffer query_tDBOutput_2 = null;
		 	String[] insertSQLSplits_tDBOutput_2 = insert_tDBOutput_2.split("\\?");





 



/**
 * [tDBOutput_2 begin ] stop
 */



	
	/**
	 * [tMap_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_4", false);
		start_Hash.put("tMap_4", System.currentTimeMillis());
		
	
	currentComponent="tMap_4";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row14");
			
		int tos_count_tMap_4 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tMap_4", "tMap");
				talendJobLogProcess(globalMap);
			}
			




// ###############################
// # Lookup's keys initialization
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_4__Struct  {
	int var1;
}
Var__tMap_4__Struct Var__tMap_4 = new Var__tMap_4__Struct();
// ###############################

// ###############################
// # Outputs initialization
copyOfoutStruct copyOfout_tmp = new copyOfoutStruct();
// ###############################

        
        



        









 



/**
 * [tMap_4 begin ] stop
 */



	
	/**
	 * [tExtractJSONFields_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tExtractJSONFields_2", false);
		start_Hash.put("tExtractJSONFields_2", System.currentTimeMillis());
		
	
	currentComponent="tExtractJSONFields_2";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row10");
			
		int tos_count_tExtractJSONFields_2 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tExtractJSONFields_2", "tExtractJSONFields");
				talendJobLogProcess(globalMap);
			}
			

int nb_line_tExtractJSONFields_2 = 0;
String jsonStr_tExtractJSONFields_2 = "";

	

class JsonPathCache_tExtractJSONFields_2 {
	final java.util.Map<String,com.jayway.jsonpath.JsonPath> jsonPathString2compiledJsonPath = new java.util.HashMap<String,com.jayway.jsonpath.JsonPath>();
	
	public com.jayway.jsonpath.JsonPath getCompiledJsonPath(String jsonPath) {
		if(jsonPathString2compiledJsonPath.containsKey(jsonPath)) {
			return jsonPathString2compiledJsonPath.get(jsonPath);
		} else {
			com.jayway.jsonpath.JsonPath compiledLoopPath = com.jayway.jsonpath.JsonPath.compile(jsonPath);
			jsonPathString2compiledJsonPath.put(jsonPath,compiledLoopPath);
			return compiledLoopPath;
		}
	}
}

JsonPathCache_tExtractJSONFields_2 jsonPathCache_tExtractJSONFields_2 = new JsonPathCache_tExtractJSONFields_2();

 



/**
 * [tExtractJSONFields_2 begin ] stop
 */



	
	/**
	 * [tREST_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tREST_2", false);
		start_Hash.put("tREST_2", System.currentTimeMillis());
		
	
	currentComponent="tREST_2";

	
		int tos_count_tREST_2 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tREST_2", "tREST");
				talendJobLogProcess(globalMap);
			}
			
	

	
	String endpoint_tREST_2 = "https://irx.dev1.awse1.anthem.com/static/unprotect/json";
	
	String trustStoreFile_tREST_2 = System.getProperty("javax.net.ssl.trustStore");
	String trustStoreType_tREST_2 = System.getProperty("javax.net.ssl.trustStoreType");
	String trustStorePWD_tREST_2 = System.getProperty("javax.net.ssl.trustStorePassword");
	
	String keyStoreFile_tREST_2 = System.getProperty("javax.net.ssl.keyStore");
	String keyStoreType_tREST_2 = System.getProperty("javax.net.ssl.keyStoreType");
	String keyStorePWD_tREST_2 = System.getProperty("javax.net.ssl.keyStorePassword");
	
	com.sun.jersey.api.client.config.ClientConfig config_tREST_2 = new com.sun.jersey.api.client.config.DefaultClientConfig();
	javax.net.ssl.SSLContext ctx_tREST_2 = javax.net.ssl.SSLContext.getInstance("SSL");
	
	javax.net.ssl.TrustManager[] tms_tREST_2 = null;
	if(trustStoreFile_tREST_2!=null && trustStoreType_tREST_2!=null){
		char[] password_tREST_2 = null;
		if(trustStorePWD_tREST_2!=null)
			password_tREST_2 = trustStorePWD_tREST_2.toCharArray();
		java.security.KeyStore trustStore_tREST_2 = java.security.KeyStore.getInstance(trustStoreType_tREST_2);
		trustStore_tREST_2.load(new java.io.FileInputStream(trustStoreFile_tREST_2), password_tREST_2);
		
		javax.net.ssl.TrustManagerFactory tmf_tREST_2 = javax.net.ssl.TrustManagerFactory.getInstance(javax.net.ssl.KeyManagerFactory.getDefaultAlgorithm());
        tmf_tREST_2.init(trustStore_tREST_2);
        tms_tREST_2 = tmf_tREST_2.getTrustManagers();
	}
	
	javax.net.ssl.KeyManager[] kms_tREST_2 = null;
	if(keyStoreFile_tREST_2!=null && keyStoreType_tREST_2!=null){
		char[] password_tREST_2 = null;
		if(keyStorePWD_tREST_2!=null)
			password_tREST_2 = keyStorePWD_tREST_2.toCharArray();
		java.security.KeyStore keyStore_tREST_2 = java.security.KeyStore.getInstance(keyStoreType_tREST_2);
		keyStore_tREST_2.load(new java.io.FileInputStream(keyStoreFile_tREST_2), password_tREST_2);
		
		javax.net.ssl.KeyManagerFactory kmf_tREST_2 = javax.net.ssl.KeyManagerFactory.getInstance(javax.net.ssl.KeyManagerFactory.getDefaultAlgorithm());
        kmf_tREST_2.init(keyStore_tREST_2,password_tREST_2);
        kms_tREST_2 = kmf_tREST_2.getKeyManagers();
	}
	
    ctx_tREST_2.init(kms_tREST_2, tms_tREST_2 , null);
    config_tREST_2.getProperties().put(com.sun.jersey.client.urlconnection.HTTPSProperties.PROPERTY_HTTPS_PROPERTIES,
                new com.sun.jersey.client.urlconnection.HTTPSProperties(new javax.net.ssl.HostnameVerifier() {

                    public boolean verify(String hostName, javax.net.ssl.SSLSession session) {
                        return true;
                    }
                }, ctx_tREST_2));

	com.sun.jersey.api.client.Client restClient_tREST_2 = com.sun.jersey.api.client.Client.create(config_tREST_2);
	
	java.util.Map<String, Object> headers_tREST_2 = new java.util.HashMap<String, Object>();
	
    	headers_tREST_2.put("Authorization","Basic U1JDX0lSWF9SRVNUX0lSWEVQOkZvQzIhSGVMJEIzRA==");
	
	
	Object transfer_encoding_tREST_2 = headers_tREST_2.get("Transfer-Encoding");
	if(transfer_encoding_tREST_2!=null && "chunked".equals(transfer_encoding_tREST_2)) {
		restClient_tREST_2.setChunkedEncodingSize(4096);
	}
	
	com.sun.jersey.api.client.WebResource restResource_tREST_2;
	if(endpoint_tREST_2!=null && !("").equals(endpoint_tREST_2)){
		restResource_tREST_2 = restClient_tREST_2.resource(endpoint_tREST_2);
	}else{
		throw new IllegalArgumentException("url can't be empty!");
	}
	
	com.sun.jersey.api.client.ClientResponse errorResponse_tREST_2 = null;
	String restResponse_tREST_2 = "";
	try{
		
		com.sun.jersey.api.client.WebResource.Builder builder_tREST_2 = null;
		for(java.util.Map.Entry<String, Object> header_tREST_2 : headers_tREST_2.entrySet()) {
			if(builder_tREST_2 == null) {
				builder_tREST_2 = restResource_tREST_2.header(header_tREST_2.getKey(), header_tREST_2.getValue());
			} else {
				builder_tREST_2.header(header_tREST_2.getKey(), header_tREST_2.getValue());
			}
		}
		
		
			if(builder_tREST_2!=null) {
				restResponse_tREST_2 = builder_tREST_2.post(String.class,row9.content);
			} else {
				restResponse_tREST_2 = restResource_tREST_2.post(String.class,row9.content);
			}
		
	}catch (com.sun.jersey.api.client.UniformInterfaceException ue) {
        errorResponse_tREST_2 = ue.getResponse();
    }
	
	// for output
			
				row10 = new row10Struct();
				if(errorResponse_tREST_2!=null){
					row10.ERROR_CODE = errorResponse_tREST_2.getStatus();
					if(row10.ERROR_CODE!=204){
					    row10.Body = errorResponse_tREST_2.getEntity(String.class);
					}
				}else{
					row10.Body = restResponse_tREST_2;
				}
			

 



/**
 * [tREST_2 begin ] stop
 */
	
	/**
	 * [tREST_2 main ] start
	 */

	

	
	
	currentComponent="tREST_2";

	

 


	tos_count_tREST_2++;

/**
 * [tREST_2 main ] stop
 */
	
	/**
	 * [tREST_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tREST_2";

	

 



/**
 * [tREST_2 process_data_begin ] stop
 */

	
	/**
	 * [tExtractJSONFields_2 main ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_2";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"row10");
			

            if(row10.Body!=null){// C_01
                jsonStr_tExtractJSONFields_2 = row10.Body.toString();
   
row14 = null;

	

String loopPath_tExtractJSONFields_2 = "$[*]";
java.util.List<Object> resultset_tExtractJSONFields_2 = new java.util.ArrayList<Object>();

boolean isStructError_tExtractJSONFields_2 = true;
com.jayway.jsonpath.ReadContext document_tExtractJSONFields_2 = null;
try {
	document_tExtractJSONFields_2 = com.jayway.jsonpath.JsonPath.parse(jsonStr_tExtractJSONFields_2);
	com.jayway.jsonpath.JsonPath compiledLoopPath_tExtractJSONFields_2 = jsonPathCache_tExtractJSONFields_2.getCompiledJsonPath(loopPath_tExtractJSONFields_2);
	Object result_tExtractJSONFields_2 = document_tExtractJSONFields_2.read(compiledLoopPath_tExtractJSONFields_2,net.minidev.json.JSONObject.class);
	if (result_tExtractJSONFields_2 instanceof net.minidev.json.JSONArray) {
		resultset_tExtractJSONFields_2 = (net.minidev.json.JSONArray) result_tExtractJSONFields_2;
	} else {
		resultset_tExtractJSONFields_2.add(result_tExtractJSONFields_2);
	}
	
	isStructError_tExtractJSONFields_2 = false;
} catch (java.lang.Exception ex_tExtractJSONFields_2) {
		System.err.println(ex_tExtractJSONFields_2.getMessage());
}

String jsonPath_tExtractJSONFields_2 = null;
com.jayway.jsonpath.JsonPath compiledJsonPath_tExtractJSONFields_2 = null;

Object value_tExtractJSONFields_2 = null;

Object root_tExtractJSONFields_2 = null;
for(int i_tExtractJSONFields_2=0; isStructError_tExtractJSONFields_2 || (i_tExtractJSONFields_2 < resultset_tExtractJSONFields_2.size());i_tExtractJSONFields_2++){
	if(!isStructError_tExtractJSONFields_2){
		Object row_tExtractJSONFields_2 = resultset_tExtractJSONFields_2.get(i_tExtractJSONFields_2);
            row14 = null;
	row14 = new row14Struct();
	nb_line_tExtractJSONFields_2++;
	try {
		jsonPath_tExtractJSONFields_2 = "firstName";
		compiledJsonPath_tExtractJSONFields_2 = jsonPathCache_tExtractJSONFields_2.getCompiledJsonPath(jsonPath_tExtractJSONFields_2);
		
		try {
		    
		        value_tExtractJSONFields_2 = compiledJsonPath_tExtractJSONFields_2.read(row_tExtractJSONFields_2);
		    
				row14.firstName = value_tExtractJSONFields_2 == null ? 

		null

 : value_tExtractJSONFields_2.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_2) {
			row14.firstName = 

		null

;
		}
		jsonPath_tExtractJSONFields_2 = "lastName";
		compiledJsonPath_tExtractJSONFields_2 = jsonPathCache_tExtractJSONFields_2.getCompiledJsonPath(jsonPath_tExtractJSONFields_2);
		
		try {
		    
		        value_tExtractJSONFields_2 = compiledJsonPath_tExtractJSONFields_2.read(row_tExtractJSONFields_2);
		    
				row14.lastName = value_tExtractJSONFields_2 == null ? 

		null

 : value_tExtractJSONFields_2.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_2) {
			row14.lastName = 

		null

;
		}
		jsonPath_tExtractJSONFields_2 = "MBI";
		compiledJsonPath_tExtractJSONFields_2 = jsonPathCache_tExtractJSONFields_2.getCompiledJsonPath(jsonPath_tExtractJSONFields_2);
		
		try {
		    
		        value_tExtractJSONFields_2 = compiledJsonPath_tExtractJSONFields_2.read(row_tExtractJSONFields_2);
		    
				row14.MBI = value_tExtractJSONFields_2 == null ? 

		null

 : value_tExtractJSONFields_2.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_2) {
			row14.MBI = 

		null

;
		}
		jsonPath_tExtractJSONFields_2 = "DOB";
		compiledJsonPath_tExtractJSONFields_2 = jsonPathCache_tExtractJSONFields_2.getCompiledJsonPath(jsonPath_tExtractJSONFields_2);
		
		try {
		    
		        value_tExtractJSONFields_2 = compiledJsonPath_tExtractJSONFields_2.read(row_tExtractJSONFields_2);
		    
				row14.DOB = value_tExtractJSONFields_2 == null ? 

		null

 : value_tExtractJSONFields_2.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_2) {
			row14.DOB = 

		null

;
		}
		jsonPath_tExtractJSONFields_2 = "OtherID";
		compiledJsonPath_tExtractJSONFields_2 = jsonPathCache_tExtractJSONFields_2.getCompiledJsonPath(jsonPath_tExtractJSONFields_2);
		
		try {
		    
		        value_tExtractJSONFields_2 = compiledJsonPath_tExtractJSONFields_2.read(row_tExtractJSONFields_2);
		    
				row14.OtherID = value_tExtractJSONFields_2 == null ? 

		null

 : value_tExtractJSONFields_2.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_2) {
			row14.OtherID = 

		null

;
		}
		jsonPath_tExtractJSONFields_2 = "SSN";
		compiledJsonPath_tExtractJSONFields_2 = jsonPathCache_tExtractJSONFields_2.getCompiledJsonPath(jsonPath_tExtractJSONFields_2);
		
		try {
		    
		        value_tExtractJSONFields_2 = compiledJsonPath_tExtractJSONFields_2.read(row_tExtractJSONFields_2);
		    
				row14.SSN = value_tExtractJSONFields_2 == null ? 

		null

 : value_tExtractJSONFields_2.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_2) {
			row14.SSN = 

		null

;
		}	
	} catch (java.lang.Exception ex_tExtractJSONFields_2) {
		    System.err.println(ex_tExtractJSONFields_2.getMessage());
		    row14 = null;	
	}
	
	}
    
	isStructError_tExtractJSONFields_2 = false;
	
//}


 


	tos_count_tExtractJSONFields_2++;

/**
 * [tExtractJSONFields_2 main ] stop
 */
	
	/**
	 * [tExtractJSONFields_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_2";

	

 



/**
 * [tExtractJSONFields_2 process_data_begin ] stop
 */
// Start of branch "row14"
if(row14 != null) { 



	
	/**
	 * [tMap_4 main ] start
	 */

	

	
	
	currentComponent="tMap_4";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"row14");
			

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_4 = false;
		
        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_4 = false;
		  boolean mainRowRejected_tMap_4 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_4__Struct Var = Var__tMap_4;
Var.var1 = Numeric.sequence("s4",1,1) ;// ###############################
        // ###############################
        // # Output tables

copyOfout = null;


// # Output table : 'copyOfout'
copyOfout_tmp.firstName = row14.firstName ;
copyOfout_tmp.lastName = row14.lastName ;
copyOfout_tmp.MBI = row14.MBI ;
copyOfout_tmp.DOB = row14.DOB ;
copyOfout_tmp.OtherID = row14.OtherID ;
copyOfout_tmp.SSN = row14.SSN ;
copyOfout_tmp.scd_key = Var.var1 ;
copyOfout = copyOfout_tmp;
// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_4 = false;










 


	tos_count_tMap_4++;

/**
 * [tMap_4 main ] stop
 */
	
	/**
	 * [tMap_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_4";

	

 



/**
 * [tMap_4 process_data_begin ] stop
 */
// Start of branch "copyOfout"
if(copyOfout != null) { 



	
	/**
	 * [tDBOutput_2 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"copyOfout");
			



            row16 = null;
        query_tDBOutput_2 = new StringBuffer("");
        whetherReject_tDBOutput_2 = false;
                        if(copyOfout.firstName == null) {
pstmt_tDBOutput_2.setNull(1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(1, copyOfout.firstName);
}

                        query_tDBOutput_2 = query_tDBOutput_2.append(insertSQLSplits_tDBOutput_2[0]).append(copyOfout.firstName== null ?  "null" :"'" + copyOfout.firstName + "'").append(insertSQLSplits_tDBOutput_2[1]);
                        if(copyOfout.lastName == null) {
pstmt_tDBOutput_2.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(2, copyOfout.lastName);
}

                        query_tDBOutput_2 = query_tDBOutput_2.append(copyOfout.lastName== null ?  "null" :"'" + copyOfout.lastName + "'").append(insertSQLSplits_tDBOutput_2[2]);
                        if(copyOfout.MBI == null) {
pstmt_tDBOutput_2.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(3, copyOfout.MBI);
}

                        query_tDBOutput_2 = query_tDBOutput_2.append(copyOfout.MBI== null ?  "null" :"'" + copyOfout.MBI + "'").append(insertSQLSplits_tDBOutput_2[3]);
                        if(copyOfout.DOB == null) {
pstmt_tDBOutput_2.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(4, copyOfout.DOB);
}

                        query_tDBOutput_2 = query_tDBOutput_2.append(copyOfout.DOB== null ?  "null" :"'" + copyOfout.DOB + "'").append(insertSQLSplits_tDBOutput_2[4]);
                        if(copyOfout.OtherID == null) {
pstmt_tDBOutput_2.setNull(5, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(5, copyOfout.OtherID);
}

                        query_tDBOutput_2 = query_tDBOutput_2.append(copyOfout.OtherID== null ?  "null" :"'" + copyOfout.OtherID + "'").append(insertSQLSplits_tDBOutput_2[5]);
                        if(copyOfout.SSN == null) {
pstmt_tDBOutput_2.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(6, copyOfout.SSN);
}

                        query_tDBOutput_2 = query_tDBOutput_2.append(copyOfout.SSN== null ?  "null" :"'" + copyOfout.SSN + "'").append(insertSQLSplits_tDBOutput_2[6]);
                        pstmt_tDBOutput_2.setInt(7, copyOfout.scd_key);

                        query_tDBOutput_2 = query_tDBOutput_2.append(String.valueOf(copyOfout.scd_key)).append(insertSQLSplits_tDBOutput_2[7]);
                globalMap.put("tDBOutput_2_QUERY", query_tDBOutput_2.toString().trim());
                try {
                    nb_line_tDBOutput_2++;
                    insertedCount_tDBOutput_2 = insertedCount_tDBOutput_2 + pstmt_tDBOutput_2.executeUpdate();
                } catch(java.lang.Exception e_tDBOutput_2) {
                    whetherReject_tDBOutput_2 = true;
                            System.err.print(e_tDBOutput_2.getMessage());
                }
            if(!whetherReject_tDBOutput_2) {
                            row16 = new row16Struct();
                                row16.firstName = copyOfout.firstName;
                                row16.lastName = copyOfout.lastName;
                                row16.MBI = copyOfout.MBI;
                                row16.DOB = copyOfout.DOB;
                                row16.OtherID = copyOfout.OtherID;
                                row16.SSN = copyOfout.SSN;
                                row16.scd_key = copyOfout.scd_key;
            }

 


	tos_count_tDBOutput_2++;

/**
 * [tDBOutput_2 main ] stop
 */
	
	/**
	 * [tDBOutput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";

	

 



/**
 * [tDBOutput_2 process_data_begin ] stop
 */
// Start of branch "row16"
if(row16 != null) { 



	
	/**
	 * [tLogRow_3 main ] start
	 */

	

	
	
	currentComponent="tLogRow_3";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"row16");
			
///////////////////////		
						

				
				String[] row_tLogRow_3 = new String[7];
   				
	    		if(row16.firstName != null) { //              
                 row_tLogRow_3[0]=    						    
				                String.valueOf(row16.firstName)			
					          ;	
							
	    		} //			
    			   				
	    		if(row16.lastName != null) { //              
                 row_tLogRow_3[1]=    						    
				                String.valueOf(row16.lastName)			
					          ;	
							
	    		} //			
    			   				
	    		if(row16.MBI != null) { //              
                 row_tLogRow_3[2]=    						    
				                String.valueOf(row16.MBI)			
					          ;	
							
	    		} //			
    			   				
	    		if(row16.DOB != null) { //              
                 row_tLogRow_3[3]=    						    
				                String.valueOf(row16.DOB)			
					          ;	
							
	    		} //			
    			   				
	    		if(row16.OtherID != null) { //              
                 row_tLogRow_3[4]=    						    
				                String.valueOf(row16.OtherID)			
					          ;	
							
	    		} //			
    			   				
	    		if(row16.SSN != null) { //              
                 row_tLogRow_3[5]=    						    
				                String.valueOf(row16.SSN)			
					          ;	
							
	    		} //			
    			              
                 row_tLogRow_3[6]=    						    
				                String.valueOf(row16.scd_key)			
					          ;	
										
    			 

				util_tLogRow_3.addRow(row_tLogRow_3);	
				nb_line_tLogRow_3++;
//////

//////                    
                    
///////////////////////    			

 


	tos_count_tLogRow_3++;

/**
 * [tLogRow_3 main ] stop
 */
	
	/**
	 * [tLogRow_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tLogRow_3";

	

 



/**
 * [tLogRow_3 process_data_begin ] stop
 */
	
	/**
	 * [tLogRow_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tLogRow_3";

	

 



/**
 * [tLogRow_3 process_data_end ] stop
 */

} // End of branch "row16"




	
	/**
	 * [tDBOutput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";

	

 



/**
 * [tDBOutput_2 process_data_end ] stop
 */

} // End of branch "copyOfout"




	
	/**
	 * [tMap_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_4";

	

 



/**
 * [tMap_4 process_data_end ] stop
 */

} // End of branch "row14"

		// end for
	}


	
		} // C_01
	
	
	/**
	 * [tExtractJSONFields_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_2";

	

 



/**
 * [tExtractJSONFields_2 process_data_end ] stop
 */



	
	/**
	 * [tREST_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tREST_2";

	

 



/**
 * [tREST_2 process_data_end ] stop
 */
	
	/**
	 * [tREST_2 end ] start
	 */

	

	
	
	currentComponent="tREST_2";

	

 

ok_Hash.put("tREST_2", true);
end_Hash.put("tREST_2", System.currentTimeMillis());




/**
 * [tREST_2 end ] stop
 */

	
	/**
	 * [tExtractJSONFields_2 end ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_2";

	
   globalMap.put("tExtractJSONFields_2_NB_LINE", nb_line_tExtractJSONFields_2);


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row10",2,0,
			 			talendJobLog,"tREST_2","tREST","tExtractJSONFields_2","tExtractJSONFields","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tExtractJSONFields_2", true);
end_Hash.put("tExtractJSONFields_2", System.currentTimeMillis());




/**
 * [tExtractJSONFields_2 end ] stop
 */

	
	/**
	 * [tMap_4 end ] start
	 */

	

	
	
	currentComponent="tMap_4";

	


// ###############################
// # Lookup hashes releasing
// ###############################      





			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row14",2,0,
			 			talendJobLog,"tExtractJSONFields_2","tExtractJSONFields","tMap_4","tMap","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tMap_4", true);
end_Hash.put("tMap_4", System.currentTimeMillis());




/**
 * [tMap_4 end ] stop
 */

	
	/**
	 * [tDBOutput_2 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";

	
	



	
        if(pstmt_tDBOutput_2 != null) {
			
				pstmt_tDBOutput_2.close();
				resourceMap.remove("pstmt_tDBOutput_2");
			
        }
    resourceMap.put("statementClosed_tDBOutput_2", true);


	
	nb_line_deleted_tDBOutput_2=nb_line_deleted_tDBOutput_2+ deletedCount_tDBOutput_2;
	nb_line_update_tDBOutput_2=nb_line_update_tDBOutput_2 + updatedCount_tDBOutput_2;
	nb_line_inserted_tDBOutput_2=nb_line_inserted_tDBOutput_2 + insertedCount_tDBOutput_2;
	nb_line_rejected_tDBOutput_2=nb_line_rejected_tDBOutput_2 + rejectedCount_tDBOutput_2;
	
        globalMap.put("tDBOutput_2_NB_LINE",nb_line_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_UPDATED",nb_line_update_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_DELETED",nb_line_deleted_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_2);
    
	



			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"copyOfout",2,0,
			 			talendJobLog,"tMap_4","tMap","tDBOutput_2","tOracleOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tDBOutput_2", true);
end_Hash.put("tDBOutput_2", System.currentTimeMillis());




/**
 * [tDBOutput_2 end ] stop
 */

	
	/**
	 * [tLogRow_3 end ] start
	 */

	

	
	
	currentComponent="tLogRow_3";

	


//////

                    
                    java.io.PrintStream consoleOut_tLogRow_3 = null;
                    if (globalMap.get("tLogRow_CONSOLE")!=null)
                    {
                    	consoleOut_tLogRow_3 = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
                    }
                    else
                    {
                    	consoleOut_tLogRow_3 = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
                    	globalMap.put("tLogRow_CONSOLE",consoleOut_tLogRow_3);
                    }
                    
                    consoleOut_tLogRow_3.println(util_tLogRow_3.format().toString());
                    consoleOut_tLogRow_3.flush();
//////
globalMap.put("tLogRow_3_NB_LINE",nb_line_tLogRow_3);

///////////////////////    			

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row16",2,0,
			 			talendJobLog,"tDBOutput_2","tOracleOutput","tLogRow_3","tLogRow","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tLogRow_3", true);
end_Hash.put("tLogRow_3", System.currentTimeMillis());




/**
 * [tLogRow_3 end ] stop
 */












						if(execStat){
							runStat.updateStatOnConnection("iterate4", 2, "exec" + NB_ITERATE_tREST_2);
						}				
					




	
	/**
	 * [tFlowToIterate_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_2";

	

 



/**
 * [tFlowToIterate_2 process_data_end ] stop
 */



	
	/**
	 * [tFileInputRaw_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileInputRaw_2";

	

 



/**
 * [tFileInputRaw_2 process_data_end ] stop
 */
	
	/**
	 * [tFileInputRaw_2 end ] start
	 */

	

	
	
	currentComponent="tFileInputRaw_2";

	



 

ok_Hash.put("tFileInputRaw_2", true);
end_Hash.put("tFileInputRaw_2", System.currentTimeMillis());




/**
 * [tFileInputRaw_2 end ] stop
 */

	
	/**
	 * [tFlowToIterate_2 end ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_2";

	

globalMap.put("tFlowToIterate_2_NB_LINE",nb_line_tFlowToIterate_2);
			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row9",2,0,
			 			talendJobLog,"tFileInputRaw_2","tFileInputRaw","tFlowToIterate_2","tFlowToIterate","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tFlowToIterate_2", true);
end_Hash.put("tFlowToIterate_2", System.currentTimeMillis());




/**
 * [tFlowToIterate_2 end ] stop
 */



				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFileInputRaw_2:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk7", 0, "ok");
								} 
							
							tDBInput_3Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileInputRaw_2 finally ] start
	 */

	

	
	
	currentComponent="tFileInputRaw_2";

	

 



/**
 * [tFileInputRaw_2 finally ] stop
 */

	
	/**
	 * [tFlowToIterate_2 finally ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_2";

	

 



/**
 * [tFlowToIterate_2 finally ] stop
 */

	
	/**
	 * [tREST_2 finally ] start
	 */

	

	
	
	currentComponent="tREST_2";

	

 



/**
 * [tREST_2 finally ] stop
 */

	
	/**
	 * [tExtractJSONFields_2 finally ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_2";

	

 



/**
 * [tExtractJSONFields_2 finally ] stop
 */

	
	/**
	 * [tMap_4 finally ] start
	 */

	

	
	
	currentComponent="tMap_4";

	

 



/**
 * [tMap_4 finally ] stop
 */

	
	/**
	 * [tDBOutput_2 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";

	



    if (resourceMap.get("statementClosed_tDBOutput_2") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_2 = null;
                if ((pstmtToClose_tDBOutput_2 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_2")) != null) {
                    pstmtToClose_tDBOutput_2.close();
                }
    }
 



/**
 * [tDBOutput_2 finally ] stop
 */

	
	/**
	 * [tLogRow_3 finally ] start
	 */

	

	
	
	currentComponent="tLogRow_3";

	

 



/**
 * [tLogRow_3 finally ] stop
 */


















				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileInputRaw_2_SUBPROCESS_STATE", 1);
	}
	


public static class copyOfoutputStruct implements routines.system.IPersistableRow<copyOfoutputStruct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];

	
			    public String Gender;

				public String getGender () {
					return this.Gender;
				}
				
			    public String Date_of_Birth;

				public String getDate_of_Birth () {
					return this.Date_of_Birth;
				}
				
			    public String First_Name;

				public String getFirst_Name () {
					return this.First_Name;
				}
				
			    public String Last_Name;

				public String getLast_Name () {
					return this.Last_Name;
				}
				
			    public String State;

				public String getState () {
					return this.State;
				}
				
			    public String City;

				public String getCity () {
					return this.City;
				}
				
			    public String Zip_Code;

				public String getZip_Code () {
					return this.Zip_Code;
				}
				
			    public String Address_Line_1;

				public String getAddress_Line_1 () {
					return this.Address_Line_1;
				}
				
			    public String Address_Line_2;

				public String getAddress_Line_2 () {
					return this.Address_Line_2;
				}
				
			    public String Phone_Number;

				public String getPhone_Number () {
					return this.Phone_Number;
				}
				
			    public String Social_Security_Number;

				public String getSocial_Security_Number () {
					return this.Social_Security_Number;
				}
				
			    public String UPI_ID;

				public String getUPI_ID () {
					return this.UPI_ID;
				}
				
			    public String MBI;

				public String getMBI () {
					return this.MBI;
				}
				
			    public String Client_ID;

				public String getClient_ID () {
					return this.Client_ID;
				}
				
			    public String Carrier_ID;

				public String getCarrier_ID () {
					return this.Carrier_ID;
				}
				
			    public String Account_ID;

				public String getAccount_ID () {
					return this.Account_ID;
				}
				
			    public String Group_ID;

				public String getGroup_ID () {
					return this.Group_ID;
				}
				
			    public String Contract_Family_ID;

				public String getContract_Family_ID () {
					return this.Contract_Family_ID;
				}
				
			    public String Multi_Birth_Code;

				public String getMulti_Birth_Code () {
					return this.Multi_Birth_Code;
				}
				
			    public String Member_Key;

				public String getMember_Key () {
					return this.Member_Key;
				}
				
			    public String Source;

				public String getSource () {
					return this.Source;
				}
				
			    public java.util.Date Lastupdated_date;

				public java.util.Date getLastupdated_date () {
					return this.Lastupdated_date;
				}
				
			    public String Lastupdateby;

				public String getLastupdateby () {
					return this.Lastupdateby;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam) {

        	try {

        		int length = 0;
		
					this.Gender = readString(dis);
					
					this.Date_of_Birth = readString(dis);
					
					this.First_Name = readString(dis);
					
					this.Last_Name = readString(dis);
					
					this.State = readString(dis);
					
					this.City = readString(dis);
					
					this.Zip_Code = readString(dis);
					
					this.Address_Line_1 = readString(dis);
					
					this.Address_Line_2 = readString(dis);
					
					this.Phone_Number = readString(dis);
					
					this.Social_Security_Number = readString(dis);
					
					this.UPI_ID = readString(dis);
					
					this.MBI = readString(dis);
					
					this.Client_ID = readString(dis);
					
					this.Carrier_ID = readString(dis);
					
					this.Account_ID = readString(dis);
					
					this.Group_ID = readString(dis);
					
					this.Contract_Family_ID = readString(dis);
					
					this.Multi_Birth_Code = readString(dis);
					
					this.Member_Key = readString(dis);
					
					this.Source = readString(dis);
					
					this.Lastupdated_date = readDate(dis);
					
					this.Lastupdateby = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Gender,dos);
					
					// String
				
						writeString(this.Date_of_Birth,dos);
					
					// String
				
						writeString(this.First_Name,dos);
					
					// String
				
						writeString(this.Last_Name,dos);
					
					// String
				
						writeString(this.State,dos);
					
					// String
				
						writeString(this.City,dos);
					
					// String
				
						writeString(this.Zip_Code,dos);
					
					// String
				
						writeString(this.Address_Line_1,dos);
					
					// String
				
						writeString(this.Address_Line_2,dos);
					
					// String
				
						writeString(this.Phone_Number,dos);
					
					// String
				
						writeString(this.Social_Security_Number,dos);
					
					// String
				
						writeString(this.UPI_ID,dos);
					
					// String
				
						writeString(this.MBI,dos);
					
					// String
				
						writeString(this.Client_ID,dos);
					
					// String
				
						writeString(this.Carrier_ID,dos);
					
					// String
				
						writeString(this.Account_ID,dos);
					
					// String
				
						writeString(this.Group_ID,dos);
					
					// String
				
						writeString(this.Contract_Family_ID,dos);
					
					// String
				
						writeString(this.Multi_Birth_Code,dos);
					
					// String
				
						writeString(this.Member_Key,dos);
					
					// String
				
						writeString(this.Source,dos);
					
					// java.util.Date
				
						writeDate(this.Lastupdated_date,dos);
					
					// String
				
						writeString(this.Lastupdateby,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Gender="+Gender);
		sb.append(",Date_of_Birth="+Date_of_Birth);
		sb.append(",First_Name="+First_Name);
		sb.append(",Last_Name="+Last_Name);
		sb.append(",State="+State);
		sb.append(",City="+City);
		sb.append(",Zip_Code="+Zip_Code);
		sb.append(",Address_Line_1="+Address_Line_1);
		sb.append(",Address_Line_2="+Address_Line_2);
		sb.append(",Phone_Number="+Phone_Number);
		sb.append(",Social_Security_Number="+Social_Security_Number);
		sb.append(",UPI_ID="+UPI_ID);
		sb.append(",MBI="+MBI);
		sb.append(",Client_ID="+Client_ID);
		sb.append(",Carrier_ID="+Carrier_ID);
		sb.append(",Account_ID="+Account_ID);
		sb.append(",Group_ID="+Group_ID);
		sb.append(",Contract_Family_ID="+Contract_Family_ID);
		sb.append(",Multi_Birth_Code="+Multi_Birth_Code);
		sb.append(",Member_Key="+Member_Key);
		sb.append(",Source="+Source);
		sb.append(",Lastupdated_date="+String.valueOf(Lastupdated_date));
		sb.append(",Lastupdateby="+Lastupdateby);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(copyOfoutputStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class file_outStruct implements routines.system.IPersistableRow<file_outStruct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];

	
			    public String Gender;

				public String getGender () {
					return this.Gender;
				}
				
			    public String Date_of_Birth;

				public String getDate_of_Birth () {
					return this.Date_of_Birth;
				}
				
			    public String First_Name;

				public String getFirst_Name () {
					return this.First_Name;
				}
				
			    public String Last_Name;

				public String getLast_Name () {
					return this.Last_Name;
				}
				
			    public String State;

				public String getState () {
					return this.State;
				}
				
			    public String City;

				public String getCity () {
					return this.City;
				}
				
			    public String Zip_Code;

				public String getZip_Code () {
					return this.Zip_Code;
				}
				
			    public String Address_Line_1;

				public String getAddress_Line_1 () {
					return this.Address_Line_1;
				}
				
			    public String Address_Line_2;

				public String getAddress_Line_2 () {
					return this.Address_Line_2;
				}
				
			    public String Phone_Number;

				public String getPhone_Number () {
					return this.Phone_Number;
				}
				
			    public String Social_Security_Number;

				public String getSocial_Security_Number () {
					return this.Social_Security_Number;
				}
				
			    public String UPI_ID;

				public String getUPI_ID () {
					return this.UPI_ID;
				}
				
			    public String MBI;

				public String getMBI () {
					return this.MBI;
				}
				
			    public String Client_ID;

				public String getClient_ID () {
					return this.Client_ID;
				}
				
			    public String Carrier_ID;

				public String getCarrier_ID () {
					return this.Carrier_ID;
				}
				
			    public String Account_ID;

				public String getAccount_ID () {
					return this.Account_ID;
				}
				
			    public String Group_ID;

				public String getGroup_ID () {
					return this.Group_ID;
				}
				
			    public String Contract_Family_ID;

				public String getContract_Family_ID () {
					return this.Contract_Family_ID;
				}
				
			    public String Multi_Birth_Code;

				public String getMulti_Birth_Code () {
					return this.Multi_Birth_Code;
				}
				
			    public String Member_Key;

				public String getMember_Key () {
					return this.Member_Key;
				}
				
			    public String Source;

				public String getSource () {
					return this.Source;
				}
				
			    public java.util.Date Lastupdated_date;

				public java.util.Date getLastupdated_date () {
					return this.Lastupdated_date;
				}
				
			    public String Lastupdateby;

				public String getLastupdateby () {
					return this.Lastupdateby;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam) {

        	try {

        		int length = 0;
		
					this.Gender = readString(dis);
					
					this.Date_of_Birth = readString(dis);
					
					this.First_Name = readString(dis);
					
					this.Last_Name = readString(dis);
					
					this.State = readString(dis);
					
					this.City = readString(dis);
					
					this.Zip_Code = readString(dis);
					
					this.Address_Line_1 = readString(dis);
					
					this.Address_Line_2 = readString(dis);
					
					this.Phone_Number = readString(dis);
					
					this.Social_Security_Number = readString(dis);
					
					this.UPI_ID = readString(dis);
					
					this.MBI = readString(dis);
					
					this.Client_ID = readString(dis);
					
					this.Carrier_ID = readString(dis);
					
					this.Account_ID = readString(dis);
					
					this.Group_ID = readString(dis);
					
					this.Contract_Family_ID = readString(dis);
					
					this.Multi_Birth_Code = readString(dis);
					
					this.Member_Key = readString(dis);
					
					this.Source = readString(dis);
					
					this.Lastupdated_date = readDate(dis);
					
					this.Lastupdateby = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Gender,dos);
					
					// String
				
						writeString(this.Date_of_Birth,dos);
					
					// String
				
						writeString(this.First_Name,dos);
					
					// String
				
						writeString(this.Last_Name,dos);
					
					// String
				
						writeString(this.State,dos);
					
					// String
				
						writeString(this.City,dos);
					
					// String
				
						writeString(this.Zip_Code,dos);
					
					// String
				
						writeString(this.Address_Line_1,dos);
					
					// String
				
						writeString(this.Address_Line_2,dos);
					
					// String
				
						writeString(this.Phone_Number,dos);
					
					// String
				
						writeString(this.Social_Security_Number,dos);
					
					// String
				
						writeString(this.UPI_ID,dos);
					
					// String
				
						writeString(this.MBI,dos);
					
					// String
				
						writeString(this.Client_ID,dos);
					
					// String
				
						writeString(this.Carrier_ID,dos);
					
					// String
				
						writeString(this.Account_ID,dos);
					
					// String
				
						writeString(this.Group_ID,dos);
					
					// String
				
						writeString(this.Contract_Family_ID,dos);
					
					// String
				
						writeString(this.Multi_Birth_Code,dos);
					
					// String
				
						writeString(this.Member_Key,dos);
					
					// String
				
						writeString(this.Source,dos);
					
					// java.util.Date
				
						writeDate(this.Lastupdated_date,dos);
					
					// String
				
						writeString(this.Lastupdateby,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Gender="+Gender);
		sb.append(",Date_of_Birth="+Date_of_Birth);
		sb.append(",First_Name="+First_Name);
		sb.append(",Last_Name="+Last_Name);
		sb.append(",State="+State);
		sb.append(",City="+City);
		sb.append(",Zip_Code="+Zip_Code);
		sb.append(",Address_Line_1="+Address_Line_1);
		sb.append(",Address_Line_2="+Address_Line_2);
		sb.append(",Phone_Number="+Phone_Number);
		sb.append(",Social_Security_Number="+Social_Security_Number);
		sb.append(",UPI_ID="+UPI_ID);
		sb.append(",MBI="+MBI);
		sb.append(",Client_ID="+Client_ID);
		sb.append(",Carrier_ID="+Carrier_ID);
		sb.append(",Account_ID="+Account_ID);
		sb.append(",Group_ID="+Group_ID);
		sb.append(",Contract_Family_ID="+Contract_Family_ID);
		sb.append(",Multi_Birth_Code="+Multi_Birth_Code);
		sb.append(",Member_Key="+Member_Key);
		sb.append(",Source="+Source);
		sb.append(",Lastupdated_date="+String.valueOf(Lastupdated_date));
		sb.append(",Lastupdateby="+Lastupdateby);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(file_outStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row26Struct implements routines.system.IPersistableRow<row26Struct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];

	
			    public String Gender;

				public String getGender () {
					return this.Gender;
				}
				
			    public String State;

				public String getState () {
					return this.State;
				}
				
			    public String City;

				public String getCity () {
					return this.City;
				}
				
			    public String Zip_Code;

				public String getZip_Code () {
					return this.Zip_Code;
				}
				
			    public String Address_Line_1;

				public String getAddress_Line_1 () {
					return this.Address_Line_1;
				}
				
			    public String Address_Line_2;

				public String getAddress_Line_2 () {
					return this.Address_Line_2;
				}
				
			    public String Phone_Number;

				public String getPhone_Number () {
					return this.Phone_Number;
				}
				
			    public String UPI_ID;

				public String getUPI_ID () {
					return this.UPI_ID;
				}
				
			    public String Client_ID;

				public String getClient_ID () {
					return this.Client_ID;
				}
				
			    public String Carrier_ID;

				public String getCarrier_ID () {
					return this.Carrier_ID;
				}
				
			    public String Account_ID;

				public String getAccount_ID () {
					return this.Account_ID;
				}
				
			    public String Group_ID;

				public String getGroup_ID () {
					return this.Group_ID;
				}
				
			    public String Multi_Birth_Code;

				public String getMulti_Birth_Code () {
					return this.Multi_Birth_Code;
				}
				
			    public String Member_Key;

				public String getMember_Key () {
					return this.Member_Key;
				}
				
			    public String Source;

				public String getSource () {
					return this.Source;
				}
				
			    public int scd_key;

				public int getScd_key () {
					return this.scd_key;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam) {

        	try {

        		int length = 0;
		
					this.Gender = readString(dis);
					
					this.State = readString(dis);
					
					this.City = readString(dis);
					
					this.Zip_Code = readString(dis);
					
					this.Address_Line_1 = readString(dis);
					
					this.Address_Line_2 = readString(dis);
					
					this.Phone_Number = readString(dis);
					
					this.UPI_ID = readString(dis);
					
					this.Client_ID = readString(dis);
					
					this.Carrier_ID = readString(dis);
					
					this.Account_ID = readString(dis);
					
					this.Group_ID = readString(dis);
					
					this.Multi_Birth_Code = readString(dis);
					
					this.Member_Key = readString(dis);
					
					this.Source = readString(dis);
					
			        this.scd_key = dis.readInt();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Gender,dos);
					
					// String
				
						writeString(this.State,dos);
					
					// String
				
						writeString(this.City,dos);
					
					// String
				
						writeString(this.Zip_Code,dos);
					
					// String
				
						writeString(this.Address_Line_1,dos);
					
					// String
				
						writeString(this.Address_Line_2,dos);
					
					// String
				
						writeString(this.Phone_Number,dos);
					
					// String
				
						writeString(this.UPI_ID,dos);
					
					// String
				
						writeString(this.Client_ID,dos);
					
					// String
				
						writeString(this.Carrier_ID,dos);
					
					// String
				
						writeString(this.Account_ID,dos);
					
					// String
				
						writeString(this.Group_ID,dos);
					
					// String
				
						writeString(this.Multi_Birth_Code,dos);
					
					// String
				
						writeString(this.Member_Key,dos);
					
					// String
				
						writeString(this.Source,dos);
					
					// int
				
		            	dos.writeInt(this.scd_key);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Gender="+Gender);
		sb.append(",State="+State);
		sb.append(",City="+City);
		sb.append(",Zip_Code="+Zip_Code);
		sb.append(",Address_Line_1="+Address_Line_1);
		sb.append(",Address_Line_2="+Address_Line_2);
		sb.append(",Phone_Number="+Phone_Number);
		sb.append(",UPI_ID="+UPI_ID);
		sb.append(",Client_ID="+Client_ID);
		sb.append(",Carrier_ID="+Carrier_ID);
		sb.append(",Account_ID="+Account_ID);
		sb.append(",Group_ID="+Group_ID);
		sb.append(",Multi_Birth_Code="+Multi_Birth_Code);
		sb.append(",Member_Key="+Member_Key);
		sb.append(",Source="+Source);
		sb.append(",scd_key="+String.valueOf(scd_key));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row26Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class after_tDBInput_3Struct implements routines.system.IPersistableRow<after_tDBInput_3Struct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];

	
			    public String Gender;

				public String getGender () {
					return this.Gender;
				}
				
			    public String State;

				public String getState () {
					return this.State;
				}
				
			    public String City;

				public String getCity () {
					return this.City;
				}
				
			    public String Zip_Code;

				public String getZip_Code () {
					return this.Zip_Code;
				}
				
			    public String Address_Line_1;

				public String getAddress_Line_1 () {
					return this.Address_Line_1;
				}
				
			    public String Address_Line_2;

				public String getAddress_Line_2 () {
					return this.Address_Line_2;
				}
				
			    public String Phone_Number;

				public String getPhone_Number () {
					return this.Phone_Number;
				}
				
			    public String UPI_ID;

				public String getUPI_ID () {
					return this.UPI_ID;
				}
				
			    public String Client_ID;

				public String getClient_ID () {
					return this.Client_ID;
				}
				
			    public String Carrier_ID;

				public String getCarrier_ID () {
					return this.Carrier_ID;
				}
				
			    public String Account_ID;

				public String getAccount_ID () {
					return this.Account_ID;
				}
				
			    public String Group_ID;

				public String getGroup_ID () {
					return this.Group_ID;
				}
				
			    public String Multi_Birth_Code;

				public String getMulti_Birth_Code () {
					return this.Multi_Birth_Code;
				}
				
			    public String Member_Key;

				public String getMember_Key () {
					return this.Member_Key;
				}
				
			    public String Source;

				public String getSource () {
					return this.Source;
				}
				
			    public int scd_key;

				public int getScd_key () {
					return this.scd_key;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam) {

        	try {

        		int length = 0;
		
					this.Gender = readString(dis);
					
					this.State = readString(dis);
					
					this.City = readString(dis);
					
					this.Zip_Code = readString(dis);
					
					this.Address_Line_1 = readString(dis);
					
					this.Address_Line_2 = readString(dis);
					
					this.Phone_Number = readString(dis);
					
					this.UPI_ID = readString(dis);
					
					this.Client_ID = readString(dis);
					
					this.Carrier_ID = readString(dis);
					
					this.Account_ID = readString(dis);
					
					this.Group_ID = readString(dis);
					
					this.Multi_Birth_Code = readString(dis);
					
					this.Member_Key = readString(dis);
					
					this.Source = readString(dis);
					
			        this.scd_key = dis.readInt();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Gender,dos);
					
					// String
				
						writeString(this.State,dos);
					
					// String
				
						writeString(this.City,dos);
					
					// String
				
						writeString(this.Zip_Code,dos);
					
					// String
				
						writeString(this.Address_Line_1,dos);
					
					// String
				
						writeString(this.Address_Line_2,dos);
					
					// String
				
						writeString(this.Phone_Number,dos);
					
					// String
				
						writeString(this.UPI_ID,dos);
					
					// String
				
						writeString(this.Client_ID,dos);
					
					// String
				
						writeString(this.Carrier_ID,dos);
					
					// String
				
						writeString(this.Account_ID,dos);
					
					// String
				
						writeString(this.Group_ID,dos);
					
					// String
				
						writeString(this.Multi_Birth_Code,dos);
					
					// String
				
						writeString(this.Member_Key,dos);
					
					// String
				
						writeString(this.Source,dos);
					
					// int
				
		            	dos.writeInt(this.scd_key);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Gender="+Gender);
		sb.append(",State="+State);
		sb.append(",City="+City);
		sb.append(",Zip_Code="+Zip_Code);
		sb.append(",Address_Line_1="+Address_Line_1);
		sb.append(",Address_Line_2="+Address_Line_2);
		sb.append(",Phone_Number="+Phone_Number);
		sb.append(",UPI_ID="+UPI_ID);
		sb.append(",Client_ID="+Client_ID);
		sb.append(",Carrier_ID="+Carrier_ID);
		sb.append(",Account_ID="+Account_ID);
		sb.append(",Group_ID="+Group_ID);
		sb.append(",Multi_Birth_Code="+Multi_Birth_Code);
		sb.append(",Member_Key="+Member_Key);
		sb.append(",Source="+Source);
		sb.append(",scd_key="+String.valueOf(scd_key));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(after_tDBInput_3Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tDBInput_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;


		tDBInput_1Process(globalMap);

		row26Struct row26 = new row26Struct();
copyOfoutputStruct copyOfoutput = new copyOfoutputStruct();
file_outStruct file_out = new file_outStruct();





	
	/**
	 * [tDBOutput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_3", false);
		start_Hash.put("tDBOutput_3", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_3";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"copyOfoutput");
			
		int tos_count_tDBOutput_3 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_3", "tOracleOutput");
				talendJobLogProcess(globalMap);
			}
			






    int nb_line_tDBOutput_3 = 0;
    int nb_line_update_tDBOutput_3 = 0;
    int nb_line_inserted_tDBOutput_3 = 0;
    int nb_line_deleted_tDBOutput_3 = 0;
    int nb_line_rejected_tDBOutput_3 = 0;

    int tmp_batchUpdateCount_tDBOutput_3 = 0;

    int deletedCount_tDBOutput_3=0;
    int updatedCount_tDBOutput_3=0;
    int insertedCount_tDBOutput_3=0;
    int rejectedCount_tDBOutput_3=0;

    boolean whetherReject_tDBOutput_3 = false;

    java.sql.Connection conn_tDBOutput_3 = null;

    //optional table
    String dbschema_tDBOutput_3 = null;
    String tableName_tDBOutput_3 = null;
        dbschema_tDBOutput_3 = (String)globalMap.get("dbschema_tDBConnection_1");
		
        conn_tDBOutput_3 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
        int count_tDBOutput_3=0;

        if(dbschema_tDBOutput_3 == null || dbschema_tDBOutput_3.trim().length() == 0) {
            tableName_tDBOutput_3 = ("MDM_Master");
        } else {
            tableName_tDBOutput_3 = dbschema_tDBOutput_3 + "." + ("MDM_Master");
        }
                                String tableNameForSearch_tDBOutput_3= "" + ((String)"MDM_Master") + "";
String dbschemaForSearch_tDBOutput_3= null;
if(dbschema_tDBOutput_3== null || dbschema_tDBOutput_3.trim().length() == 0) {
dbschemaForSearch_tDBOutput_3= ((String)globalMap.get("username_tDBConnection_1")).toUpperCase();
} else {
dbschemaForSearch_tDBOutput_3= dbschema_tDBOutput_3.toUpperCase();
}

                                java.sql.DatabaseMetaData dbMetaData_tDBOutput_3 = conn_tDBOutput_3.getMetaData();
                                if(tableNameForSearch_tDBOutput_3.indexOf("\"")==-1){
                                    tableNameForSearch_tDBOutput_3 = tableNameForSearch_tDBOutput_3.toUpperCase();
                                }else{
                                    tableNameForSearch_tDBOutput_3 = tableNameForSearch_tDBOutput_3.replaceAll("\"","");
                                }
                                boolean whetherExist_tDBOutput_3 = false;
                                try (java.sql.ResultSet rsTable_tDBOutput_3 = dbMetaData_tDBOutput_3.getTables(null, dbschemaForSearch_tDBOutput_3, tableNameForSearch_tDBOutput_3, new String[]{"TABLE"})) {
                                    if(rsTable_tDBOutput_3.next()) {
                                        whetherExist_tDBOutput_3 = true;
                                    }
                                }

                                if(whetherExist_tDBOutput_3) {
                                    try (java.sql.Statement stmtDrop_tDBOutput_3 = conn_tDBOutput_3.createStatement()) {
                                        stmtDrop_tDBOutput_3.execute("DROP TABLE " + tableName_tDBOutput_3 + "" );
                                    }
                                }
                                try(java.sql.Statement stmtCreate_tDBOutput_3 = conn_tDBOutput_3.createStatement()) {
                                    stmtCreate_tDBOutput_3.execute("CREATE TABLE " + tableName_tDBOutput_3 + "(Gender VARCHAR2(1)  ,Date_of_Birth VARCHAR2(14)  ,First_Name VARCHAR2(50)  ,Last_Name VARCHAR2(50)  ,State VARCHAR2(2)  ,City VARCHAR2(50)  ,Zip_Code VARCHAR2(15)  ,Address_Line_1 VARCHAR2(50)  ,Address_Line_2 VARCHAR2(50)  ,Phone_Number VARCHAR2(15)  ,Social_Security_Number VARCHAR2(15)  ,UPI_ID VARCHAR2(40)  ,MBI VARCHAR2(32)  ,Client_ID VARCHAR2(32)  ,Carrier_ID VARCHAR2(32)  ,Account_ID VARCHAR2(32)  ,Group_ID VARCHAR2(32)  ,Contract_Family_ID VARCHAR2(50)  ,Multi_Birth_Code VARCHAR2(10)  ,Member_Key VARCHAR2(38)  ,Source VARCHAR2(15)  ,Lastupdated_date DATE ,Lastupdateby VARCHAR2(14)  )");
                                }
                String insert_tDBOutput_3 = "INSERT INTO " + tableName_tDBOutput_3 + " (Gender,Date_of_Birth,First_Name,Last_Name,State,City,Zip_Code,Address_Line_1,Address_Line_2,Phone_Number,Social_Security_Number,UPI_ID,MBI,Client_ID,Carrier_ID,Account_ID,Group_ID,Contract_Family_ID,Multi_Birth_Code,Member_Key,Source,Lastupdated_date,Lastupdateby) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";    

                        java.sql.PreparedStatement pstmt_tDBOutput_3 = conn_tDBOutput_3.prepareStatement(insert_tDBOutput_3);
                        resourceMap.put("pstmt_tDBOutput_3", pstmt_tDBOutput_3);
                StringBuffer query_tDBOutput_3 = null;
		 	String[] insertSQLSplits_tDBOutput_3 = insert_tDBOutput_3.split("\\?");





 



/**
 * [tDBOutput_3 begin ] stop
 */




	
	/**
	 * [tFileOutputDelimited_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileOutputDelimited_1", false);
		start_Hash.put("tFileOutputDelimited_1", System.currentTimeMillis());
		
	
	currentComponent="tFileOutputDelimited_1";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"file_out");
			
		int tos_count_tFileOutputDelimited_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tFileOutputDelimited_1", "tFileOutputDelimited");
				talendJobLogProcess(globalMap);
			}
			

String fileName_tFileOutputDelimited_1 = "";
    fileName_tFileOutputDelimited_1 = (new java.io.File(context.stg_location+"Mdm_master.csv")).getAbsolutePath().replace("\\","/");
    String fullName_tFileOutputDelimited_1 = null;
    String extension_tFileOutputDelimited_1 = null;
    String directory_tFileOutputDelimited_1 = null;
    if((fileName_tFileOutputDelimited_1.indexOf("/") != -1)) {
        if(fileName_tFileOutputDelimited_1.lastIndexOf(".") < fileName_tFileOutputDelimited_1.lastIndexOf("/")) {
            fullName_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1;
            extension_tFileOutputDelimited_1 = "";
        } else {
            fullName_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1.substring(0, fileName_tFileOutputDelimited_1.lastIndexOf("."));
            extension_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1.substring(fileName_tFileOutputDelimited_1.lastIndexOf("."));
        }
        directory_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1.substring(0, fileName_tFileOutputDelimited_1.lastIndexOf("/"));
    } else {
        if(fileName_tFileOutputDelimited_1.lastIndexOf(".") != -1) {
            fullName_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1.substring(0, fileName_tFileOutputDelimited_1.lastIndexOf("."));
            extension_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1.substring(fileName_tFileOutputDelimited_1.lastIndexOf("."));
        } else {
            fullName_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1;
            extension_tFileOutputDelimited_1 = "";
        }
        directory_tFileOutputDelimited_1 = "";
    }
    boolean isFileGenerated_tFileOutputDelimited_1 = true;
    java.io.File filetFileOutputDelimited_1 = new java.io.File(fileName_tFileOutputDelimited_1);
    globalMap.put("tFileOutputDelimited_1_FILE_NAME",fileName_tFileOutputDelimited_1);
            int nb_line_tFileOutputDelimited_1 = 0;
            int splitedFileNo_tFileOutputDelimited_1 = 0;
            int currentRow_tFileOutputDelimited_1 = 0;

            final String OUT_DELIM_tFileOutputDelimited_1 = /** Start field tFileOutputDelimited_1:FIELDSEPARATOR */"|"/** End field tFileOutputDelimited_1:FIELDSEPARATOR */;

            final String OUT_DELIM_ROWSEP_tFileOutputDelimited_1 = /** Start field tFileOutputDelimited_1:ROWSEPARATOR */"\n"/** End field tFileOutputDelimited_1:ROWSEPARATOR */;

                    //create directory only if not exists
                    if(directory_tFileOutputDelimited_1 != null && directory_tFileOutputDelimited_1.trim().length() != 0) {
                        java.io.File dir_tFileOutputDelimited_1 = new java.io.File(directory_tFileOutputDelimited_1);
                        if(!dir_tFileOutputDelimited_1.exists()) {
                            dir_tFileOutputDelimited_1.mkdirs();
                        }
                    }

                        //routines.system.Row
                        java.io.Writer outtFileOutputDelimited_1 = null;

                        java.io.File fileToDelete_tFileOutputDelimited_1 = new java.io.File(fileName_tFileOutputDelimited_1);
                        if(fileToDelete_tFileOutputDelimited_1.exists()) {
                            fileToDelete_tFileOutputDelimited_1.delete();
                        }
                        outtFileOutputDelimited_1 = new java.io.BufferedWriter(new java.io.OutputStreamWriter(
                        new java.io.FileOutputStream(fileName_tFileOutputDelimited_1, false),"ISO-8859-15"));
                                    if(filetFileOutputDelimited_1.length()==0){
                                        outtFileOutputDelimited_1.write("Gender");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("Date_of_Birth");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("First_Name");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("Last_Name");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("State");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("City");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("Zip_Code");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("Address_Line_1");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("Address_Line_2");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("Phone_Number");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("Social_Security_Number");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("UPI_ID");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("MBI");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("Client_ID");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("Carrier_ID");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("Account_ID");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("Group_ID");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("Contract_Family_ID");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("Multi_Birth_Code");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("Member_Key");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("Source");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("Lastupdated_date");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("Lastupdateby");
                                        outtFileOutputDelimited_1.write(OUT_DELIM_ROWSEP_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.flush();
                                    }


        resourceMap.put("out_tFileOutputDelimited_1", outtFileOutputDelimited_1);
resourceMap.put("nb_line_tFileOutputDelimited_1", nb_line_tFileOutputDelimited_1);

 



/**
 * [tFileOutputDelimited_1 begin ] stop
 */



	
	/**
	 * [tMap_7 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_7", false);
		start_Hash.put("tMap_7", System.currentTimeMillis());
		
	
	currentComponent="tMap_7";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row26");
			
		int tos_count_tMap_7 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tMap_7", "tMap");
				talendJobLogProcess(globalMap);
			}
			




// ###############################
// # Lookup's keys initialization
	
		org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row19Struct> tHash_Lookup_row19 = (org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row19Struct>) 
				((org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row19Struct>) 
					globalMap.get( "tHash_Lookup_row19" ))
					;					
					
	

row19Struct row19HashKey = new row19Struct();
row19Struct row19Default = new row19Struct();
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_7__Struct  {
}
Var__tMap_7__Struct Var__tMap_7 = new Var__tMap_7__Struct();
// ###############################

// ###############################
// # Outputs initialization
copyOfoutputStruct copyOfoutput_tmp = new copyOfoutputStruct();
file_outStruct file_out_tmp = new file_outStruct();
// ###############################

        
        



        









 



/**
 * [tMap_7 begin ] stop
 */



	
	/**
	 * [tDBInput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_3", false);
		start_Hash.put("tDBInput_3", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_3";

	
		int tos_count_tDBInput_3 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_3", "tOracleInput");
				talendJobLogProcess(globalMap);
			}
			
	


	
		    int nb_line_tDBInput_3 = 0;
		    java.sql.Connection conn_tDBInput_3 = null;
				conn_tDBInput_3 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
                boolean isTimeZoneNull_tDBInput_3 = false;
				boolean isConnectionWrapped_tDBInput_3 = !(conn_tDBInput_3 instanceof oracle.jdbc.OracleConnection) && conn_tDBInput_3.isWrapperFor(oracle.jdbc.OracleConnection.class);
				oracle.jdbc.OracleConnection unwrappedOraConn_tDBInput_3 = null;
                if (isConnectionWrapped_tDBInput_3) {
					unwrappedOraConn_tDBInput_3 = conn_tDBInput_3.unwrap(oracle.jdbc.OracleConnection.class);
                    if (unwrappedOraConn_tDBInput_3 != null) {
                        isTimeZoneNull_tDBInput_3 = (unwrappedOraConn_tDBInput_3.getSessionTimeZone() == null);
                    }
                } else {
                    isTimeZoneNull_tDBInput_3 = (((oracle.jdbc.OracleConnection)conn_tDBInput_3).getSessionTimeZone() == null);
                }

				if(isTimeZoneNull_tDBInput_3) {
					java.sql.Statement stmtGetTZ_tDBInput_3 = conn_tDBInput_3.createStatement();
					java.sql.ResultSet rsGetTZ_tDBInput_3 = stmtGetTZ_tDBInput_3.executeQuery("select sessiontimezone from dual");
					String sessionTimezone_tDBInput_3 = java.util.TimeZone.getDefault().getID();
					while (rsGetTZ_tDBInput_3.next()) {
						sessionTimezone_tDBInput_3 = rsGetTZ_tDBInput_3.getString(1);
					}
					if (isConnectionWrapped_tDBInput_3 && unwrappedOraConn_tDBInput_3 != null) {
                        unwrappedOraConn_tDBInput_3.setSessionTimeZone(sessionTimezone_tDBInput_3);
                    } else {
                        ((oracle.jdbc.OracleConnection)conn_tDBInput_3).setSessionTimeZone(sessionTimezone_tDBInput_3);
                    }
				}
			
		    
			java.sql.Statement stmt_tDBInput_3 = conn_tDBInput_3.createStatement();

		    String dbquery_tDBInput_3 = "SELECT * from IRXMDM_DEV.TokenizationNotRequired_after";
			

            	globalMap.put("tDBInput_3_QUERY",dbquery_tDBInput_3);
		    java.sql.ResultSet rs_tDBInput_3 = null;

		    try {
		    	rs_tDBInput_3 = stmt_tDBInput_3.executeQuery(dbquery_tDBInput_3);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_3 = rs_tDBInput_3.getMetaData();
		    	int colQtyInRs_tDBInput_3 = rsmd_tDBInput_3.getColumnCount();

		    String tmpContent_tDBInput_3 = null;
		    
		    
		    while (rs_tDBInput_3.next()) {
		        nb_line_tDBInput_3++;
		        
							if(colQtyInRs_tDBInput_3 < 1) {
								row26.Gender = null;
							} else {
	                         		
        	row26.Gender = routines.system.JDBCUtil.getString(rs_tDBInput_3, 1, false);
		                    }
							if(colQtyInRs_tDBInput_3 < 2) {
								row26.State = null;
							} else {
	                         		
        	row26.State = routines.system.JDBCUtil.getString(rs_tDBInput_3, 2, false);
		                    }
							if(colQtyInRs_tDBInput_3 < 3) {
								row26.City = null;
							} else {
	                         		
        	row26.City = routines.system.JDBCUtil.getString(rs_tDBInput_3, 3, false);
		                    }
							if(colQtyInRs_tDBInput_3 < 4) {
								row26.Zip_Code = null;
							} else {
	                         		
        	row26.Zip_Code = routines.system.JDBCUtil.getString(rs_tDBInput_3, 4, false);
		                    }
							if(colQtyInRs_tDBInput_3 < 5) {
								row26.Address_Line_1 = null;
							} else {
	                         		
        	row26.Address_Line_1 = routines.system.JDBCUtil.getString(rs_tDBInput_3, 5, false);
		                    }
							if(colQtyInRs_tDBInput_3 < 6) {
								row26.Address_Line_2 = null;
							} else {
	                         		
        	row26.Address_Line_2 = routines.system.JDBCUtil.getString(rs_tDBInput_3, 6, false);
		                    }
							if(colQtyInRs_tDBInput_3 < 7) {
								row26.Phone_Number = null;
							} else {
	                         		
        	row26.Phone_Number = routines.system.JDBCUtil.getString(rs_tDBInput_3, 7, false);
		                    }
							if(colQtyInRs_tDBInput_3 < 8) {
								row26.UPI_ID = null;
							} else {
	                         		
        	row26.UPI_ID = routines.system.JDBCUtil.getString(rs_tDBInput_3, 8, false);
		                    }
							if(colQtyInRs_tDBInput_3 < 9) {
								row26.Client_ID = null;
							} else {
	                         		
        	row26.Client_ID = routines.system.JDBCUtil.getString(rs_tDBInput_3, 9, false);
		                    }
							if(colQtyInRs_tDBInput_3 < 10) {
								row26.Carrier_ID = null;
							} else {
	                         		
        	row26.Carrier_ID = routines.system.JDBCUtil.getString(rs_tDBInput_3, 10, false);
		                    }
							if(colQtyInRs_tDBInput_3 < 11) {
								row26.Account_ID = null;
							} else {
	                         		
        	row26.Account_ID = routines.system.JDBCUtil.getString(rs_tDBInput_3, 11, false);
		                    }
							if(colQtyInRs_tDBInput_3 < 12) {
								row26.Group_ID = null;
							} else {
	                         		
        	row26.Group_ID = routines.system.JDBCUtil.getString(rs_tDBInput_3, 12, false);
		                    }
							if(colQtyInRs_tDBInput_3 < 13) {
								row26.Multi_Birth_Code = null;
							} else {
	                         		
        	row26.Multi_Birth_Code = routines.system.JDBCUtil.getString(rs_tDBInput_3, 13, false);
		                    }
							if(colQtyInRs_tDBInput_3 < 14) {
								row26.Member_Key = null;
							} else {
	                         		
        	row26.Member_Key = routines.system.JDBCUtil.getString(rs_tDBInput_3, 14, false);
		                    }
							if(colQtyInRs_tDBInput_3 < 15) {
								row26.Source = null;
							} else {
	                         		
        	row26.Source = routines.system.JDBCUtil.getString(rs_tDBInput_3, 15, false);
		                    }
							if(colQtyInRs_tDBInput_3 < 16) {
								row26.scd_key = 0;
							} else {
		                          
					if(rs_tDBInput_3.getObject(16) != null) {
						row26.scd_key = rs_tDBInput_3.getInt(16);
					} else {
				
 	                	throw new RuntimeException("Null value in non-Nullable column");
					}
		                    }
					




 



/**
 * [tDBInput_3 begin ] stop
 */
	
	/**
	 * [tDBInput_3 main ] start
	 */

	

	
	
	currentComponent="tDBInput_3";

	

 


	tos_count_tDBInput_3++;

/**
 * [tDBInput_3 main ] stop
 */
	
	/**
	 * [tDBInput_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_3";

	

 



/**
 * [tDBInput_3 process_data_begin ] stop
 */

	
	/**
	 * [tMap_7 main ] start
	 */

	

	
	
	currentComponent="tMap_7";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"row26");
			

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_7 = false;
		
        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_7 = false;
		  boolean mainRowRejected_tMap_7 = false;
            				    								  
		

				///////////////////////////////////////////////
				// Starting Lookup Table "row19" 
				///////////////////////////////////////////////


				
				
                            
 					    boolean forceLooprow19 = false;
       		  	    	
       		  	    	
 							row19Struct row19ObjectFromLookup = null;
                          
		           		  	if(!rejectedInnerJoin_tMap_7) { // G_TM_M_020

								
								hasCasePrimitiveKeyWithNull_tMap_7 = false;
								
	                        		    	Object exprKeyValue_row19__scd_key = row26.scd_key ;
	                        		    	if(exprKeyValue_row19__scd_key == null) {
	                        		    		hasCasePrimitiveKeyWithNull_tMap_7 = true;
	                        		    	} else {
                        		    			row19HashKey.scd_key = (int)(Integer) exprKeyValue_row19__scd_key;
                        		    		}
                        		    		

								
		                        	row19HashKey.hashCodeDirty = true;
                        		
	  					
	  							
	
		  							if(!hasCasePrimitiveKeyWithNull_tMap_7) { // G_TM_M_091
		  							
			  					
			  					
			  					
	  					
		  							tHash_Lookup_row19.lookup( row19HashKey );

	  							

	  							

			  						} // G_TM_M_091
			  						
			  					

 								
								  
								  if(hasCasePrimitiveKeyWithNull_tMap_7 || !tHash_Lookup_row19.hasNext()) { // G_TM_M_090

  								
		  				
	  								
			  							rejectedInnerJoin_tMap_7 = true;
	  								
						
									
  									  		
 								
								  
								  } // G_TM_M_090

  								



							} // G_TM_M_020
			           		  	  
							
				           		if(tHash_Lookup_row19 != null && tHash_Lookup_row19.getCount(row19HashKey) > 1) { // G 071
			  							
			  						
									 		
									//System.out.println("WARNING: UNIQUE MATCH is configured for the lookup 'row19' and it contains more one result from keys :  row19.scd_key = '" + row19HashKey.scd_key + "'");
								} // G 071
							

							row19Struct row19 = null;
                    		  	 
							   
                    		  	 
	       		  	    	row19Struct fromLookup_row19 = null;
							row19 = row19Default;
										 
							
								 
							
							
								if (tHash_Lookup_row19 !=null && tHash_Lookup_row19.hasNext()) { // G 099
								
							
								
								fromLookup_row19 = tHash_Lookup_row19.next();

							
							
								} // G 099
							
							

							if(fromLookup_row19 != null) {
								row19 = fromLookup_row19;
							}
							
							
							
			  							
								
	                    		  	
		                    
	            	
	            	
	            // ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_7__Struct Var = Var__tMap_7;// ###############################
        // ###############################
        // # Output tables

copyOfoutput = null;
file_out = null;

if(!rejectedInnerJoin_tMap_7 ) {

// # Output table : 'copyOfoutput'
copyOfoutput_tmp.Gender = row26.Gender;
copyOfoutput_tmp.Date_of_Birth = row19.DOB ;
copyOfoutput_tmp.First_Name = row19.firstName ;
copyOfoutput_tmp.Last_Name = row19.lastName ;
copyOfoutput_tmp.State = row26.State;
copyOfoutput_tmp.City = row26.City;
copyOfoutput_tmp.Zip_Code = row26.Zip_Code;
copyOfoutput_tmp.Address_Line_1 = row26.Address_Line_1;
copyOfoutput_tmp.Address_Line_2 = row26.Address_Line_2;
copyOfoutput_tmp.Phone_Number = row26.Phone_Number;
copyOfoutput_tmp.Social_Security_Number = row19.SSN ;
copyOfoutput_tmp.UPI_ID = row26.UPI_ID ;
copyOfoutput_tmp.MBI = row19.MBI;
copyOfoutput_tmp.Client_ID = row26.Client_ID;
copyOfoutput_tmp.Carrier_ID = row26.Carrier_ID;
copyOfoutput_tmp.Account_ID = row26.Account_ID;
copyOfoutput_tmp.Group_ID = row26.Group_ID;
copyOfoutput_tmp.Contract_Family_ID = row19.OtherID ;
copyOfoutput_tmp.Multi_Birth_Code = row26.Multi_Birth_Code;
copyOfoutput_tmp.Member_Key = row26.Member_Key;
copyOfoutput_tmp.Source = row26.Source;
copyOfoutput_tmp.Lastupdated_date = TalendDate.getCurrentDate() ;
copyOfoutput_tmp.Lastupdateby = "Talend";
copyOfoutput = copyOfoutput_tmp;

// # Output table : 'file_out'
file_out_tmp.Gender = row26.Gender;
file_out_tmp.Date_of_Birth = row19.DOB ;
file_out_tmp.First_Name = row19.firstName ;
file_out_tmp.Last_Name = row19.lastName ;
file_out_tmp.State = row26.State;
file_out_tmp.City = row26.City;
file_out_tmp.Zip_Code = row26.Zip_Code;
file_out_tmp.Address_Line_1 = row26.Address_Line_1;
file_out_tmp.Address_Line_2 = row26.Address_Line_2;
file_out_tmp.Phone_Number = row26.Phone_Number;
file_out_tmp.Social_Security_Number = row19.SSN ;
file_out_tmp.UPI_ID = row26.UPI_ID;
file_out_tmp.MBI = row19.MBI;
file_out_tmp.Client_ID = row26.Client_ID;
file_out_tmp.Carrier_ID = row26.Carrier_ID;
file_out_tmp.Account_ID = row26.Account_ID;
file_out_tmp.Group_ID = row26.Group_ID;
file_out_tmp.Contract_Family_ID = row19.OtherID ;
file_out_tmp.Multi_Birth_Code = row26.Multi_Birth_Code;
file_out_tmp.Member_Key = row26.Member_Key;
file_out_tmp.Source = row26.Source;
file_out_tmp.Lastupdated_date = TalendDate.getCurrentDate() ;
file_out_tmp.Lastupdateby = "Talend";
file_out = file_out_tmp;
}  // closing inner join bracket (2)
// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_7 = false;










 


	tos_count_tMap_7++;

/**
 * [tMap_7 main ] stop
 */
	
	/**
	 * [tMap_7 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_7";

	

 



/**
 * [tMap_7 process_data_begin ] stop
 */
// Start of branch "copyOfoutput"
if(copyOfoutput != null) { 



	
	/**
	 * [tDBOutput_3 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"copyOfoutput");
			



        query_tDBOutput_3 = new StringBuffer("");
        whetherReject_tDBOutput_3 = false;
                        if(copyOfoutput.Gender == null) {
pstmt_tDBOutput_3.setNull(1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(1, copyOfoutput.Gender);
}

                        query_tDBOutput_3 = query_tDBOutput_3.append(insertSQLSplits_tDBOutput_3[0]).append(copyOfoutput.Gender== null ?  "null" :"'" + copyOfoutput.Gender + "'").append(insertSQLSplits_tDBOutput_3[1]);
                        if(copyOfoutput.Date_of_Birth == null) {
pstmt_tDBOutput_3.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(2, copyOfoutput.Date_of_Birth);
}

                        query_tDBOutput_3 = query_tDBOutput_3.append(copyOfoutput.Date_of_Birth== null ?  "null" :"'" + copyOfoutput.Date_of_Birth + "'").append(insertSQLSplits_tDBOutput_3[2]);
                        if(copyOfoutput.First_Name == null) {
pstmt_tDBOutput_3.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(3, copyOfoutput.First_Name);
}

                        query_tDBOutput_3 = query_tDBOutput_3.append(copyOfoutput.First_Name== null ?  "null" :"'" + copyOfoutput.First_Name + "'").append(insertSQLSplits_tDBOutput_3[3]);
                        if(copyOfoutput.Last_Name == null) {
pstmt_tDBOutput_3.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(4, copyOfoutput.Last_Name);
}

                        query_tDBOutput_3 = query_tDBOutput_3.append(copyOfoutput.Last_Name== null ?  "null" :"'" + copyOfoutput.Last_Name + "'").append(insertSQLSplits_tDBOutput_3[4]);
                        if(copyOfoutput.State == null) {
pstmt_tDBOutput_3.setNull(5, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(5, copyOfoutput.State);
}

                        query_tDBOutput_3 = query_tDBOutput_3.append(copyOfoutput.State== null ?  "null" :"'" + copyOfoutput.State + "'").append(insertSQLSplits_tDBOutput_3[5]);
                        if(copyOfoutput.City == null) {
pstmt_tDBOutput_3.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(6, copyOfoutput.City);
}

                        query_tDBOutput_3 = query_tDBOutput_3.append(copyOfoutput.City== null ?  "null" :"'" + copyOfoutput.City + "'").append(insertSQLSplits_tDBOutput_3[6]);
                        if(copyOfoutput.Zip_Code == null) {
pstmt_tDBOutput_3.setNull(7, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(7, copyOfoutput.Zip_Code);
}

                        query_tDBOutput_3 = query_tDBOutput_3.append(copyOfoutput.Zip_Code== null ?  "null" :"'" + copyOfoutput.Zip_Code + "'").append(insertSQLSplits_tDBOutput_3[7]);
                        if(copyOfoutput.Address_Line_1 == null) {
pstmt_tDBOutput_3.setNull(8, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(8, copyOfoutput.Address_Line_1);
}

                        query_tDBOutput_3 = query_tDBOutput_3.append(copyOfoutput.Address_Line_1== null ?  "null" :"'" + copyOfoutput.Address_Line_1 + "'").append(insertSQLSplits_tDBOutput_3[8]);
                        if(copyOfoutput.Address_Line_2 == null) {
pstmt_tDBOutput_3.setNull(9, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(9, copyOfoutput.Address_Line_2);
}

                        query_tDBOutput_3 = query_tDBOutput_3.append(copyOfoutput.Address_Line_2== null ?  "null" :"'" + copyOfoutput.Address_Line_2 + "'").append(insertSQLSplits_tDBOutput_3[9]);
                        if(copyOfoutput.Phone_Number == null) {
pstmt_tDBOutput_3.setNull(10, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(10, copyOfoutput.Phone_Number);
}

                        query_tDBOutput_3 = query_tDBOutput_3.append(copyOfoutput.Phone_Number== null ?  "null" :"'" + copyOfoutput.Phone_Number + "'").append(insertSQLSplits_tDBOutput_3[10]);
                        if(copyOfoutput.Social_Security_Number == null) {
pstmt_tDBOutput_3.setNull(11, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(11, copyOfoutput.Social_Security_Number);
}

                        query_tDBOutput_3 = query_tDBOutput_3.append(copyOfoutput.Social_Security_Number== null ?  "null" :"'" + copyOfoutput.Social_Security_Number + "'").append(insertSQLSplits_tDBOutput_3[11]);
                        if(copyOfoutput.UPI_ID == null) {
pstmt_tDBOutput_3.setNull(12, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(12, copyOfoutput.UPI_ID);
}

                        query_tDBOutput_3 = query_tDBOutput_3.append(copyOfoutput.UPI_ID== null ?  "null" :"'" + copyOfoutput.UPI_ID + "'").append(insertSQLSplits_tDBOutput_3[12]);
                        if(copyOfoutput.MBI == null) {
pstmt_tDBOutput_3.setNull(13, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(13, copyOfoutput.MBI);
}

                        query_tDBOutput_3 = query_tDBOutput_3.append(copyOfoutput.MBI== null ?  "null" :"'" + copyOfoutput.MBI + "'").append(insertSQLSplits_tDBOutput_3[13]);
                        if(copyOfoutput.Client_ID == null) {
pstmt_tDBOutput_3.setNull(14, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(14, copyOfoutput.Client_ID);
}

                        query_tDBOutput_3 = query_tDBOutput_3.append(copyOfoutput.Client_ID== null ?  "null" :"'" + copyOfoutput.Client_ID + "'").append(insertSQLSplits_tDBOutput_3[14]);
                        if(copyOfoutput.Carrier_ID == null) {
pstmt_tDBOutput_3.setNull(15, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(15, copyOfoutput.Carrier_ID);
}

                        query_tDBOutput_3 = query_tDBOutput_3.append(copyOfoutput.Carrier_ID== null ?  "null" :"'" + copyOfoutput.Carrier_ID + "'").append(insertSQLSplits_tDBOutput_3[15]);
                        if(copyOfoutput.Account_ID == null) {
pstmt_tDBOutput_3.setNull(16, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(16, copyOfoutput.Account_ID);
}

                        query_tDBOutput_3 = query_tDBOutput_3.append(copyOfoutput.Account_ID== null ?  "null" :"'" + copyOfoutput.Account_ID + "'").append(insertSQLSplits_tDBOutput_3[16]);
                        if(copyOfoutput.Group_ID == null) {
pstmt_tDBOutput_3.setNull(17, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(17, copyOfoutput.Group_ID);
}

                        query_tDBOutput_3 = query_tDBOutput_3.append(copyOfoutput.Group_ID== null ?  "null" :"'" + copyOfoutput.Group_ID + "'").append(insertSQLSplits_tDBOutput_3[17]);
                        if(copyOfoutput.Contract_Family_ID == null) {
pstmt_tDBOutput_3.setNull(18, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(18, copyOfoutput.Contract_Family_ID);
}

                        query_tDBOutput_3 = query_tDBOutput_3.append(copyOfoutput.Contract_Family_ID== null ?  "null" :"'" + copyOfoutput.Contract_Family_ID + "'").append(insertSQLSplits_tDBOutput_3[18]);
                        if(copyOfoutput.Multi_Birth_Code == null) {
pstmt_tDBOutput_3.setNull(19, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(19, copyOfoutput.Multi_Birth_Code);
}

                        query_tDBOutput_3 = query_tDBOutput_3.append(copyOfoutput.Multi_Birth_Code== null ?  "null" :"'" + copyOfoutput.Multi_Birth_Code + "'").append(insertSQLSplits_tDBOutput_3[19]);
                        if(copyOfoutput.Member_Key == null) {
pstmt_tDBOutput_3.setNull(20, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(20, copyOfoutput.Member_Key);
}

                        query_tDBOutput_3 = query_tDBOutput_3.append(copyOfoutput.Member_Key== null ?  "null" :"'" + copyOfoutput.Member_Key + "'").append(insertSQLSplits_tDBOutput_3[20]);
                        if(copyOfoutput.Source == null) {
pstmt_tDBOutput_3.setNull(21, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(21, copyOfoutput.Source);
}

                        query_tDBOutput_3 = query_tDBOutput_3.append(copyOfoutput.Source== null ?  "null" :"'" + copyOfoutput.Source + "'").append(insertSQLSplits_tDBOutput_3[21]);
                        if(copyOfoutput.Lastupdated_date != null) {
pstmt_tDBOutput_3.setDate(22, new java.sql.Date(copyOfoutput.Lastupdated_date.getTime()));
} else {
pstmt_tDBOutput_3.setNull(22, java.sql.Types.DATE);
}

                        query_tDBOutput_3 = query_tDBOutput_3.append(copyOfoutput.Lastupdated_date== null ?  "null" :"'" + new java.text.SimpleDateFormat("dd-MM-yyyy").format(copyOfoutput.Lastupdated_date) + "'").append(insertSQLSplits_tDBOutput_3[22]);
                        if(copyOfoutput.Lastupdateby == null) {
pstmt_tDBOutput_3.setNull(23, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(23, copyOfoutput.Lastupdateby);
}

                        query_tDBOutput_3 = query_tDBOutput_3.append(copyOfoutput.Lastupdateby== null ?  "null" :"'" + copyOfoutput.Lastupdateby + "'").append(insertSQLSplits_tDBOutput_3[23]);
                globalMap.put("tDBOutput_3_QUERY", query_tDBOutput_3.toString().trim());
                try {
                    nb_line_tDBOutput_3++;
                    insertedCount_tDBOutput_3 = insertedCount_tDBOutput_3 + pstmt_tDBOutput_3.executeUpdate();
                } catch(java.lang.Exception e_tDBOutput_3) {
                    whetherReject_tDBOutput_3 = true;
                            System.err.print(e_tDBOutput_3.getMessage());
                }

 


	tos_count_tDBOutput_3++;

/**
 * [tDBOutput_3 main ] stop
 */
	
	/**
	 * [tDBOutput_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";

	

 



/**
 * [tDBOutput_3 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";

	

 



/**
 * [tDBOutput_3 process_data_end ] stop
 */

} // End of branch "copyOfoutput"




// Start of branch "file_out"
if(file_out != null) { 



	
	/**
	 * [tFileOutputDelimited_1 main ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_1";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"file_out");
			


                    StringBuilder sb_tFileOutputDelimited_1 = new StringBuilder();
                            if(file_out.Gender != null) {
                        sb_tFileOutputDelimited_1.append(
                            file_out.Gender
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(file_out.Date_of_Birth != null) {
                        sb_tFileOutputDelimited_1.append(
                            file_out.Date_of_Birth
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(file_out.First_Name != null) {
                        sb_tFileOutputDelimited_1.append(
                            file_out.First_Name
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(file_out.Last_Name != null) {
                        sb_tFileOutputDelimited_1.append(
                            file_out.Last_Name
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(file_out.State != null) {
                        sb_tFileOutputDelimited_1.append(
                            file_out.State
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(file_out.City != null) {
                        sb_tFileOutputDelimited_1.append(
                            file_out.City
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(file_out.Zip_Code != null) {
                        sb_tFileOutputDelimited_1.append(
                            file_out.Zip_Code
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(file_out.Address_Line_1 != null) {
                        sb_tFileOutputDelimited_1.append(
                            file_out.Address_Line_1
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(file_out.Address_Line_2 != null) {
                        sb_tFileOutputDelimited_1.append(
                            file_out.Address_Line_2
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(file_out.Phone_Number != null) {
                        sb_tFileOutputDelimited_1.append(
                            file_out.Phone_Number
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(file_out.Social_Security_Number != null) {
                        sb_tFileOutputDelimited_1.append(
                            file_out.Social_Security_Number
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(file_out.UPI_ID != null) {
                        sb_tFileOutputDelimited_1.append(
                            file_out.UPI_ID
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(file_out.MBI != null) {
                        sb_tFileOutputDelimited_1.append(
                            file_out.MBI
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(file_out.Client_ID != null) {
                        sb_tFileOutputDelimited_1.append(
                            file_out.Client_ID
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(file_out.Carrier_ID != null) {
                        sb_tFileOutputDelimited_1.append(
                            file_out.Carrier_ID
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(file_out.Account_ID != null) {
                        sb_tFileOutputDelimited_1.append(
                            file_out.Account_ID
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(file_out.Group_ID != null) {
                        sb_tFileOutputDelimited_1.append(
                            file_out.Group_ID
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(file_out.Contract_Family_ID != null) {
                        sb_tFileOutputDelimited_1.append(
                            file_out.Contract_Family_ID
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(file_out.Multi_Birth_Code != null) {
                        sb_tFileOutputDelimited_1.append(
                            file_out.Multi_Birth_Code
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(file_out.Member_Key != null) {
                        sb_tFileOutputDelimited_1.append(
                            file_out.Member_Key
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(file_out.Source != null) {
                        sb_tFileOutputDelimited_1.append(
                            file_out.Source
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(file_out.Lastupdated_date != null) {
                        sb_tFileOutputDelimited_1.append(
                            FormatterUtils.format_Date(file_out.Lastupdated_date, "dd-MM-yyyy")
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(file_out.Lastupdateby != null) {
                        sb_tFileOutputDelimited_1.append(
                            file_out.Lastupdateby
                        );
                            }
                    sb_tFileOutputDelimited_1.append(OUT_DELIM_ROWSEP_tFileOutputDelimited_1);


                    nb_line_tFileOutputDelimited_1++;
                    resourceMap.put("nb_line_tFileOutputDelimited_1", nb_line_tFileOutputDelimited_1);

                        outtFileOutputDelimited_1.write(sb_tFileOutputDelimited_1.toString());




 


	tos_count_tFileOutputDelimited_1++;

/**
 * [tFileOutputDelimited_1 main ] stop
 */
	
	/**
	 * [tFileOutputDelimited_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_1";

	

 



/**
 * [tFileOutputDelimited_1 process_data_begin ] stop
 */
	
	/**
	 * [tFileOutputDelimited_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_1";

	

 



/**
 * [tFileOutputDelimited_1 process_data_end ] stop
 */

} // End of branch "file_out"




	
	/**
	 * [tMap_7 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_7";

	

 



/**
 * [tMap_7 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_3";

	

 



/**
 * [tDBInput_3 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_3 end ] start
	 */

	

	
	
	currentComponent="tDBInput_3";

	

}
}finally{
	if (rs_tDBInput_3 != null) {
		rs_tDBInput_3.close();
	}
	if (stmt_tDBInput_3 != null) {
		stmt_tDBInput_3.close();
	}
}

globalMap.put("tDBInput_3_NB_LINE",nb_line_tDBInput_3);
 

ok_Hash.put("tDBInput_3", true);
end_Hash.put("tDBInput_3", System.currentTimeMillis());




/**
 * [tDBInput_3 end ] stop
 */

	
	/**
	 * [tMap_7 end ] start
	 */

	

	
	
	currentComponent="tMap_7";

	


// ###############################
// # Lookup hashes releasing
					if(tHash_Lookup_row19 != null) {
						tHash_Lookup_row19.endGet();
					}
					globalMap.remove( "tHash_Lookup_row19" );

					
					
				
// ###############################      





			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row26",2,0,
			 			talendJobLog,"tDBInput_3","tOracleInput","tMap_7","tMap","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tMap_7", true);
end_Hash.put("tMap_7", System.currentTimeMillis());




/**
 * [tMap_7 end ] stop
 */

	
	/**
	 * [tDBOutput_3 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";

	
	



	
        if(pstmt_tDBOutput_3 != null) {
			
				pstmt_tDBOutput_3.close();
				resourceMap.remove("pstmt_tDBOutput_3");
			
        }
    resourceMap.put("statementClosed_tDBOutput_3", true);


	
	nb_line_deleted_tDBOutput_3=nb_line_deleted_tDBOutput_3+ deletedCount_tDBOutput_3;
	nb_line_update_tDBOutput_3=nb_line_update_tDBOutput_3 + updatedCount_tDBOutput_3;
	nb_line_inserted_tDBOutput_3=nb_line_inserted_tDBOutput_3 + insertedCount_tDBOutput_3;
	nb_line_rejected_tDBOutput_3=nb_line_rejected_tDBOutput_3 + rejectedCount_tDBOutput_3;
	
        globalMap.put("tDBOutput_3_NB_LINE",nb_line_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_UPDATED",nb_line_update_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_DELETED",nb_line_deleted_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_3);
    
	



			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"copyOfoutput",2,0,
			 			talendJobLog,"tMap_7","tMap","tDBOutput_3","tOracleOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tDBOutput_3", true);
end_Hash.put("tDBOutput_3", System.currentTimeMillis());




/**
 * [tDBOutput_3 end ] stop
 */




	
	/**
	 * [tFileOutputDelimited_1 end ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_1";

	



		
			
					if(outtFileOutputDelimited_1!=null) {
						outtFileOutputDelimited_1.flush();
						outtFileOutputDelimited_1.close();
					}
				
				globalMap.put("tFileOutputDelimited_1_NB_LINE",nb_line_tFileOutputDelimited_1);
				globalMap.put("tFileOutputDelimited_1_FILE_NAME",fileName_tFileOutputDelimited_1);
			
		
		
		resourceMap.put("finish_tFileOutputDelimited_1", true);
	

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"file_out",2,0,
			 			talendJobLog,"tMap_7","tMap","tFileOutputDelimited_1","tFileOutputDelimited","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tFileOutputDelimited_1", true);
end_Hash.put("tFileOutputDelimited_1", System.currentTimeMillis());




/**
 * [tFileOutputDelimited_1 end ] stop
 */






				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
					     			//free memory for "tMap_7"
					     			globalMap.remove("tHash_Lookup_row19"); 
				     			
				try{
					
	
	/**
	 * [tDBInput_3 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_3";

	

 



/**
 * [tDBInput_3 finally ] stop
 */

	
	/**
	 * [tMap_7 finally ] start
	 */

	

	
	
	currentComponent="tMap_7";

	

 



/**
 * [tMap_7 finally ] stop
 */

	
	/**
	 * [tDBOutput_3 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";

	



    if (resourceMap.get("statementClosed_tDBOutput_3") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_3 = null;
                if ((pstmtToClose_tDBOutput_3 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_3")) != null) {
                    pstmtToClose_tDBOutput_3.close();
                }
    }
 



/**
 * [tDBOutput_3 finally ] stop
 */




	
	/**
	 * [tFileOutputDelimited_1 finally ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_1";

	


		if(resourceMap.get("finish_tFileOutputDelimited_1") == null){ 
			
				
						java.io.Writer outtFileOutputDelimited_1 = (java.io.Writer)resourceMap.get("out_tFileOutputDelimited_1");
						if(outtFileOutputDelimited_1!=null) {
							outtFileOutputDelimited_1.flush();
							outtFileOutputDelimited_1.close();
						}
					
				
			
		}
	

 



/**
 * [tFileOutputDelimited_1 finally ] stop
 */






				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_3_SUBPROCESS_STATE", 1);
	}
	

public void tDBConnection_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBConnection_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBConnection_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBConnection_1", false);
		start_Hash.put("tDBConnection_1", System.currentTimeMillis());
		
	
	currentComponent="tDBConnection_1";

	
		int tos_count_tDBConnection_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tDBConnection_1", "tOracleConnection");
				talendJobLogProcess(globalMap);
			}
			
	

	
        String url_tDBConnection_1 = "jdbc:oracle:thin:@" + "aorcl-imdm-00dev01.czzet3yjlkjq.us-east-1.rds.amazonaws.com" + ":" + "1521" + ":" + "AIMDM00D";
    	globalMap.put("connectionType_" + "tDBConnection_1", "ORACLE_SID");
	String dbUser_tDBConnection_1 = "IRXMDM_DEV";
	
	
		 
	final String decryptedPassword_tDBConnection_1 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:rXu1383hdrqYYmKOGSNRmsx4wgAQl/cleVnFCRZ/u4heuoP8");
		String dbPwd_tDBConnection_1 = decryptedPassword_tDBConnection_1;
	
	
	java.sql.Connection conn_tDBConnection_1 = null;
	
		
			String driverClass_tDBConnection_1 = "oracle.jdbc.OracleDriver";
			java.lang.Class jdbcclazz_tDBConnection_1 = java.lang.Class.forName(driverClass_tDBConnection_1);
			globalMap.put("driverClass_tDBConnection_1", driverClass_tDBConnection_1);
		
			conn_tDBConnection_1 = java.sql.DriverManager.getConnection(url_tDBConnection_1,dbUser_tDBConnection_1,dbPwd_tDBConnection_1);

		globalMap.put("conn_tDBConnection_1", conn_tDBConnection_1);
	if (null != conn_tDBConnection_1) {
		
			conn_tDBConnection_1.setAutoCommit(true);
	}
        globalMap.put("host_" + "tDBConnection_1","aorcl-imdm-00dev01.czzet3yjlkjq.us-east-1.rds.amazonaws.com");
        globalMap.put("port_" + "tDBConnection_1","1521");
        globalMap.put("dbname_" + "tDBConnection_1","AIMDM00D");

	globalMap.put("conn_" + "tDBConnection_1",conn_tDBConnection_1);
	globalMap.put("dbschema_" + "tDBConnection_1", "IRXMDM_DEV");
	globalMap.put("username_" + "tDBConnection_1","IRXMDM_DEV");
	globalMap.put("password_" + "tDBConnection_1",dbPwd_tDBConnection_1);

 



/**
 * [tDBConnection_1 begin ] stop
 */
	
	/**
	 * [tDBConnection_1 main ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";

	

 


	tos_count_tDBConnection_1++;

/**
 * [tDBConnection_1 main ] stop
 */
	
	/**
	 * [tDBConnection_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";

	

 



/**
 * [tDBConnection_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBConnection_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";

	

 



/**
 * [tDBConnection_1 process_data_end ] stop
 */
	
	/**
	 * [tDBConnection_1 end ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";

	

 

ok_Hash.put("tDBConnection_1", true);
end_Hash.put("tDBConnection_1", System.currentTimeMillis());




/**
 * [tDBConnection_1 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tDBConnection_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk2", 0, "ok");
								} 
							
							tSetKeystore_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBConnection_1 finally ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";

	

 



/**
 * [tDBConnection_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBConnection_1_SUBPROCESS_STATE", 1);
	}
	

public void tSetKeystore_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tSetKeystore_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tSetKeystore_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tSetKeystore_1", false);
		start_Hash.put("tSetKeystore_1", System.currentTimeMillis());
		
	
	currentComponent="tSetKeystore_1";

	
		int tos_count_tSetKeystore_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tSetKeystore_1", "tSetKeystore");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tSetKeystore_1 begin ] stop
 */
	
	/**
	 * [tSetKeystore_1 main ] start
	 */

	

	
	
	currentComponent="tSetKeystore_1";

	



    System.setProperty("javax.net.ssl.trustStore", context.key_store_path);
    System.setProperty("javax.net.ssl.trustStoreType", "PKCS12");
    
    
	final String decryptedPassword_tSetKeystore_1 = context.key_store_password; 
    
    
    System.setProperty("javax.net.ssl.trustStorePassword", decryptedPassword_tSetKeystore_1);
	System.clearProperty("javax.net.ssl.keyStore");
	System.clearProperty("javax.net.ssl.keyStoreType");
	System.clearProperty("javax.net.ssl.keyStorePassword");
	        

 


	tos_count_tSetKeystore_1++;

/**
 * [tSetKeystore_1 main ] stop
 */
	
	/**
	 * [tSetKeystore_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tSetKeystore_1";

	

 



/**
 * [tSetKeystore_1 process_data_begin ] stop
 */
	
	/**
	 * [tSetKeystore_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tSetKeystore_1";

	

 



/**
 * [tSetKeystore_1 process_data_end ] stop
 */
	
	/**
	 * [tSetKeystore_1 end ] start
	 */

	

	
	
	currentComponent="tSetKeystore_1";

	

 

ok_Hash.put("tSetKeystore_1", true);
end_Hash.put("tSetKeystore_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk3", 0, "ok");
				}
				tCreateTemporaryFile_1Process(globalMap);



/**
 * [tSetKeystore_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tSetKeystore_1 finally ] start
	 */

	

	
	
	currentComponent="tSetKeystore_1";

	

 



/**
 * [tSetKeystore_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tSetKeystore_1_SUBPROCESS_STATE", 1);
	}
	

public void tCreateTemporaryFile_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tCreateTemporaryFile_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tCreateTemporaryFile_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tCreateTemporaryFile_1", false);
		start_Hash.put("tCreateTemporaryFile_1", System.currentTimeMillis());
		
	
	currentComponent="tCreateTemporaryFile_1";

	
		int tos_count_tCreateTemporaryFile_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tCreateTemporaryFile_1", "tCreateTemporaryFile");
				talendJobLogProcess(globalMap);
			}
			


	java.io.File dir_tCreateTemporaryFile_1 = new java.io.File(java.lang.System.getProperty("java.io.tmpdir"));
dir_tCreateTemporaryFile_1.mkdirs();
java.io.File file_tCreateTemporaryFile_1;
String name_tCreateTemporaryFile_1 = "tempfile";
String suffix_tCreateTemporaryFile_1 = ("".equals("tmp")) ? null : "." + "tmp".replaceAll("\\.", "");
file_tCreateTemporaryFile_1 = java.io.File.createTempFile(name_tCreateTemporaryFile_1, suffix_tCreateTemporaryFile_1, dir_tCreateTemporaryFile_1);

if (true || file_tCreateTemporaryFile_1.createNewFile()){
    file_tCreateTemporaryFile_1.deleteOnExit();
}
globalMap.put("tCreateTemporaryFile_1_FILEPATH", file_tCreateTemporaryFile_1.getCanonicalPath());


 



/**
 * [tCreateTemporaryFile_1 begin ] stop
 */
	
	/**
	 * [tCreateTemporaryFile_1 main ] start
	 */

	

	
	
	currentComponent="tCreateTemporaryFile_1";

	

 


	tos_count_tCreateTemporaryFile_1++;

/**
 * [tCreateTemporaryFile_1 main ] stop
 */
	
	/**
	 * [tCreateTemporaryFile_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tCreateTemporaryFile_1";

	

 



/**
 * [tCreateTemporaryFile_1 process_data_begin ] stop
 */
	
	/**
	 * [tCreateTemporaryFile_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tCreateTemporaryFile_1";

	

 



/**
 * [tCreateTemporaryFile_1 process_data_end ] stop
 */
	
	/**
	 * [tCreateTemporaryFile_1 end ] start
	 */

	

	
	
	currentComponent="tCreateTemporaryFile_1";

	

 

ok_Hash.put("tCreateTemporaryFile_1", true);
end_Hash.put("tCreateTemporaryFile_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk2", 0, "ok");
				}
				tCreateTemporaryFile_2Process(globalMap);



/**
 * [tCreateTemporaryFile_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tCreateTemporaryFile_1 finally ] start
	 */

	

	
	
	currentComponent="tCreateTemporaryFile_1";

	

 



/**
 * [tCreateTemporaryFile_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tCreateTemporaryFile_1_SUBPROCESS_STATE", 1);
	}
	

public void tCreateTemporaryFile_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tCreateTemporaryFile_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tCreateTemporaryFile_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tCreateTemporaryFile_2", false);
		start_Hash.put("tCreateTemporaryFile_2", System.currentTimeMillis());
		
	
	currentComponent="tCreateTemporaryFile_2";

	
		int tos_count_tCreateTemporaryFile_2 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tCreateTemporaryFile_2", "tCreateTemporaryFile");
				talendJobLogProcess(globalMap);
			}
			


	java.io.File dir_tCreateTemporaryFile_2 = new java.io.File(java.lang.System.getProperty("java.io.tmpdir"));
dir_tCreateTemporaryFile_2.mkdirs();
java.io.File file_tCreateTemporaryFile_2;
String name_tCreateTemporaryFile_2 = "UPI_detokenized";
String suffix_tCreateTemporaryFile_2 = ("".equals("tmp")) ? null : "." + "tmp".replaceAll("\\.", "");
file_tCreateTemporaryFile_2 = java.io.File.createTempFile(name_tCreateTemporaryFile_2, suffix_tCreateTemporaryFile_2, dir_tCreateTemporaryFile_2);

if (true || file_tCreateTemporaryFile_2.createNewFile()){
    file_tCreateTemporaryFile_2.deleteOnExit();
}
globalMap.put("tCreateTemporaryFile_2_FILEPATH", file_tCreateTemporaryFile_2.getCanonicalPath());


 



/**
 * [tCreateTemporaryFile_2 begin ] stop
 */
	
	/**
	 * [tCreateTemporaryFile_2 main ] start
	 */

	

	
	
	currentComponent="tCreateTemporaryFile_2";

	

 


	tos_count_tCreateTemporaryFile_2++;

/**
 * [tCreateTemporaryFile_2 main ] stop
 */
	
	/**
	 * [tCreateTemporaryFile_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tCreateTemporaryFile_2";

	

 



/**
 * [tCreateTemporaryFile_2 process_data_begin ] stop
 */
	
	/**
	 * [tCreateTemporaryFile_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tCreateTemporaryFile_2";

	

 



/**
 * [tCreateTemporaryFile_2 process_data_end ] stop
 */
	
	/**
	 * [tCreateTemporaryFile_2 end ] start
	 */

	

	
	
	currentComponent="tCreateTemporaryFile_2";

	

 

ok_Hash.put("tCreateTemporaryFile_2", true);
end_Hash.put("tCreateTemporaryFile_2", System.currentTimeMillis());




/**
 * [tCreateTemporaryFile_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tCreateTemporaryFile_2 finally ] start
	 */

	

	
	
	currentComponent="tCreateTemporaryFile_2";

	

 



/**
 * [tCreateTemporaryFile_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tCreateTemporaryFile_2_SUBPROCESS_STATE", 1);
	}
	


public static class row7Struct implements routines.system.IPersistableComparableLookupRow<row7Struct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public String firstName;

				public String getFirstName () {
					return this.firstName;
				}
				
			    public String lastName;

				public String getLastName () {
					return this.lastName;
				}
				
			    public String MBI;

				public String getMBI () {
					return this.MBI;
				}
				
			    public String DOB;

				public String getDOB () {
					return this.DOB;
				}
				
			    public String OtherID;

				public String getOtherID () {
					return this.OtherID;
				}
				
			    public String SSN;

				public String getSSN () {
					return this.SSN;
				}
				
			    public int scd_key;

				public int getScd_key () {
					return this.scd_key;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.scd_key;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row7Struct other = (row7Struct) obj;
		
						if (this.scd_key != other.scd_key)
							return false;
					

		return true;
    }

	public void copyDataTo(row7Struct other) {

		other.firstName = this.firstName;
	            other.lastName = this.lastName;
	            other.MBI = this.MBI;
	            other.DOB = this.DOB;
	            other.OtherID = this.OtherID;
	            other.SSN = this.SSN;
	            other.scd_key = this.scd_key;
	            
	}

	public void copyKeysDataTo(row7Struct other) {

		other.scd_key = this.scd_key;
	            	
	}




	private String readString(DataInputStream dis, ObjectInputStream ois) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			byte[] byteArray = new byte[length];
			dis.read(byteArray);
			strReturn = new String(byteArray, utf8Charset);
		}
		return strReturn;
	}

	private void writeString(String str, DataOutputStream dos, ObjectOutputStream oos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
	}

    public void readKeysData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam) {

        	try {

        		int length = 0;
		
			        this.scd_key = dis.readInt();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeKeysData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.scd_key);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }



    /**
     * Fill Values data by reading ObjectInputStream.
     */
    public void readValuesData(DataInputStream dis, ObjectInputStream ois) {
        try {

			int length = 0;
		
						this.firstName = readString(dis,ois);
					
						this.lastName = readString(dis,ois);
					
						this.MBI = readString(dis,ois);
					
						this.DOB = readString(dis,ois);
					
						this.OtherID = readString(dis,ois);
					
						this.SSN = readString(dis,ois);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

    }

    /**
     * Return a byte array which represents Values data.
     */
    public void writeValuesData(DataOutputStream dos, ObjectOutputStream oos) {
        try {

		
						writeString(this.firstName, dos, oos);
					
						writeString(this.lastName, dos, oos);
					
						writeString(this.MBI, dos, oos);
					
						writeString(this.DOB, dos, oos);
					
						writeString(this.OtherID, dos, oos);
					
						writeString(this.SSN, dos, oos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        	}

    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("firstName="+firstName);
		sb.append(",lastName="+lastName);
		sb.append(",MBI="+MBI);
		sb.append(",DOB="+DOB);
		sb.append(",OtherID="+OtherID);
		sb.append(",SSN="+SSN);
		sb.append(",scd_key="+String.valueOf(scd_key));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row7Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.scd_key, other.scd_key);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tBufferInput_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tBufferInput_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row7Struct row7 = new row7Struct();




	
	/**
	 * [tAdvancedHash_row7 begin ] start
	 */

	

	
		
		ok_Hash.put("tAdvancedHash_row7", false);
		start_Hash.put("tAdvancedHash_row7", System.currentTimeMillis());
		
	
	currentComponent="tAdvancedHash_row7";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row7");
			
		int tos_count_tAdvancedHash_row7 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAdvancedHash_row7", "tAdvancedHash");
				talendJobLogProcess(globalMap);
			}
			

			   		// connection name:row7
			   		// source node:tBufferInput_2 - inputs:(after_tDBInput_2) outputs:(row7,row7) | target node:tAdvancedHash_row7 - inputs:(row7) outputs:()
			   		// linked node: tMap_1 - inputs:(row1,row7) outputs:(output)
			   
			   		org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_row7 = 
			   			org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.UNIQUE_MATCH;
			   			
			   
	   			org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row7Struct> tHash_Lookup_row7 =org.talend.designer.components.lookup.memory.AdvancedMemoryLookup.
	   						<row7Struct>getLookup(matchingModeEnum_row7);
	   						   
		   	   	   globalMap.put("tHash_Lookup_row7", tHash_Lookup_row7);
		   	   	   
				
           

 



/**
 * [tAdvancedHash_row7 begin ] stop
 */



	
	/**
	 * [tBufferInput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tBufferInput_2", false);
		start_Hash.put("tBufferInput_2", System.currentTimeMillis());
		
	
	currentComponent="tBufferInput_2";

	
		int tos_count_tBufferInput_2 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tBufferInput_2", "tBufferInput");
				talendJobLogProcess(globalMap);
			}
			

int nb_line_tBufferInput_2 = 0;

String[] row_tBufferInput_2 = new String[7];
for (int n = 0; n < globalBuffer.size(); n++)
{
	row_tBufferInput_2 = (String[])globalBuffer.get(n);	
	if(0 < row_tBufferInput_2.length){
	
		row7.firstName = row_tBufferInput_2[0];	
	
	}
	
	else{
		row7.firstName = null;
	}	
	if(1 < row_tBufferInput_2.length){
	
		row7.lastName = row_tBufferInput_2[1];	
	
	}
	
	else{
		row7.lastName = null;
	}	
	if(2 < row_tBufferInput_2.length){
	
		row7.MBI = row_tBufferInput_2[2];	
	
	}
	
	else{
		row7.MBI = null;
	}	
	if(3 < row_tBufferInput_2.length){
	
		row7.DOB = row_tBufferInput_2[3];	
	
	}
	
	else{
		row7.DOB = null;
	}	
	if(4 < row_tBufferInput_2.length){
	
		row7.OtherID = row_tBufferInput_2[4];	
	
	}
	
	else{
		row7.OtherID = null;
	}	
	if(5 < row_tBufferInput_2.length){
	
		row7.SSN = row_tBufferInput_2[5];	
	
	}
	
	else{
		row7.SSN = null;
	}	
	if(6 < row_tBufferInput_2.length){
	
		row7.scd_key = ParserUtils.parseTo_int(row_tBufferInput_2[6]);
	
	}
	
 



/**
 * [tBufferInput_2 begin ] stop
 */
	
	/**
	 * [tBufferInput_2 main ] start
	 */

	

	
	
	currentComponent="tBufferInput_2";

	

 


	tos_count_tBufferInput_2++;

/**
 * [tBufferInput_2 main ] stop
 */
	
	/**
	 * [tBufferInput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tBufferInput_2";

	

 



/**
 * [tBufferInput_2 process_data_begin ] stop
 */

	
	/**
	 * [tAdvancedHash_row7 main ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row7";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"row7");
			


			   
			   

					row7Struct row7_HashRow = new row7Struct();
		   	   	   
				
				row7_HashRow.firstName = row7.firstName;
				
				row7_HashRow.lastName = row7.lastName;
				
				row7_HashRow.MBI = row7.MBI;
				
				row7_HashRow.DOB = row7.DOB;
				
				row7_HashRow.OtherID = row7.OtherID;
				
				row7_HashRow.SSN = row7.SSN;
				
				row7_HashRow.scd_key = row7.scd_key;
				
			tHash_Lookup_row7.put(row7_HashRow);
			
            




 


	tos_count_tAdvancedHash_row7++;

/**
 * [tAdvancedHash_row7 main ] stop
 */
	
	/**
	 * [tAdvancedHash_row7 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row7";

	

 



/**
 * [tAdvancedHash_row7 process_data_begin ] stop
 */
	
	/**
	 * [tAdvancedHash_row7 process_data_end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row7";

	

 



/**
 * [tAdvancedHash_row7 process_data_end ] stop
 */



	
	/**
	 * [tBufferInput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tBufferInput_2";

	

 



/**
 * [tBufferInput_2 process_data_end ] stop
 */
	
	/**
	 * [tBufferInput_2 end ] start
	 */

	

	
	
	currentComponent="tBufferInput_2";

	
	nb_line_tBufferInput_2++;
}
globalMap.put("tBufferInput_2_NB_LINE",nb_line_tBufferInput_2); 

 

ok_Hash.put("tBufferInput_2", true);
end_Hash.put("tBufferInput_2", System.currentTimeMillis());




/**
 * [tBufferInput_2 end ] stop
 */

	
	/**
	 * [tAdvancedHash_row7 end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row7";

	

tHash_Lookup_row7.endPut();

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row7",2,0,
			 			talendJobLog,"tBufferInput_2","tBufferInput","tAdvancedHash_row7","tAdvancedHash","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tAdvancedHash_row7", true);
end_Hash.put("tAdvancedHash_row7", System.currentTimeMillis());




/**
 * [tAdvancedHash_row7 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tBufferInput_2 finally ] start
	 */

	

	
	
	currentComponent="tBufferInput_2";

	

 



/**
 * [tBufferInput_2 finally ] stop
 */

	
	/**
	 * [tAdvancedHash_row7 finally ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row7";

	

 



/**
 * [tAdvancedHash_row7 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tBufferInput_2_SUBPROCESS_STATE", 1);
	}
	

public void tPrejob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPrejob_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tPrejob_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPrejob_1", false);
		start_Hash.put("tPrejob_1", System.currentTimeMillis());
		
	
	currentComponent="tPrejob_1";

	
		int tos_count_tPrejob_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tPrejob_1", "tPrejob");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tPrejob_1 begin ] stop
 */
	
	/**
	 * [tPrejob_1 main ] start
	 */

	

	
	
	currentComponent="tPrejob_1";

	

 


	tos_count_tPrejob_1++;

/**
 * [tPrejob_1 main ] stop
 */
	
	/**
	 * [tPrejob_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tPrejob_1";

	

 



/**
 * [tPrejob_1 process_data_begin ] stop
 */
	
	/**
	 * [tPrejob_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tPrejob_1";

	

 



/**
 * [tPrejob_1 process_data_end ] stop
 */
	
	/**
	 * [tPrejob_1 end ] start
	 */

	

	
	
	currentComponent="tPrejob_1";

	

 

ok_Hash.put("tPrejob_1", true);
end_Hash.put("tPrejob_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk1", 0, "ok");
				}
				tDBConnection_1Process(globalMap);



/**
 * [tPrejob_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPrejob_1 finally ] start
	 */

	

	
	
	currentComponent="tPrejob_1";

	

 



/**
 * [tPrejob_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPrejob_1_SUBPROCESS_STATE", 1);
	}
	


public static class row19Struct implements routines.system.IPersistableComparableLookupRow<row19Struct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecords_Detokenization_globalparam = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public String firstName;

				public String getFirstName () {
					return this.firstName;
				}
				
			    public String lastName;

				public String getLastName () {
					return this.lastName;
				}
				
			    public String MBI;

				public String getMBI () {
					return this.MBI;
				}
				
			    public String DOB;

				public String getDOB () {
					return this.DOB;
				}
				
			    public String OtherID;

				public String getOtherID () {
					return this.OtherID;
				}
				
			    public String SSN;

				public String getSSN () {
					return this.SSN;
				}
				
			    public int scd_key;

				public int getScd_key () {
					return this.scd_key;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.scd_key;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row19Struct other = (row19Struct) obj;
		
						if (this.scd_key != other.scd_key)
							return false;
					

		return true;
    }

	public void copyDataTo(row19Struct other) {

		other.firstName = this.firstName;
	            other.lastName = this.lastName;
	            other.MBI = this.MBI;
	            other.DOB = this.DOB;
	            other.OtherID = this.OtherID;
	            other.SSN = this.SSN;
	            other.scd_key = this.scd_key;
	            
	}

	public void copyKeysDataTo(row19Struct other) {

		other.scd_key = this.scd_key;
	            	
	}




	private String readString(DataInputStream dis, ObjectInputStream ois) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			byte[] byteArray = new byte[length];
			dis.read(byteArray);
			strReturn = new String(byteArray, utf8Charset);
		}
		return strReturn;
	}

	private void writeString(String str, DataOutputStream dos, ObjectOutputStream oos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
	}

    public void readKeysData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Detokenization_globalparam) {

        	try {

        		int length = 0;
		
			        this.scd_key = dis.readInt();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeKeysData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.scd_key);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }



    /**
     * Fill Values data by reading ObjectInputStream.
     */
    public void readValuesData(DataInputStream dis, ObjectInputStream ois) {
        try {

			int length = 0;
		
						this.firstName = readString(dis,ois);
					
						this.lastName = readString(dis,ois);
					
						this.MBI = readString(dis,ois);
					
						this.DOB = readString(dis,ois);
					
						this.OtherID = readString(dis,ois);
					
						this.SSN = readString(dis,ois);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

    }

    /**
     * Return a byte array which represents Values data.
     */
    public void writeValuesData(DataOutputStream dos, ObjectOutputStream oos) {
        try {

		
						writeString(this.firstName, dos, oos);
					
						writeString(this.lastName, dos, oos);
					
						writeString(this.MBI, dos, oos);
					
						writeString(this.DOB, dos, oos);
					
						writeString(this.OtherID, dos, oos);
					
						writeString(this.SSN, dos, oos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        	}

    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("firstName="+firstName);
		sb.append(",lastName="+lastName);
		sb.append(",MBI="+MBI);
		sb.append(",DOB="+DOB);
		sb.append(",OtherID="+OtherID);
		sb.append(",SSN="+SSN);
		sb.append(",scd_key="+String.valueOf(scd_key));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row19Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.scd_key, other.scd_key);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tDBInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row19Struct row19 = new row19Struct();




	
	/**
	 * [tAdvancedHash_row19 begin ] start
	 */

	

	
		
		ok_Hash.put("tAdvancedHash_row19", false);
		start_Hash.put("tAdvancedHash_row19", System.currentTimeMillis());
		
	
	currentComponent="tAdvancedHash_row19";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row19");
			
		int tos_count_tAdvancedHash_row19 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAdvancedHash_row19", "tAdvancedHash");
				talendJobLogProcess(globalMap);
			}
			

			   		// connection name:row19
			   		// source node:tDBInput_1 - inputs:(after_tDBInput_3) outputs:(row19,row19) | target node:tAdvancedHash_row19 - inputs:(row19) outputs:()
			   		// linked node: tMap_7 - inputs:(row26,row19) outputs:(copyOfoutput,file_out)
			   
			   		org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_row19 = 
			   			org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.UNIQUE_MATCH;
			   			
			   
	   			org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row19Struct> tHash_Lookup_row19 =org.talend.designer.components.lookup.memory.AdvancedMemoryLookup.
	   						<row19Struct>getLookup(matchingModeEnum_row19);
	   						   
		   	   	   globalMap.put("tHash_Lookup_row19", tHash_Lookup_row19);
		   	   	   
				
           

 



/**
 * [tAdvancedHash_row19 begin ] stop
 */



	
	/**
	 * [tDBInput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_1", false);
		start_Hash.put("tDBInput_1", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_1";

	
		int tos_count_tDBInput_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_1", "tOracleInput");
				talendJobLogProcess(globalMap);
			}
			
	


	
		    int nb_line_tDBInput_1 = 0;
		    java.sql.Connection conn_tDBInput_1 = null;
				conn_tDBInput_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
                boolean isTimeZoneNull_tDBInput_1 = false;
				boolean isConnectionWrapped_tDBInput_1 = !(conn_tDBInput_1 instanceof oracle.jdbc.OracleConnection) && conn_tDBInput_1.isWrapperFor(oracle.jdbc.OracleConnection.class);
				oracle.jdbc.OracleConnection unwrappedOraConn_tDBInput_1 = null;
                if (isConnectionWrapped_tDBInput_1) {
					unwrappedOraConn_tDBInput_1 = conn_tDBInput_1.unwrap(oracle.jdbc.OracleConnection.class);
                    if (unwrappedOraConn_tDBInput_1 != null) {
                        isTimeZoneNull_tDBInput_1 = (unwrappedOraConn_tDBInput_1.getSessionTimeZone() == null);
                    }
                } else {
                    isTimeZoneNull_tDBInput_1 = (((oracle.jdbc.OracleConnection)conn_tDBInput_1).getSessionTimeZone() == null);
                }

				if(isTimeZoneNull_tDBInput_1) {
					java.sql.Statement stmtGetTZ_tDBInput_1 = conn_tDBInput_1.createStatement();
					java.sql.ResultSet rsGetTZ_tDBInput_1 = stmtGetTZ_tDBInput_1.executeQuery("select sessiontimezone from dual");
					String sessionTimezone_tDBInput_1 = java.util.TimeZone.getDefault().getID();
					while (rsGetTZ_tDBInput_1.next()) {
						sessionTimezone_tDBInput_1 = rsGetTZ_tDBInput_1.getString(1);
					}
					if (isConnectionWrapped_tDBInput_1 && unwrappedOraConn_tDBInput_1 != null) {
                        unwrappedOraConn_tDBInput_1.setSessionTimeZone(sessionTimezone_tDBInput_1);
                    } else {
                        ((oracle.jdbc.OracleConnection)conn_tDBInput_1).setSessionTimeZone(sessionTimezone_tDBInput_1);
                    }
				}
			
		    
			java.sql.Statement stmt_tDBInput_1 = conn_tDBInput_1.createStatement();

		    String dbquery_tDBInput_1 = "SELECT  * FROM IRXMDM_DEV.tokenized_landing";
			

            	globalMap.put("tDBInput_1_QUERY",dbquery_tDBInput_1);
		    java.sql.ResultSet rs_tDBInput_1 = null;

		    try {
		    	rs_tDBInput_1 = stmt_tDBInput_1.executeQuery(dbquery_tDBInput_1);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_1 = rs_tDBInput_1.getMetaData();
		    	int colQtyInRs_tDBInput_1 = rsmd_tDBInput_1.getColumnCount();

		    String tmpContent_tDBInput_1 = null;
		    
		    
		    while (rs_tDBInput_1.next()) {
		        nb_line_tDBInput_1++;
		        
							if(colQtyInRs_tDBInput_1 < 1) {
								row19.firstName = null;
							} else {
	                         		
        	row19.firstName = routines.system.JDBCUtil.getString(rs_tDBInput_1, 1, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 2) {
								row19.lastName = null;
							} else {
	                         		
        	row19.lastName = routines.system.JDBCUtil.getString(rs_tDBInput_1, 2, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 3) {
								row19.MBI = null;
							} else {
	                         		
        	row19.MBI = routines.system.JDBCUtil.getString(rs_tDBInput_1, 3, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 4) {
								row19.DOB = null;
							} else {
	                         		
        	row19.DOB = routines.system.JDBCUtil.getString(rs_tDBInput_1, 4, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 5) {
								row19.OtherID = null;
							} else {
	                         		
        	row19.OtherID = routines.system.JDBCUtil.getString(rs_tDBInput_1, 5, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 6) {
								row19.SSN = null;
							} else {
	                         		
        	row19.SSN = routines.system.JDBCUtil.getString(rs_tDBInput_1, 6, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 7) {
								row19.scd_key = 0;
							} else {
		                          
					if(rs_tDBInput_1.getObject(7) != null) {
						row19.scd_key = rs_tDBInput_1.getInt(7);
					} else {
				
 	                	throw new RuntimeException("Null value in non-Nullable column");
					}
		                    }
					




 



/**
 * [tDBInput_1 begin ] stop
 */
	
	/**
	 * [tDBInput_1 main ] start
	 */

	

	
	
	currentComponent="tDBInput_1";

	

 


	tos_count_tDBInput_1++;

/**
 * [tDBInput_1 main ] stop
 */
	
	/**
	 * [tDBInput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_1";

	

 



/**
 * [tDBInput_1 process_data_begin ] stop
 */

	
	/**
	 * [tAdvancedHash_row19 main ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row19";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"row19");
			


			   
			   

					row19Struct row19_HashRow = new row19Struct();
		   	   	   
				
				row19_HashRow.firstName = row19.firstName;
				
				row19_HashRow.lastName = row19.lastName;
				
				row19_HashRow.MBI = row19.MBI;
				
				row19_HashRow.DOB = row19.DOB;
				
				row19_HashRow.OtherID = row19.OtherID;
				
				row19_HashRow.SSN = row19.SSN;
				
				row19_HashRow.scd_key = row19.scd_key;
				
			tHash_Lookup_row19.put(row19_HashRow);
			
            




 


	tos_count_tAdvancedHash_row19++;

/**
 * [tAdvancedHash_row19 main ] stop
 */
	
	/**
	 * [tAdvancedHash_row19 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row19";

	

 



/**
 * [tAdvancedHash_row19 process_data_begin ] stop
 */
	
	/**
	 * [tAdvancedHash_row19 process_data_end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row19";

	

 



/**
 * [tAdvancedHash_row19 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_1";

	

 



/**
 * [tDBInput_1 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_1 end ] start
	 */

	

	
	
	currentComponent="tDBInput_1";

	

}
}finally{
	if (rs_tDBInput_1 != null) {
		rs_tDBInput_1.close();
	}
	if (stmt_tDBInput_1 != null) {
		stmt_tDBInput_1.close();
	}
}

globalMap.put("tDBInput_1_NB_LINE",nb_line_tDBInput_1);
 

ok_Hash.put("tDBInput_1", true);
end_Hash.put("tDBInput_1", System.currentTimeMillis());




/**
 * [tDBInput_1 end ] stop
 */

	
	/**
	 * [tAdvancedHash_row19 end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row19";

	

tHash_Lookup_row19.endPut();

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row19",2,0,
			 			talendJobLog,"tDBInput_1","tOracleInput","tAdvancedHash_row19","tAdvancedHash","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tAdvancedHash_row19", true);
end_Hash.put("tAdvancedHash_row19", System.currentTimeMillis());




/**
 * [tAdvancedHash_row19 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_1 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_1";

	

 



/**
 * [tDBInput_1 finally ] stop
 */

	
	/**
	 * [tAdvancedHash_row19 finally ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row19";

	

 



/**
 * [tAdvancedHash_row19 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_1_SUBPROCESS_STATE", 1);
	}
	

public void tPostjob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPostjob_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tPostjob_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPostjob_1", false);
		start_Hash.put("tPostjob_1", System.currentTimeMillis());
		
	
	currentComponent="tPostjob_1";

	
		int tos_count_tPostjob_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tPostjob_1", "tPostjob");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tPostjob_1 begin ] stop
 */
	
	/**
	 * [tPostjob_1 main ] start
	 */

	

	
	
	currentComponent="tPostjob_1";

	

 


	tos_count_tPostjob_1++;

/**
 * [tPostjob_1 main ] stop
 */
	
	/**
	 * [tPostjob_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tPostjob_1";

	

 



/**
 * [tPostjob_1 process_data_begin ] stop
 */
	
	/**
	 * [tPostjob_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tPostjob_1";

	

 



/**
 * [tPostjob_1 process_data_end ] stop
 */
	
	/**
	 * [tPostjob_1 end ] start
	 */

	

	
	
	currentComponent="tPostjob_1";

	

 

ok_Hash.put("tPostjob_1", true);
end_Hash.put("tPostjob_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk8", 0, "ok");
				}
				tDBClose_1Process(globalMap);



/**
 * [tPostjob_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPostjob_1 finally ] start
	 */

	

	
	
	currentComponent="tPostjob_1";

	

 



/**
 * [tPostjob_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPostjob_1_SUBPROCESS_STATE", 1);
	}
	

public void tDBClose_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBClose_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tDBClose_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBClose_1", false);
		start_Hash.put("tDBClose_1", System.currentTimeMillis());
		
	
	currentComponent="tDBClose_1";

	
		int tos_count_tDBClose_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tDBClose_1", "tOracleClose");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tDBClose_1 begin ] stop
 */
	
	/**
	 * [tDBClose_1 main ] start
	 */

	

	
	
	currentComponent="tDBClose_1";

	

	java.sql.Connection conn_tDBClose_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
	
	if(conn_tDBClose_1 != null && !conn_tDBClose_1.isClosed())
	{
		
			conn_tDBClose_1.close();
			
			if("com.mysql.cj.jdbc.Driver".equals((String)globalMap.get("driverClass_tDBConnection_1"))
			    && routines.system.BundleUtils.inOSGi()) {
			        Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread").
			            getMethod("checkedShutdown").invoke(null, (Object[]) null);
			}
			
	}

 


	tos_count_tDBClose_1++;

/**
 * [tDBClose_1 main ] stop
 */
	
	/**
	 * [tDBClose_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBClose_1";

	

 



/**
 * [tDBClose_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBClose_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBClose_1";

	

 



/**
 * [tDBClose_1 process_data_end ] stop
 */
	
	/**
	 * [tDBClose_1 end ] start
	 */

	

	
	
	currentComponent="tDBClose_1";

	

 

ok_Hash.put("tDBClose_1", true);
end_Hash.put("tDBClose_1", System.currentTimeMillis());




/**
 * [tDBClose_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBClose_1 finally ] start
	 */

	

	
	
	currentComponent="tDBClose_1";

	

 



/**
 * [tDBClose_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBClose_1_SUBPROCESS_STATE", 1);
	}
	

public void talendJobLogProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("talendJobLog_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [talendJobLog begin ] start
	 */

	

	
		
		ok_Hash.put("talendJobLog", false);
		start_Hash.put("talendJobLog", System.currentTimeMillis());
		
	
	currentComponent="talendJobLog";

	
		int tos_count_talendJobLog = 0;
		

	for (JobStructureCatcherUtils.JobStructureCatcherMessage jcm : talendJobLog.getMessages()) {
		org.talend.logging.audit.Context log_context_talendJobLog = null;
		if(jcm.component_name == null) {//job level log
			if(jcm.status == null) {//job start
				log_context_talendJobLog = org.talend.job.audit.JobContextBuilder.create().jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version).timestamp(jcm.moment).build();
				auditLogger_talendJobLog.jobstart(log_context_talendJobLog);
			} else {//job end
				long timeMS = jcm.end_time - jcm.start_time;
				String duration = String.format(java.util.Locale.US, "%1$.2fs", (timeMS * 1.0)/1000);
			
				log_context_talendJobLog = org.talend.job.audit.JobContextBuilder.create().jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version)
					.timestamp(jcm.moment).duration(duration).status(jcm.status).build();
				auditLogger_talendJobLog.jobstop(log_context_talendJobLog);
			}
		} else if(jcm.current_connector == null) {//component log
			log_context_talendJobLog = org.talend.job.audit.JobContextBuilder.create().jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version)
				.connectorType(jcm.component_name).connectorId(jcm.component_id).build();
			auditLogger_talendJobLog.runcomponent(log_context_talendJobLog);
		} else {//component connector meter log
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.format(java.util.Locale.US, "%1$.2fs", (timeMS * 1.0)/1000);
			
			if(jcm.current_connector_as_input) {//log current component input line
				log_context_talendJobLog = org.talend.job.audit.JobContextBuilder.create().jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version)
					.connectorType(jcm.component_name).connectorId(jcm.component_id)
					.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
					.rows(jcm.total_row_number).duration(duration).build();
				auditLogger_talendJobLog.flowInput(log_context_talendJobLog);
			} else {//log current component output/reject line
				log_context_talendJobLog = org.talend.job.audit.JobContextBuilder.create().jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version)
					.connectorType(jcm.component_name).connectorId(jcm.component_id)
					.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
					.rows(jcm.total_row_number).duration(duration).build();
				auditLogger_talendJobLog.flowOutput(log_context_talendJobLog);
			}
		}
	}

 



/**
 * [talendJobLog begin ] stop
 */
	
	/**
	 * [talendJobLog main ] start
	 */

	

	
	
	currentComponent="talendJobLog";

	

 


	tos_count_talendJobLog++;

/**
 * [talendJobLog main ] stop
 */
	
	/**
	 * [talendJobLog process_data_begin ] start
	 */

	

	
	
	currentComponent="talendJobLog";

	

 



/**
 * [talendJobLog process_data_begin ] stop
 */
	
	/**
	 * [talendJobLog process_data_end ] start
	 */

	

	
	
	currentComponent="talendJobLog";

	

 



/**
 * [talendJobLog process_data_end ] stop
 */
	
	/**
	 * [talendJobLog end ] start
	 */

	

	
	
	currentComponent="talendJobLog";

	

 

ok_Hash.put("talendJobLog", true);
end_Hash.put("talendJobLog", System.currentTimeMillis());




/**
 * [talendJobLog end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [talendJobLog finally ] start
	 */

	

	
	
	currentComponent="talendJobLog";

	

 



/**
 * [talendJobLog finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("talendJobLog_SUBPROCESS_STATE", 1);
	}
	
    public String resuming_logs_dir_path = null;
    public String resuming_checkpoint_path = null;
    public String parent_part_launcher = null;
    private String resumeEntryMethodName = null;
    private boolean globalResumeTicket = false;

    public boolean watch = false;
    // portStats is null, it means don't execute the statistics
    public Integer portStats = null;
    public int portTraces = 4334;
    public String clientHost;
    public String defaultClientHost = "localhost";
    public String contextStr = "Default";
    public boolean isDefaultContext = true;
    public String pid = "0";
    public String rootPid = null;
    public String fatherPid = null;
    public String fatherNode = null;
    public long startTime = 0;
    public boolean isChildJob = false;
    public String log4jLevel = "";
    
    private boolean enableLogStash;

    private boolean execStat = true;

    private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
        protected java.util.Map<String, String> initialValue() {
            java.util.Map<String,String> threadRunResultMap = new java.util.HashMap<String, String>();
            threadRunResultMap.put("errorCode", null);
            threadRunResultMap.put("status", "");
            return threadRunResultMap;
        };
    };


    private PropertiesWithType context_param = new PropertiesWithType();
    public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

    public String status= "";
    

    public static void main(String[] args){
        final IngestRecords_Detokenization_globalparam IngestRecords_Detokenization_globalparamClass = new IngestRecords_Detokenization_globalparam();

        int exitCode = IngestRecords_Detokenization_globalparamClass.runJobInTOS(args);

        System.exit(exitCode);
    }


    public String[][] runJob(String[] args) {

        int exitCode = runJobInTOS(args);
        String[][] bufferValue = (String[][])globalBuffer.toArray(new String[globalBuffer.size()][]);

        return bufferValue;
    }

    public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;
    	
        		hastBufferOutput = true;
    	
        return hastBufferOutput;
    }

    public int runJobInTOS(String[] args) {
	   	// reset status
	   	status = "";
	   	
        String lastStr = "";
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--context_param")) {
                lastStr = arg;
            } else if (lastStr.equals("")) {
                evalParam(arg);
            } else {
                evalParam(lastStr + " " + arg);
                lastStr = "";
            }
        }
        enableLogStash = "true".equalsIgnoreCase(System.getProperty("monitoring"));

    	
    	
			if(enableLogStash) {
				java.util.Properties properties_talendJobLog = new java.util.Properties();
				properties_talendJobLog.setProperty("root.logger", "audit");
				properties_talendJobLog.setProperty("encoding", "UTF-8");
				properties_talendJobLog.setProperty("application.name", "Talend Studio");
				properties_talendJobLog.setProperty("service.name", "Talend Studio Job");
				properties_talendJobLog.setProperty("instance.name", "Talend Studio Job Instance");
				properties_talendJobLog.setProperty("propagate.appender.exceptions", "none");
				properties_talendJobLog.setProperty("log.appender", "file");
				properties_talendJobLog.setProperty("appender.file.path", "audit.json");
				properties_talendJobLog.setProperty("appender.file.maxsize", "52428800");
				properties_talendJobLog.setProperty("appender.file.maxbackup", "20");
				properties_talendJobLog.setProperty("host", "false");

				System.getProperties().stringPropertyNames().stream()
					.filter(it -> it.startsWith("monitoring.audit.logger.properties."))
					.forEach(key -> properties_talendJobLog.setProperty(key.substring("monitoring.audit.logger.properties.".length()), System.getProperty(key)));

				
				
				
				org.apache.logging.log4j.core.config.Configurator.setLevel("audit", org.apache.logging.log4j.Level.DEBUG);
				
				auditLogger_talendJobLog = org.talend.job.audit.JobEventAuditLoggerFactory.createJobAuditLogger(properties_talendJobLog);
			}
		

        if(clientHost == null) {
            clientHost = defaultClientHost;
        }

        if(pid == null || "0".equals(pid)) {
            pid = TalendString.getAsciiRandomString(6);
        }

        if (rootPid==null) {
            rootPid = pid;
        }
        if (fatherPid==null) {
            fatherPid = pid;
        }else{
            isChildJob = true;
        }

        if (portStats != null) {
            // portStats = -1; //for testing
            if (portStats < 0 || portStats > 65535) {
                // issue:10869, the portStats is invalid, so this client socket can't open
                System.err.println("The statistics socket port " + portStats + " is invalid.");
                execStat = false;
            }
        } else {
            execStat = false;
        }

        try {
            //call job/subjob with an existing context, like: --context=production. if without this parameter, there will use the default context instead.
            java.io.InputStream inContext = IngestRecords_Detokenization_globalparam.class.getClassLoader().getResourceAsStream("upi_process/ingestrecords_detokenization_globalparam_0_1/contexts/" + contextStr + ".properties");
            if (inContext == null) {
                inContext = IngestRecords_Detokenization_globalparam.class.getClassLoader().getResourceAsStream("config/contexts/" + contextStr + ".properties");
            }
            if (inContext != null) {
                //defaultProps is in order to keep the original context value
                if(context != null && context.isEmpty()) {
	                defaultProps.load(inContext);
	                context = new ContextProperties(defaultProps);
                }
                
                inContext.close();
            } else if (!isDefaultContext) {
                //print info and job continue to run, for case: context_param is not empty.
                System.err.println("Could not find the context " + contextStr);
            }

            if(!context_param.isEmpty()) {
                context.putAll(context_param);
				//set types for params from parentJobs
				for (Object key: context_param.keySet()){
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
            }
            class ContextProcessing {
                private void processContext_0() {
                        context.setContextType("obj", "id_Object");
                            context.obj=(Object) context.getProperty("obj");
                        context.setContextType("detokenize", "id_Directory");
                            context.detokenize=(String) context.getProperty("detokenize");
                        context.setContextType("filename", "id_String");
                            context.filename=(String) context.getProperty("filename");
                        context.setContextType("key_store_password", "id_Password");
                            String pwd_key_store_password_value = context.getProperty("key_store_password");
                            context.key_store_password = null;
                            if(pwd_key_store_password_value!=null) {
                                if(context_param.containsKey("key_store_password")) {//no need to decrypt if it come from program argument or parent job runtime
                                    context.key_store_password = pwd_key_store_password_value;
                                } else if (!pwd_key_store_password_value.isEmpty()) {
                                    try {
                                        context.key_store_password = routines.system.PasswordEncryptUtil.decryptPassword(pwd_key_store_password_value);
                                        context.put("key_store_password",context.key_store_password);
                                    } catch (java.lang.RuntimeException e) {
                                        //do nothing
                                    }
                                }
                            }
                        context.setContextType("key_store_path", "id_Directory");
                            context.key_store_path=(String) context.getProperty("key_store_path");
                        context.setContextType("landing", "id_Directory");
                            context.landing=(String) context.getProperty("landing");
                        context.setContextType("stg_location", "id_Directory");
                            context.stg_location=(String) context.getProperty("stg_location");
                        context.setContextType("jsonfile_after", "id_Directory");
                            context.jsonfile_after=(String) context.getProperty("jsonfile_after");
                        context.setContextType("jsonfile_prior", "id_Directory");
                            context.jsonfile_prior=(String) context.getProperty("jsonfile_prior");
                        context.setContextType("location", "id_String");
                            context.location=(String) context.getProperty("location");
                } 
                public void processAllContext() {
                        processContext_0();
                }
            }

            new ContextProcessing().processAllContext();
        } catch (java.io.IOException ie) {
            System.err.println("Could not load context "+contextStr);
            ie.printStackTrace();
        }

        // get context value from parent directly
        if (parentContextMap != null && !parentContextMap.isEmpty()) {if (parentContextMap.containsKey("obj")) {
                context.obj = (Object) parentContextMap.get("obj");
            }if (parentContextMap.containsKey("detokenize")) {
                context.detokenize = (String) parentContextMap.get("detokenize");
            }if (parentContextMap.containsKey("filename")) {
                context.filename = (String) parentContextMap.get("filename");
            }if (parentContextMap.containsKey("key_store_password")) {
                context.key_store_password = (java.lang.String) parentContextMap.get("key_store_password");
            }if (parentContextMap.containsKey("key_store_path")) {
                context.key_store_path = (String) parentContextMap.get("key_store_path");
            }if (parentContextMap.containsKey("landing")) {
                context.landing = (String) parentContextMap.get("landing");
            }if (parentContextMap.containsKey("stg_location")) {
                context.stg_location = (String) parentContextMap.get("stg_location");
            }if (parentContextMap.containsKey("jsonfile_after")) {
                context.jsonfile_after = (String) parentContextMap.get("jsonfile_after");
            }if (parentContextMap.containsKey("jsonfile_prior")) {
                context.jsonfile_prior = (String) parentContextMap.get("jsonfile_prior");
            }if (parentContextMap.containsKey("location")) {
                context.location = (String) parentContextMap.get("location");
            }
        }

        //Resume: init the resumeUtil
        resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
        resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
        resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
			parametersToEncrypt.add("key_store_password");
        //Resume: jobStart
        resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,parametersToEncrypt));

if(execStat) {
    try {
        runStat.openSocket(!isChildJob);
        runStat.setAllPID(rootPid, fatherPid, pid, jobName);
        runStat.startThreadStat(clientHost, portStats);
        runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
    } catch (java.io.IOException ioException) {
        ioException.printStackTrace();
    }
}



	
	    java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
	    globalMap.put("concurrentHashMap", concurrentHashMap);
	

    long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    long endUsedMemory = 0;
    long end = 0;

    startTime = System.currentTimeMillis();




this.globalResumeTicket = true;//to run tPreJob

try {
errorCode = null;tPrejob_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tPrejob_1) {
globalMap.put("tPrejob_1_SUBPROCESS_STATE", -1);

e_tPrejob_1.printStackTrace();

}


		if(enableLogStash) {
	        talendJobLog.addJobStartMessage();
	        try {
	            talendJobLogProcess(globalMap);
	        } catch (java.lang.Exception e) {
	            e.printStackTrace();
	        }
        }

this.globalResumeTicket = false;//to run others jobs

try {
errorCode = null;tFileInputRaw_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tFileInputRaw_1) {
globalMap.put("tFileInputRaw_1_SUBPROCESS_STATE", -1);

e_tFileInputRaw_1.printStackTrace();

}

this.globalResumeTicket = true;//to run tPostJob

try {
errorCode = null;tPostjob_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tPostjob_1) {
globalMap.put("tPostjob_1_SUBPROCESS_STATE", -1);

e_tPostjob_1.printStackTrace();

}



        end = System.currentTimeMillis();

        if (watch) {
            System.out.println((end-startTime)+" milliseconds");
        }

        endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        if (false) {
            System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : IngestRecords_Detokenization_globalparam");
        }
		if(enableLogStash) {
	        talendJobLog.addJobEndMessage(startTime, end, status);
	        try {
	            talendJobLogProcess(globalMap);
	        } catch (java.lang.Exception e) {
	            e.printStackTrace();
	        }
        }



if (execStat) {
    runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
    runStat.stopThreadStat();
}
    int returnCode = 0;
    if(errorCode == null) {
         returnCode = status != null && status.equals("failure") ? 1 : 0;
    } else {
         returnCode = errorCode.intValue();
    }
    resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","" + returnCode,"","","");

    return returnCode;

  }

    // only for OSGi env
    public void destroy() {
    closeSqlDbConnections();


    }



    private void closeSqlDbConnections() {
        try {
            Object obj_conn;
            obj_conn = globalMap.remove("conn_tDBConnection_1");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
        } catch (java.lang.Exception e) {
        }
    }











    private java.util.Map<String, Object> getSharedConnections4REST() {
        java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();
            connections.put("conn_tDBConnection_1", globalMap.get("conn_tDBConnection_1"));







        return connections;
    }

    private void evalParam(String arg) {
        if (arg.startsWith("--resuming_logs_dir_path")) {
            resuming_logs_dir_path = arg.substring(25);
        } else if (arg.startsWith("--resuming_checkpoint_path")) {
            resuming_checkpoint_path = arg.substring(27);
        } else if (arg.startsWith("--parent_part_launcher")) {
            parent_part_launcher = arg.substring(23);
        } else if (arg.startsWith("--watch")) {
            watch = true;
        } else if (arg.startsWith("--stat_port=")) {
            String portStatsStr = arg.substring(12);
            if (portStatsStr != null && !portStatsStr.equals("null")) {
                portStats = Integer.parseInt(portStatsStr);
            }
        } else if (arg.startsWith("--trace_port=")) {
            portTraces = Integer.parseInt(arg.substring(13));
        } else if (arg.startsWith("--client_host=")) {
            clientHost = arg.substring(14);
        } else if (arg.startsWith("--context=")) {
            contextStr = arg.substring(10);
            isDefaultContext = false;
        } else if (arg.startsWith("--father_pid=")) {
            fatherPid = arg.substring(13);
        } else if (arg.startsWith("--root_pid=")) {
            rootPid = arg.substring(11);
        } else if (arg.startsWith("--father_node=")) {
            fatherNode = arg.substring(14);
        } else if (arg.startsWith("--pid=")) {
            pid = arg.substring(6);
        } else if (arg.startsWith("--context_type")) {
            String keyValue = arg.substring(15);
			int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.setContextType(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }

            }

		} else if (arg.startsWith("--context_param")) {
            String keyValue = arg.substring(16);
            int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }
            }
        } else if (arg.startsWith("--log4jLevel=")) {
            log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--monitoring") && arg.contains("=")) {//for trunjob call
		    final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
    }
    
    private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

    private final String[][] escapeChars = {
        {"\\\\","\\"},{"\\n","\n"},{"\\'","\'"},{"\\r","\r"},
        {"\\f","\f"},{"\\b","\b"},{"\\t","\t"}
        };
    private String replaceEscapeChars (String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0],currIndex);
				if (index>=0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0], strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
    }

    public Integer getErrorCode() {
        return errorCode;
    }


    public String getStatus() {
        return status;
    }

    ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 *     718843 characters generated by Talend Data Management Platform 
 *     on the September 11, 2020 10:45:26 PM EDT
 ************************************************************************************************/