
package upi_process.ingestrecords_tokenization_0_1;

import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.DataQuality;
import routines.Relational;
import routines.DataQualityDependencies;
import routines.Mathematical;
import routines.SQLike;
import routines.Numeric;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.DQTechnical;
import routines.StringHandling;
import routines.DataMasking;
import routines.TalendDate;
import routines.DqStringHandling;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;
 




	//the import part of tJava_1
	//import java.util.List;


@SuppressWarnings("unused")

/**
 * Job: IngestRecords_Tokenization Purpose: <br>
 * Description:  <br>
 * @author Gurubaskaran, Akila
 * @version 7.3.1.20200219_1130
 * @status 
 */
public class IngestRecords_Tokenization implements TalendJob {

protected static void logIgnoredError(String message, Throwable cause) {
       System.err.println(message);
       if (cause != null) {
               cause.printStackTrace();
       }

}


	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}
	
	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	
	private final static String utf8Charset = "UTF-8";
	//contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String,String> propertyTypes = new java.util.HashMap<>();
		
		public PropertiesWithType(java.util.Properties properties){
			super(properties);
		}
		public PropertiesWithType(){
			super();
		}
		
		public void setContextType(String key, String type) {
			propertyTypes.put(key,type);
		}
	
		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}
	
	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();
	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties){
			super(properties);
		}
		public ContextProperties(){
			super();
		}

		public void synchronizeContext(){
			
			if(filename != null){
				
					this.setProperty("filename", filename.toString());
				
			}
			
			if(key_store_password != null){
				
					this.setProperty("key_store_password", key_store_password.toString());
				
			}
			
			if(jsonfile_after != null){
				
					this.setProperty("jsonfile_after", jsonfile_after.toString());
				
			}
			
			if(location != null){
				
					this.setProperty("location", location.toString());
				
			}
			
			if(output != null){
				
					this.setProperty("output", output.toString());
				
			}
			
		}

public String filename;
public String getFilename(){
	return this.filename;
}
public java.lang.String key_store_password;
public java.lang.String getKey_store_password(){
	return this.key_store_password;
}
		public String jsonfile_after;
		public String getJsonfile_after(){
			return this.jsonfile_after;
		}
		
public String location;
public String getLocation(){
	return this.location;
}
public String output;
public String getOutput(){
	return this.output;
}
	}
	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.
	public ContextProperties getContext() {
		return this.context;
	}
	private final String jobVersion = "0.1";
	private final String jobName = "IngestRecords_Tokenization";
	private final String projectName = "UPI_PROCESS";
	public Integer errorCode = null;
	private String currentComponent = "";
	
		private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
        private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();
	
		private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
		public  final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();
	

private RunStat runStat = new RunStat();

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";
	
	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(), new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	JobStructureCatcherUtils talendJobLog = new JobStructureCatcherUtils(jobName, "_HX6CYOssEeqim7QFOJYHXg", "0.1");
	org.talend.job.audit.JobAuditLogger auditLogger_talendJobLog = null;

private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

public String getExceptionStackTrace() {
	if ("failure".equals(this.getStatus())) {
		errorMessagePS.flush();
		return baos.toString();
	}
	return null;
}

private Exception exception;

public Exception getException() {
	if ("failure".equals(this.getStatus())) {
		return this.exception;
	}
	return null;
}

private class TalendException extends Exception {

	private static final long serialVersionUID = 1L;

	private java.util.Map<String, Object> globalMap = null;
	private Exception e = null;
	private String currentComponent = null;
	private String virtualComponentName = null;
	
	public void setVirtualComponentName (String virtualComponentName){
		this.virtualComponentName = virtualComponentName;
	}

	private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
		this.currentComponent= errorComponent;
		this.globalMap = globalMap;
		this.e = e;
	}

	public Exception getException() {
		return this.e;
	}

	public String getCurrentComponent() {
		return this.currentComponent;
	}

	
    public String getExceptionCauseMessage(Exception e){
        Throwable cause = e;
        String message = null;
        int i = 10;
        while (null != cause && 0 < i--) {
            message = cause.getMessage();
            if (null == message) {
                cause = cause.getCause();
            } else {
                break;          
            }
        }
        if (null == message) {
            message = e.getClass().getName();
        }   
        return message;
    }

	@Override
	public void printStackTrace() {
		if (!(e instanceof TalendException || e instanceof TDieException)) {
			if(virtualComponentName!=null && currentComponent.indexOf(virtualComponentName+"_")==0){
				globalMap.put(virtualComponentName+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			}
			globalMap.put(currentComponent+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
		}
		if (!(e instanceof TDieException)) {
			if(e instanceof TalendException){
				e.printStackTrace();
			} else {
				e.printStackTrace();
				e.printStackTrace(errorMessagePS);
				IngestRecords_Tokenization.this.exception = e;
			}
		}
		if (!(e instanceof TalendException)) {
		try {
			for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
				if (m.getName().compareTo(currentComponent + "_error") == 0) {
					m.invoke(IngestRecords_Tokenization.this, new Object[] { e , currentComponent, globalMap});
					break;
				}
			}

			if(!(e instanceof TDieException)){
			}
		} catch (Exception e) {
			this.e.printStackTrace();
		}
		}
	}
}

			public void tPrejob_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPrejob_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBConnection_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBConnection_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPostjob_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPostjob_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBClose_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBClose_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputDelimited_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tLogRow_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileOutputJSON_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputRaw_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputRaw_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFlowToIterate_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputRaw_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tREST_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputRaw_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tExtractJSONFields_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputRaw_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputRaw_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputRaw_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tLogRow_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputRaw_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileOutputDelimited_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAdvancedHash_row4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void talendJobLog_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					talendJobLog_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPrejob_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBConnection_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tPostjob_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBClose_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileInputDelimited_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileInputRaw_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void talendJobLog_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}





	

	
public void tPrejob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPrejob_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tPrejob_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPrejob_1", false);
		start_Hash.put("tPrejob_1", System.currentTimeMillis());
		
	
	currentComponent="tPrejob_1";

	
		int tos_count_tPrejob_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tPrejob_1", "tPrejob");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tPrejob_1 begin ] stop
 */
	
	/**
	 * [tPrejob_1 main ] start
	 */

	

	
	
	currentComponent="tPrejob_1";

	

 


	tos_count_tPrejob_1++;

/**
 * [tPrejob_1 main ] stop
 */
	
	/**
	 * [tPrejob_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tPrejob_1";

	

 



/**
 * [tPrejob_1 process_data_begin ] stop
 */
	
	/**
	 * [tPrejob_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tPrejob_1";

	

 



/**
 * [tPrejob_1 process_data_end ] stop
 */
	
	/**
	 * [tPrejob_1 end ] start
	 */

	

	
	
	currentComponent="tPrejob_1";

	

 

ok_Hash.put("tPrejob_1", true);
end_Hash.put("tPrejob_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk1", 0, "ok");
				}
				tDBConnection_1Process(globalMap);



/**
 * [tPrejob_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPrejob_1 finally ] start
	 */

	

	
	
	currentComponent="tPrejob_1";

	

 



/**
 * [tPrejob_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPrejob_1_SUBPROCESS_STATE", 1);
	}
	

public void tDBConnection_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBConnection_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBConnection_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBConnection_1", false);
		start_Hash.put("tDBConnection_1", System.currentTimeMillis());
		
	
	currentComponent="tDBConnection_1";

	
		int tos_count_tDBConnection_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tDBConnection_1", "tOracleConnection");
				talendJobLogProcess(globalMap);
			}
			
	

	
        String url_tDBConnection_1 = "jdbc:oracle:thin:@" + "aorcl-imdm-00dev01.czzet3yjlkjq.us-east-1.rds.amazonaws.com" + ":" + "1521" + ":" + "AIMDM00D";
    	globalMap.put("connectionType_" + "tDBConnection_1", "ORACLE_SID");
	String dbUser_tDBConnection_1 = "IRXMDM_DEV";
	
	
		 
	final String decryptedPassword_tDBConnection_1 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:ZwuSAoYeB2mtBCr74kIeF4d+fwRalHOUEYTdRbdQTC9DNQXg");
		String dbPwd_tDBConnection_1 = decryptedPassword_tDBConnection_1;
	
	
	java.sql.Connection conn_tDBConnection_1 = null;
	
		
			String driverClass_tDBConnection_1 = "oracle.jdbc.OracleDriver";
			java.lang.Class jdbcclazz_tDBConnection_1 = java.lang.Class.forName(driverClass_tDBConnection_1);
			globalMap.put("driverClass_tDBConnection_1", driverClass_tDBConnection_1);
		
			conn_tDBConnection_1 = java.sql.DriverManager.getConnection(url_tDBConnection_1,dbUser_tDBConnection_1,dbPwd_tDBConnection_1);

		globalMap.put("conn_tDBConnection_1", conn_tDBConnection_1);
	if (null != conn_tDBConnection_1) {
		
			conn_tDBConnection_1.setAutoCommit(true);
	}
        globalMap.put("host_" + "tDBConnection_1","aorcl-imdm-00dev01.czzet3yjlkjq.us-east-1.rds.amazonaws.com");
        globalMap.put("port_" + "tDBConnection_1","1521");
        globalMap.put("dbname_" + "tDBConnection_1","AIMDM00D");

	globalMap.put("conn_" + "tDBConnection_1",conn_tDBConnection_1);
	globalMap.put("dbschema_" + "tDBConnection_1", "IRXMDM_DEV");
	globalMap.put("username_" + "tDBConnection_1","IRXMDM_DEV");
	globalMap.put("password_" + "tDBConnection_1",dbPwd_tDBConnection_1);

 



/**
 * [tDBConnection_1 begin ] stop
 */
	
	/**
	 * [tDBConnection_1 main ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";

	

 


	tos_count_tDBConnection_1++;

/**
 * [tDBConnection_1 main ] stop
 */
	
	/**
	 * [tDBConnection_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";

	

 



/**
 * [tDBConnection_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBConnection_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";

	

 



/**
 * [tDBConnection_1 process_data_end ] stop
 */
	
	/**
	 * [tDBConnection_1 end ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";

	

 

ok_Hash.put("tDBConnection_1", true);
end_Hash.put("tDBConnection_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk3", 0, "ok");
				}
				tJava_1Process(globalMap);



/**
 * [tDBConnection_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBConnection_1 finally ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";

	

 



/**
 * [tDBConnection_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBConnection_1_SUBPROCESS_STATE", 1);
	}
	

public void tJava_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tJava_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_1", false);
		start_Hash.put("tJava_1", System.currentTimeMillis());
		
	
	currentComponent="tJava_1";

	
		int tos_count_tJava_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tJava_1", "tJava");
				talendJobLogProcess(globalMap);
			}
			


System.out.println("filename while processing:"+context.filename);
 



/**
 * [tJava_1 begin ] stop
 */
	
	/**
	 * [tJava_1 main ] start
	 */

	

	
	
	currentComponent="tJava_1";

	

 


	tos_count_tJava_1++;

/**
 * [tJava_1 main ] stop
 */
	
	/**
	 * [tJava_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tJava_1";

	

 



/**
 * [tJava_1 process_data_begin ] stop
 */
	
	/**
	 * [tJava_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tJava_1";

	

 



/**
 * [tJava_1 process_data_end ] stop
 */
	
	/**
	 * [tJava_1 end ] start
	 */

	

	
	
	currentComponent="tJava_1";

	

 

ok_Hash.put("tJava_1", true);
end_Hash.put("tJava_1", System.currentTimeMillis());




/**
 * [tJava_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_1 finally ] start
	 */

	

	
	
	currentComponent="tJava_1";

	

 



/**
 * [tJava_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_1_SUBPROCESS_STATE", 1);
	}
	

public void tPostjob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPostjob_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tPostjob_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPostjob_1", false);
		start_Hash.put("tPostjob_1", System.currentTimeMillis());
		
	
	currentComponent="tPostjob_1";

	
		int tos_count_tPostjob_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tPostjob_1", "tPostjob");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tPostjob_1 begin ] stop
 */
	
	/**
	 * [tPostjob_1 main ] start
	 */

	

	
	
	currentComponent="tPostjob_1";

	

 


	tos_count_tPostjob_1++;

/**
 * [tPostjob_1 main ] stop
 */
	
	/**
	 * [tPostjob_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tPostjob_1";

	

 



/**
 * [tPostjob_1 process_data_begin ] stop
 */
	
	/**
	 * [tPostjob_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tPostjob_1";

	

 



/**
 * [tPostjob_1 process_data_end ] stop
 */
	
	/**
	 * [tPostjob_1 end ] start
	 */

	

	
	
	currentComponent="tPostjob_1";

	

 

ok_Hash.put("tPostjob_1", true);
end_Hash.put("tPostjob_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk2", 0, "ok");
				}
				tDBClose_1Process(globalMap);



/**
 * [tPostjob_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPostjob_1 finally ] start
	 */

	

	
	
	currentComponent="tPostjob_1";

	

 



/**
 * [tPostjob_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPostjob_1_SUBPROCESS_STATE", 1);
	}
	

public void tDBClose_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBClose_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tDBClose_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBClose_1", false);
		start_Hash.put("tDBClose_1", System.currentTimeMillis());
		
	
	currentComponent="tDBClose_1";

	
		int tos_count_tDBClose_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tDBClose_1", "tOracleClose");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tDBClose_1 begin ] stop
 */
	
	/**
	 * [tDBClose_1 main ] start
	 */

	

	
	
	currentComponent="tDBClose_1";

	

	java.sql.Connection conn_tDBClose_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
	
	if(conn_tDBClose_1 != null && !conn_tDBClose_1.isClosed())
	{
		
			conn_tDBClose_1.close();
			
			if("com.mysql.cj.jdbc.Driver".equals((String)globalMap.get("driverClass_tDBConnection_1"))
			    && routines.system.BundleUtils.inOSGi()) {
			        Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread").
			            getMethod("checkedShutdown").invoke(null, (Object[]) null);
			}
			
	}

 


	tos_count_tDBClose_1++;

/**
 * [tDBClose_1 main ] stop
 */
	
	/**
	 * [tDBClose_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBClose_1";

	

 



/**
 * [tDBClose_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBClose_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBClose_1";

	

 



/**
 * [tDBClose_1 process_data_end ] stop
 */
	
	/**
	 * [tDBClose_1 end ] start
	 */

	

	
	
	currentComponent="tDBClose_1";

	

 

ok_Hash.put("tDBClose_1", true);
end_Hash.put("tDBClose_1", System.currentTimeMillis());




/**
 * [tDBClose_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBClose_1 finally ] start
	 */

	

	
	
	currentComponent="tDBClose_1";

	

 



/**
 * [tDBClose_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBClose_1_SUBPROCESS_STATE", 1);
	}
	


public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Tokenization = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecords_Tokenization = new byte[0];

	
			    public Character Gender;

				public Character getGender () {
					return this.Gender;
				}
				
			    public String State;

				public String getState () {
					return this.State;
				}
				
			    public String City;

				public String getCity () {
					return this.City;
				}
				
			    public String Zip_Code;

				public String getZip_Code () {
					return this.Zip_Code;
				}
				
			    public String Address_Line_1;

				public String getAddress_Line_1 () {
					return this.Address_Line_1;
				}
				
			    public String Address_Line_2;

				public String getAddress_Line_2 () {
					return this.Address_Line_2;
				}
				
			    public String Phone_Number;

				public String getPhone_Number () {
					return this.Phone_Number;
				}
				
			    public String UPI_ID;

				public String getUPI_ID () {
					return this.UPI_ID;
				}
				
			    public String Client_ID;

				public String getClient_ID () {
					return this.Client_ID;
				}
				
			    public String Carrier_ID;

				public String getCarrier_ID () {
					return this.Carrier_ID;
				}
				
			    public String Account_ID;

				public String getAccount_ID () {
					return this.Account_ID;
				}
				
			    public String Group_ID;

				public String getGroup_ID () {
					return this.Group_ID;
				}
				
			    public String Multi_Birth_Code;

				public String getMulti_Birth_Code () {
					return this.Multi_Birth_Code;
				}
				
			    public String Member_Key;

				public String getMember_Key () {
					return this.Member_Key;
				}
				
			    public String Source;

				public String getSource () {
					return this.Source;
				}
				
			    public int scd_key;

				public int getScd_key () {
					return this.scd_key;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecords_Tokenization.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecords_Tokenization.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecords_Tokenization = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecords_Tokenization = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecords_Tokenization, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecords_Tokenization, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Tokenization) {

        	try {

        		int length = 0;
		
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.Gender = null;
           				} else {
           			    	this.Gender = dis.readChar();
           				}
					
					this.State = readString(dis);
					
					this.City = readString(dis);
					
					this.Zip_Code = readString(dis);
					
					this.Address_Line_1 = readString(dis);
					
					this.Address_Line_2 = readString(dis);
					
					this.Phone_Number = readString(dis);
					
					this.UPI_ID = readString(dis);
					
					this.Client_ID = readString(dis);
					
					this.Carrier_ID = readString(dis);
					
					this.Account_ID = readString(dis);
					
					this.Group_ID = readString(dis);
					
					this.Multi_Birth_Code = readString(dis);
					
					this.Member_Key = readString(dis);
					
					this.Source = readString(dis);
					
			        this.scd_key = dis.readInt();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Character
				
						if(this.Gender == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeChar(this.Gender);
		            	}
					
					// String
				
						writeString(this.State,dos);
					
					// String
				
						writeString(this.City,dos);
					
					// String
				
						writeString(this.Zip_Code,dos);
					
					// String
				
						writeString(this.Address_Line_1,dos);
					
					// String
				
						writeString(this.Address_Line_2,dos);
					
					// String
				
						writeString(this.Phone_Number,dos);
					
					// String
				
						writeString(this.UPI_ID,dos);
					
					// String
				
						writeString(this.Client_ID,dos);
					
					// String
				
						writeString(this.Carrier_ID,dos);
					
					// String
				
						writeString(this.Account_ID,dos);
					
					// String
				
						writeString(this.Group_ID,dos);
					
					// String
				
						writeString(this.Multi_Birth_Code,dos);
					
					// String
				
						writeString(this.Member_Key,dos);
					
					// String
				
						writeString(this.Source,dos);
					
					// int
				
		            	dos.writeInt(this.scd_key);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Gender="+String.valueOf(Gender));
		sb.append(",State="+State);
		sb.append(",City="+City);
		sb.append(",Zip_Code="+Zip_Code);
		sb.append(",Address_Line_1="+Address_Line_1);
		sb.append(",Address_Line_2="+Address_Line_2);
		sb.append(",Phone_Number="+Phone_Number);
		sb.append(",UPI_ID="+UPI_ID);
		sb.append(",Client_ID="+Client_ID);
		sb.append(",Carrier_ID="+Carrier_ID);
		sb.append(",Account_ID="+Account_ID);
		sb.append(",Group_ID="+Group_ID);
		sb.append(",Multi_Birth_Code="+Multi_Birth_Code);
		sb.append(",Member_Key="+Member_Key);
		sb.append(",Source="+Source);
		sb.append(",scd_key="+String.valueOf(scd_key));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row1Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class copyOfNoTokenizationStruct implements routines.system.IPersistableRow<copyOfNoTokenizationStruct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Tokenization = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecords_Tokenization = new byte[0];

	
			    public Character Gender;

				public Character getGender () {
					return this.Gender;
				}
				
			    public String State;

				public String getState () {
					return this.State;
				}
				
			    public String City;

				public String getCity () {
					return this.City;
				}
				
			    public String Zip_Code;

				public String getZip_Code () {
					return this.Zip_Code;
				}
				
			    public String Address_Line_1;

				public String getAddress_Line_1 () {
					return this.Address_Line_1;
				}
				
			    public String Address_Line_2;

				public String getAddress_Line_2 () {
					return this.Address_Line_2;
				}
				
			    public String Phone_Number;

				public String getPhone_Number () {
					return this.Phone_Number;
				}
				
			    public String UPI_ID;

				public String getUPI_ID () {
					return this.UPI_ID;
				}
				
			    public String Client_ID;

				public String getClient_ID () {
					return this.Client_ID;
				}
				
			    public String Carrier_ID;

				public String getCarrier_ID () {
					return this.Carrier_ID;
				}
				
			    public String Account_ID;

				public String getAccount_ID () {
					return this.Account_ID;
				}
				
			    public String Group_ID;

				public String getGroup_ID () {
					return this.Group_ID;
				}
				
			    public String Multi_Birth_Code;

				public String getMulti_Birth_Code () {
					return this.Multi_Birth_Code;
				}
				
			    public String Member_Key;

				public String getMember_Key () {
					return this.Member_Key;
				}
				
			    public String Source;

				public String getSource () {
					return this.Source;
				}
				
			    public int scd_key;

				public int getScd_key () {
					return this.scd_key;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecords_Tokenization.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecords_Tokenization.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecords_Tokenization = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecords_Tokenization = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecords_Tokenization, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecords_Tokenization, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Tokenization) {

        	try {

        		int length = 0;
		
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.Gender = null;
           				} else {
           			    	this.Gender = dis.readChar();
           				}
					
					this.State = readString(dis);
					
					this.City = readString(dis);
					
					this.Zip_Code = readString(dis);
					
					this.Address_Line_1 = readString(dis);
					
					this.Address_Line_2 = readString(dis);
					
					this.Phone_Number = readString(dis);
					
					this.UPI_ID = readString(dis);
					
					this.Client_ID = readString(dis);
					
					this.Carrier_ID = readString(dis);
					
					this.Account_ID = readString(dis);
					
					this.Group_ID = readString(dis);
					
					this.Multi_Birth_Code = readString(dis);
					
					this.Member_Key = readString(dis);
					
					this.Source = readString(dis);
					
			        this.scd_key = dis.readInt();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Character
				
						if(this.Gender == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeChar(this.Gender);
		            	}
					
					// String
				
						writeString(this.State,dos);
					
					// String
				
						writeString(this.City,dos);
					
					// String
				
						writeString(this.Zip_Code,dos);
					
					// String
				
						writeString(this.Address_Line_1,dos);
					
					// String
				
						writeString(this.Address_Line_2,dos);
					
					// String
				
						writeString(this.Phone_Number,dos);
					
					// String
				
						writeString(this.UPI_ID,dos);
					
					// String
				
						writeString(this.Client_ID,dos);
					
					// String
				
						writeString(this.Carrier_ID,dos);
					
					// String
				
						writeString(this.Account_ID,dos);
					
					// String
				
						writeString(this.Group_ID,dos);
					
					// String
				
						writeString(this.Multi_Birth_Code,dos);
					
					// String
				
						writeString(this.Member_Key,dos);
					
					// String
				
						writeString(this.Source,dos);
					
					// int
				
		            	dos.writeInt(this.scd_key);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Gender="+String.valueOf(Gender));
		sb.append(",State="+State);
		sb.append(",City="+City);
		sb.append(",Zip_Code="+Zip_Code);
		sb.append(",Address_Line_1="+Address_Line_1);
		sb.append(",Address_Line_2="+Address_Line_2);
		sb.append(",Phone_Number="+Phone_Number);
		sb.append(",UPI_ID="+UPI_ID);
		sb.append(",Client_ID="+Client_ID);
		sb.append(",Carrier_ID="+Carrier_ID);
		sb.append(",Account_ID="+Account_ID);
		sb.append(",Group_ID="+Group_ID);
		sb.append(",Multi_Birth_Code="+Multi_Birth_Code);
		sb.append(",Member_Key="+Member_Key);
		sb.append(",Source="+Source);
		sb.append(",scd_key="+String.valueOf(scd_key));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(copyOfNoTokenizationStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class copyOfTokenization1Struct implements routines.system.IPersistableRow<copyOfTokenization1Struct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Tokenization = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecords_Tokenization = new byte[0];

	
			    public String DOB;

				public String getDOB () {
					return this.DOB;
				}
				
			    public String firstName;

				public String getFirstName () {
					return this.firstName;
				}
				
			    public String lastName;

				public String getLastName () {
					return this.lastName;
				}
				
			    public String SSN;

				public String getSSN () {
					return this.SSN;
				}
				
			    public String MBI;

				public String getMBI () {
					return this.MBI;
				}
				
			    public String OtherID;

				public String getOtherID () {
					return this.OtherID;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecords_Tokenization.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecords_Tokenization.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecords_Tokenization = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecords_Tokenization = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecords_Tokenization, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecords_Tokenization, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Tokenization) {

        	try {

        		int length = 0;
		
					this.DOB = readString(dis);
					
					this.firstName = readString(dis);
					
					this.lastName = readString(dis);
					
					this.SSN = readString(dis);
					
					this.MBI = readString(dis);
					
					this.OtherID = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.DOB,dos);
					
					// String
				
						writeString(this.firstName,dos);
					
					// String
				
						writeString(this.lastName,dos);
					
					// String
				
						writeString(this.SSN,dos);
					
					// String
				
						writeString(this.MBI,dos);
					
					// String
				
						writeString(this.OtherID,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("DOB="+DOB);
		sb.append(",firstName="+firstName);
		sb.append(",lastName="+lastName);
		sb.append(",SSN="+SSN);
		sb.append(",MBI="+MBI);
		sb.append(",OtherID="+OtherID);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(copyOfTokenization1Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row12Struct implements routines.system.IPersistableRow<row12Struct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Tokenization = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecords_Tokenization = new byte[0];

	
			    public Character Gender;

				public Character getGender () {
					return this.Gender;
				}
				
			    public String Date_of_Birth;

				public String getDate_of_Birth () {
					return this.Date_of_Birth;
				}
				
			    public String First_Name;

				public String getFirst_Name () {
					return this.First_Name;
				}
				
			    public String Last_Name;

				public String getLast_Name () {
					return this.Last_Name;
				}
				
			    public String State;

				public String getState () {
					return this.State;
				}
				
			    public String City;

				public String getCity () {
					return this.City;
				}
				
			    public String Zip_Code;

				public String getZip_Code () {
					return this.Zip_Code;
				}
				
			    public String Address_Line_1;

				public String getAddress_Line_1 () {
					return this.Address_Line_1;
				}
				
			    public String Address_Line_2;

				public String getAddress_Line_2 () {
					return this.Address_Line_2;
				}
				
			    public String Phone_Number;

				public String getPhone_Number () {
					return this.Phone_Number;
				}
				
			    public String Social_Security_Number;

				public String getSocial_Security_Number () {
					return this.Social_Security_Number;
				}
				
			    public String UPI_ID;

				public String getUPI_ID () {
					return this.UPI_ID;
				}
				
			    public String MBI;

				public String getMBI () {
					return this.MBI;
				}
				
			    public String Client_ID;

				public String getClient_ID () {
					return this.Client_ID;
				}
				
			    public String Carrier_ID;

				public String getCarrier_ID () {
					return this.Carrier_ID;
				}
				
			    public String Account_ID;

				public String getAccount_ID () {
					return this.Account_ID;
				}
				
			    public String Group_ID;

				public String getGroup_ID () {
					return this.Group_ID;
				}
				
			    public String Contract_Family_ID;

				public String getContract_Family_ID () {
					return this.Contract_Family_ID;
				}
				
			    public String Multi_Birth_Code;

				public String getMulti_Birth_Code () {
					return this.Multi_Birth_Code;
				}
				
			    public String Member_Key;

				public String getMember_Key () {
					return this.Member_Key;
				}
				
			    public String Source;

				public String getSource () {
					return this.Source;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecords_Tokenization.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecords_Tokenization.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecords_Tokenization = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecords_Tokenization = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecords_Tokenization, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecords_Tokenization, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Tokenization) {

        	try {

        		int length = 0;
		
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.Gender = null;
           				} else {
           			    	this.Gender = dis.readChar();
           				}
					
					this.Date_of_Birth = readString(dis);
					
					this.First_Name = readString(dis);
					
					this.Last_Name = readString(dis);
					
					this.State = readString(dis);
					
					this.City = readString(dis);
					
					this.Zip_Code = readString(dis);
					
					this.Address_Line_1 = readString(dis);
					
					this.Address_Line_2 = readString(dis);
					
					this.Phone_Number = readString(dis);
					
					this.Social_Security_Number = readString(dis);
					
					this.UPI_ID = readString(dis);
					
					this.MBI = readString(dis);
					
					this.Client_ID = readString(dis);
					
					this.Carrier_ID = readString(dis);
					
					this.Account_ID = readString(dis);
					
					this.Group_ID = readString(dis);
					
					this.Contract_Family_ID = readString(dis);
					
					this.Multi_Birth_Code = readString(dis);
					
					this.Member_Key = readString(dis);
					
					this.Source = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Character
				
						if(this.Gender == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeChar(this.Gender);
		            	}
					
					// String
				
						writeString(this.Date_of_Birth,dos);
					
					// String
				
						writeString(this.First_Name,dos);
					
					// String
				
						writeString(this.Last_Name,dos);
					
					// String
				
						writeString(this.State,dos);
					
					// String
				
						writeString(this.City,dos);
					
					// String
				
						writeString(this.Zip_Code,dos);
					
					// String
				
						writeString(this.Address_Line_1,dos);
					
					// String
				
						writeString(this.Address_Line_2,dos);
					
					// String
				
						writeString(this.Phone_Number,dos);
					
					// String
				
						writeString(this.Social_Security_Number,dos);
					
					// String
				
						writeString(this.UPI_ID,dos);
					
					// String
				
						writeString(this.MBI,dos);
					
					// String
				
						writeString(this.Client_ID,dos);
					
					// String
				
						writeString(this.Carrier_ID,dos);
					
					// String
				
						writeString(this.Account_ID,dos);
					
					// String
				
						writeString(this.Group_ID,dos);
					
					// String
				
						writeString(this.Contract_Family_ID,dos);
					
					// String
				
						writeString(this.Multi_Birth_Code,dos);
					
					// String
				
						writeString(this.Member_Key,dos);
					
					// String
				
						writeString(this.Source,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Gender="+String.valueOf(Gender));
		sb.append(",Date_of_Birth="+Date_of_Birth);
		sb.append(",First_Name="+First_Name);
		sb.append(",Last_Name="+Last_Name);
		sb.append(",State="+State);
		sb.append(",City="+City);
		sb.append(",Zip_Code="+Zip_Code);
		sb.append(",Address_Line_1="+Address_Line_1);
		sb.append(",Address_Line_2="+Address_Line_2);
		sb.append(",Phone_Number="+Phone_Number);
		sb.append(",Social_Security_Number="+Social_Security_Number);
		sb.append(",UPI_ID="+UPI_ID);
		sb.append(",MBI="+MBI);
		sb.append(",Client_ID="+Client_ID);
		sb.append(",Carrier_ID="+Carrier_ID);
		sb.append(",Account_ID="+Account_ID);
		sb.append(",Group_ID="+Group_ID);
		sb.append(",Contract_Family_ID="+Contract_Family_ID);
		sb.append(",Multi_Birth_Code="+Multi_Birth_Code);
		sb.append(",Member_Key="+Member_Key);
		sb.append(",Source="+Source);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row12Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFileInputDelimited_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileInputDelimited_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row12Struct row12 = new row12Struct();
copyOfNoTokenizationStruct copyOfNoTokenization = new copyOfNoTokenizationStruct();
row1Struct row1 = new row1Struct();
copyOfTokenization1Struct copyOfTokenization1 = new copyOfTokenization1Struct();






	
	/**
	 * [tLogRow_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tLogRow_1", false);
		start_Hash.put("tLogRow_1", System.currentTimeMillis());
		
	
	currentComponent="tLogRow_1";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row1");
			
		int tos_count_tLogRow_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tLogRow_1", "tLogRow");
				talendJobLogProcess(globalMap);
			}
			

	///////////////////////
	
         class Util_tLogRow_1 {

        String[] des_top = { ".", ".", "-", "+" };

        String[] des_head = { "|=", "=|", "-", "+" };

        String[] des_bottom = { "'", "'", "-", "+" };

        String name="";

        java.util.List<String[]> list = new java.util.ArrayList<String[]>();

        int[] colLengths = new int[16];

        public void addRow(String[] row) {

            for (int i = 0; i < 16; i++) {
                if (row[i]!=null) {
                  colLengths[i] = Math.max(colLengths[i], row[i].length());
                }
            }
            list.add(row);
        }

        public void setTableName(String name) {

            this.name = name;
        }

            public StringBuilder format() {
            
                StringBuilder sb = new StringBuilder();
  
            
                    sb.append(print(des_top));
    
                    int totals = 0;
                    for (int i = 0; i < colLengths.length; i++) {
                        totals = totals + colLengths[i];
                    }
    
                    // name
                    sb.append("|");
                    int k = 0;
                    for (k = 0; k < (totals + 15 - name.length()) / 2; k++) {
                        sb.append(' ');
                    }
                    sb.append(name);
                    for (int i = 0; i < totals + 15 - name.length() - k; i++) {
                        sb.append(' ');
                    }
                    sb.append("|\n");

                    // head and rows
                    sb.append(print(des_head));
                    for (int i = 0; i < list.size(); i++) {
    
                        String[] row = list.get(i);
    
                        java.util.Formatter formatter = new java.util.Formatter(new StringBuilder());
                        
                        StringBuilder sbformat = new StringBuilder();                                             
        			        sbformat.append("|%1$-");
        			        sbformat.append(colLengths[0]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%2$-");
        			        sbformat.append(colLengths[1]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%3$-");
        			        sbformat.append(colLengths[2]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%4$-");
        			        sbformat.append(colLengths[3]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%5$-");
        			        sbformat.append(colLengths[4]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%6$-");
        			        sbformat.append(colLengths[5]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%7$-");
        			        sbformat.append(colLengths[6]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%8$-");
        			        sbformat.append(colLengths[7]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%9$-");
        			        sbformat.append(colLengths[8]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%10$-");
        			        sbformat.append(colLengths[9]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%11$-");
        			        sbformat.append(colLengths[10]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%12$-");
        			        sbformat.append(colLengths[11]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%13$-");
        			        sbformat.append(colLengths[12]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%14$-");
        			        sbformat.append(colLengths[13]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%15$-");
        			        sbformat.append(colLengths[14]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%16$-");
        			        sbformat.append(colLengths[15]);
        			        sbformat.append("s");
        			                      
                        sbformat.append("|\n");                    
       
                        formatter.format(sbformat.toString(), (Object[])row);	
                                
                        sb.append(formatter.toString());
                        if (i == 0)
                            sb.append(print(des_head)); // print the head
                    }
    
                    // end
                    sb.append(print(des_bottom));
                    return sb;
                }
            

            private StringBuilder print(String[] fillChars) {
                StringBuilder sb = new StringBuilder();
                //first column
                sb.append(fillChars[0]);                
                    for (int i = 0; i < colLengths[0] - fillChars[0].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);	                

                    for (int i = 0; i < colLengths[1] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[2] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[3] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[4] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[5] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[6] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[7] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[8] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[9] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[10] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[11] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[12] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[13] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[14] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                
                    //last column
                    for (int i = 0; i < colLengths[15] - fillChars[1].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }         
                sb.append(fillChars[1]);
                sb.append("\n");               
                return sb;
            }
            
            public boolean isTableEmpty(){
            	if (list.size() > 1)
            		return false;
            	return true;
            }
        }
        Util_tLogRow_1 util_tLogRow_1 = new Util_tLogRow_1();
        util_tLogRow_1.setTableName("tLogRow_1");
        util_tLogRow_1.addRow(new String[]{"Gender","State","City","Zip_Code","Address_Line_1","Address_Line_2","Phone_Number","UPI_ID","Client_ID","Carrier_ID","Account_ID","Group_ID","Multi_Birth_Code","Member_Key","Source","scd_key",});        
 		StringBuilder strBuffer_tLogRow_1 = null;
		int nb_line_tLogRow_1 = 0;
///////////////////////    			



 



/**
 * [tLogRow_1 begin ] stop
 */



	
	/**
	 * [tDBOutput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_3", false);
		start_Hash.put("tDBOutput_3", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_3";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"copyOfNoTokenization");
			
		int tos_count_tDBOutput_3 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_3", "tOracleOutput");
				talendJobLogProcess(globalMap);
			}
			






    int nb_line_tDBOutput_3 = 0;
    int nb_line_update_tDBOutput_3 = 0;
    int nb_line_inserted_tDBOutput_3 = 0;
    int nb_line_deleted_tDBOutput_3 = 0;
    int nb_line_rejected_tDBOutput_3 = 0;

    int tmp_batchUpdateCount_tDBOutput_3 = 0;

    int deletedCount_tDBOutput_3=0;
    int updatedCount_tDBOutput_3=0;
    int insertedCount_tDBOutput_3=0;
    int rejectedCount_tDBOutput_3=0;

    boolean whetherReject_tDBOutput_3 = false;

    java.sql.Connection conn_tDBOutput_3 = null;

    //optional table
    String dbschema_tDBOutput_3 = null;
    String tableName_tDBOutput_3 = null;
        dbschema_tDBOutput_3 = (String)globalMap.get("dbschema_tDBConnection_1");
		
        conn_tDBOutput_3 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
        int count_tDBOutput_3=0;

        if(dbschema_tDBOutput_3 == null || dbschema_tDBOutput_3.trim().length() == 0) {
            tableName_tDBOutput_3 = ("TokenizationNotRequired_after");
        } else {
            tableName_tDBOutput_3 = dbschema_tDBOutput_3 + "." + ("TokenizationNotRequired_after");
        }
                                String tableNameForSearch_tDBOutput_3= "" + ((String)"TokenizationNotRequired_after") + "";
String dbschemaForSearch_tDBOutput_3= null;
if(dbschema_tDBOutput_3== null || dbschema_tDBOutput_3.trim().length() == 0) {
dbschemaForSearch_tDBOutput_3= ((String)globalMap.get("username_tDBConnection_1")).toUpperCase();
} else {
dbschemaForSearch_tDBOutput_3= dbschema_tDBOutput_3.toUpperCase();
}

                                java.sql.DatabaseMetaData dbMetaData_tDBOutput_3 = conn_tDBOutput_3.getMetaData();
                                if(tableNameForSearch_tDBOutput_3.indexOf("\"")==-1){
                                    tableNameForSearch_tDBOutput_3 = tableNameForSearch_tDBOutput_3.toUpperCase();
                                }else{
                                    tableNameForSearch_tDBOutput_3 = tableNameForSearch_tDBOutput_3.replaceAll("\"","");
                                }
                                boolean whetherExist_tDBOutput_3 = false;
                                try (java.sql.ResultSet rsTable_tDBOutput_3 = dbMetaData_tDBOutput_3.getTables(null, dbschemaForSearch_tDBOutput_3, tableNameForSearch_tDBOutput_3, new String[]{"TABLE"})) {
                                    if(rsTable_tDBOutput_3.next()) {
                                        whetherExist_tDBOutput_3 = true;
                                    }
                                }

                                if(whetherExist_tDBOutput_3) {
                                    try (java.sql.Statement stmtDrop_tDBOutput_3 = conn_tDBOutput_3.createStatement()) {
                                        stmtDrop_tDBOutput_3.execute("DROP TABLE " + tableName_tDBOutput_3 + "" );
                                    }
                                }
                                try(java.sql.Statement stmtCreate_tDBOutput_3 = conn_tDBOutput_3.createStatement()) {
                                    stmtCreate_tDBOutput_3.execute("CREATE TABLE " + tableName_tDBOutput_3 + "(Gender CHAR(1)  ,State VARCHAR2(2)  ,City VARCHAR2(50)  ,Zip_Code VARCHAR2(15)  ,Address_Line_1 VARCHAR2(50)  ,Address_Line_2 VARCHAR2(50)  ,Phone_Number VARCHAR2(15)  ,UPI_ID VARCHAR2(40)  ,Client_ID VARCHAR2(32)  ,Carrier_ID VARCHAR2(32)  ,Account_ID VARCHAR2(32)  ,Group_ID VARCHAR2(32)  ,Multi_Birth_Code VARCHAR2(10)  ,Member_Key VARCHAR2(38)  ,Source VARCHAR2(15)  ,scd_key INT  not null )");
                                }
                String insert_tDBOutput_3 = "INSERT INTO " + tableName_tDBOutput_3 + " (Gender,State,City,Zip_Code,Address_Line_1,Address_Line_2,Phone_Number,UPI_ID,Client_ID,Carrier_ID,Account_ID,Group_ID,Multi_Birth_Code,Member_Key,Source,scd_key) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";    

                        java.sql.PreparedStatement pstmt_tDBOutput_3 = conn_tDBOutput_3.prepareStatement(insert_tDBOutput_3);
                        resourceMap.put("pstmt_tDBOutput_3", pstmt_tDBOutput_3);





 



/**
 * [tDBOutput_3 begin ] stop
 */




	
	/**
	 * [tFileOutputJSON_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileOutputJSON_1", false);
		start_Hash.put("tFileOutputJSON_1", System.currentTimeMillis());
		
	
	currentComponent="tFileOutputJSON_1";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"copyOfTokenization1");
			
		int tos_count_tFileOutputJSON_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tFileOutputJSON_1", "tFileOutputJSON");
				talendJobLogProcess(globalMap);
			}
			
int nb_line_tFileOutputJSON_1 = 0;
java.io.File file_tFileOutputJSON_1 = new java.io.File(context.jsonfile_after);
java.io.File dir_tFileOutputJSON_1 = file_tFileOutputJSON_1.getParentFile();
	if(dir_tFileOutputJSON_1!=null && !dir_tFileOutputJSON_1.exists()){
		dir_tFileOutputJSON_1.mkdirs();
	}
java.io.PrintWriter outtFileOutputJSON_1 = new java.io.PrintWriter(new java.io.BufferedWriter(new java.io.FileWriter(context.jsonfile_after)));
	outtFileOutputJSON_1.append("[");
boolean isFirst_tFileOutputJSON_1 = true;
 



/**
 * [tFileOutputJSON_1 begin ] stop
 */



	
	/**
	 * [tMap_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_1", false);
		start_Hash.put("tMap_1", System.currentTimeMillis());
		
	
	currentComponent="tMap_1";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row12");
			
		int tos_count_tMap_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tMap_1", "tMap");
				talendJobLogProcess(globalMap);
			}
			




// ###############################
// # Lookup's keys initialization
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_1__Struct  {
	int var1;
}
Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
// ###############################

// ###############################
// # Outputs initialization
copyOfNoTokenizationStruct copyOfNoTokenization_tmp = new copyOfNoTokenizationStruct();
copyOfTokenization1Struct copyOfTokenization1_tmp = new copyOfTokenization1Struct();
// ###############################

        
        



        









 



/**
 * [tMap_1 begin ] stop
 */



	
	/**
	 * [tFileInputDelimited_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputDelimited_1", false);
		start_Hash.put("tFileInputDelimited_1", System.currentTimeMillis());
		
	
	currentComponent="tFileInputDelimited_1";

	
		int tos_count_tFileInputDelimited_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tFileInputDelimited_1", "tFileInputDelimited");
				talendJobLogProcess(globalMap);
			}
			
	
	
	
 
	
	
	final routines.system.RowState rowstate_tFileInputDelimited_1 = new routines.system.RowState();
	
	
				int nb_line_tFileInputDelimited_1 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_1 = null;
				int limit_tFileInputDelimited_1 = -1;
				try{
					
						Object filename_tFileInputDelimited_1 = context.filename;
						if(filename_tFileInputDelimited_1 instanceof java.io.InputStream){
							
			int footer_value_tFileInputDelimited_1 = 0, random_value_tFileInputDelimited_1 = -1;
			if(footer_value_tFileInputDelimited_1 >0 || random_value_tFileInputDelimited_1 > 0){
				throw new java.lang.Exception("When the input source is a stream,footer and random shouldn't be bigger than 0.");				
			}
		
						}
						try {
							fid_tFileInputDelimited_1 = new org.talend.fileprocess.FileInputDelimited(context.filename, "ISO-8859-15","|","\n",false,1,0,
									limit_tFileInputDelimited_1
								,-1, false);
						} catch(java.lang.Exception e) {
							
								
								System.err.println(e.getMessage());
							
						}
					
				    
					while (fid_tFileInputDelimited_1!=null && fid_tFileInputDelimited_1.nextRecord()) {
						rowstate_tFileInputDelimited_1.reset();
						
			    						row12 = null;			
												
									boolean whetherReject_tFileInputDelimited_1 = false;
									row12 = new row12Struct();
									try {
										
				int columnIndexWithD_tFileInputDelimited_1 = 0;
				
					String temp = ""; 
				
					columnIndexWithD_tFileInputDelimited_1 = 0;
					
						temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						if(temp.length() > 0) {
							
								try {
								
    								row12.Gender = ParserUtils.parseTo_Character(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_1) {
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"Gender", "row12", temp, ex_tFileInputDelimited_1), ex_tFileInputDelimited_1));
								}
    							
						} else {						
							
								
									row12.Gender = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_1 = 1;
					
							row12.Date_of_Birth = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 2;
					
							row12.First_Name = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 3;
					
							row12.Last_Name = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 4;
					
							row12.State = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 5;
					
							row12.City = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 6;
					
							row12.Zip_Code = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 7;
					
							row12.Address_Line_1 = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 8;
					
							row12.Address_Line_2 = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 9;
					
							row12.Phone_Number = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 10;
					
							row12.Social_Security_Number = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 11;
					
							row12.UPI_ID = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 12;
					
							row12.MBI = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 13;
					
							row12.Client_ID = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 14;
					
							row12.Carrier_ID = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 15;
					
							row12.Account_ID = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 16;
					
							row12.Group_ID = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 17;
					
							row12.Contract_Family_ID = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 18;
					
							row12.Multi_Birth_Code = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 19;
					
							row12.Member_Key = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 20;
					
							row12.Source = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
				
										
										if(rowstate_tFileInputDelimited_1.getException()!=null) {
											throw rowstate_tFileInputDelimited_1.getException();
										}
										
										
							
			    					} catch (java.lang.Exception e) {
			        					whetherReject_tFileInputDelimited_1 = true;
			        					
			                					System.err.println(e.getMessage());
			                					row12 = null;
			                				
			    					}
								

 



/**
 * [tFileInputDelimited_1 begin ] stop
 */
	
	/**
	 * [tFileInputDelimited_1 main ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_1";

	

 


	tos_count_tFileInputDelimited_1++;

/**
 * [tFileInputDelimited_1 main ] stop
 */
	
	/**
	 * [tFileInputDelimited_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_1";

	

 



/**
 * [tFileInputDelimited_1 process_data_begin ] stop
 */
// Start of branch "row12"
if(row12 != null) { 



	
	/**
	 * [tMap_1 main ] start
	 */

	

	
	
	currentComponent="tMap_1";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"row12");
			

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;
		
        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_1 = false;
		  boolean mainRowRejected_tMap_1 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_1__Struct Var = Var__tMap_1;
Var.var1 = Numeric.sequence("s3",1,1) ;// ###############################
        // ###############################
        // # Output tables

copyOfNoTokenization = null;
copyOfTokenization1 = null;


// # Output table : 'copyOfNoTokenization'
copyOfNoTokenization_tmp.Gender = row12.Gender ;
copyOfNoTokenization_tmp.State = row12.State ;
copyOfNoTokenization_tmp.City = row12.City ;
copyOfNoTokenization_tmp.Zip_Code = row12.Zip_Code ;
copyOfNoTokenization_tmp.Address_Line_1 = row12.Address_Line_1 ;
copyOfNoTokenization_tmp.Address_Line_2 = row12.Address_Line_2 ;
copyOfNoTokenization_tmp.Phone_Number = row12.Phone_Number ;
copyOfNoTokenization_tmp.UPI_ID = row12.UPI_ID ;
copyOfNoTokenization_tmp.Client_ID = row12.Client_ID ;
copyOfNoTokenization_tmp.Carrier_ID = row12.Carrier_ID ;
copyOfNoTokenization_tmp.Account_ID = row12.Account_ID ;
copyOfNoTokenization_tmp.Group_ID = row12.Group_ID ;
copyOfNoTokenization_tmp.Multi_Birth_Code = row12.Multi_Birth_Code ;
copyOfNoTokenization_tmp.Member_Key = row12.Member_Key ;
copyOfNoTokenization_tmp.Source = row12.Source ;
copyOfNoTokenization_tmp.scd_key = Var.var1 ;
copyOfNoTokenization = copyOfNoTokenization_tmp;

// # Output table : 'copyOfTokenization1'
copyOfTokenization1_tmp.DOB = row12.Date_of_Birth ;
copyOfTokenization1_tmp.firstName = row12.First_Name ;
copyOfTokenization1_tmp.lastName = row12.Last_Name ;
copyOfTokenization1_tmp.SSN = row12.Social_Security_Number ;
copyOfTokenization1_tmp.MBI = row12.MBI ;
copyOfTokenization1_tmp.OtherID = row12.Contract_Family_ID ;
copyOfTokenization1 = copyOfTokenization1_tmp;
// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_1 = false;










 


	tos_count_tMap_1++;

/**
 * [tMap_1 main ] stop
 */
	
	/**
	 * [tMap_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

 



/**
 * [tMap_1 process_data_begin ] stop
 */
// Start of branch "copyOfNoTokenization"
if(copyOfNoTokenization != null) { 



	
	/**
	 * [tDBOutput_3 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"copyOfNoTokenization");
			



            row1 = null;
        whetherReject_tDBOutput_3 = false;
                        if(copyOfNoTokenization.Gender == null) {
pstmt_tDBOutput_3.setNull(1, java.sql.Types.CHAR);
} else {if(copyOfNoTokenization.Gender == null) {
pstmt_tDBOutput_3.setNull(1, java.sql.Types.CHAR);
} else if(copyOfNoTokenization.Gender == ' '){
pstmt_tDBOutput_3.setString(1, "");
} else {
pstmt_tDBOutput_3.setString(1, String.valueOf(copyOfNoTokenization.Gender));
}}

                        if(copyOfNoTokenization.State == null) {
pstmt_tDBOutput_3.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(2, copyOfNoTokenization.State);
}

                        if(copyOfNoTokenization.City == null) {
pstmt_tDBOutput_3.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(3, copyOfNoTokenization.City);
}

                        if(copyOfNoTokenization.Zip_Code == null) {
pstmt_tDBOutput_3.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(4, copyOfNoTokenization.Zip_Code);
}

                        if(copyOfNoTokenization.Address_Line_1 == null) {
pstmt_tDBOutput_3.setNull(5, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(5, copyOfNoTokenization.Address_Line_1);
}

                        if(copyOfNoTokenization.Address_Line_2 == null) {
pstmt_tDBOutput_3.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(6, copyOfNoTokenization.Address_Line_2);
}

                        if(copyOfNoTokenization.Phone_Number == null) {
pstmt_tDBOutput_3.setNull(7, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(7, copyOfNoTokenization.Phone_Number);
}

                        if(copyOfNoTokenization.UPI_ID == null) {
pstmt_tDBOutput_3.setNull(8, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(8, copyOfNoTokenization.UPI_ID);
}

                        if(copyOfNoTokenization.Client_ID == null) {
pstmt_tDBOutput_3.setNull(9, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(9, copyOfNoTokenization.Client_ID);
}

                        if(copyOfNoTokenization.Carrier_ID == null) {
pstmt_tDBOutput_3.setNull(10, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(10, copyOfNoTokenization.Carrier_ID);
}

                        if(copyOfNoTokenization.Account_ID == null) {
pstmt_tDBOutput_3.setNull(11, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(11, copyOfNoTokenization.Account_ID);
}

                        if(copyOfNoTokenization.Group_ID == null) {
pstmt_tDBOutput_3.setNull(12, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(12, copyOfNoTokenization.Group_ID);
}

                        if(copyOfNoTokenization.Multi_Birth_Code == null) {
pstmt_tDBOutput_3.setNull(13, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(13, copyOfNoTokenization.Multi_Birth_Code);
}

                        if(copyOfNoTokenization.Member_Key == null) {
pstmt_tDBOutput_3.setNull(14, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(14, copyOfNoTokenization.Member_Key);
}

                        if(copyOfNoTokenization.Source == null) {
pstmt_tDBOutput_3.setNull(15, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(15, copyOfNoTokenization.Source);
}

                        pstmt_tDBOutput_3.setInt(16, copyOfNoTokenization.scd_key);

                try {
                    nb_line_tDBOutput_3++;
                    insertedCount_tDBOutput_3 = insertedCount_tDBOutput_3 + pstmt_tDBOutput_3.executeUpdate();
                } catch(java.lang.Exception e_tDBOutput_3) {
                    whetherReject_tDBOutput_3 = true;
                            System.err.print(e_tDBOutput_3.getMessage());
                }
            if(!whetherReject_tDBOutput_3) {
                            row1 = new row1Struct();
                                row1.Gender = copyOfNoTokenization.Gender;
                                row1.State = copyOfNoTokenization.State;
                                row1.City = copyOfNoTokenization.City;
                                row1.Zip_Code = copyOfNoTokenization.Zip_Code;
                                row1.Address_Line_1 = copyOfNoTokenization.Address_Line_1;
                                row1.Address_Line_2 = copyOfNoTokenization.Address_Line_2;
                                row1.Phone_Number = copyOfNoTokenization.Phone_Number;
                                row1.UPI_ID = copyOfNoTokenization.UPI_ID;
                                row1.Client_ID = copyOfNoTokenization.Client_ID;
                                row1.Carrier_ID = copyOfNoTokenization.Carrier_ID;
                                row1.Account_ID = copyOfNoTokenization.Account_ID;
                                row1.Group_ID = copyOfNoTokenization.Group_ID;
                                row1.Multi_Birth_Code = copyOfNoTokenization.Multi_Birth_Code;
                                row1.Member_Key = copyOfNoTokenization.Member_Key;
                                row1.Source = copyOfNoTokenization.Source;
                                row1.scd_key = copyOfNoTokenization.scd_key;
            }

 


	tos_count_tDBOutput_3++;

/**
 * [tDBOutput_3 main ] stop
 */
	
	/**
	 * [tDBOutput_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";

	

 



/**
 * [tDBOutput_3 process_data_begin ] stop
 */
// Start of branch "row1"
if(row1 != null) { 



	
	/**
	 * [tLogRow_1 main ] start
	 */

	

	
	
	currentComponent="tLogRow_1";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"row1");
			
///////////////////////		
						

				
				String[] row_tLogRow_1 = new String[16];
   				
	    		if(row1.Gender != null) { //              
                 row_tLogRow_1[0]=    						    
				                String.valueOf(row1.Gender)			
					          ;	
							
	    		} //			
    			   				
	    		if(row1.State != null) { //              
                 row_tLogRow_1[1]=    						    
				                String.valueOf(row1.State)			
					          ;	
							
	    		} //			
    			   				
	    		if(row1.City != null) { //              
                 row_tLogRow_1[2]=    						    
				                String.valueOf(row1.City)			
					          ;	
							
	    		} //			
    			   				
	    		if(row1.Zip_Code != null) { //              
                 row_tLogRow_1[3]=    						    
				                String.valueOf(row1.Zip_Code)			
					          ;	
							
	    		} //			
    			   				
	    		if(row1.Address_Line_1 != null) { //              
                 row_tLogRow_1[4]=    						    
				                String.valueOf(row1.Address_Line_1)			
					          ;	
							
	    		} //			
    			   				
	    		if(row1.Address_Line_2 != null) { //              
                 row_tLogRow_1[5]=    						    
				                String.valueOf(row1.Address_Line_2)			
					          ;	
							
	    		} //			
    			   				
	    		if(row1.Phone_Number != null) { //              
                 row_tLogRow_1[6]=    						    
				                String.valueOf(row1.Phone_Number)			
					          ;	
							
	    		} //			
    			   				
	    		if(row1.UPI_ID != null) { //              
                 row_tLogRow_1[7]=    						    
				                String.valueOf(row1.UPI_ID)			
					          ;	
							
	    		} //			
    			   				
	    		if(row1.Client_ID != null) { //              
                 row_tLogRow_1[8]=    						    
				                String.valueOf(row1.Client_ID)			
					          ;	
							
	    		} //			
    			   				
	    		if(row1.Carrier_ID != null) { //              
                 row_tLogRow_1[9]=    						    
				                String.valueOf(row1.Carrier_ID)			
					          ;	
							
	    		} //			
    			   				
	    		if(row1.Account_ID != null) { //              
                 row_tLogRow_1[10]=    						    
				                String.valueOf(row1.Account_ID)			
					          ;	
							
	    		} //			
    			   				
	    		if(row1.Group_ID != null) { //              
                 row_tLogRow_1[11]=    						    
				                String.valueOf(row1.Group_ID)			
					          ;	
							
	    		} //			
    			   				
	    		if(row1.Multi_Birth_Code != null) { //              
                 row_tLogRow_1[12]=    						    
				                String.valueOf(row1.Multi_Birth_Code)			
					          ;	
							
	    		} //			
    			   				
	    		if(row1.Member_Key != null) { //              
                 row_tLogRow_1[13]=    						    
				                String.valueOf(row1.Member_Key)			
					          ;	
							
	    		} //			
    			   				
	    		if(row1.Source != null) { //              
                 row_tLogRow_1[14]=    						    
				                String.valueOf(row1.Source)			
					          ;	
							
	    		} //			
    			              
                 row_tLogRow_1[15]=    						    
				                String.valueOf(row1.scd_key)			
					          ;	
										
    			 

				util_tLogRow_1.addRow(row_tLogRow_1);	
				nb_line_tLogRow_1++;
//////

//////                    
                    
///////////////////////    			

 


	tos_count_tLogRow_1++;

/**
 * [tLogRow_1 main ] stop
 */
	
	/**
	 * [tLogRow_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tLogRow_1";

	

 



/**
 * [tLogRow_1 process_data_begin ] stop
 */
	
	/**
	 * [tLogRow_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tLogRow_1";

	

 



/**
 * [tLogRow_1 process_data_end ] stop
 */

} // End of branch "row1"




	
	/**
	 * [tDBOutput_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";

	

 



/**
 * [tDBOutput_3 process_data_end ] stop
 */

} // End of branch "copyOfNoTokenization"




// Start of branch "copyOfTokenization1"
if(copyOfTokenization1 != null) { 



	
	/**
	 * [tFileOutputJSON_1 main ] start
	 */

	

	
	
	currentComponent="tFileOutputJSON_1";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"copyOfTokenization1");
			


org.json.simple.JSONObject jsonRowtFileOutputJSON_1 = new org.json.simple.JSONObject();
			    	if(copyOfTokenization1.DOB != null){
			    
					jsonRowtFileOutputJSON_1.put("DOB", copyOfTokenization1.DOB);
				
					}else{
						jsonRowtFileOutputJSON_1.put("DOB", null);
					}
				
			    	if(copyOfTokenization1.firstName != null){
			    
					jsonRowtFileOutputJSON_1.put("firstName", copyOfTokenization1.firstName);
				
					}else{
						jsonRowtFileOutputJSON_1.put("firstName", null);
					}
				
			    	if(copyOfTokenization1.lastName != null){
			    
					jsonRowtFileOutputJSON_1.put("lastName", copyOfTokenization1.lastName);
				
					}else{
						jsonRowtFileOutputJSON_1.put("lastName", null);
					}
				
			    	if(copyOfTokenization1.SSN != null){
			    
					jsonRowtFileOutputJSON_1.put("SSN", copyOfTokenization1.SSN);
				
					}else{
						jsonRowtFileOutputJSON_1.put("SSN", null);
					}
				
			    	if(copyOfTokenization1.MBI != null){
			    
					jsonRowtFileOutputJSON_1.put("MBI", copyOfTokenization1.MBI);
				
					}else{
						jsonRowtFileOutputJSON_1.put("MBI", null);
					}
				
			    	if(copyOfTokenization1.OtherID != null){
			    
					jsonRowtFileOutputJSON_1.put("OtherID", copyOfTokenization1.OtherID);
				
					}else{
						jsonRowtFileOutputJSON_1.put("OtherID", null);
					}
				

if(!isFirst_tFileOutputJSON_1){
	outtFileOutputJSON_1.append(",");
}
isFirst_tFileOutputJSON_1 = false;
outtFileOutputJSON_1.append(jsonRowtFileOutputJSON_1.toJSONString());
nb_line_tFileOutputJSON_1++;

 


	tos_count_tFileOutputJSON_1++;

/**
 * [tFileOutputJSON_1 main ] stop
 */
	
	/**
	 * [tFileOutputJSON_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileOutputJSON_1";

	

 



/**
 * [tFileOutputJSON_1 process_data_begin ] stop
 */
	
	/**
	 * [tFileOutputJSON_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileOutputJSON_1";

	

 



/**
 * [tFileOutputJSON_1 process_data_end ] stop
 */

} // End of branch "copyOfTokenization1"




	
	/**
	 * [tMap_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

 



/**
 * [tMap_1 process_data_end ] stop
 */

} // End of branch "row12"




	
	/**
	 * [tFileInputDelimited_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_1";

	

 



/**
 * [tFileInputDelimited_1 process_data_end ] stop
 */
	
	/**
	 * [tFileInputDelimited_1 end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_1";

	



            }
            }finally{
                if(!((Object)(context.filename) instanceof java.io.InputStream)){
                	if(fid_tFileInputDelimited_1!=null){
                		fid_tFileInputDelimited_1.close();
                	}
                }
                if(fid_tFileInputDelimited_1!=null){
                	globalMap.put("tFileInputDelimited_1_NB_LINE", fid_tFileInputDelimited_1.getRowNumber());
					
                }
			}
			  

 

ok_Hash.put("tFileInputDelimited_1", true);
end_Hash.put("tFileInputDelimited_1", System.currentTimeMillis());




/**
 * [tFileInputDelimited_1 end ] stop
 */

	
	/**
	 * [tMap_1 end ] start
	 */

	

	
	
	currentComponent="tMap_1";

	


// ###############################
// # Lookup hashes releasing
// ###############################      





			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row12",2,0,
			 			talendJobLog,"tFileInputDelimited_1","tFileInputDelimited","tMap_1","tMap","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tMap_1", true);
end_Hash.put("tMap_1", System.currentTimeMillis());




/**
 * [tMap_1 end ] stop
 */

	
	/**
	 * [tDBOutput_3 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";

	
	



	
        if(pstmt_tDBOutput_3 != null) {
			
				pstmt_tDBOutput_3.close();
				resourceMap.remove("pstmt_tDBOutput_3");
			
        }
    resourceMap.put("statementClosed_tDBOutput_3", true);


	
	nb_line_deleted_tDBOutput_3=nb_line_deleted_tDBOutput_3+ deletedCount_tDBOutput_3;
	nb_line_update_tDBOutput_3=nb_line_update_tDBOutput_3 + updatedCount_tDBOutput_3;
	nb_line_inserted_tDBOutput_3=nb_line_inserted_tDBOutput_3 + insertedCount_tDBOutput_3;
	nb_line_rejected_tDBOutput_3=nb_line_rejected_tDBOutput_3 + rejectedCount_tDBOutput_3;
	
        globalMap.put("tDBOutput_3_NB_LINE",nb_line_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_UPDATED",nb_line_update_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_DELETED",nb_line_deleted_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_3);
    
	



			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"copyOfNoTokenization",2,0,
			 			talendJobLog,"tMap_1","tMap","tDBOutput_3","tOracleOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tDBOutput_3", true);
end_Hash.put("tDBOutput_3", System.currentTimeMillis());




/**
 * [tDBOutput_3 end ] stop
 */

	
	/**
	 * [tLogRow_1 end ] start
	 */

	

	
	
	currentComponent="tLogRow_1";

	


//////

                    
                    java.io.PrintStream consoleOut_tLogRow_1 = null;
                    if (globalMap.get("tLogRow_CONSOLE")!=null)
                    {
                    	consoleOut_tLogRow_1 = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
                    }
                    else
                    {
                    	consoleOut_tLogRow_1 = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
                    	globalMap.put("tLogRow_CONSOLE",consoleOut_tLogRow_1);
                    }
                    
                    consoleOut_tLogRow_1.println(util_tLogRow_1.format().toString());
                    consoleOut_tLogRow_1.flush();
//////
globalMap.put("tLogRow_1_NB_LINE",nb_line_tLogRow_1);

///////////////////////    			

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row1",2,0,
			 			talendJobLog,"tDBOutput_3","tOracleOutput","tLogRow_1","tLogRow","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tLogRow_1", true);
end_Hash.put("tLogRow_1", System.currentTimeMillis());




/**
 * [tLogRow_1 end ] stop
 */







	
	/**
	 * [tFileOutputJSON_1 end ] start
	 */

	

	
	
	currentComponent="tFileOutputJSON_1";

	

	outtFileOutputJSON_1.print("]");
outtFileOutputJSON_1.close();
globalMap.put("tFileOutputJSON_1_NB_LINE",nb_line_tFileOutputJSON_1);

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"copyOfTokenization1",2,0,
			 			talendJobLog,"tMap_1","tMap","tFileOutputJSON_1","tFileOutputJSON","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tFileOutputJSON_1", true);
end_Hash.put("tFileOutputJSON_1", System.currentTimeMillis());




/**
 * [tFileOutputJSON_1 end ] stop
 */






				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFileInputDelimited_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk2", 0, "ok");
								} 
							
							tFileInputRaw_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileInputDelimited_1 finally ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_1";

	

 



/**
 * [tFileInputDelimited_1 finally ] stop
 */

	
	/**
	 * [tMap_1 finally ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

 



/**
 * [tMap_1 finally ] stop
 */

	
	/**
	 * [tDBOutput_3 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";

	



    if (resourceMap.get("statementClosed_tDBOutput_3") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_3 = null;
                if ((pstmtToClose_tDBOutput_3 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_3")) != null) {
                    pstmtToClose_tDBOutput_3.close();
                }
    }
 



/**
 * [tDBOutput_3 finally ] stop
 */

	
	/**
	 * [tLogRow_1 finally ] start
	 */

	

	
	
	currentComponent="tLogRow_1";

	

 



/**
 * [tLogRow_1 finally ] stop
 */







	
	/**
	 * [tFileOutputJSON_1 finally ] start
	 */

	

	
	
	currentComponent="tFileOutputJSON_1";

	

 



/**
 * [tFileOutputJSON_1 finally ] stop
 */






				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileInputDelimited_1_SUBPROCESS_STATE", 1);
	}
	


public static class row7Struct implements routines.system.IPersistableRow<row7Struct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Tokenization = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecords_Tokenization = new byte[0];

	
			    public String firstName;

				public String getFirstName () {
					return this.firstName;
				}
				
			    public String lastName;

				public String getLastName () {
					return this.lastName;
				}
				
			    public String MBI;

				public String getMBI () {
					return this.MBI;
				}
				
			    public String DOB;

				public String getDOB () {
					return this.DOB;
				}
				
			    public String OtherID;

				public String getOtherID () {
					return this.OtherID;
				}
				
			    public String SSN;

				public String getSSN () {
					return this.SSN;
				}
				
			    public int scd_key;

				public int getScd_key () {
					return this.scd_key;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecords_Tokenization.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecords_Tokenization.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecords_Tokenization = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecords_Tokenization = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecords_Tokenization, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecords_Tokenization, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Tokenization) {

        	try {

        		int length = 0;
		
					this.firstName = readString(dis);
					
					this.lastName = readString(dis);
					
					this.MBI = readString(dis);
					
					this.DOB = readString(dis);
					
					this.OtherID = readString(dis);
					
					this.SSN = readString(dis);
					
			        this.scd_key = dis.readInt();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.firstName,dos);
					
					// String
				
						writeString(this.lastName,dos);
					
					// String
				
						writeString(this.MBI,dos);
					
					// String
				
						writeString(this.DOB,dos);
					
					// String
				
						writeString(this.OtherID,dos);
					
					// String
				
						writeString(this.SSN,dos);
					
					// int
				
		            	dos.writeInt(this.scd_key);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("firstName="+firstName);
		sb.append(",lastName="+lastName);
		sb.append(",MBI="+MBI);
		sb.append(",DOB="+DOB);
		sb.append(",OtherID="+OtherID);
		sb.append(",SSN="+SSN);
		sb.append(",scd_key="+String.valueOf(scd_key));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row7Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class outStruct implements routines.system.IPersistableRow<outStruct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Tokenization = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecords_Tokenization = new byte[0];

	
			    public String firstName;

				public String getFirstName () {
					return this.firstName;
				}
				
			    public String lastName;

				public String getLastName () {
					return this.lastName;
				}
				
			    public String MBI;

				public String getMBI () {
					return this.MBI;
				}
				
			    public String DOB;

				public String getDOB () {
					return this.DOB;
				}
				
			    public String OtherID;

				public String getOtherID () {
					return this.OtherID;
				}
				
			    public String SSN;

				public String getSSN () {
					return this.SSN;
				}
				
			    public int scd_key;

				public int getScd_key () {
					return this.scd_key;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecords_Tokenization.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecords_Tokenization.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecords_Tokenization = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecords_Tokenization = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecords_Tokenization, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecords_Tokenization, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Tokenization) {

        	try {

        		int length = 0;
		
					this.firstName = readString(dis);
					
					this.lastName = readString(dis);
					
					this.MBI = readString(dis);
					
					this.DOB = readString(dis);
					
					this.OtherID = readString(dis);
					
					this.SSN = readString(dis);
					
			        this.scd_key = dis.readInt();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.firstName,dos);
					
					// String
				
						writeString(this.lastName,dos);
					
					// String
				
						writeString(this.MBI,dos);
					
					// String
				
						writeString(this.DOB,dos);
					
					// String
				
						writeString(this.OtherID,dos);
					
					// String
				
						writeString(this.SSN,dos);
					
					// int
				
		            	dos.writeInt(this.scd_key);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("firstName="+firstName);
		sb.append(",lastName="+lastName);
		sb.append(",MBI="+MBI);
		sb.append(",DOB="+DOB);
		sb.append(",OtherID="+OtherID);
		sb.append(",SSN="+SSN);
		sb.append(",scd_key="+String.valueOf(scd_key));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(outStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row5Struct implements routines.system.IPersistableRow<row5Struct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Tokenization = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecords_Tokenization = new byte[0];

	
			    public String firstName;

				public String getFirstName () {
					return this.firstName;
				}
				
			    public String lastName;

				public String getLastName () {
					return this.lastName;
				}
				
			    public String MBI;

				public String getMBI () {
					return this.MBI;
				}
				
			    public String DOB;

				public String getDOB () {
					return this.DOB;
				}
				
			    public String OtherID;

				public String getOtherID () {
					return this.OtherID;
				}
				
			    public String SSN;

				public String getSSN () {
					return this.SSN;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecords_Tokenization.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecords_Tokenization.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecords_Tokenization = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecords_Tokenization = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecords_Tokenization, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecords_Tokenization, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Tokenization) {

        	try {

        		int length = 0;
		
					this.firstName = readString(dis);
					
					this.lastName = readString(dis);
					
					this.MBI = readString(dis);
					
					this.DOB = readString(dis);
					
					this.OtherID = readString(dis);
					
					this.SSN = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.firstName,dos);
					
					// String
				
						writeString(this.lastName,dos);
					
					// String
				
						writeString(this.MBI,dos);
					
					// String
				
						writeString(this.DOB,dos);
					
					// String
				
						writeString(this.OtherID,dos);
					
					// String
				
						writeString(this.SSN,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("firstName="+firstName);
		sb.append(",lastName="+lastName);
		sb.append(",MBI="+MBI);
		sb.append(",DOB="+DOB);
		sb.append(",OtherID="+OtherID);
		sb.append(",SSN="+SSN);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row5Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Tokenization = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecords_Tokenization = new byte[0];

	
			    public String Body;

				public String getBody () {
					return this.Body;
				}
				
			    public Integer ERROR_CODE;

				public Integer getERROR_CODE () {
					return this.ERROR_CODE;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecords_Tokenization.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecords_Tokenization.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecords_Tokenization = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecords_Tokenization = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecords_Tokenization, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecords_Tokenization, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Tokenization) {

        	try {

        		int length = 0;
		
					this.Body = readString(dis);
					
						this.ERROR_CODE = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Body,dos);
					
					// Integer
				
						writeInteger(this.ERROR_CODE,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Body="+Body);
		sb.append(",ERROR_CODE="+String.valueOf(ERROR_CODE));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row2Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row6Struct implements routines.system.IPersistableRow<row6Struct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Tokenization = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecords_Tokenization = new byte[0];

	
			    public Object content;

				public Object getContent () {
					return this.content;
				}
				



    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Tokenization) {

        	try {

        		int length = 0;
		
						this.content = (Object) dis.readObject();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Object
				
       			    	dos.writeObject(this.content);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("content="+String.valueOf(content));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row6Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFileInputRaw_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileInputRaw_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row6Struct row6 = new row6Struct();
row2Struct row2 = new row2Struct();
row5Struct row5 = new row5Struct();
outStruct out = new outStruct();
row7Struct row7 = new row7Struct();




	
	/**
	 * [tFlowToIterate_1 begin ] start
	 */

				
			int NB_ITERATE_tREST_1 = 0; //for statistics
			

	
		
		ok_Hash.put("tFlowToIterate_1", false);
		start_Hash.put("tFlowToIterate_1", System.currentTimeMillis());
		
	
	currentComponent="tFlowToIterate_1";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row6");
			
		int tos_count_tFlowToIterate_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tFlowToIterate_1", "tFlowToIterate");
				talendJobLogProcess(globalMap);
			}
			

int nb_line_tFlowToIterate_1 = 0;
int counter_tFlowToIterate_1 = 0;

 



/**
 * [tFlowToIterate_1 begin ] stop
 */



	
	/**
	 * [tFileInputRaw_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputRaw_1", false);
		start_Hash.put("tFileInputRaw_1", System.currentTimeMillis());
		
	
	currentComponent="tFileInputRaw_1";

	
		int tos_count_tFileInputRaw_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tFileInputRaw_1", "tFileInputRaw");
				talendJobLogProcess(globalMap);
			}
			
	

				try {					
					String content_tFileInputRaw_1 = org.apache.commons.io.FileUtils.readFileToString(new java.io.File(context.jsonfile_after), "ISO-8859-15");
					row6.content = content_tFileInputRaw_1;					
					globalMap.put("tFileInputRaw_1_FILENAME_PATH", context.jsonfile_after);
				} catch (java.io.IOException e_tFileInputRaw_1) {
					
					System.err.println(e_tFileInputRaw_1);
				}


 



/**
 * [tFileInputRaw_1 begin ] stop
 */
	
	/**
	 * [tFileInputRaw_1 main ] start
	 */

	

	
	
	currentComponent="tFileInputRaw_1";

	

 


	tos_count_tFileInputRaw_1++;

/**
 * [tFileInputRaw_1 main ] stop
 */
	
	/**
	 * [tFileInputRaw_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileInputRaw_1";

	

 



/**
 * [tFileInputRaw_1 process_data_begin ] stop
 */

	
	/**
	 * [tFlowToIterate_1 main ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_1";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"row6");
			


    	            
            globalMap.put("row6.content", row6.content);
    	
 
	   nb_line_tFlowToIterate_1++;  
       counter_tFlowToIterate_1++;
       globalMap.put("tFlowToIterate_1_CURRENT_ITERATION", counter_tFlowToIterate_1);
 


	tos_count_tFlowToIterate_1++;

/**
 * [tFlowToIterate_1 main ] stop
 */
	
	/**
	 * [tFlowToIterate_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_1";

	

 



/**
 * [tFlowToIterate_1 process_data_begin ] stop
 */
	NB_ITERATE_tREST_1++;
	
	
					if(execStat){				
	       				runStat.updateStatOnConnection("row5", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row2", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row7", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("out", 3, 0);
					}           			
				
				if(execStat){
					runStat.updateStatOnConnection("iterate1", 1, "exec" + NB_ITERATE_tREST_1);
					//Thread.sleep(1000);
				}				
			





	
	/**
	 * [tLogRow_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tLogRow_2", false);
		start_Hash.put("tLogRow_2", System.currentTimeMillis());
		
	
	currentComponent="tLogRow_2";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row7");
			
		int tos_count_tLogRow_2 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tLogRow_2", "tLogRow");
				talendJobLogProcess(globalMap);
			}
			

	///////////////////////
	
         class Util_tLogRow_2 {

        String[] des_top = { ".", ".", "-", "+" };

        String[] des_head = { "|=", "=|", "-", "+" };

        String[] des_bottom = { "'", "'", "-", "+" };

        String name="";

        java.util.List<String[]> list = new java.util.ArrayList<String[]>();

        int[] colLengths = new int[7];

        public void addRow(String[] row) {

            for (int i = 0; i < 7; i++) {
                if (row[i]!=null) {
                  colLengths[i] = Math.max(colLengths[i], row[i].length());
                }
            }
            list.add(row);
        }

        public void setTableName(String name) {

            this.name = name;
        }

            public StringBuilder format() {
            
                StringBuilder sb = new StringBuilder();
  
            
                    sb.append(print(des_top));
    
                    int totals = 0;
                    for (int i = 0; i < colLengths.length; i++) {
                        totals = totals + colLengths[i];
                    }
    
                    // name
                    sb.append("|");
                    int k = 0;
                    for (k = 0; k < (totals + 6 - name.length()) / 2; k++) {
                        sb.append(' ');
                    }
                    sb.append(name);
                    for (int i = 0; i < totals + 6 - name.length() - k; i++) {
                        sb.append(' ');
                    }
                    sb.append("|\n");

                    // head and rows
                    sb.append(print(des_head));
                    for (int i = 0; i < list.size(); i++) {
    
                        String[] row = list.get(i);
    
                        java.util.Formatter formatter = new java.util.Formatter(new StringBuilder());
                        
                        StringBuilder sbformat = new StringBuilder();                                             
        			        sbformat.append("|%1$-");
        			        sbformat.append(colLengths[0]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%2$-");
        			        sbformat.append(colLengths[1]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%3$-");
        			        sbformat.append(colLengths[2]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%4$-");
        			        sbformat.append(colLengths[3]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%5$-");
        			        sbformat.append(colLengths[4]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%6$-");
        			        sbformat.append(colLengths[5]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%7$-");
        			        sbformat.append(colLengths[6]);
        			        sbformat.append("s");
        			                      
                        sbformat.append("|\n");                    
       
                        formatter.format(sbformat.toString(), (Object[])row);	
                                
                        sb.append(formatter.toString());
                        if (i == 0)
                            sb.append(print(des_head)); // print the head
                    }
    
                    // end
                    sb.append(print(des_bottom));
                    return sb;
                }
            

            private StringBuilder print(String[] fillChars) {
                StringBuilder sb = new StringBuilder();
                //first column
                sb.append(fillChars[0]);                
                    for (int i = 0; i < colLengths[0] - fillChars[0].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);	                

                    for (int i = 0; i < colLengths[1] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[2] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[3] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[4] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[5] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                
                    //last column
                    for (int i = 0; i < colLengths[6] - fillChars[1].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }         
                sb.append(fillChars[1]);
                sb.append("\n");               
                return sb;
            }
            
            public boolean isTableEmpty(){
            	if (list.size() > 1)
            		return false;
            	return true;
            }
        }
        Util_tLogRow_2 util_tLogRow_2 = new Util_tLogRow_2();
        util_tLogRow_2.setTableName("tLogRow_2");
        util_tLogRow_2.addRow(new String[]{"firstName","lastName","MBI","DOB","OtherID","SSN","scd_key",});        
 		StringBuilder strBuffer_tLogRow_2 = null;
		int nb_line_tLogRow_2 = 0;
///////////////////////    			



 



/**
 * [tLogRow_2 begin ] stop
 */



	
	/**
	 * [tDBOutput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_1", false);
		start_Hash.put("tDBOutput_1", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_1";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"out");
			
		int tos_count_tDBOutput_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_1", "tOracleOutput");
				talendJobLogProcess(globalMap);
			}
			






    int nb_line_tDBOutput_1 = 0;
    int nb_line_update_tDBOutput_1 = 0;
    int nb_line_inserted_tDBOutput_1 = 0;
    int nb_line_deleted_tDBOutput_1 = 0;
    int nb_line_rejected_tDBOutput_1 = 0;

    int tmp_batchUpdateCount_tDBOutput_1 = 0;

    int deletedCount_tDBOutput_1=0;
    int updatedCount_tDBOutput_1=0;
    int insertedCount_tDBOutput_1=0;
    int rejectedCount_tDBOutput_1=0;

    boolean whetherReject_tDBOutput_1 = false;

    java.sql.Connection conn_tDBOutput_1 = null;

    //optional table
    String dbschema_tDBOutput_1 = null;
    String tableName_tDBOutput_1 = null;
        dbschema_tDBOutput_1 = (String)globalMap.get("dbschema_tDBConnection_1");
		
        conn_tDBOutput_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
        int count_tDBOutput_1=0;

        if(dbschema_tDBOutput_1 == null || dbschema_tDBOutput_1.trim().length() == 0) {
            tableName_tDBOutput_1 = ("tokenized_landing");
        } else {
            tableName_tDBOutput_1 = dbschema_tDBOutput_1 + "." + ("tokenized_landing");
        }
            try (java.sql.Statement stmtClear_tDBOutput_1 = conn_tDBOutput_1.createStatement()) {
                stmtClear_tDBOutput_1.executeUpdate("DELETE FROM " + tableName_tDBOutput_1 + "");
            }
                String insert_tDBOutput_1 = "INSERT INTO " + tableName_tDBOutput_1 + " (firstName,lastName,MBI,DOB,OtherID,SSN,scd_key) VALUES (?,?,?,?,?,?,?)";    

                        java.sql.PreparedStatement pstmt_tDBOutput_1 = conn_tDBOutput_1.prepareStatement(insert_tDBOutput_1);
                        resourceMap.put("pstmt_tDBOutput_1", pstmt_tDBOutput_1);
                StringBuffer query_tDBOutput_1 = null;
		 	String[] insertSQLSplits_tDBOutput_1 = insert_tDBOutput_1.split("\\?");





 



/**
 * [tDBOutput_1 begin ] stop
 */



	
	/**
	 * [tMap_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_2", false);
		start_Hash.put("tMap_2", System.currentTimeMillis());
		
	
	currentComponent="tMap_2";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row5");
			
		int tos_count_tMap_2 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tMap_2", "tMap");
				talendJobLogProcess(globalMap);
			}
			




// ###############################
// # Lookup's keys initialization
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_2__Struct  {
	int var1;
}
Var__tMap_2__Struct Var__tMap_2 = new Var__tMap_2__Struct();
// ###############################

// ###############################
// # Outputs initialization
outStruct out_tmp = new outStruct();
// ###############################

        
        



        









 



/**
 * [tMap_2 begin ] stop
 */



	
	/**
	 * [tExtractJSONFields_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tExtractJSONFields_1", false);
		start_Hash.put("tExtractJSONFields_1", System.currentTimeMillis());
		
	
	currentComponent="tExtractJSONFields_1";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row2");
			
		int tos_count_tExtractJSONFields_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tExtractJSONFields_1", "tExtractJSONFields");
				talendJobLogProcess(globalMap);
			}
			

int nb_line_tExtractJSONFields_1 = 0;
String jsonStr_tExtractJSONFields_1 = "";

	

class JsonPathCache_tExtractJSONFields_1 {
	final java.util.Map<String,com.jayway.jsonpath.JsonPath> jsonPathString2compiledJsonPath = new java.util.HashMap<String,com.jayway.jsonpath.JsonPath>();
	
	public com.jayway.jsonpath.JsonPath getCompiledJsonPath(String jsonPath) {
		if(jsonPathString2compiledJsonPath.containsKey(jsonPath)) {
			return jsonPathString2compiledJsonPath.get(jsonPath);
		} else {
			com.jayway.jsonpath.JsonPath compiledLoopPath = com.jayway.jsonpath.JsonPath.compile(jsonPath);
			jsonPathString2compiledJsonPath.put(jsonPath,compiledLoopPath);
			return compiledLoopPath;
		}
	}
}

JsonPathCache_tExtractJSONFields_1 jsonPathCache_tExtractJSONFields_1 = new JsonPathCache_tExtractJSONFields_1();

 



/**
 * [tExtractJSONFields_1 begin ] stop
 */



	
	/**
	 * [tREST_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tREST_1", false);
		start_Hash.put("tREST_1", System.currentTimeMillis());
		
	
	currentComponent="tREST_1";

	
		int tos_count_tREST_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tREST_1", "tREST");
				talendJobLogProcess(globalMap);
			}
			
	

	
	String endpoint_tREST_1 = "https://irx.dev1.awse1.anthem.com/static/unprotect/json";
	
	String trustStoreFile_tREST_1 = System.getProperty("javax.net.ssl.trustStore");
	String trustStoreType_tREST_1 = System.getProperty("javax.net.ssl.trustStoreType");
	String trustStorePWD_tREST_1 = System.getProperty("javax.net.ssl.trustStorePassword");
	
	String keyStoreFile_tREST_1 = System.getProperty("javax.net.ssl.keyStore");
	String keyStoreType_tREST_1 = System.getProperty("javax.net.ssl.keyStoreType");
	String keyStorePWD_tREST_1 = System.getProperty("javax.net.ssl.keyStorePassword");
	
	com.sun.jersey.api.client.config.ClientConfig config_tREST_1 = new com.sun.jersey.api.client.config.DefaultClientConfig();
	javax.net.ssl.SSLContext ctx_tREST_1 = javax.net.ssl.SSLContext.getInstance("SSL");
	
	javax.net.ssl.TrustManager[] tms_tREST_1 = null;
	if(trustStoreFile_tREST_1!=null && trustStoreType_tREST_1!=null){
		char[] password_tREST_1 = null;
		if(trustStorePWD_tREST_1!=null)
			password_tREST_1 = trustStorePWD_tREST_1.toCharArray();
		java.security.KeyStore trustStore_tREST_1 = java.security.KeyStore.getInstance(trustStoreType_tREST_1);
		trustStore_tREST_1.load(new java.io.FileInputStream(trustStoreFile_tREST_1), password_tREST_1);
		
		javax.net.ssl.TrustManagerFactory tmf_tREST_1 = javax.net.ssl.TrustManagerFactory.getInstance(javax.net.ssl.KeyManagerFactory.getDefaultAlgorithm());
        tmf_tREST_1.init(trustStore_tREST_1);
        tms_tREST_1 = tmf_tREST_1.getTrustManagers();
	}
	
	javax.net.ssl.KeyManager[] kms_tREST_1 = null;
	if(keyStoreFile_tREST_1!=null && keyStoreType_tREST_1!=null){
		char[] password_tREST_1 = null;
		if(keyStorePWD_tREST_1!=null)
			password_tREST_1 = keyStorePWD_tREST_1.toCharArray();
		java.security.KeyStore keyStore_tREST_1 = java.security.KeyStore.getInstance(keyStoreType_tREST_1);
		keyStore_tREST_1.load(new java.io.FileInputStream(keyStoreFile_tREST_1), password_tREST_1);
		
		javax.net.ssl.KeyManagerFactory kmf_tREST_1 = javax.net.ssl.KeyManagerFactory.getInstance(javax.net.ssl.KeyManagerFactory.getDefaultAlgorithm());
        kmf_tREST_1.init(keyStore_tREST_1,password_tREST_1);
        kms_tREST_1 = kmf_tREST_1.getKeyManagers();
	}
	
    ctx_tREST_1.init(kms_tREST_1, tms_tREST_1 , null);
    config_tREST_1.getProperties().put(com.sun.jersey.client.urlconnection.HTTPSProperties.PROPERTY_HTTPS_PROPERTIES,
                new com.sun.jersey.client.urlconnection.HTTPSProperties(new javax.net.ssl.HostnameVerifier() {

                    public boolean verify(String hostName, javax.net.ssl.SSLSession session) {
                        return true;
                    }
                }, ctx_tREST_1));

	com.sun.jersey.api.client.Client restClient_tREST_1 = com.sun.jersey.api.client.Client.create(config_tREST_1);
	
	java.util.Map<String, Object> headers_tREST_1 = new java.util.HashMap<String, Object>();
	
    	headers_tREST_1.put("Authorization","Basic U1JDX0lSWF9SRVNUX0lSWEVQOkZvQzIhSGVMJEIzRA==");
	
	
	Object transfer_encoding_tREST_1 = headers_tREST_1.get("Transfer-Encoding");
	if(transfer_encoding_tREST_1!=null && "chunked".equals(transfer_encoding_tREST_1)) {
		restClient_tREST_1.setChunkedEncodingSize(4096);
	}
	
	com.sun.jersey.api.client.WebResource restResource_tREST_1;
	if(endpoint_tREST_1!=null && !("").equals(endpoint_tREST_1)){
		restResource_tREST_1 = restClient_tREST_1.resource(endpoint_tREST_1);
	}else{
		throw new IllegalArgumentException("url can't be empty!");
	}
	
	com.sun.jersey.api.client.ClientResponse errorResponse_tREST_1 = null;
	String restResponse_tREST_1 = "";
	try{
		
		com.sun.jersey.api.client.WebResource.Builder builder_tREST_1 = null;
		for(java.util.Map.Entry<String, Object> header_tREST_1 : headers_tREST_1.entrySet()) {
			if(builder_tREST_1 == null) {
				builder_tREST_1 = restResource_tREST_1.header(header_tREST_1.getKey(), header_tREST_1.getValue());
			} else {
				builder_tREST_1.header(header_tREST_1.getKey(), header_tREST_1.getValue());
			}
		}
		
		
			if(builder_tREST_1!=null) {
				restResponse_tREST_1 = builder_tREST_1.post(String.class,row6.content);
			} else {
				restResponse_tREST_1 = restResource_tREST_1.post(String.class,row6.content);
			}
		
	}catch (com.sun.jersey.api.client.UniformInterfaceException ue) {
        errorResponse_tREST_1 = ue.getResponse();
    }
	
	// for output
			
				row2 = new row2Struct();
				if(errorResponse_tREST_1!=null){
					row2.ERROR_CODE = errorResponse_tREST_1.getStatus();
					if(row2.ERROR_CODE!=204){
					    row2.Body = errorResponse_tREST_1.getEntity(String.class);
					}
				}else{
					row2.Body = restResponse_tREST_1;
				}
			

 



/**
 * [tREST_1 begin ] stop
 */
	
	/**
	 * [tREST_1 main ] start
	 */

	

	
	
	currentComponent="tREST_1";

	

 


	tos_count_tREST_1++;

/**
 * [tREST_1 main ] stop
 */
	
	/**
	 * [tREST_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tREST_1";

	

 



/**
 * [tREST_1 process_data_begin ] stop
 */

	
	/**
	 * [tExtractJSONFields_1 main ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_1";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"row2");
			

            if(row2.Body!=null){// C_01
                jsonStr_tExtractJSONFields_1 = row2.Body.toString();
   
row5 = null;

	

String loopPath_tExtractJSONFields_1 = "$[*]";
java.util.List<Object> resultset_tExtractJSONFields_1 = new java.util.ArrayList<Object>();

boolean isStructError_tExtractJSONFields_1 = true;
com.jayway.jsonpath.ReadContext document_tExtractJSONFields_1 = null;
try {
	document_tExtractJSONFields_1 = com.jayway.jsonpath.JsonPath.parse(jsonStr_tExtractJSONFields_1);
	com.jayway.jsonpath.JsonPath compiledLoopPath_tExtractJSONFields_1 = jsonPathCache_tExtractJSONFields_1.getCompiledJsonPath(loopPath_tExtractJSONFields_1);
	Object result_tExtractJSONFields_1 = document_tExtractJSONFields_1.read(compiledLoopPath_tExtractJSONFields_1,net.minidev.json.JSONObject.class);
	if (result_tExtractJSONFields_1 instanceof net.minidev.json.JSONArray) {
		resultset_tExtractJSONFields_1 = (net.minidev.json.JSONArray) result_tExtractJSONFields_1;
	} else {
		resultset_tExtractJSONFields_1.add(result_tExtractJSONFields_1);
	}
	
	isStructError_tExtractJSONFields_1 = false;
} catch (java.lang.Exception ex_tExtractJSONFields_1) {
		System.err.println(ex_tExtractJSONFields_1.getMessage());
}

String jsonPath_tExtractJSONFields_1 = null;
com.jayway.jsonpath.JsonPath compiledJsonPath_tExtractJSONFields_1 = null;

Object value_tExtractJSONFields_1 = null;

Object root_tExtractJSONFields_1 = null;
for(int i_tExtractJSONFields_1=0; isStructError_tExtractJSONFields_1 || (i_tExtractJSONFields_1 < resultset_tExtractJSONFields_1.size());i_tExtractJSONFields_1++){
	if(!isStructError_tExtractJSONFields_1){
		Object row_tExtractJSONFields_1 = resultset_tExtractJSONFields_1.get(i_tExtractJSONFields_1);
            row5 = null;
	row5 = new row5Struct();
	nb_line_tExtractJSONFields_1++;
	try {
		jsonPath_tExtractJSONFields_1 = "firstName";
		compiledJsonPath_tExtractJSONFields_1 = jsonPathCache_tExtractJSONFields_1.getCompiledJsonPath(jsonPath_tExtractJSONFields_1);
		
		try {
		    
		        value_tExtractJSONFields_1 = compiledJsonPath_tExtractJSONFields_1.read(row_tExtractJSONFields_1);
		    
				row5.firstName = value_tExtractJSONFields_1 == null ? 

		null

 : value_tExtractJSONFields_1.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_1) {
			row5.firstName = 

		null

;
		}
		jsonPath_tExtractJSONFields_1 = "lastName";
		compiledJsonPath_tExtractJSONFields_1 = jsonPathCache_tExtractJSONFields_1.getCompiledJsonPath(jsonPath_tExtractJSONFields_1);
		
		try {
		    
		        value_tExtractJSONFields_1 = compiledJsonPath_tExtractJSONFields_1.read(row_tExtractJSONFields_1);
		    
				row5.lastName = value_tExtractJSONFields_1 == null ? 

		null

 : value_tExtractJSONFields_1.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_1) {
			row5.lastName = 

		null

;
		}
		jsonPath_tExtractJSONFields_1 = "MBI";
		compiledJsonPath_tExtractJSONFields_1 = jsonPathCache_tExtractJSONFields_1.getCompiledJsonPath(jsonPath_tExtractJSONFields_1);
		
		try {
		    
		        value_tExtractJSONFields_1 = compiledJsonPath_tExtractJSONFields_1.read(row_tExtractJSONFields_1);
		    
				row5.MBI = value_tExtractJSONFields_1 == null ? 

		null

 : value_tExtractJSONFields_1.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_1) {
			row5.MBI = 

		null

;
		}
		jsonPath_tExtractJSONFields_1 = "DOB";
		compiledJsonPath_tExtractJSONFields_1 = jsonPathCache_tExtractJSONFields_1.getCompiledJsonPath(jsonPath_tExtractJSONFields_1);
		
		try {
		    
		        value_tExtractJSONFields_1 = compiledJsonPath_tExtractJSONFields_1.read(row_tExtractJSONFields_1);
		    
				row5.DOB = value_tExtractJSONFields_1 == null ? 

		null

 : value_tExtractJSONFields_1.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_1) {
			row5.DOB = 

		null

;
		}
		jsonPath_tExtractJSONFields_1 = "OtherID";
		compiledJsonPath_tExtractJSONFields_1 = jsonPathCache_tExtractJSONFields_1.getCompiledJsonPath(jsonPath_tExtractJSONFields_1);
		
		try {
		    
		        value_tExtractJSONFields_1 = compiledJsonPath_tExtractJSONFields_1.read(row_tExtractJSONFields_1);
		    
				row5.OtherID = value_tExtractJSONFields_1 == null ? 

		null

 : value_tExtractJSONFields_1.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_1) {
			row5.OtherID = 

		null

;
		}
		jsonPath_tExtractJSONFields_1 = "SSN";
		compiledJsonPath_tExtractJSONFields_1 = jsonPathCache_tExtractJSONFields_1.getCompiledJsonPath(jsonPath_tExtractJSONFields_1);
		
		try {
		    
		        value_tExtractJSONFields_1 = compiledJsonPath_tExtractJSONFields_1.read(row_tExtractJSONFields_1);
		    
				row5.SSN = value_tExtractJSONFields_1 == null ? 

		null

 : value_tExtractJSONFields_1.toString();
		} catch (com.jayway.jsonpath.PathNotFoundException e_tExtractJSONFields_1) {
			row5.SSN = 

		null

;
		}	
	} catch (java.lang.Exception ex_tExtractJSONFields_1) {
		    System.err.println(ex_tExtractJSONFields_1.getMessage());
		    row5 = null;	
	}
	
	}
    
	isStructError_tExtractJSONFields_1 = false;
	
//}


 


	tos_count_tExtractJSONFields_1++;

/**
 * [tExtractJSONFields_1 main ] stop
 */
	
	/**
	 * [tExtractJSONFields_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_1";

	

 



/**
 * [tExtractJSONFields_1 process_data_begin ] stop
 */
// Start of branch "row5"
if(row5 != null) { 



	
	/**
	 * [tMap_2 main ] start
	 */

	

	
	
	currentComponent="tMap_2";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"row5");
			

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_2 = false;
		
        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_2 = false;
		  boolean mainRowRejected_tMap_2 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_2__Struct Var = Var__tMap_2;
Var.var1 = Numeric.sequence("s4",1,1) ;// ###############################
        // ###############################
        // # Output tables

out = null;


// # Output table : 'out'
out_tmp.firstName = row5.firstName ;
out_tmp.lastName = row5.lastName ;
out_tmp.MBI = row5.MBI ;
out_tmp.DOB = row5.DOB ;
out_tmp.OtherID = row5.OtherID ;
out_tmp.SSN = row5.SSN ;
out_tmp.scd_key = Var.var1 ;
out = out_tmp;
// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_2 = false;










 


	tos_count_tMap_2++;

/**
 * [tMap_2 main ] stop
 */
	
	/**
	 * [tMap_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_2";

	

 



/**
 * [tMap_2 process_data_begin ] stop
 */
// Start of branch "out"
if(out != null) { 



	
	/**
	 * [tDBOutput_1 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"out");
			



            row7 = null;
        query_tDBOutput_1 = new StringBuffer("");
        whetherReject_tDBOutput_1 = false;
                        if(out.firstName == null) {
pstmt_tDBOutput_1.setNull(1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(1, out.firstName);
}

                        query_tDBOutput_1 = query_tDBOutput_1.append(insertSQLSplits_tDBOutput_1[0]).append(out.firstName== null ?  "null" :"'" + out.firstName + "'").append(insertSQLSplits_tDBOutput_1[1]);
                        if(out.lastName == null) {
pstmt_tDBOutput_1.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(2, out.lastName);
}

                        query_tDBOutput_1 = query_tDBOutput_1.append(out.lastName== null ?  "null" :"'" + out.lastName + "'").append(insertSQLSplits_tDBOutput_1[2]);
                        if(out.MBI == null) {
pstmt_tDBOutput_1.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(3, out.MBI);
}

                        query_tDBOutput_1 = query_tDBOutput_1.append(out.MBI== null ?  "null" :"'" + out.MBI + "'").append(insertSQLSplits_tDBOutput_1[3]);
                        if(out.DOB == null) {
pstmt_tDBOutput_1.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(4, out.DOB);
}

                        query_tDBOutput_1 = query_tDBOutput_1.append(out.DOB== null ?  "null" :"'" + out.DOB + "'").append(insertSQLSplits_tDBOutput_1[4]);
                        if(out.OtherID == null) {
pstmt_tDBOutput_1.setNull(5, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(5, out.OtherID);
}

                        query_tDBOutput_1 = query_tDBOutput_1.append(out.OtherID== null ?  "null" :"'" + out.OtherID + "'").append(insertSQLSplits_tDBOutput_1[5]);
                        if(out.SSN == null) {
pstmt_tDBOutput_1.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(6, out.SSN);
}

                        query_tDBOutput_1 = query_tDBOutput_1.append(out.SSN== null ?  "null" :"'" + out.SSN + "'").append(insertSQLSplits_tDBOutput_1[6]);
                        pstmt_tDBOutput_1.setInt(7, out.scd_key);

                        query_tDBOutput_1 = query_tDBOutput_1.append(String.valueOf(out.scd_key)).append(insertSQLSplits_tDBOutput_1[7]);
                globalMap.put("tDBOutput_1_QUERY", query_tDBOutput_1.toString().trim());
                try {
                    nb_line_tDBOutput_1++;
                    insertedCount_tDBOutput_1 = insertedCount_tDBOutput_1 + pstmt_tDBOutput_1.executeUpdate();
                } catch(java.lang.Exception e_tDBOutput_1) {
                    whetherReject_tDBOutput_1 = true;
                            System.err.print(e_tDBOutput_1.getMessage());
                }
            if(!whetherReject_tDBOutput_1) {
                            row7 = new row7Struct();
                                row7.firstName = out.firstName;
                                row7.lastName = out.lastName;
                                row7.MBI = out.MBI;
                                row7.DOB = out.DOB;
                                row7.OtherID = out.OtherID;
                                row7.SSN = out.SSN;
                                row7.scd_key = out.scd_key;
            }

 


	tos_count_tDBOutput_1++;

/**
 * [tDBOutput_1 main ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	

 



/**
 * [tDBOutput_1 process_data_begin ] stop
 */
// Start of branch "row7"
if(row7 != null) { 



	
	/**
	 * [tLogRow_2 main ] start
	 */

	

	
	
	currentComponent="tLogRow_2";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"row7");
			
///////////////////////		
						

				
				String[] row_tLogRow_2 = new String[7];
   				
	    		if(row7.firstName != null) { //              
                 row_tLogRow_2[0]=    						    
				                String.valueOf(row7.firstName)			
					          ;	
							
	    		} //			
    			   				
	    		if(row7.lastName != null) { //              
                 row_tLogRow_2[1]=    						    
				                String.valueOf(row7.lastName)			
					          ;	
							
	    		} //			
    			   				
	    		if(row7.MBI != null) { //              
                 row_tLogRow_2[2]=    						    
				                String.valueOf(row7.MBI)			
					          ;	
							
	    		} //			
    			   				
	    		if(row7.DOB != null) { //              
                 row_tLogRow_2[3]=    						    
				                String.valueOf(row7.DOB)			
					          ;	
							
	    		} //			
    			   				
	    		if(row7.OtherID != null) { //              
                 row_tLogRow_2[4]=    						    
				                String.valueOf(row7.OtherID)			
					          ;	
							
	    		} //			
    			   				
	    		if(row7.SSN != null) { //              
                 row_tLogRow_2[5]=    						    
				                String.valueOf(row7.SSN)			
					          ;	
							
	    		} //			
    			              
                 row_tLogRow_2[6]=    						    
				                String.valueOf(row7.scd_key)			
					          ;	
										
    			 

				util_tLogRow_2.addRow(row_tLogRow_2);	
				nb_line_tLogRow_2++;
//////

//////                    
                    
///////////////////////    			

 


	tos_count_tLogRow_2++;

/**
 * [tLogRow_2 main ] stop
 */
	
	/**
	 * [tLogRow_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tLogRow_2";

	

 



/**
 * [tLogRow_2 process_data_begin ] stop
 */
	
	/**
	 * [tLogRow_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tLogRow_2";

	

 



/**
 * [tLogRow_2 process_data_end ] stop
 */

} // End of branch "row7"




	
	/**
	 * [tDBOutput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	

 



/**
 * [tDBOutput_1 process_data_end ] stop
 */

} // End of branch "out"




	
	/**
	 * [tMap_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_2";

	

 



/**
 * [tMap_2 process_data_end ] stop
 */

} // End of branch "row5"

		// end for
	}


	
		} // C_01
	
	
	/**
	 * [tExtractJSONFields_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_1";

	

 



/**
 * [tExtractJSONFields_1 process_data_end ] stop
 */



	
	/**
	 * [tREST_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tREST_1";

	

 



/**
 * [tREST_1 process_data_end ] stop
 */
	
	/**
	 * [tREST_1 end ] start
	 */

	

	
	
	currentComponent="tREST_1";

	

 

ok_Hash.put("tREST_1", true);
end_Hash.put("tREST_1", System.currentTimeMillis());




/**
 * [tREST_1 end ] stop
 */

	
	/**
	 * [tExtractJSONFields_1 end ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_1";

	
   globalMap.put("tExtractJSONFields_1_NB_LINE", nb_line_tExtractJSONFields_1);


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row2",2,0,
			 			talendJobLog,"tREST_1","tREST","tExtractJSONFields_1","tExtractJSONFields","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tExtractJSONFields_1", true);
end_Hash.put("tExtractJSONFields_1", System.currentTimeMillis());




/**
 * [tExtractJSONFields_1 end ] stop
 */

	
	/**
	 * [tMap_2 end ] start
	 */

	

	
	
	currentComponent="tMap_2";

	


// ###############################
// # Lookup hashes releasing
// ###############################      





			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row5",2,0,
			 			talendJobLog,"tExtractJSONFields_1","tExtractJSONFields","tMap_2","tMap","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tMap_2", true);
end_Hash.put("tMap_2", System.currentTimeMillis());




/**
 * [tMap_2 end ] stop
 */

	
	/**
	 * [tDBOutput_1 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	
	



	
        if(pstmt_tDBOutput_1 != null) {
			
				pstmt_tDBOutput_1.close();
				resourceMap.remove("pstmt_tDBOutput_1");
			
        }
    resourceMap.put("statementClosed_tDBOutput_1", true);


	
	nb_line_deleted_tDBOutput_1=nb_line_deleted_tDBOutput_1+ deletedCount_tDBOutput_1;
	nb_line_update_tDBOutput_1=nb_line_update_tDBOutput_1 + updatedCount_tDBOutput_1;
	nb_line_inserted_tDBOutput_1=nb_line_inserted_tDBOutput_1 + insertedCount_tDBOutput_1;
	nb_line_rejected_tDBOutput_1=nb_line_rejected_tDBOutput_1 + rejectedCount_tDBOutput_1;
	
        globalMap.put("tDBOutput_1_NB_LINE",nb_line_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_UPDATED",nb_line_update_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_DELETED",nb_line_deleted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_1);
    
	



			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"out",2,0,
			 			talendJobLog,"tMap_2","tMap","tDBOutput_1","tOracleOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tDBOutput_1", true);
end_Hash.put("tDBOutput_1", System.currentTimeMillis());




/**
 * [tDBOutput_1 end ] stop
 */

	
	/**
	 * [tLogRow_2 end ] start
	 */

	

	
	
	currentComponent="tLogRow_2";

	


//////

                    
                    java.io.PrintStream consoleOut_tLogRow_2 = null;
                    if (globalMap.get("tLogRow_CONSOLE")!=null)
                    {
                    	consoleOut_tLogRow_2 = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
                    }
                    else
                    {
                    	consoleOut_tLogRow_2 = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
                    	globalMap.put("tLogRow_CONSOLE",consoleOut_tLogRow_2);
                    }
                    
                    consoleOut_tLogRow_2.println(util_tLogRow_2.format().toString());
                    consoleOut_tLogRow_2.flush();
//////
globalMap.put("tLogRow_2_NB_LINE",nb_line_tLogRow_2);

///////////////////////    			

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row7",2,0,
			 			talendJobLog,"tDBOutput_1","tOracleOutput","tLogRow_2","tLogRow","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tLogRow_2", true);
end_Hash.put("tLogRow_2", System.currentTimeMillis());




/**
 * [tLogRow_2 end ] stop
 */












						if(execStat){
							runStat.updateStatOnConnection("iterate1", 2, "exec" + NB_ITERATE_tREST_1);
						}				
					




	
	/**
	 * [tFlowToIterate_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_1";

	

 



/**
 * [tFlowToIterate_1 process_data_end ] stop
 */



	
	/**
	 * [tFileInputRaw_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileInputRaw_1";

	

 



/**
 * [tFileInputRaw_1 process_data_end ] stop
 */
	
	/**
	 * [tFileInputRaw_1 end ] start
	 */

	

	
	
	currentComponent="tFileInputRaw_1";

	



 

ok_Hash.put("tFileInputRaw_1", true);
end_Hash.put("tFileInputRaw_1", System.currentTimeMillis());




/**
 * [tFileInputRaw_1 end ] stop
 */

	
	/**
	 * [tFlowToIterate_1 end ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_1";

	

globalMap.put("tFlowToIterate_1_NB_LINE",nb_line_tFlowToIterate_1);
			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row6",2,0,
			 			talendJobLog,"tFileInputRaw_1","tFileInputRaw","tFlowToIterate_1","tFlowToIterate","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tFlowToIterate_1", true);
end_Hash.put("tFlowToIterate_1", System.currentTimeMillis());




/**
 * [tFlowToIterate_1 end ] stop
 */



				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFileInputRaw_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk1", 0, "ok");
								} 
							
							tDBInput_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileInputRaw_1 finally ] start
	 */

	

	
	
	currentComponent="tFileInputRaw_1";

	

 



/**
 * [tFileInputRaw_1 finally ] stop
 */

	
	/**
	 * [tFlowToIterate_1 finally ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_1";

	

 



/**
 * [tFlowToIterate_1 finally ] stop
 */

	
	/**
	 * [tREST_1 finally ] start
	 */

	

	
	
	currentComponent="tREST_1";

	

 



/**
 * [tREST_1 finally ] stop
 */

	
	/**
	 * [tExtractJSONFields_1 finally ] start
	 */

	

	
	
	currentComponent="tExtractJSONFields_1";

	

 



/**
 * [tExtractJSONFields_1 finally ] stop
 */

	
	/**
	 * [tMap_2 finally ] start
	 */

	

	
	
	currentComponent="tMap_2";

	

 



/**
 * [tMap_2 finally ] stop
 */

	
	/**
	 * [tDBOutput_1 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	



    if (resourceMap.get("statementClosed_tDBOutput_1") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_1 = null;
                if ((pstmtToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_1")) != null) {
                    pstmtToClose_tDBOutput_1.close();
                }
    }
 



/**
 * [tDBOutput_1 finally ] stop
 */

	
	/**
	 * [tLogRow_2 finally ] start
	 */

	

	
	
	currentComponent="tLogRow_2";

	

 



/**
 * [tLogRow_2 finally ] stop
 */


















				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileInputRaw_1_SUBPROCESS_STATE", 1);
	}
	


public static class copyOfoutputStruct implements routines.system.IPersistableRow<copyOfoutputStruct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Tokenization = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecords_Tokenization = new byte[0];

	
			    public Character Gender;

				public Character getGender () {
					return this.Gender;
				}
				
			    public String Date_of_Birth;

				public String getDate_of_Birth () {
					return this.Date_of_Birth;
				}
				
			    public String First_Name;

				public String getFirst_Name () {
					return this.First_Name;
				}
				
			    public String Last_Name;

				public String getLast_Name () {
					return this.Last_Name;
				}
				
			    public String State;

				public String getState () {
					return this.State;
				}
				
			    public String City;

				public String getCity () {
					return this.City;
				}
				
			    public String Zip_Code;

				public String getZip_Code () {
					return this.Zip_Code;
				}
				
			    public String Address_Line_1;

				public String getAddress_Line_1 () {
					return this.Address_Line_1;
				}
				
			    public String Address_Line_2;

				public String getAddress_Line_2 () {
					return this.Address_Line_2;
				}
				
			    public String Phone_Number;

				public String getPhone_Number () {
					return this.Phone_Number;
				}
				
			    public String Social_Security_Number;

				public String getSocial_Security_Number () {
					return this.Social_Security_Number;
				}
				
			    public String UPI_ID;

				public String getUPI_ID () {
					return this.UPI_ID;
				}
				
			    public String MBI;

				public String getMBI () {
					return this.MBI;
				}
				
			    public String Client_ID;

				public String getClient_ID () {
					return this.Client_ID;
				}
				
			    public String Carrier_ID;

				public String getCarrier_ID () {
					return this.Carrier_ID;
				}
				
			    public String Account_ID;

				public String getAccount_ID () {
					return this.Account_ID;
				}
				
			    public String Group_ID;

				public String getGroup_ID () {
					return this.Group_ID;
				}
				
			    public String Contract_Family_ID;

				public String getContract_Family_ID () {
					return this.Contract_Family_ID;
				}
				
			    public String Multi_Birth_Code;

				public String getMulti_Birth_Code () {
					return this.Multi_Birth_Code;
				}
				
			    public String Member_Key;

				public String getMember_Key () {
					return this.Member_Key;
				}
				
			    public String Source;

				public String getSource () {
					return this.Source;
				}
				
			    public java.util.Date Lastupdated_date;

				public java.util.Date getLastupdated_date () {
					return this.Lastupdated_date;
				}
				
			    public String Lastupdateby;

				public String getLastupdateby () {
					return this.Lastupdateby;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecords_Tokenization.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecords_Tokenization.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecords_Tokenization = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecords_Tokenization = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecords_Tokenization, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecords_Tokenization, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Tokenization) {

        	try {

        		int length = 0;
		
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.Gender = null;
           				} else {
           			    	this.Gender = dis.readChar();
           				}
					
					this.Date_of_Birth = readString(dis);
					
					this.First_Name = readString(dis);
					
					this.Last_Name = readString(dis);
					
					this.State = readString(dis);
					
					this.City = readString(dis);
					
					this.Zip_Code = readString(dis);
					
					this.Address_Line_1 = readString(dis);
					
					this.Address_Line_2 = readString(dis);
					
					this.Phone_Number = readString(dis);
					
					this.Social_Security_Number = readString(dis);
					
					this.UPI_ID = readString(dis);
					
					this.MBI = readString(dis);
					
					this.Client_ID = readString(dis);
					
					this.Carrier_ID = readString(dis);
					
					this.Account_ID = readString(dis);
					
					this.Group_ID = readString(dis);
					
					this.Contract_Family_ID = readString(dis);
					
					this.Multi_Birth_Code = readString(dis);
					
					this.Member_Key = readString(dis);
					
					this.Source = readString(dis);
					
					this.Lastupdated_date = readDate(dis);
					
					this.Lastupdateby = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Character
				
						if(this.Gender == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeChar(this.Gender);
		            	}
					
					// String
				
						writeString(this.Date_of_Birth,dos);
					
					// String
				
						writeString(this.First_Name,dos);
					
					// String
				
						writeString(this.Last_Name,dos);
					
					// String
				
						writeString(this.State,dos);
					
					// String
				
						writeString(this.City,dos);
					
					// String
				
						writeString(this.Zip_Code,dos);
					
					// String
				
						writeString(this.Address_Line_1,dos);
					
					// String
				
						writeString(this.Address_Line_2,dos);
					
					// String
				
						writeString(this.Phone_Number,dos);
					
					// String
				
						writeString(this.Social_Security_Number,dos);
					
					// String
				
						writeString(this.UPI_ID,dos);
					
					// String
				
						writeString(this.MBI,dos);
					
					// String
				
						writeString(this.Client_ID,dos);
					
					// String
				
						writeString(this.Carrier_ID,dos);
					
					// String
				
						writeString(this.Account_ID,dos);
					
					// String
				
						writeString(this.Group_ID,dos);
					
					// String
				
						writeString(this.Contract_Family_ID,dos);
					
					// String
				
						writeString(this.Multi_Birth_Code,dos);
					
					// String
				
						writeString(this.Member_Key,dos);
					
					// String
				
						writeString(this.Source,dos);
					
					// java.util.Date
				
						writeDate(this.Lastupdated_date,dos);
					
					// String
				
						writeString(this.Lastupdateby,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Gender="+String.valueOf(Gender));
		sb.append(",Date_of_Birth="+Date_of_Birth);
		sb.append(",First_Name="+First_Name);
		sb.append(",Last_Name="+Last_Name);
		sb.append(",State="+State);
		sb.append(",City="+City);
		sb.append(",Zip_Code="+Zip_Code);
		sb.append(",Address_Line_1="+Address_Line_1);
		sb.append(",Address_Line_2="+Address_Line_2);
		sb.append(",Phone_Number="+Phone_Number);
		sb.append(",Social_Security_Number="+Social_Security_Number);
		sb.append(",UPI_ID="+UPI_ID);
		sb.append(",MBI="+MBI);
		sb.append(",Client_ID="+Client_ID);
		sb.append(",Carrier_ID="+Carrier_ID);
		sb.append(",Account_ID="+Account_ID);
		sb.append(",Group_ID="+Group_ID);
		sb.append(",Contract_Family_ID="+Contract_Family_ID);
		sb.append(",Multi_Birth_Code="+Multi_Birth_Code);
		sb.append(",Member_Key="+Member_Key);
		sb.append(",Source="+Source);
		sb.append(",Lastupdated_date="+String.valueOf(Lastupdated_date));
		sb.append(",Lastupdateby="+Lastupdateby);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(copyOfoutputStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class file_outStruct implements routines.system.IPersistableRow<file_outStruct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Tokenization = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecords_Tokenization = new byte[0];

	
			    public Character Gender;

				public Character getGender () {
					return this.Gender;
				}
				
			    public String Date_of_Birth;

				public String getDate_of_Birth () {
					return this.Date_of_Birth;
				}
				
			    public String First_Name;

				public String getFirst_Name () {
					return this.First_Name;
				}
				
			    public String Last_Name;

				public String getLast_Name () {
					return this.Last_Name;
				}
				
			    public String State;

				public String getState () {
					return this.State;
				}
				
			    public String City;

				public String getCity () {
					return this.City;
				}
				
			    public String Zip_Code;

				public String getZip_Code () {
					return this.Zip_Code;
				}
				
			    public String Address_Line_1;

				public String getAddress_Line_1 () {
					return this.Address_Line_1;
				}
				
			    public String Address_Line_2;

				public String getAddress_Line_2 () {
					return this.Address_Line_2;
				}
				
			    public String Phone_Number;

				public String getPhone_Number () {
					return this.Phone_Number;
				}
				
			    public String Social_Security_Number;

				public String getSocial_Security_Number () {
					return this.Social_Security_Number;
				}
				
			    public String UPI_ID;

				public String getUPI_ID () {
					return this.UPI_ID;
				}
				
			    public String MBI;

				public String getMBI () {
					return this.MBI;
				}
				
			    public String Client_ID;

				public String getClient_ID () {
					return this.Client_ID;
				}
				
			    public String Carrier_ID;

				public String getCarrier_ID () {
					return this.Carrier_ID;
				}
				
			    public String Account_ID;

				public String getAccount_ID () {
					return this.Account_ID;
				}
				
			    public String Group_ID;

				public String getGroup_ID () {
					return this.Group_ID;
				}
				
			    public String Contract_Family_ID;

				public String getContract_Family_ID () {
					return this.Contract_Family_ID;
				}
				
			    public String Multi_Birth_Code;

				public String getMulti_Birth_Code () {
					return this.Multi_Birth_Code;
				}
				
			    public String Member_Key;

				public String getMember_Key () {
					return this.Member_Key;
				}
				
			    public String Source;

				public String getSource () {
					return this.Source;
				}
				
			    public java.util.Date Lastupdated_date;

				public java.util.Date getLastupdated_date () {
					return this.Lastupdated_date;
				}
				
			    public String Lastupdateby;

				public String getLastupdateby () {
					return this.Lastupdateby;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecords_Tokenization.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecords_Tokenization.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecords_Tokenization = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecords_Tokenization = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecords_Tokenization, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecords_Tokenization, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Tokenization) {

        	try {

        		int length = 0;
		
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.Gender = null;
           				} else {
           			    	this.Gender = dis.readChar();
           				}
					
					this.Date_of_Birth = readString(dis);
					
					this.First_Name = readString(dis);
					
					this.Last_Name = readString(dis);
					
					this.State = readString(dis);
					
					this.City = readString(dis);
					
					this.Zip_Code = readString(dis);
					
					this.Address_Line_1 = readString(dis);
					
					this.Address_Line_2 = readString(dis);
					
					this.Phone_Number = readString(dis);
					
					this.Social_Security_Number = readString(dis);
					
					this.UPI_ID = readString(dis);
					
					this.MBI = readString(dis);
					
					this.Client_ID = readString(dis);
					
					this.Carrier_ID = readString(dis);
					
					this.Account_ID = readString(dis);
					
					this.Group_ID = readString(dis);
					
					this.Contract_Family_ID = readString(dis);
					
					this.Multi_Birth_Code = readString(dis);
					
					this.Member_Key = readString(dis);
					
					this.Source = readString(dis);
					
					this.Lastupdated_date = readDate(dis);
					
					this.Lastupdateby = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Character
				
						if(this.Gender == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeChar(this.Gender);
		            	}
					
					// String
				
						writeString(this.Date_of_Birth,dos);
					
					// String
				
						writeString(this.First_Name,dos);
					
					// String
				
						writeString(this.Last_Name,dos);
					
					// String
				
						writeString(this.State,dos);
					
					// String
				
						writeString(this.City,dos);
					
					// String
				
						writeString(this.Zip_Code,dos);
					
					// String
				
						writeString(this.Address_Line_1,dos);
					
					// String
				
						writeString(this.Address_Line_2,dos);
					
					// String
				
						writeString(this.Phone_Number,dos);
					
					// String
				
						writeString(this.Social_Security_Number,dos);
					
					// String
				
						writeString(this.UPI_ID,dos);
					
					// String
				
						writeString(this.MBI,dos);
					
					// String
				
						writeString(this.Client_ID,dos);
					
					// String
				
						writeString(this.Carrier_ID,dos);
					
					// String
				
						writeString(this.Account_ID,dos);
					
					// String
				
						writeString(this.Group_ID,dos);
					
					// String
				
						writeString(this.Contract_Family_ID,dos);
					
					// String
				
						writeString(this.Multi_Birth_Code,dos);
					
					// String
				
						writeString(this.Member_Key,dos);
					
					// String
				
						writeString(this.Source,dos);
					
					// java.util.Date
				
						writeDate(this.Lastupdated_date,dos);
					
					// String
				
						writeString(this.Lastupdateby,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Gender="+String.valueOf(Gender));
		sb.append(",Date_of_Birth="+Date_of_Birth);
		sb.append(",First_Name="+First_Name);
		sb.append(",Last_Name="+Last_Name);
		sb.append(",State="+State);
		sb.append(",City="+City);
		sb.append(",Zip_Code="+Zip_Code);
		sb.append(",Address_Line_1="+Address_Line_1);
		sb.append(",Address_Line_2="+Address_Line_2);
		sb.append(",Phone_Number="+Phone_Number);
		sb.append(",Social_Security_Number="+Social_Security_Number);
		sb.append(",UPI_ID="+UPI_ID);
		sb.append(",MBI="+MBI);
		sb.append(",Client_ID="+Client_ID);
		sb.append(",Carrier_ID="+Carrier_ID);
		sb.append(",Account_ID="+Account_ID);
		sb.append(",Group_ID="+Group_ID);
		sb.append(",Contract_Family_ID="+Contract_Family_ID);
		sb.append(",Multi_Birth_Code="+Multi_Birth_Code);
		sb.append(",Member_Key="+Member_Key);
		sb.append(",Source="+Source);
		sb.append(",Lastupdated_date="+String.valueOf(Lastupdated_date));
		sb.append(",Lastupdateby="+Lastupdateby);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(file_outStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row3Struct implements routines.system.IPersistableRow<row3Struct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Tokenization = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecords_Tokenization = new byte[0];

	
			    public Character Gender;

				public Character getGender () {
					return this.Gender;
				}
				
			    public String State;

				public String getState () {
					return this.State;
				}
				
			    public String City;

				public String getCity () {
					return this.City;
				}
				
			    public String Zip_Code;

				public String getZip_Code () {
					return this.Zip_Code;
				}
				
			    public String Address_Line_1;

				public String getAddress_Line_1 () {
					return this.Address_Line_1;
				}
				
			    public String Address_Line_2;

				public String getAddress_Line_2 () {
					return this.Address_Line_2;
				}
				
			    public String Phone_Number;

				public String getPhone_Number () {
					return this.Phone_Number;
				}
				
			    public String UPI_ID;

				public String getUPI_ID () {
					return this.UPI_ID;
				}
				
			    public String Client_ID;

				public String getClient_ID () {
					return this.Client_ID;
				}
				
			    public String Carrier_ID;

				public String getCarrier_ID () {
					return this.Carrier_ID;
				}
				
			    public String Account_ID;

				public String getAccount_ID () {
					return this.Account_ID;
				}
				
			    public String Group_ID;

				public String getGroup_ID () {
					return this.Group_ID;
				}
				
			    public String Multi_Birth_Code;

				public String getMulti_Birth_Code () {
					return this.Multi_Birth_Code;
				}
				
			    public String Member_Key;

				public String getMember_Key () {
					return this.Member_Key;
				}
				
			    public String Source;

				public String getSource () {
					return this.Source;
				}
				
			    public int scd_key;

				public int getScd_key () {
					return this.scd_key;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecords_Tokenization.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecords_Tokenization.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecords_Tokenization = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecords_Tokenization = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecords_Tokenization, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecords_Tokenization, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Tokenization) {

        	try {

        		int length = 0;
		
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.Gender = null;
           				} else {
           			    	this.Gender = dis.readChar();
           				}
					
					this.State = readString(dis);
					
					this.City = readString(dis);
					
					this.Zip_Code = readString(dis);
					
					this.Address_Line_1 = readString(dis);
					
					this.Address_Line_2 = readString(dis);
					
					this.Phone_Number = readString(dis);
					
					this.UPI_ID = readString(dis);
					
					this.Client_ID = readString(dis);
					
					this.Carrier_ID = readString(dis);
					
					this.Account_ID = readString(dis);
					
					this.Group_ID = readString(dis);
					
					this.Multi_Birth_Code = readString(dis);
					
					this.Member_Key = readString(dis);
					
					this.Source = readString(dis);
					
			        this.scd_key = dis.readInt();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Character
				
						if(this.Gender == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeChar(this.Gender);
		            	}
					
					// String
				
						writeString(this.State,dos);
					
					// String
				
						writeString(this.City,dos);
					
					// String
				
						writeString(this.Zip_Code,dos);
					
					// String
				
						writeString(this.Address_Line_1,dos);
					
					// String
				
						writeString(this.Address_Line_2,dos);
					
					// String
				
						writeString(this.Phone_Number,dos);
					
					// String
				
						writeString(this.UPI_ID,dos);
					
					// String
				
						writeString(this.Client_ID,dos);
					
					// String
				
						writeString(this.Carrier_ID,dos);
					
					// String
				
						writeString(this.Account_ID,dos);
					
					// String
				
						writeString(this.Group_ID,dos);
					
					// String
				
						writeString(this.Multi_Birth_Code,dos);
					
					// String
				
						writeString(this.Member_Key,dos);
					
					// String
				
						writeString(this.Source,dos);
					
					// int
				
		            	dos.writeInt(this.scd_key);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Gender="+String.valueOf(Gender));
		sb.append(",State="+State);
		sb.append(",City="+City);
		sb.append(",Zip_Code="+Zip_Code);
		sb.append(",Address_Line_1="+Address_Line_1);
		sb.append(",Address_Line_2="+Address_Line_2);
		sb.append(",Phone_Number="+Phone_Number);
		sb.append(",UPI_ID="+UPI_ID);
		sb.append(",Client_ID="+Client_ID);
		sb.append(",Carrier_ID="+Carrier_ID);
		sb.append(",Account_ID="+Account_ID);
		sb.append(",Group_ID="+Group_ID);
		sb.append(",Multi_Birth_Code="+Multi_Birth_Code);
		sb.append(",Member_Key="+Member_Key);
		sb.append(",Source="+Source);
		sb.append(",scd_key="+String.valueOf(scd_key));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row3Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class after_tDBInput_1Struct implements routines.system.IPersistableRow<after_tDBInput_1Struct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Tokenization = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecords_Tokenization = new byte[0];

	
			    public Character Gender;

				public Character getGender () {
					return this.Gender;
				}
				
			    public String State;

				public String getState () {
					return this.State;
				}
				
			    public String City;

				public String getCity () {
					return this.City;
				}
				
			    public String Zip_Code;

				public String getZip_Code () {
					return this.Zip_Code;
				}
				
			    public String Address_Line_1;

				public String getAddress_Line_1 () {
					return this.Address_Line_1;
				}
				
			    public String Address_Line_2;

				public String getAddress_Line_2 () {
					return this.Address_Line_2;
				}
				
			    public String Phone_Number;

				public String getPhone_Number () {
					return this.Phone_Number;
				}
				
			    public String UPI_ID;

				public String getUPI_ID () {
					return this.UPI_ID;
				}
				
			    public String Client_ID;

				public String getClient_ID () {
					return this.Client_ID;
				}
				
			    public String Carrier_ID;

				public String getCarrier_ID () {
					return this.Carrier_ID;
				}
				
			    public String Account_ID;

				public String getAccount_ID () {
					return this.Account_ID;
				}
				
			    public String Group_ID;

				public String getGroup_ID () {
					return this.Group_ID;
				}
				
			    public String Multi_Birth_Code;

				public String getMulti_Birth_Code () {
					return this.Multi_Birth_Code;
				}
				
			    public String Member_Key;

				public String getMember_Key () {
					return this.Member_Key;
				}
				
			    public String Source;

				public String getSource () {
					return this.Source;
				}
				
			    public int scd_key;

				public int getScd_key () {
					return this.scd_key;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_UPI_PROCESS_IngestRecords_Tokenization.length) {
				if(length < 1024 && commonByteArray_UPI_PROCESS_IngestRecords_Tokenization.length == 0) {
   					commonByteArray_UPI_PROCESS_IngestRecords_Tokenization = new byte[1024];
				} else {
   					commonByteArray_UPI_PROCESS_IngestRecords_Tokenization = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_UPI_PROCESS_IngestRecords_Tokenization, 0, length);
			strReturn = new String(commonByteArray_UPI_PROCESS_IngestRecords_Tokenization, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Tokenization) {

        	try {

        		int length = 0;
		
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.Gender = null;
           				} else {
           			    	this.Gender = dis.readChar();
           				}
					
					this.State = readString(dis);
					
					this.City = readString(dis);
					
					this.Zip_Code = readString(dis);
					
					this.Address_Line_1 = readString(dis);
					
					this.Address_Line_2 = readString(dis);
					
					this.Phone_Number = readString(dis);
					
					this.UPI_ID = readString(dis);
					
					this.Client_ID = readString(dis);
					
					this.Carrier_ID = readString(dis);
					
					this.Account_ID = readString(dis);
					
					this.Group_ID = readString(dis);
					
					this.Multi_Birth_Code = readString(dis);
					
					this.Member_Key = readString(dis);
					
					this.Source = readString(dis);
					
			        this.scd_key = dis.readInt();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Character
				
						if(this.Gender == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeChar(this.Gender);
		            	}
					
					// String
				
						writeString(this.State,dos);
					
					// String
				
						writeString(this.City,dos);
					
					// String
				
						writeString(this.Zip_Code,dos);
					
					// String
				
						writeString(this.Address_Line_1,dos);
					
					// String
				
						writeString(this.Address_Line_2,dos);
					
					// String
				
						writeString(this.Phone_Number,dos);
					
					// String
				
						writeString(this.UPI_ID,dos);
					
					// String
				
						writeString(this.Client_ID,dos);
					
					// String
				
						writeString(this.Carrier_ID,dos);
					
					// String
				
						writeString(this.Account_ID,dos);
					
					// String
				
						writeString(this.Group_ID,dos);
					
					// String
				
						writeString(this.Multi_Birth_Code,dos);
					
					// String
				
						writeString(this.Member_Key,dos);
					
					// String
				
						writeString(this.Source,dos);
					
					// int
				
		            	dos.writeInt(this.scd_key);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Gender="+String.valueOf(Gender));
		sb.append(",State="+State);
		sb.append(",City="+City);
		sb.append(",Zip_Code="+Zip_Code);
		sb.append(",Address_Line_1="+Address_Line_1);
		sb.append(",Address_Line_2="+Address_Line_2);
		sb.append(",Phone_Number="+Phone_Number);
		sb.append(",UPI_ID="+UPI_ID);
		sb.append(",Client_ID="+Client_ID);
		sb.append(",Carrier_ID="+Carrier_ID);
		sb.append(",Account_ID="+Account_ID);
		sb.append(",Group_ID="+Group_ID);
		sb.append(",Multi_Birth_Code="+Multi_Birth_Code);
		sb.append(",Member_Key="+Member_Key);
		sb.append(",Source="+Source);
		sb.append(",scd_key="+String.valueOf(scd_key));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(after_tDBInput_1Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tDBInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;


		tDBInput_2Process(globalMap);

		row3Struct row3 = new row3Struct();
copyOfoutputStruct copyOfoutput = new copyOfoutputStruct();
file_outStruct file_out = new file_outStruct();





	
	/**
	 * [tDBOutput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_2", false);
		start_Hash.put("tDBOutput_2", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_2";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"copyOfoutput");
			
		int tos_count_tDBOutput_2 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_2", "tOracleOutput");
				talendJobLogProcess(globalMap);
			}
			






    int nb_line_tDBOutput_2 = 0;
    int nb_line_update_tDBOutput_2 = 0;
    int nb_line_inserted_tDBOutput_2 = 0;
    int nb_line_deleted_tDBOutput_2 = 0;
    int nb_line_rejected_tDBOutput_2 = 0;

    int tmp_batchUpdateCount_tDBOutput_2 = 0;

    int deletedCount_tDBOutput_2=0;
    int updatedCount_tDBOutput_2=0;
    int insertedCount_tDBOutput_2=0;
    int rejectedCount_tDBOutput_2=0;

    boolean whetherReject_tDBOutput_2 = false;

    java.sql.Connection conn_tDBOutput_2 = null;

    //optional table
    String dbschema_tDBOutput_2 = null;
    String tableName_tDBOutput_2 = null;
        dbschema_tDBOutput_2 = (String)globalMap.get("dbschema_tDBConnection_1");
		
        conn_tDBOutput_2 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
        int count_tDBOutput_2=0;

        if(dbschema_tDBOutput_2 == null || dbschema_tDBOutput_2.trim().length() == 0) {
            tableName_tDBOutput_2 = ("MDM_Master");
        } else {
            tableName_tDBOutput_2 = dbschema_tDBOutput_2 + "." + ("MDM_Master");
        }
                                String tableNameForSearch_tDBOutput_2= "" + ((String)"MDM_Master") + "";
String dbschemaForSearch_tDBOutput_2= null;
if(dbschema_tDBOutput_2== null || dbschema_tDBOutput_2.trim().length() == 0) {
dbschemaForSearch_tDBOutput_2= ((String)globalMap.get("username_tDBConnection_1")).toUpperCase();
} else {
dbschemaForSearch_tDBOutput_2= dbschema_tDBOutput_2.toUpperCase();
}

                                java.sql.DatabaseMetaData dbMetaData_tDBOutput_2 = conn_tDBOutput_2.getMetaData();
                                if(tableNameForSearch_tDBOutput_2.indexOf("\"")==-1){
                                    tableNameForSearch_tDBOutput_2 = tableNameForSearch_tDBOutput_2.toUpperCase();
                                }else{
                                    tableNameForSearch_tDBOutput_2 = tableNameForSearch_tDBOutput_2.replaceAll("\"","");
                                }
                                boolean whetherExist_tDBOutput_2 = false;
                                try (java.sql.ResultSet rsTable_tDBOutput_2 = dbMetaData_tDBOutput_2.getTables(null, dbschemaForSearch_tDBOutput_2, tableNameForSearch_tDBOutput_2, new String[]{"TABLE"})) {
                                    if(rsTable_tDBOutput_2.next()) {
                                        whetherExist_tDBOutput_2 = true;
                                    }
                                }

                                if(whetherExist_tDBOutput_2) {
                                    try (java.sql.Statement stmtDrop_tDBOutput_2 = conn_tDBOutput_2.createStatement()) {
                                        stmtDrop_tDBOutput_2.execute("DROP TABLE " + tableName_tDBOutput_2 + "" );
                                    }
                                }
                                try(java.sql.Statement stmtCreate_tDBOutput_2 = conn_tDBOutput_2.createStatement()) {
                                    stmtCreate_tDBOutput_2.execute("CREATE TABLE " + tableName_tDBOutput_2 + "(Gender CHAR(1)  ,Date_of_Birth VARCHAR2(14)  ,First_Name VARCHAR2(50)  ,Last_Name VARCHAR2(50)  ,State VARCHAR2(2)  ,City VARCHAR2(50)  ,Zip_Code VARCHAR2(15)  ,Address_Line_1 VARCHAR2(50)  ,Address_Line_2 VARCHAR2(50)  ,Phone_Number VARCHAR2(15)  ,Social_Security_Number VARCHAR2(15)  ,UPI_ID VARCHAR2(40)  ,MBI VARCHAR2(32)  ,Client_ID VARCHAR2(32)  ,Carrier_ID VARCHAR2(32)  ,Account_ID VARCHAR2(32)  ,Group_ID VARCHAR2(32)  ,Contract_Family_ID VARCHAR2(50)  ,Multi_Birth_Code VARCHAR2(10)  ,Member_Key VARCHAR2(38)  ,Source VARCHAR2(15)  ,Lastupdated_date DATE ,Lastupdateby VARCHAR2(14)  )");
                                }
                String insert_tDBOutput_2 = "INSERT INTO " + tableName_tDBOutput_2 + " (Gender,Date_of_Birth,First_Name,Last_Name,State,City,Zip_Code,Address_Line_1,Address_Line_2,Phone_Number,Social_Security_Number,UPI_ID,MBI,Client_ID,Carrier_ID,Account_ID,Group_ID,Contract_Family_ID,Multi_Birth_Code,Member_Key,Source,Lastupdated_date,Lastupdateby) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";    

                        java.sql.PreparedStatement pstmt_tDBOutput_2 = conn_tDBOutput_2.prepareStatement(insert_tDBOutput_2);
                        resourceMap.put("pstmt_tDBOutput_2", pstmt_tDBOutput_2);
                StringBuffer query_tDBOutput_2 = null;
		 	String[] insertSQLSplits_tDBOutput_2 = insert_tDBOutput_2.split("\\?");





 



/**
 * [tDBOutput_2 begin ] stop
 */




	
	/**
	 * [tFileOutputDelimited_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileOutputDelimited_1", false);
		start_Hash.put("tFileOutputDelimited_1", System.currentTimeMillis());
		
	
	currentComponent="tFileOutputDelimited_1";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"file_out");
			
		int tos_count_tFileOutputDelimited_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tFileOutputDelimited_1", "tFileOutputDelimited");
				talendJobLogProcess(globalMap);
			}
			

String fileName_tFileOutputDelimited_1 = "";
    fileName_tFileOutputDelimited_1 = (new java.io.File(context.output+"Mdm_master.csv")).getAbsolutePath().replace("\\","/");
    String fullName_tFileOutputDelimited_1 = null;
    String extension_tFileOutputDelimited_1 = null;
    String directory_tFileOutputDelimited_1 = null;
    if((fileName_tFileOutputDelimited_1.indexOf("/") != -1)) {
        if(fileName_tFileOutputDelimited_1.lastIndexOf(".") < fileName_tFileOutputDelimited_1.lastIndexOf("/")) {
            fullName_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1;
            extension_tFileOutputDelimited_1 = "";
        } else {
            fullName_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1.substring(0, fileName_tFileOutputDelimited_1.lastIndexOf("."));
            extension_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1.substring(fileName_tFileOutputDelimited_1.lastIndexOf("."));
        }
        directory_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1.substring(0, fileName_tFileOutputDelimited_1.lastIndexOf("/"));
    } else {
        if(fileName_tFileOutputDelimited_1.lastIndexOf(".") != -1) {
            fullName_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1.substring(0, fileName_tFileOutputDelimited_1.lastIndexOf("."));
            extension_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1.substring(fileName_tFileOutputDelimited_1.lastIndexOf("."));
        } else {
            fullName_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1;
            extension_tFileOutputDelimited_1 = "";
        }
        directory_tFileOutputDelimited_1 = "";
    }
    boolean isFileGenerated_tFileOutputDelimited_1 = true;
    java.io.File filetFileOutputDelimited_1 = new java.io.File(fileName_tFileOutputDelimited_1);
    globalMap.put("tFileOutputDelimited_1_FILE_NAME",fileName_tFileOutputDelimited_1);
            int nb_line_tFileOutputDelimited_1 = 0;
            int splitedFileNo_tFileOutputDelimited_1 = 0;
            int currentRow_tFileOutputDelimited_1 = 0;

            final String OUT_DELIM_tFileOutputDelimited_1 = /** Start field tFileOutputDelimited_1:FIELDSEPARATOR */"|"/** End field tFileOutputDelimited_1:FIELDSEPARATOR */;

            final String OUT_DELIM_ROWSEP_tFileOutputDelimited_1 = /** Start field tFileOutputDelimited_1:ROWSEPARATOR */"\n"/** End field tFileOutputDelimited_1:ROWSEPARATOR */;

                    //create directory only if not exists
                    if(directory_tFileOutputDelimited_1 != null && directory_tFileOutputDelimited_1.trim().length() != 0) {
                        java.io.File dir_tFileOutputDelimited_1 = new java.io.File(directory_tFileOutputDelimited_1);
                        if(!dir_tFileOutputDelimited_1.exists()) {
                            dir_tFileOutputDelimited_1.mkdirs();
                        }
                    }

                        //routines.system.Row
                        java.io.Writer outtFileOutputDelimited_1 = null;

                        java.io.File fileToDelete_tFileOutputDelimited_1 = new java.io.File(fileName_tFileOutputDelimited_1);
                        if(fileToDelete_tFileOutputDelimited_1.exists()) {
                            fileToDelete_tFileOutputDelimited_1.delete();
                        }
                        outtFileOutputDelimited_1 = new java.io.BufferedWriter(new java.io.OutputStreamWriter(
                        new java.io.FileOutputStream(fileName_tFileOutputDelimited_1, false),"ISO-8859-15"));
                                    if(filetFileOutputDelimited_1.length()==0){
                                        outtFileOutputDelimited_1.write("Gender");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("Date_of_Birth");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("First_Name");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("Last_Name");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("State");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("City");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("Zip_Code");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("Address_Line_1");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("Address_Line_2");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("Phone_Number");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("Social_Security_Number");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("UPI_ID");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("MBI");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("Client_ID");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("Carrier_ID");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("Account_ID");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("Group_ID");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("Contract_Family_ID");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("Multi_Birth_Code");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("Member_Key");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("Source");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("Lastupdated_date");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("Lastupdateby");
                                        outtFileOutputDelimited_1.write(OUT_DELIM_ROWSEP_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.flush();
                                    }


        resourceMap.put("out_tFileOutputDelimited_1", outtFileOutputDelimited_1);
resourceMap.put("nb_line_tFileOutputDelimited_1", nb_line_tFileOutputDelimited_1);

 



/**
 * [tFileOutputDelimited_1 begin ] stop
 */



	
	/**
	 * [tMap_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_3", false);
		start_Hash.put("tMap_3", System.currentTimeMillis());
		
	
	currentComponent="tMap_3";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row3");
			
		int tos_count_tMap_3 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tMap_3", "tMap");
				talendJobLogProcess(globalMap);
			}
			




// ###############################
// # Lookup's keys initialization
	
		org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row4Struct> tHash_Lookup_row4 = (org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row4Struct>) 
				((org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row4Struct>) 
					globalMap.get( "tHash_Lookup_row4" ))
					;					
					
	

row4Struct row4HashKey = new row4Struct();
row4Struct row4Default = new row4Struct();
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_3__Struct  {
}
Var__tMap_3__Struct Var__tMap_3 = new Var__tMap_3__Struct();
// ###############################

// ###############################
// # Outputs initialization
copyOfoutputStruct copyOfoutput_tmp = new copyOfoutputStruct();
file_outStruct file_out_tmp = new file_outStruct();
// ###############################

        
        



        









 



/**
 * [tMap_3 begin ] stop
 */



	
	/**
	 * [tDBInput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_1", false);
		start_Hash.put("tDBInput_1", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_1";

	
		int tos_count_tDBInput_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_1", "tOracleInput");
				talendJobLogProcess(globalMap);
			}
			
	


	
		    int nb_line_tDBInput_1 = 0;
		    java.sql.Connection conn_tDBInput_1 = null;
				conn_tDBInput_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
                boolean isTimeZoneNull_tDBInput_1 = false;
				boolean isConnectionWrapped_tDBInput_1 = !(conn_tDBInput_1 instanceof oracle.jdbc.OracleConnection) && conn_tDBInput_1.isWrapperFor(oracle.jdbc.OracleConnection.class);
				oracle.jdbc.OracleConnection unwrappedOraConn_tDBInput_1 = null;
                if (isConnectionWrapped_tDBInput_1) {
					unwrappedOraConn_tDBInput_1 = conn_tDBInput_1.unwrap(oracle.jdbc.OracleConnection.class);
                    if (unwrappedOraConn_tDBInput_1 != null) {
                        isTimeZoneNull_tDBInput_1 = (unwrappedOraConn_tDBInput_1.getSessionTimeZone() == null);
                    }
                } else {
                    isTimeZoneNull_tDBInput_1 = (((oracle.jdbc.OracleConnection)conn_tDBInput_1).getSessionTimeZone() == null);
                }

				if(isTimeZoneNull_tDBInput_1) {
					java.sql.Statement stmtGetTZ_tDBInput_1 = conn_tDBInput_1.createStatement();
					java.sql.ResultSet rsGetTZ_tDBInput_1 = stmtGetTZ_tDBInput_1.executeQuery("select sessiontimezone from dual");
					String sessionTimezone_tDBInput_1 = java.util.TimeZone.getDefault().getID();
					while (rsGetTZ_tDBInput_1.next()) {
						sessionTimezone_tDBInput_1 = rsGetTZ_tDBInput_1.getString(1);
					}
					if (isConnectionWrapped_tDBInput_1 && unwrappedOraConn_tDBInput_1 != null) {
                        unwrappedOraConn_tDBInput_1.setSessionTimeZone(sessionTimezone_tDBInput_1);
                    } else {
                        ((oracle.jdbc.OracleConnection)conn_tDBInput_1).setSessionTimeZone(sessionTimezone_tDBInput_1);
                    }
				}
			
		    
			java.sql.Statement stmt_tDBInput_1 = conn_tDBInput_1.createStatement();

		    String dbquery_tDBInput_1 = "SELECT * from IRXMDM_DEV.TokenizationNotRequired_after";
			

            	globalMap.put("tDBInput_1_QUERY",dbquery_tDBInput_1);
		    java.sql.ResultSet rs_tDBInput_1 = null;

		    try {
		    	rs_tDBInput_1 = stmt_tDBInput_1.executeQuery(dbquery_tDBInput_1);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_1 = rs_tDBInput_1.getMetaData();
		    	int colQtyInRs_tDBInput_1 = rsmd_tDBInput_1.getColumnCount();

		    String tmpContent_tDBInput_1 = null;
		    
		    
		    while (rs_tDBInput_1.next()) {
		        nb_line_tDBInput_1++;
		        
							if(colQtyInRs_tDBInput_1 < 1) {
								row3.Gender = null;
							} else {
									
					tmpContent_tDBInput_1 = rs_tDBInput_1.getString(1);
                    if(tmpContent_tDBInput_1 != null && tmpContent_tDBInput_1.length() > 0) {			  	
                        row3.Gender = tmpContent_tDBInput_1.charAt(0);			  		
                    } else {			  				  	    
                            if(tmpContent_tDBInput_1 == null) {			  	   	
                                row3.Gender = null;			  			
                            } else {			  		
                                row3.Gender = '\0';			  			
                            }
                    }
		                    }
							if(colQtyInRs_tDBInput_1 < 2) {
								row3.State = null;
							} else {
	                         		
        	row3.State = routines.system.JDBCUtil.getString(rs_tDBInput_1, 2, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 3) {
								row3.City = null;
							} else {
	                         		
        	row3.City = routines.system.JDBCUtil.getString(rs_tDBInput_1, 3, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 4) {
								row3.Zip_Code = null;
							} else {
	                         		
        	row3.Zip_Code = routines.system.JDBCUtil.getString(rs_tDBInput_1, 4, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 5) {
								row3.Address_Line_1 = null;
							} else {
	                         		
        	row3.Address_Line_1 = routines.system.JDBCUtil.getString(rs_tDBInput_1, 5, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 6) {
								row3.Address_Line_2 = null;
							} else {
	                         		
        	row3.Address_Line_2 = routines.system.JDBCUtil.getString(rs_tDBInput_1, 6, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 7) {
								row3.Phone_Number = null;
							} else {
	                         		
        	row3.Phone_Number = routines.system.JDBCUtil.getString(rs_tDBInput_1, 7, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 8) {
								row3.UPI_ID = null;
							} else {
	                         		
        	row3.UPI_ID = routines.system.JDBCUtil.getString(rs_tDBInput_1, 8, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 9) {
								row3.Client_ID = null;
							} else {
	                         		
        	row3.Client_ID = routines.system.JDBCUtil.getString(rs_tDBInput_1, 9, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 10) {
								row3.Carrier_ID = null;
							} else {
	                         		
        	row3.Carrier_ID = routines.system.JDBCUtil.getString(rs_tDBInput_1, 10, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 11) {
								row3.Account_ID = null;
							} else {
	                         		
        	row3.Account_ID = routines.system.JDBCUtil.getString(rs_tDBInput_1, 11, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 12) {
								row3.Group_ID = null;
							} else {
	                         		
        	row3.Group_ID = routines.system.JDBCUtil.getString(rs_tDBInput_1, 12, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 13) {
								row3.Multi_Birth_Code = null;
							} else {
	                         		
        	row3.Multi_Birth_Code = routines.system.JDBCUtil.getString(rs_tDBInput_1, 13, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 14) {
								row3.Member_Key = null;
							} else {
	                         		
        	row3.Member_Key = routines.system.JDBCUtil.getString(rs_tDBInput_1, 14, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 15) {
								row3.Source = null;
							} else {
	                         		
        	row3.Source = routines.system.JDBCUtil.getString(rs_tDBInput_1, 15, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 16) {
								row3.scd_key = 0;
							} else {
		                          
					if(rs_tDBInput_1.getObject(16) != null) {
						row3.scd_key = rs_tDBInput_1.getInt(16);
					} else {
				
 	                	throw new RuntimeException("Null value in non-Nullable column");
					}
		                    }
					




 



/**
 * [tDBInput_1 begin ] stop
 */
	
	/**
	 * [tDBInput_1 main ] start
	 */

	

	
	
	currentComponent="tDBInput_1";

	

 


	tos_count_tDBInput_1++;

/**
 * [tDBInput_1 main ] stop
 */
	
	/**
	 * [tDBInput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_1";

	

 



/**
 * [tDBInput_1 process_data_begin ] stop
 */

	
	/**
	 * [tMap_3 main ] start
	 */

	

	
	
	currentComponent="tMap_3";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"row3");
			

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_3 = false;
		
        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_3 = false;
		  boolean mainRowRejected_tMap_3 = false;
            				    								  
		

				///////////////////////////////////////////////
				// Starting Lookup Table "row4" 
				///////////////////////////////////////////////


				
				
                            
 					    boolean forceLooprow4 = false;
       		  	    	
       		  	    	
 							row4Struct row4ObjectFromLookup = null;
                          
		           		  	if(!rejectedInnerJoin_tMap_3) { // G_TM_M_020

								
								hasCasePrimitiveKeyWithNull_tMap_3 = false;
								
	                        		    	Object exprKeyValue_row4__scd_key = row3.scd_key ;
	                        		    	if(exprKeyValue_row4__scd_key == null) {
	                        		    		hasCasePrimitiveKeyWithNull_tMap_3 = true;
	                        		    	} else {
                        		    			row4HashKey.scd_key = (int)(Integer) exprKeyValue_row4__scd_key;
                        		    		}
                        		    		

								
		                        	row4HashKey.hashCodeDirty = true;
                        		
	  					
	  							
	
		  							if(!hasCasePrimitiveKeyWithNull_tMap_3) { // G_TM_M_091
		  							
			  					
			  					
			  					
	  					
		  							tHash_Lookup_row4.lookup( row4HashKey );

	  							

	  							

			  						} // G_TM_M_091
			  						
			  					

 								
								  
								  if(hasCasePrimitiveKeyWithNull_tMap_3 || !tHash_Lookup_row4.hasNext()) { // G_TM_M_090

  								
		  				
	  								
			  							rejectedInnerJoin_tMap_3 = true;
	  								
						
									
  									  		
 								
								  
								  } // G_TM_M_090

  								



							} // G_TM_M_020
			           		  	  
							
				           		if(tHash_Lookup_row4 != null && tHash_Lookup_row4.getCount(row4HashKey) > 1) { // G 071
			  							
			  						
									 		
									//System.out.println("WARNING: UNIQUE MATCH is configured for the lookup 'row4' and it contains more one result from keys :  row4.scd_key = '" + row4HashKey.scd_key + "'");
								} // G 071
							

							row4Struct row4 = null;
                    		  	 
							   
                    		  	 
	       		  	    	row4Struct fromLookup_row4 = null;
							row4 = row4Default;
										 
							
								 
							
							
								if (tHash_Lookup_row4 !=null && tHash_Lookup_row4.hasNext()) { // G 099
								
							
								
								fromLookup_row4 = tHash_Lookup_row4.next();

							
							
								} // G 099
							
							

							if(fromLookup_row4 != null) {
								row4 = fromLookup_row4;
							}
							
							
							
			  							
								
	                    		  	
		                    
	            	
	            	
	            // ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_3__Struct Var = Var__tMap_3;// ###############################
        // ###############################
        // # Output tables

copyOfoutput = null;
file_out = null;

if(!rejectedInnerJoin_tMap_3 ) {

// # Output table : 'copyOfoutput'
copyOfoutput_tmp.Gender = row3.Gender;
copyOfoutput_tmp.Date_of_Birth = row4.DOB ;
copyOfoutput_tmp.First_Name = row4.firstName ;
copyOfoutput_tmp.Last_Name = row4.lastName ;
copyOfoutput_tmp.State = row3.State;
copyOfoutput_tmp.City = row3.City;
copyOfoutput_tmp.Zip_Code = row3.Zip_Code;
copyOfoutput_tmp.Address_Line_1 = row3.Address_Line_1;
copyOfoutput_tmp.Address_Line_2 = row3.Address_Line_2;
copyOfoutput_tmp.Phone_Number = row3.Phone_Number;
copyOfoutput_tmp.Social_Security_Number = row4.SSN ;
copyOfoutput_tmp.UPI_ID = row3.UPI_ID ;
copyOfoutput_tmp.MBI = row4.MBI;
copyOfoutput_tmp.Client_ID = row3.Client_ID;
copyOfoutput_tmp.Carrier_ID = row3.Carrier_ID;
copyOfoutput_tmp.Account_ID = row3.Account_ID;
copyOfoutput_tmp.Group_ID = row3.Group_ID;
copyOfoutput_tmp.Contract_Family_ID = row4.OtherID ;
copyOfoutput_tmp.Multi_Birth_Code = row3.Multi_Birth_Code;
copyOfoutput_tmp.Member_Key = row3.Member_Key;
copyOfoutput_tmp.Source = row3.Source;
copyOfoutput_tmp.Lastupdated_date = TalendDate.getCurrentDate() ;
copyOfoutput_tmp.Lastupdateby = "Talend";
copyOfoutput = copyOfoutput_tmp;

// # Output table : 'file_out'
file_out_tmp.Gender = row3.Gender;
file_out_tmp.Date_of_Birth = row4.DOB ;
file_out_tmp.First_Name = row4.firstName ;
file_out_tmp.Last_Name = row4.lastName ;
file_out_tmp.State = row3.State;
file_out_tmp.City = row3.City;
file_out_tmp.Zip_Code = row3.Zip_Code;
file_out_tmp.Address_Line_1 = row3.Address_Line_1;
file_out_tmp.Address_Line_2 = row3.Address_Line_2;
file_out_tmp.Phone_Number = row3.Phone_Number;
file_out_tmp.Social_Security_Number = row4.SSN ;
file_out_tmp.UPI_ID = row3.UPI_ID;
file_out_tmp.MBI = row4.MBI;
file_out_tmp.Client_ID = row3.Client_ID;
file_out_tmp.Carrier_ID = row3.Carrier_ID;
file_out_tmp.Account_ID = row3.Account_ID;
file_out_tmp.Group_ID = row3.Group_ID;
file_out_tmp.Contract_Family_ID = row4.OtherID ;
file_out_tmp.Multi_Birth_Code = row3.Multi_Birth_Code;
file_out_tmp.Member_Key = row3.Member_Key;
file_out_tmp.Source = row3.Source;
file_out_tmp.Lastupdated_date = TalendDate.getCurrentDate() ;
file_out_tmp.Lastupdateby = "Talend";
file_out = file_out_tmp;
}  // closing inner join bracket (2)
// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_3 = false;










 


	tos_count_tMap_3++;

/**
 * [tMap_3 main ] stop
 */
	
	/**
	 * [tMap_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_3";

	

 



/**
 * [tMap_3 process_data_begin ] stop
 */
// Start of branch "copyOfoutput"
if(copyOfoutput != null) { 



	
	/**
	 * [tDBOutput_2 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"copyOfoutput");
			



        query_tDBOutput_2 = new StringBuffer("");
        whetherReject_tDBOutput_2 = false;
                        if(copyOfoutput.Gender == null) {
pstmt_tDBOutput_2.setNull(1, java.sql.Types.CHAR);
} else {if(copyOfoutput.Gender == null) {
pstmt_tDBOutput_2.setNull(1, java.sql.Types.CHAR);
} else if(copyOfoutput.Gender == ' '){
pstmt_tDBOutput_2.setString(1, "");
} else {
pstmt_tDBOutput_2.setString(1, String.valueOf(copyOfoutput.Gender));
}}

                        query_tDBOutput_2 = query_tDBOutput_2.append(insertSQLSplits_tDBOutput_2[0]).append(copyOfoutput.Gender== null ?  "null" :"'" + String.valueOf(copyOfoutput.Gender) + "'").append(insertSQLSplits_tDBOutput_2[1]);
                        if(copyOfoutput.Date_of_Birth == null) {
pstmt_tDBOutput_2.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(2, copyOfoutput.Date_of_Birth);
}

                        query_tDBOutput_2 = query_tDBOutput_2.append(copyOfoutput.Date_of_Birth== null ?  "null" :"'" + copyOfoutput.Date_of_Birth + "'").append(insertSQLSplits_tDBOutput_2[2]);
                        if(copyOfoutput.First_Name == null) {
pstmt_tDBOutput_2.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(3, copyOfoutput.First_Name);
}

                        query_tDBOutput_2 = query_tDBOutput_2.append(copyOfoutput.First_Name== null ?  "null" :"'" + copyOfoutput.First_Name + "'").append(insertSQLSplits_tDBOutput_2[3]);
                        if(copyOfoutput.Last_Name == null) {
pstmt_tDBOutput_2.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(4, copyOfoutput.Last_Name);
}

                        query_tDBOutput_2 = query_tDBOutput_2.append(copyOfoutput.Last_Name== null ?  "null" :"'" + copyOfoutput.Last_Name + "'").append(insertSQLSplits_tDBOutput_2[4]);
                        if(copyOfoutput.State == null) {
pstmt_tDBOutput_2.setNull(5, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(5, copyOfoutput.State);
}

                        query_tDBOutput_2 = query_tDBOutput_2.append(copyOfoutput.State== null ?  "null" :"'" + copyOfoutput.State + "'").append(insertSQLSplits_tDBOutput_2[5]);
                        if(copyOfoutput.City == null) {
pstmt_tDBOutput_2.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(6, copyOfoutput.City);
}

                        query_tDBOutput_2 = query_tDBOutput_2.append(copyOfoutput.City== null ?  "null" :"'" + copyOfoutput.City + "'").append(insertSQLSplits_tDBOutput_2[6]);
                        if(copyOfoutput.Zip_Code == null) {
pstmt_tDBOutput_2.setNull(7, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(7, copyOfoutput.Zip_Code);
}

                        query_tDBOutput_2 = query_tDBOutput_2.append(copyOfoutput.Zip_Code== null ?  "null" :"'" + copyOfoutput.Zip_Code + "'").append(insertSQLSplits_tDBOutput_2[7]);
                        if(copyOfoutput.Address_Line_1 == null) {
pstmt_tDBOutput_2.setNull(8, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(8, copyOfoutput.Address_Line_1);
}

                        query_tDBOutput_2 = query_tDBOutput_2.append(copyOfoutput.Address_Line_1== null ?  "null" :"'" + copyOfoutput.Address_Line_1 + "'").append(insertSQLSplits_tDBOutput_2[8]);
                        if(copyOfoutput.Address_Line_2 == null) {
pstmt_tDBOutput_2.setNull(9, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(9, copyOfoutput.Address_Line_2);
}

                        query_tDBOutput_2 = query_tDBOutput_2.append(copyOfoutput.Address_Line_2== null ?  "null" :"'" + copyOfoutput.Address_Line_2 + "'").append(insertSQLSplits_tDBOutput_2[9]);
                        if(copyOfoutput.Phone_Number == null) {
pstmt_tDBOutput_2.setNull(10, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(10, copyOfoutput.Phone_Number);
}

                        query_tDBOutput_2 = query_tDBOutput_2.append(copyOfoutput.Phone_Number== null ?  "null" :"'" + copyOfoutput.Phone_Number + "'").append(insertSQLSplits_tDBOutput_2[10]);
                        if(copyOfoutput.Social_Security_Number == null) {
pstmt_tDBOutput_2.setNull(11, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(11, copyOfoutput.Social_Security_Number);
}

                        query_tDBOutput_2 = query_tDBOutput_2.append(copyOfoutput.Social_Security_Number== null ?  "null" :"'" + copyOfoutput.Social_Security_Number + "'").append(insertSQLSplits_tDBOutput_2[11]);
                        if(copyOfoutput.UPI_ID == null) {
pstmt_tDBOutput_2.setNull(12, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(12, copyOfoutput.UPI_ID);
}

                        query_tDBOutput_2 = query_tDBOutput_2.append(copyOfoutput.UPI_ID== null ?  "null" :"'" + copyOfoutput.UPI_ID + "'").append(insertSQLSplits_tDBOutput_2[12]);
                        if(copyOfoutput.MBI == null) {
pstmt_tDBOutput_2.setNull(13, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(13, copyOfoutput.MBI);
}

                        query_tDBOutput_2 = query_tDBOutput_2.append(copyOfoutput.MBI== null ?  "null" :"'" + copyOfoutput.MBI + "'").append(insertSQLSplits_tDBOutput_2[13]);
                        if(copyOfoutput.Client_ID == null) {
pstmt_tDBOutput_2.setNull(14, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(14, copyOfoutput.Client_ID);
}

                        query_tDBOutput_2 = query_tDBOutput_2.append(copyOfoutput.Client_ID== null ?  "null" :"'" + copyOfoutput.Client_ID + "'").append(insertSQLSplits_tDBOutput_2[14]);
                        if(copyOfoutput.Carrier_ID == null) {
pstmt_tDBOutput_2.setNull(15, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(15, copyOfoutput.Carrier_ID);
}

                        query_tDBOutput_2 = query_tDBOutput_2.append(copyOfoutput.Carrier_ID== null ?  "null" :"'" + copyOfoutput.Carrier_ID + "'").append(insertSQLSplits_tDBOutput_2[15]);
                        if(copyOfoutput.Account_ID == null) {
pstmt_tDBOutput_2.setNull(16, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(16, copyOfoutput.Account_ID);
}

                        query_tDBOutput_2 = query_tDBOutput_2.append(copyOfoutput.Account_ID== null ?  "null" :"'" + copyOfoutput.Account_ID + "'").append(insertSQLSplits_tDBOutput_2[16]);
                        if(copyOfoutput.Group_ID == null) {
pstmt_tDBOutput_2.setNull(17, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(17, copyOfoutput.Group_ID);
}

                        query_tDBOutput_2 = query_tDBOutput_2.append(copyOfoutput.Group_ID== null ?  "null" :"'" + copyOfoutput.Group_ID + "'").append(insertSQLSplits_tDBOutput_2[17]);
                        if(copyOfoutput.Contract_Family_ID == null) {
pstmt_tDBOutput_2.setNull(18, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(18, copyOfoutput.Contract_Family_ID);
}

                        query_tDBOutput_2 = query_tDBOutput_2.append(copyOfoutput.Contract_Family_ID== null ?  "null" :"'" + copyOfoutput.Contract_Family_ID + "'").append(insertSQLSplits_tDBOutput_2[18]);
                        if(copyOfoutput.Multi_Birth_Code == null) {
pstmt_tDBOutput_2.setNull(19, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(19, copyOfoutput.Multi_Birth_Code);
}

                        query_tDBOutput_2 = query_tDBOutput_2.append(copyOfoutput.Multi_Birth_Code== null ?  "null" :"'" + copyOfoutput.Multi_Birth_Code + "'").append(insertSQLSplits_tDBOutput_2[19]);
                        if(copyOfoutput.Member_Key == null) {
pstmt_tDBOutput_2.setNull(20, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(20, copyOfoutput.Member_Key);
}

                        query_tDBOutput_2 = query_tDBOutput_2.append(copyOfoutput.Member_Key== null ?  "null" :"'" + copyOfoutput.Member_Key + "'").append(insertSQLSplits_tDBOutput_2[20]);
                        if(copyOfoutput.Source == null) {
pstmt_tDBOutput_2.setNull(21, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(21, copyOfoutput.Source);
}

                        query_tDBOutput_2 = query_tDBOutput_2.append(copyOfoutput.Source== null ?  "null" :"'" + copyOfoutput.Source + "'").append(insertSQLSplits_tDBOutput_2[21]);
                        if(copyOfoutput.Lastupdated_date != null) {
pstmt_tDBOutput_2.setDate(22, new java.sql.Date(copyOfoutput.Lastupdated_date.getTime()));
} else {
pstmt_tDBOutput_2.setNull(22, java.sql.Types.DATE);
}

                        query_tDBOutput_2 = query_tDBOutput_2.append(copyOfoutput.Lastupdated_date== null ?  "null" :"'" + new java.text.SimpleDateFormat("dd-MM-yyyy").format(copyOfoutput.Lastupdated_date) + "'").append(insertSQLSplits_tDBOutput_2[22]);
                        if(copyOfoutput.Lastupdateby == null) {
pstmt_tDBOutput_2.setNull(23, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(23, copyOfoutput.Lastupdateby);
}

                        query_tDBOutput_2 = query_tDBOutput_2.append(copyOfoutput.Lastupdateby== null ?  "null" :"'" + copyOfoutput.Lastupdateby + "'").append(insertSQLSplits_tDBOutput_2[23]);
                globalMap.put("tDBOutput_2_QUERY", query_tDBOutput_2.toString().trim());
                try {
                    nb_line_tDBOutput_2++;
                    insertedCount_tDBOutput_2 = insertedCount_tDBOutput_2 + pstmt_tDBOutput_2.executeUpdate();
                } catch(java.lang.Exception e_tDBOutput_2) {
                    whetherReject_tDBOutput_2 = true;
                            System.err.print(e_tDBOutput_2.getMessage());
                }

 


	tos_count_tDBOutput_2++;

/**
 * [tDBOutput_2 main ] stop
 */
	
	/**
	 * [tDBOutput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";

	

 



/**
 * [tDBOutput_2 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";

	

 



/**
 * [tDBOutput_2 process_data_end ] stop
 */

} // End of branch "copyOfoutput"




// Start of branch "file_out"
if(file_out != null) { 



	
	/**
	 * [tFileOutputDelimited_1 main ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_1";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"file_out");
			


                    StringBuilder sb_tFileOutputDelimited_1 = new StringBuilder();
                            if(file_out.Gender != null) {
                        sb_tFileOutputDelimited_1.append(
                            file_out.Gender
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(file_out.Date_of_Birth != null) {
                        sb_tFileOutputDelimited_1.append(
                            file_out.Date_of_Birth
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(file_out.First_Name != null) {
                        sb_tFileOutputDelimited_1.append(
                            file_out.First_Name
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(file_out.Last_Name != null) {
                        sb_tFileOutputDelimited_1.append(
                            file_out.Last_Name
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(file_out.State != null) {
                        sb_tFileOutputDelimited_1.append(
                            file_out.State
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(file_out.City != null) {
                        sb_tFileOutputDelimited_1.append(
                            file_out.City
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(file_out.Zip_Code != null) {
                        sb_tFileOutputDelimited_1.append(
                            file_out.Zip_Code
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(file_out.Address_Line_1 != null) {
                        sb_tFileOutputDelimited_1.append(
                            file_out.Address_Line_1
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(file_out.Address_Line_2 != null) {
                        sb_tFileOutputDelimited_1.append(
                            file_out.Address_Line_2
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(file_out.Phone_Number != null) {
                        sb_tFileOutputDelimited_1.append(
                            file_out.Phone_Number
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(file_out.Social_Security_Number != null) {
                        sb_tFileOutputDelimited_1.append(
                            file_out.Social_Security_Number
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(file_out.UPI_ID != null) {
                        sb_tFileOutputDelimited_1.append(
                            file_out.UPI_ID
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(file_out.MBI != null) {
                        sb_tFileOutputDelimited_1.append(
                            file_out.MBI
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(file_out.Client_ID != null) {
                        sb_tFileOutputDelimited_1.append(
                            file_out.Client_ID
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(file_out.Carrier_ID != null) {
                        sb_tFileOutputDelimited_1.append(
                            file_out.Carrier_ID
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(file_out.Account_ID != null) {
                        sb_tFileOutputDelimited_1.append(
                            file_out.Account_ID
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(file_out.Group_ID != null) {
                        sb_tFileOutputDelimited_1.append(
                            file_out.Group_ID
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(file_out.Contract_Family_ID != null) {
                        sb_tFileOutputDelimited_1.append(
                            file_out.Contract_Family_ID
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(file_out.Multi_Birth_Code != null) {
                        sb_tFileOutputDelimited_1.append(
                            file_out.Multi_Birth_Code
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(file_out.Member_Key != null) {
                        sb_tFileOutputDelimited_1.append(
                            file_out.Member_Key
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(file_out.Source != null) {
                        sb_tFileOutputDelimited_1.append(
                            file_out.Source
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(file_out.Lastupdated_date != null) {
                        sb_tFileOutputDelimited_1.append(
                            FormatterUtils.format_Date(file_out.Lastupdated_date, "dd-MM-yyyy")
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(file_out.Lastupdateby != null) {
                        sb_tFileOutputDelimited_1.append(
                            file_out.Lastupdateby
                        );
                            }
                    sb_tFileOutputDelimited_1.append(OUT_DELIM_ROWSEP_tFileOutputDelimited_1);


                    nb_line_tFileOutputDelimited_1++;
                    resourceMap.put("nb_line_tFileOutputDelimited_1", nb_line_tFileOutputDelimited_1);

                        outtFileOutputDelimited_1.write(sb_tFileOutputDelimited_1.toString());




 


	tos_count_tFileOutputDelimited_1++;

/**
 * [tFileOutputDelimited_1 main ] stop
 */
	
	/**
	 * [tFileOutputDelimited_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_1";

	

 



/**
 * [tFileOutputDelimited_1 process_data_begin ] stop
 */
	
	/**
	 * [tFileOutputDelimited_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_1";

	

 



/**
 * [tFileOutputDelimited_1 process_data_end ] stop
 */

} // End of branch "file_out"




	
	/**
	 * [tMap_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_3";

	

 



/**
 * [tMap_3 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_1";

	

 



/**
 * [tDBInput_1 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_1 end ] start
	 */

	

	
	
	currentComponent="tDBInput_1";

	

}
}finally{
	if (rs_tDBInput_1 != null) {
		rs_tDBInput_1.close();
	}
	if (stmt_tDBInput_1 != null) {
		stmt_tDBInput_1.close();
	}
}

globalMap.put("tDBInput_1_NB_LINE",nb_line_tDBInput_1);
 

ok_Hash.put("tDBInput_1", true);
end_Hash.put("tDBInput_1", System.currentTimeMillis());




/**
 * [tDBInput_1 end ] stop
 */

	
	/**
	 * [tMap_3 end ] start
	 */

	

	
	
	currentComponent="tMap_3";

	


// ###############################
// # Lookup hashes releasing
					if(tHash_Lookup_row4 != null) {
						tHash_Lookup_row4.endGet();
					}
					globalMap.remove( "tHash_Lookup_row4" );

					
					
				
// ###############################      





			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row3",2,0,
			 			talendJobLog,"tDBInput_1","tOracleInput","tMap_3","tMap","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tMap_3", true);
end_Hash.put("tMap_3", System.currentTimeMillis());




/**
 * [tMap_3 end ] stop
 */

	
	/**
	 * [tDBOutput_2 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";

	
	



	
        if(pstmt_tDBOutput_2 != null) {
			
				pstmt_tDBOutput_2.close();
				resourceMap.remove("pstmt_tDBOutput_2");
			
        }
    resourceMap.put("statementClosed_tDBOutput_2", true);


	
	nb_line_deleted_tDBOutput_2=nb_line_deleted_tDBOutput_2+ deletedCount_tDBOutput_2;
	nb_line_update_tDBOutput_2=nb_line_update_tDBOutput_2 + updatedCount_tDBOutput_2;
	nb_line_inserted_tDBOutput_2=nb_line_inserted_tDBOutput_2 + insertedCount_tDBOutput_2;
	nb_line_rejected_tDBOutput_2=nb_line_rejected_tDBOutput_2 + rejectedCount_tDBOutput_2;
	
        globalMap.put("tDBOutput_2_NB_LINE",nb_line_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_UPDATED",nb_line_update_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_DELETED",nb_line_deleted_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_2);
    
	



			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"copyOfoutput",2,0,
			 			talendJobLog,"tMap_3","tMap","tDBOutput_2","tOracleOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tDBOutput_2", true);
end_Hash.put("tDBOutput_2", System.currentTimeMillis());




/**
 * [tDBOutput_2 end ] stop
 */




	
	/**
	 * [tFileOutputDelimited_1 end ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_1";

	



		
			
					if(outtFileOutputDelimited_1!=null) {
						outtFileOutputDelimited_1.flush();
						outtFileOutputDelimited_1.close();
					}
				
				globalMap.put("tFileOutputDelimited_1_NB_LINE",nb_line_tFileOutputDelimited_1);
				globalMap.put("tFileOutputDelimited_1_FILE_NAME",fileName_tFileOutputDelimited_1);
			
		
		
		resourceMap.put("finish_tFileOutputDelimited_1", true);
	

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"file_out",2,0,
			 			talendJobLog,"tMap_3","tMap","tFileOutputDelimited_1","tFileOutputDelimited","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tFileOutputDelimited_1", true);
end_Hash.put("tFileOutputDelimited_1", System.currentTimeMillis());




/**
 * [tFileOutputDelimited_1 end ] stop
 */






				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
					     			//free memory for "tMap_3"
					     			globalMap.remove("tHash_Lookup_row4"); 
				     			
				try{
					
	
	/**
	 * [tDBInput_1 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_1";

	

 



/**
 * [tDBInput_1 finally ] stop
 */

	
	/**
	 * [tMap_3 finally ] start
	 */

	

	
	
	currentComponent="tMap_3";

	

 



/**
 * [tMap_3 finally ] stop
 */

	
	/**
	 * [tDBOutput_2 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";

	



    if (resourceMap.get("statementClosed_tDBOutput_2") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_2 = null;
                if ((pstmtToClose_tDBOutput_2 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_2")) != null) {
                    pstmtToClose_tDBOutput_2.close();
                }
    }
 



/**
 * [tDBOutput_2 finally ] stop
 */




	
	/**
	 * [tFileOutputDelimited_1 finally ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_1";

	


		if(resourceMap.get("finish_tFileOutputDelimited_1") == null){ 
			
				
						java.io.Writer outtFileOutputDelimited_1 = (java.io.Writer)resourceMap.get("out_tFileOutputDelimited_1");
						if(outtFileOutputDelimited_1!=null) {
							outtFileOutputDelimited_1.flush();
							outtFileOutputDelimited_1.close();
						}
					
				
			
		}
	

 



/**
 * [tFileOutputDelimited_1 finally ] stop
 */






				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_1_SUBPROCESS_STATE", 1);
	}
	


public static class row4Struct implements routines.system.IPersistableComparableLookupRow<row4Struct> {
    final static byte[] commonByteArrayLock_UPI_PROCESS_IngestRecords_Tokenization = new byte[0];
    static byte[] commonByteArray_UPI_PROCESS_IngestRecords_Tokenization = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public String firstName;

				public String getFirstName () {
					return this.firstName;
				}
				
			    public String lastName;

				public String getLastName () {
					return this.lastName;
				}
				
			    public String MBI;

				public String getMBI () {
					return this.MBI;
				}
				
			    public String DOB;

				public String getDOB () {
					return this.DOB;
				}
				
			    public String OtherID;

				public String getOtherID () {
					return this.OtherID;
				}
				
			    public String SSN;

				public String getSSN () {
					return this.SSN;
				}
				
			    public int scd_key;

				public int getScd_key () {
					return this.scd_key;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.scd_key;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row4Struct other = (row4Struct) obj;
		
						if (this.scd_key != other.scd_key)
							return false;
					

		return true;
    }

	public void copyDataTo(row4Struct other) {

		other.firstName = this.firstName;
	            other.lastName = this.lastName;
	            other.MBI = this.MBI;
	            other.DOB = this.DOB;
	            other.OtherID = this.OtherID;
	            other.SSN = this.SSN;
	            other.scd_key = this.scd_key;
	            
	}

	public void copyKeysDataTo(row4Struct other) {

		other.scd_key = this.scd_key;
	            	
	}




	private String readString(DataInputStream dis, ObjectInputStream ois) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			byte[] byteArray = new byte[length];
			dis.read(byteArray);
			strReturn = new String(byteArray, utf8Charset);
		}
		return strReturn;
	}

	private void writeString(String str, DataOutputStream dos, ObjectOutputStream oos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
	}

    public void readKeysData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_UPI_PROCESS_IngestRecords_Tokenization) {

        	try {

        		int length = 0;
		
			        this.scd_key = dis.readInt();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeKeysData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.scd_key);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }



    /**
     * Fill Values data by reading ObjectInputStream.
     */
    public void readValuesData(DataInputStream dis, ObjectInputStream ois) {
        try {

			int length = 0;
		
						this.firstName = readString(dis,ois);
					
						this.lastName = readString(dis,ois);
					
						this.MBI = readString(dis,ois);
					
						this.DOB = readString(dis,ois);
					
						this.OtherID = readString(dis,ois);
					
						this.SSN = readString(dis,ois);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

    }

    /**
     * Return a byte array which represents Values data.
     */
    public void writeValuesData(DataOutputStream dos, ObjectOutputStream oos) {
        try {

		
						writeString(this.firstName, dos, oos);
					
						writeString(this.lastName, dos, oos);
					
						writeString(this.MBI, dos, oos);
					
						writeString(this.DOB, dos, oos);
					
						writeString(this.OtherID, dos, oos);
					
						writeString(this.SSN, dos, oos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        	}

    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("firstName="+firstName);
		sb.append(",lastName="+lastName);
		sb.append(",MBI="+MBI);
		sb.append(",DOB="+DOB);
		sb.append(",OtherID="+OtherID);
		sb.append(",SSN="+SSN);
		sb.append(",scd_key="+String.valueOf(scd_key));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row4Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.scd_key, other.scd_key);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tDBInput_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row4Struct row4 = new row4Struct();




	
	/**
	 * [tAdvancedHash_row4 begin ] start
	 */

	

	
		
		ok_Hash.put("tAdvancedHash_row4", false);
		start_Hash.put("tAdvancedHash_row4", System.currentTimeMillis());
		
	
	currentComponent="tAdvancedHash_row4";

	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row4");
			
		int tos_count_tAdvancedHash_row4 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAdvancedHash_row4", "tAdvancedHash");
				talendJobLogProcess(globalMap);
			}
			

			   		// connection name:row4
			   		// source node:tDBInput_2 - inputs:(after_tDBInput_1) outputs:(row4,row4) | target node:tAdvancedHash_row4 - inputs:(row4) outputs:()
			   		// linked node: tMap_3 - inputs:(row3,row4) outputs:(copyOfoutput,file_out)
			   
			   		org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_row4 = 
			   			org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.UNIQUE_MATCH;
			   			
			   
	   			org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row4Struct> tHash_Lookup_row4 =org.talend.designer.components.lookup.memory.AdvancedMemoryLookup.
	   						<row4Struct>getLookup(matchingModeEnum_row4);
	   						   
		   	   	   globalMap.put("tHash_Lookup_row4", tHash_Lookup_row4);
		   	   	   
				
           

 



/**
 * [tAdvancedHash_row4 begin ] stop
 */



	
	/**
	 * [tDBInput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_2", false);
		start_Hash.put("tDBInput_2", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_2";

	
		int tos_count_tDBInput_2 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_2", "tOracleInput");
				talendJobLogProcess(globalMap);
			}
			
	


	
		    int nb_line_tDBInput_2 = 0;
		    java.sql.Connection conn_tDBInput_2 = null;
				conn_tDBInput_2 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
                boolean isTimeZoneNull_tDBInput_2 = false;
				boolean isConnectionWrapped_tDBInput_2 = !(conn_tDBInput_2 instanceof oracle.jdbc.OracleConnection) && conn_tDBInput_2.isWrapperFor(oracle.jdbc.OracleConnection.class);
				oracle.jdbc.OracleConnection unwrappedOraConn_tDBInput_2 = null;
                if (isConnectionWrapped_tDBInput_2) {
					unwrappedOraConn_tDBInput_2 = conn_tDBInput_2.unwrap(oracle.jdbc.OracleConnection.class);
                    if (unwrappedOraConn_tDBInput_2 != null) {
                        isTimeZoneNull_tDBInput_2 = (unwrappedOraConn_tDBInput_2.getSessionTimeZone() == null);
                    }
                } else {
                    isTimeZoneNull_tDBInput_2 = (((oracle.jdbc.OracleConnection)conn_tDBInput_2).getSessionTimeZone() == null);
                }

				if(isTimeZoneNull_tDBInput_2) {
					java.sql.Statement stmtGetTZ_tDBInput_2 = conn_tDBInput_2.createStatement();
					java.sql.ResultSet rsGetTZ_tDBInput_2 = stmtGetTZ_tDBInput_2.executeQuery("select sessiontimezone from dual");
					String sessionTimezone_tDBInput_2 = java.util.TimeZone.getDefault().getID();
					while (rsGetTZ_tDBInput_2.next()) {
						sessionTimezone_tDBInput_2 = rsGetTZ_tDBInput_2.getString(1);
					}
					if (isConnectionWrapped_tDBInput_2 && unwrappedOraConn_tDBInput_2 != null) {
                        unwrappedOraConn_tDBInput_2.setSessionTimeZone(sessionTimezone_tDBInput_2);
                    } else {
                        ((oracle.jdbc.OracleConnection)conn_tDBInput_2).setSessionTimeZone(sessionTimezone_tDBInput_2);
                    }
				}
			
		    
			java.sql.Statement stmt_tDBInput_2 = conn_tDBInput_2.createStatement();

		    String dbquery_tDBInput_2 = "SELECT  * FROM IRXMDM_DEV.tokenized_landing";
			

            	globalMap.put("tDBInput_2_QUERY",dbquery_tDBInput_2);
		    java.sql.ResultSet rs_tDBInput_2 = null;

		    try {
		    	rs_tDBInput_2 = stmt_tDBInput_2.executeQuery(dbquery_tDBInput_2);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_2 = rs_tDBInput_2.getMetaData();
		    	int colQtyInRs_tDBInput_2 = rsmd_tDBInput_2.getColumnCount();

		    String tmpContent_tDBInput_2 = null;
		    
		    
		    while (rs_tDBInput_2.next()) {
		        nb_line_tDBInput_2++;
		        
							if(colQtyInRs_tDBInput_2 < 1) {
								row4.firstName = null;
							} else {
	                         		
        	row4.firstName = routines.system.JDBCUtil.getString(rs_tDBInput_2, 1, false);
		                    }
							if(colQtyInRs_tDBInput_2 < 2) {
								row4.lastName = null;
							} else {
	                         		
        	row4.lastName = routines.system.JDBCUtil.getString(rs_tDBInput_2, 2, false);
		                    }
							if(colQtyInRs_tDBInput_2 < 3) {
								row4.MBI = null;
							} else {
	                         		
        	row4.MBI = routines.system.JDBCUtil.getString(rs_tDBInput_2, 3, false);
		                    }
							if(colQtyInRs_tDBInput_2 < 4) {
								row4.DOB = null;
							} else {
	                         		
        	row4.DOB = routines.system.JDBCUtil.getString(rs_tDBInput_2, 4, false);
		                    }
							if(colQtyInRs_tDBInput_2 < 5) {
								row4.OtherID = null;
							} else {
	                         		
        	row4.OtherID = routines.system.JDBCUtil.getString(rs_tDBInput_2, 5, false);
		                    }
							if(colQtyInRs_tDBInput_2 < 6) {
								row4.SSN = null;
							} else {
	                         		
        	row4.SSN = routines.system.JDBCUtil.getString(rs_tDBInput_2, 6, false);
		                    }
							if(colQtyInRs_tDBInput_2 < 7) {
								row4.scd_key = 0;
							} else {
		                          
					if(rs_tDBInput_2.getObject(7) != null) {
						row4.scd_key = rs_tDBInput_2.getInt(7);
					} else {
				
 	                	throw new RuntimeException("Null value in non-Nullable column");
					}
		                    }
					




 



/**
 * [tDBInput_2 begin ] stop
 */
	
	/**
	 * [tDBInput_2 main ] start
	 */

	

	
	
	currentComponent="tDBInput_2";

	

 


	tos_count_tDBInput_2++;

/**
 * [tDBInput_2 main ] stop
 */
	
	/**
	 * [tDBInput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_2";

	

 



/**
 * [tDBInput_2 process_data_begin ] stop
 */

	
	/**
	 * [tAdvancedHash_row4 main ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row4";

	
			runStat.updateStatAndLog(execStat,enableLogStash,iterateId,1,1,"row4");
			


			   
			   

					row4Struct row4_HashRow = new row4Struct();
		   	   	   
				
				row4_HashRow.firstName = row4.firstName;
				
				row4_HashRow.lastName = row4.lastName;
				
				row4_HashRow.MBI = row4.MBI;
				
				row4_HashRow.DOB = row4.DOB;
				
				row4_HashRow.OtherID = row4.OtherID;
				
				row4_HashRow.SSN = row4.SSN;
				
				row4_HashRow.scd_key = row4.scd_key;
				
			tHash_Lookup_row4.put(row4_HashRow);
			
            




 


	tos_count_tAdvancedHash_row4++;

/**
 * [tAdvancedHash_row4 main ] stop
 */
	
	/**
	 * [tAdvancedHash_row4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row4";

	

 



/**
 * [tAdvancedHash_row4 process_data_begin ] stop
 */
	
	/**
	 * [tAdvancedHash_row4 process_data_end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row4";

	

 



/**
 * [tAdvancedHash_row4 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_2";

	

 



/**
 * [tDBInput_2 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_2 end ] start
	 */

	

	
	
	currentComponent="tDBInput_2";

	

}
}finally{
	if (rs_tDBInput_2 != null) {
		rs_tDBInput_2.close();
	}
	if (stmt_tDBInput_2 != null) {
		stmt_tDBInput_2.close();
	}
}

globalMap.put("tDBInput_2_NB_LINE",nb_line_tDBInput_2);
 

ok_Hash.put("tDBInput_2", true);
end_Hash.put("tDBInput_2", System.currentTimeMillis());




/**
 * [tDBInput_2 end ] stop
 */

	
	/**
	 * [tAdvancedHash_row4 end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row4";

	

tHash_Lookup_row4.endPut();

			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row4",2,0,
			 			talendJobLog,"tDBInput_2","tOracleInput","tAdvancedHash_row4","tAdvancedHash","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tAdvancedHash_row4", true);
end_Hash.put("tAdvancedHash_row4", System.currentTimeMillis());




/**
 * [tAdvancedHash_row4 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_2 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_2";

	

 



/**
 * [tDBInput_2 finally ] stop
 */

	
	/**
	 * [tAdvancedHash_row4 finally ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row4";

	

 



/**
 * [tAdvancedHash_row4 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_2_SUBPROCESS_STATE", 1);
	}
	

public void talendJobLogProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("talendJobLog_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [talendJobLog begin ] start
	 */

	

	
		
		ok_Hash.put("talendJobLog", false);
		start_Hash.put("talendJobLog", System.currentTimeMillis());
		
	
	currentComponent="talendJobLog";

	
		int tos_count_talendJobLog = 0;
		

	for (JobStructureCatcherUtils.JobStructureCatcherMessage jcm : talendJobLog.getMessages()) {
		org.talend.logging.audit.Context log_context_talendJobLog = null;
		if(jcm.component_name == null) {//job level log
			if(jcm.status == null) {//job start
				log_context_talendJobLog = org.talend.job.audit.JobContextBuilder.create().jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version).timestamp(jcm.moment).build();
				auditLogger_talendJobLog.jobstart(log_context_talendJobLog);
			} else {//job end
				long timeMS = jcm.end_time - jcm.start_time;
				String duration = String.format(java.util.Locale.US, "%1$.2fs", (timeMS * 1.0)/1000);
			
				log_context_talendJobLog = org.talend.job.audit.JobContextBuilder.create().jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version)
					.timestamp(jcm.moment).duration(duration).status(jcm.status).build();
				auditLogger_talendJobLog.jobstop(log_context_talendJobLog);
			}
		} else if(jcm.current_connector == null) {//component log
			log_context_talendJobLog = org.talend.job.audit.JobContextBuilder.create().jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version)
				.connectorType(jcm.component_name).connectorId(jcm.component_id).build();
			auditLogger_talendJobLog.runcomponent(log_context_talendJobLog);
		} else {//component connector meter log
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.format(java.util.Locale.US, "%1$.2fs", (timeMS * 1.0)/1000);
			
			if(jcm.current_connector_as_input) {//log current component input line
				log_context_talendJobLog = org.talend.job.audit.JobContextBuilder.create().jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version)
					.connectorType(jcm.component_name).connectorId(jcm.component_id)
					.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
					.rows(jcm.total_row_number).duration(duration).build();
				auditLogger_talendJobLog.flowInput(log_context_talendJobLog);
			} else {//log current component output/reject line
				log_context_talendJobLog = org.talend.job.audit.JobContextBuilder.create().jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version)
					.connectorType(jcm.component_name).connectorId(jcm.component_id)
					.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
					.rows(jcm.total_row_number).duration(duration).build();
				auditLogger_talendJobLog.flowOutput(log_context_talendJobLog);
			}
		}
	}

 



/**
 * [talendJobLog begin ] stop
 */
	
	/**
	 * [talendJobLog main ] start
	 */

	

	
	
	currentComponent="talendJobLog";

	

 


	tos_count_talendJobLog++;

/**
 * [talendJobLog main ] stop
 */
	
	/**
	 * [talendJobLog process_data_begin ] start
	 */

	

	
	
	currentComponent="talendJobLog";

	

 



/**
 * [talendJobLog process_data_begin ] stop
 */
	
	/**
	 * [talendJobLog process_data_end ] start
	 */

	

	
	
	currentComponent="talendJobLog";

	

 



/**
 * [talendJobLog process_data_end ] stop
 */
	
	/**
	 * [talendJobLog end ] start
	 */

	

	
	
	currentComponent="talendJobLog";

	

 

ok_Hash.put("talendJobLog", true);
end_Hash.put("talendJobLog", System.currentTimeMillis());




/**
 * [talendJobLog end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [talendJobLog finally ] start
	 */

	

	
	
	currentComponent="talendJobLog";

	

 



/**
 * [talendJobLog finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("talendJobLog_SUBPROCESS_STATE", 1);
	}
	
    public String resuming_logs_dir_path = null;
    public String resuming_checkpoint_path = null;
    public String parent_part_launcher = null;
    private String resumeEntryMethodName = null;
    private boolean globalResumeTicket = false;

    public boolean watch = false;
    // portStats is null, it means don't execute the statistics
    public Integer portStats = null;
    public int portTraces = 4334;
    public String clientHost;
    public String defaultClientHost = "localhost";
    public String contextStr = "Default";
    public boolean isDefaultContext = true;
    public String pid = "0";
    public String rootPid = null;
    public String fatherPid = null;
    public String fatherNode = null;
    public long startTime = 0;
    public boolean isChildJob = false;
    public String log4jLevel = "";
    
    private boolean enableLogStash;

    private boolean execStat = true;

    private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
        protected java.util.Map<String, String> initialValue() {
            java.util.Map<String,String> threadRunResultMap = new java.util.HashMap<String, String>();
            threadRunResultMap.put("errorCode", null);
            threadRunResultMap.put("status", "");
            return threadRunResultMap;
        };
    };


    private PropertiesWithType context_param = new PropertiesWithType();
    public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

    public String status= "";
    

    public static void main(String[] args){
        final IngestRecords_Tokenization IngestRecords_TokenizationClass = new IngestRecords_Tokenization();

        int exitCode = IngestRecords_TokenizationClass.runJobInTOS(args);

        System.exit(exitCode);
    }


    public String[][] runJob(String[] args) {

        int exitCode = runJobInTOS(args);
        String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

        return bufferValue;
    }

    public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;
    	
        return hastBufferOutput;
    }

    public int runJobInTOS(String[] args) {
	   	// reset status
	   	status = "";
	   	
        String lastStr = "";
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--context_param")) {
                lastStr = arg;
            } else if (lastStr.equals("")) {
                evalParam(arg);
            } else {
                evalParam(lastStr + " " + arg);
                lastStr = "";
            }
        }
        enableLogStash = "true".equalsIgnoreCase(System.getProperty("monitoring"));

    	
    	
			if(enableLogStash) {
				java.util.Properties properties_talendJobLog = new java.util.Properties();
				properties_talendJobLog.setProperty("root.logger", "audit");
				properties_talendJobLog.setProperty("encoding", "UTF-8");
				properties_talendJobLog.setProperty("application.name", "Talend Studio");
				properties_talendJobLog.setProperty("service.name", "Talend Studio Job");
				properties_talendJobLog.setProperty("instance.name", "Talend Studio Job Instance");
				properties_talendJobLog.setProperty("propagate.appender.exceptions", "none");
				properties_talendJobLog.setProperty("log.appender", "file");
				properties_talendJobLog.setProperty("appender.file.path", "audit.json");
				properties_talendJobLog.setProperty("appender.file.maxsize", "52428800");
				properties_talendJobLog.setProperty("appender.file.maxbackup", "20");
				properties_talendJobLog.setProperty("host", "false");

				System.getProperties().stringPropertyNames().stream()
					.filter(it -> it.startsWith("monitoring.audit.logger.properties."))
					.forEach(key -> properties_talendJobLog.setProperty(key.substring("monitoring.audit.logger.properties.".length()), System.getProperty(key)));

				
				
				
				org.apache.logging.log4j.core.config.Configurator.setLevel("audit", org.apache.logging.log4j.Level.DEBUG);
				
				auditLogger_talendJobLog = org.talend.job.audit.JobEventAuditLoggerFactory.createJobAuditLogger(properties_talendJobLog);
			}
		

        if(clientHost == null) {
            clientHost = defaultClientHost;
        }

        if(pid == null || "0".equals(pid)) {
            pid = TalendString.getAsciiRandomString(6);
        }

        if (rootPid==null) {
            rootPid = pid;
        }
        if (fatherPid==null) {
            fatherPid = pid;
        }else{
            isChildJob = true;
        }

        if (portStats != null) {
            // portStats = -1; //for testing
            if (portStats < 0 || portStats > 65535) {
                // issue:10869, the portStats is invalid, so this client socket can't open
                System.err.println("The statistics socket port " + portStats + " is invalid.");
                execStat = false;
            }
        } else {
            execStat = false;
        }

        try {
            //call job/subjob with an existing context, like: --context=production. if without this parameter, there will use the default context instead.
            java.io.InputStream inContext = IngestRecords_Tokenization.class.getClassLoader().getResourceAsStream("upi_process/ingestrecords_tokenization_0_1/contexts/" + contextStr + ".properties");
            if (inContext == null) {
                inContext = IngestRecords_Tokenization.class.getClassLoader().getResourceAsStream("config/contexts/" + contextStr + ".properties");
            }
            if (inContext != null) {
                //defaultProps is in order to keep the original context value
                if(context != null && context.isEmpty()) {
	                defaultProps.load(inContext);
	                context = new ContextProperties(defaultProps);
                }
                
                inContext.close();
            } else if (!isDefaultContext) {
                //print info and job continue to run, for case: context_param is not empty.
                System.err.println("Could not find the context " + contextStr);
            }

            if(!context_param.isEmpty()) {
                context.putAll(context_param);
				//set types for params from parentJobs
				for (Object key: context_param.keySet()){
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
            }
            class ContextProcessing {
                private void processContext_0() {
                        context.setContextType("filename", "id_String");
                            context.filename=(String) context.getProperty("filename");
                        context.setContextType("key_store_password", "id_Password");
                            String pwd_key_store_password_value = context.getProperty("key_store_password");
                            context.key_store_password = null;
                            if(pwd_key_store_password_value!=null) {
                                if(context_param.containsKey("key_store_password")) {//no need to decrypt if it come from program argument or parent job runtime
                                    context.key_store_password = pwd_key_store_password_value;
                                } else if (!pwd_key_store_password_value.isEmpty()) {
                                    try {
                                        context.key_store_password = routines.system.PasswordEncryptUtil.decryptPassword(pwd_key_store_password_value);
                                        context.put("key_store_password",context.key_store_password);
                                    } catch (java.lang.RuntimeException e) {
                                        //do nothing
                                    }
                                }
                            }
                        context.setContextType("jsonfile_after", "id_Directory");
                            context.jsonfile_after=(String) context.getProperty("jsonfile_after");
                        context.setContextType("location", "id_String");
                            context.location=(String) context.getProperty("location");
                        context.setContextType("output", "id_String");
                            context.output=(String) context.getProperty("output");
                } 
                public void processAllContext() {
                        processContext_0();
                }
            }

            new ContextProcessing().processAllContext();
        } catch (java.io.IOException ie) {
            System.err.println("Could not load context "+contextStr);
            ie.printStackTrace();
        }

        // get context value from parent directly
        if (parentContextMap != null && !parentContextMap.isEmpty()) {if (parentContextMap.containsKey("filename")) {
                context.filename = (String) parentContextMap.get("filename");
            }if (parentContextMap.containsKey("key_store_password")) {
                context.key_store_password = (java.lang.String) parentContextMap.get("key_store_password");
            }if (parentContextMap.containsKey("jsonfile_after")) {
                context.jsonfile_after = (String) parentContextMap.get("jsonfile_after");
            }if (parentContextMap.containsKey("location")) {
                context.location = (String) parentContextMap.get("location");
            }if (parentContextMap.containsKey("output")) {
                context.output = (String) parentContextMap.get("output");
            }
        }

        //Resume: init the resumeUtil
        resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
        resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
        resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
			parametersToEncrypt.add("key_store_password");
        //Resume: jobStart
        resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,parametersToEncrypt));

if(execStat) {
    try {
        runStat.openSocket(!isChildJob);
        runStat.setAllPID(rootPid, fatherPid, pid, jobName);
        runStat.startThreadStat(clientHost, portStats);
        runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
    } catch (java.io.IOException ioException) {
        ioException.printStackTrace();
    }
}



	
	    java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
	    globalMap.put("concurrentHashMap", concurrentHashMap);
	

    long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    long endUsedMemory = 0;
    long end = 0;

    startTime = System.currentTimeMillis();




this.globalResumeTicket = true;//to run tPreJob

try {
errorCode = null;tPrejob_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tPrejob_1) {
globalMap.put("tPrejob_1_SUBPROCESS_STATE", -1);

e_tPrejob_1.printStackTrace();

}


		if(enableLogStash) {
	        talendJobLog.addJobStartMessage();
	        try {
	            talendJobLogProcess(globalMap);
	        } catch (java.lang.Exception e) {
	            e.printStackTrace();
	        }
        }

this.globalResumeTicket = false;//to run others jobs

try {
errorCode = null;tFileInputDelimited_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tFileInputDelimited_1) {
globalMap.put("tFileInputDelimited_1_SUBPROCESS_STATE", -1);

e_tFileInputDelimited_1.printStackTrace();

}

this.globalResumeTicket = true;//to run tPostJob

try {
errorCode = null;tPostjob_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tPostjob_1) {
globalMap.put("tPostjob_1_SUBPROCESS_STATE", -1);

e_tPostjob_1.printStackTrace();

}



        end = System.currentTimeMillis();

        if (watch) {
            System.out.println((end-startTime)+" milliseconds");
        }

        endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        if (false) {
            System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : IngestRecords_Tokenization");
        }
		if(enableLogStash) {
	        talendJobLog.addJobEndMessage(startTime, end, status);
	        try {
	            talendJobLogProcess(globalMap);
	        } catch (java.lang.Exception e) {
	            e.printStackTrace();
	        }
        }



if (execStat) {
    runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
    runStat.stopThreadStat();
}
    int returnCode = 0;
    if(errorCode == null) {
         returnCode = status != null && status.equals("failure") ? 1 : 0;
    } else {
         returnCode = errorCode.intValue();
    }
    resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","" + returnCode,"","","");

    return returnCode;

  }

    // only for OSGi env
    public void destroy() {
    closeSqlDbConnections();


    }



    private void closeSqlDbConnections() {
        try {
            Object obj_conn;
            obj_conn = globalMap.remove("conn_tDBConnection_1");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
        } catch (java.lang.Exception e) {
        }
    }











    private java.util.Map<String, Object> getSharedConnections4REST() {
        java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();
            connections.put("conn_tDBConnection_1", globalMap.get("conn_tDBConnection_1"));







        return connections;
    }

    private void evalParam(String arg) {
        if (arg.startsWith("--resuming_logs_dir_path")) {
            resuming_logs_dir_path = arg.substring(25);
        } else if (arg.startsWith("--resuming_checkpoint_path")) {
            resuming_checkpoint_path = arg.substring(27);
        } else if (arg.startsWith("--parent_part_launcher")) {
            parent_part_launcher = arg.substring(23);
        } else if (arg.startsWith("--watch")) {
            watch = true;
        } else if (arg.startsWith("--stat_port=")) {
            String portStatsStr = arg.substring(12);
            if (portStatsStr != null && !portStatsStr.equals("null")) {
                portStats = Integer.parseInt(portStatsStr);
            }
        } else if (arg.startsWith("--trace_port=")) {
            portTraces = Integer.parseInt(arg.substring(13));
        } else if (arg.startsWith("--client_host=")) {
            clientHost = arg.substring(14);
        } else if (arg.startsWith("--context=")) {
            contextStr = arg.substring(10);
            isDefaultContext = false;
        } else if (arg.startsWith("--father_pid=")) {
            fatherPid = arg.substring(13);
        } else if (arg.startsWith("--root_pid=")) {
            rootPid = arg.substring(11);
        } else if (arg.startsWith("--father_node=")) {
            fatherNode = arg.substring(14);
        } else if (arg.startsWith("--pid=")) {
            pid = arg.substring(6);
        } else if (arg.startsWith("--context_type")) {
            String keyValue = arg.substring(15);
			int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.setContextType(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }

            }

		} else if (arg.startsWith("--context_param")) {
            String keyValue = arg.substring(16);
            int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }
            }
        } else if (arg.startsWith("--log4jLevel=")) {
            log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--monitoring") && arg.contains("=")) {//for trunjob call
		    final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
    }
    
    private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

    private final String[][] escapeChars = {
        {"\\\\","\\"},{"\\n","\n"},{"\\'","\'"},{"\\r","\r"},
        {"\\f","\f"},{"\\b","\b"},{"\\t","\t"}
        };
    private String replaceEscapeChars (String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0],currIndex);
				if (index>=0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0], strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
    }

    public Integer getErrorCode() {
        return errorCode;
    }


    public String getStatus() {
        return status;
    }

    ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 *     309672 characters generated by Talend Data Management Platform 
 *     on the September 8, 2020 11:42:35 AM EDT
 ************************************************************************************************/